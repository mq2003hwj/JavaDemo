CREATE VIEW dbo.ViewSellerProduct
AS
SELECT     TOP (100) PERCENT dbo.Ymt_Products.sProductId, dbo.Ymt_Products.sProduct, dbo.Ymt_Pictures.sUrl, dbo.Ymt_Catalogs.iUserId, dbo.Ymt_Catalogs.sUser, 
                      dbo.Ymt_Products.iAttention, dbo.Ymt_Products.iBrandId
FROM         dbo.Ymt_Products INNER JOIN
                      dbo.Ymt_Catalogs ON dbo.Ymt_Products.sProductId = dbo.Ymt_Catalogs.sProductId LEFT OUTER JOIN
                      dbo.Ymt_Pictures ON dbo.Ymt_Products.sProductId = dbo.Ymt_Pictures.sKey
ORDER BY dbo.Ymt_Products.iAttention DESC
