CREATE PROCEDURE [dbo].[spGetSaleInfo]
	@sellerId int,		   --卖家Id
	@orderStatus varchar(50),  --订单状态枚举（多个状态，按逗号分隔）
	@minOrderTime date,		   --订单时间区域最小值
	@maxOrderTime date		   --订单时间区域最大值
AS

return 0

BEGIN


	SET NOCOUNT ON;
	
	declare @needUpdateTime datetime  
	
	set @needUpdateTime = DATEADD(HOUR, -1, GETDATE()) --更新1个小时以上的数据
	
	--需要统计的相关订单状态
	select CONVERT(int, col) iStatus into #temp_orderStatus from dbo.Split(@orderStatus, ',') where col <> ''
	
	--需要统计的相关订单信息
	select iOrderId OrderId , dPaidTime PaidTime, iDistributor Distributor, iTradingStatus OrderStatus into #temp_orders from Ymt_Orders where iDistributor > 0 and iBuyerId = @sellerId and dPaidTime >= @minOrderTime and dPaidTime <= @maxOrderTime and exists 
(select #temp_orderStatus.iStatus from #temp_orderStatus where iTradingStatus = iStatus)
	
	--需要统计的相关渠道
	select distinct Distributor into #temp_distributors from #temp_orders 
	
	--需要统计的记录
	select distinct CAST(PaidTime as DATE) StatisticsDate, Distributor, OrderStatus into #temp_statistics from #temp_orders
	
	select Sum(iAmount * ISNULL(fOriginalPrice, 0)) fProductPrice, MIN(sCatalogId) sCatalogId, iOrderId into #temp_orderinfo  from Ymt_OrderInfo o, #temp_orders t
		where o.iOrderId = t.OrderId group by o.iOrderId
	
	--插入需要统计的记录
	insert Ymt_StatisticsOrderInfo (iSellerId, iDistributor, iOrderStatus, dStatisticsDate, dLastUpdateTime, iOrderAmount, iProductAmount, fProductPrice, fOrderDiscount, fFreight, fOrderPirce)
	select @sellerId, t.Distributor, t.OrderStatus, t.StatisticsDate, '2010-01-01', 0, 0, 0, 0, 0, 0
	from #temp_statistics t
	where not exists(select * from Ymt_StatisticsOrderInfo st where st.iSellerId = @sellerId and t.StatisticsDate = st.dStatisticsDate and t.OrderStatus = st.iOrderStatus and t.Distributor = st.iDistributor)
	
	insert Ymt_StatisticsOrderPayment (iSellerId, iDistributor, iOrderStatus, dStatisticsDate, dLastUpdateTime, fPayableBillFee, fPaidBillFee, fPayableCommissionFee, fPaidCommissionFee, fPayableQuickTurnoverFee, fPaidQuickTurnoverFee)
	select @sellerId, t.Distributor, t.OrderStatus, t.StatisticsDate, '2010-01-01', 0, 0, 0, 0, 0, 0
	from #temp_statistics t
	where not exists(select * from Ymt_StatisticsOrderPayment st where st.iSellerId = @sellerId and t.StatisticsDate = st.dStatisticsDate and t.OrderStatus = st.iOrderStatus and t.Distributor = st.iDistributor)
	
	insert Ymt_StatisticsOrderState (iSellerId, iDistributor, iOrderStatus, dStatisticsDate, dLastUpdateTime, fRefundedAmount, fPaidAmount, fPostPaidAmount, fReceivableAmount, fReceivedAmount)
	select @sellerId, t.Distributor, t.OrderStatus, t.StatisticsDate, '2010-01-01', 0, 0, 0, 0, 0
	from #temp_statistics t
	where not exists(select * from Ymt_StatisticsOrderState st where st.iSellerId = @sellerId and t.StatisticsDate = st.dStatisticsDate and t.OrderStatus = st.iOrderStatus and t.Distributor = st.iDistributor)

	
	
	--更新已有数据
	update Ymt_StatisticsOrderInfo
	set
		 iOrderAmount = ISNULL((select COUNT(*) from #temp_orders where iSellerId = @sellerId and PaidTime >= dStatisticsDate and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor), 0),
		 iProductAmount = ISNULL((select SUM(iAmount) from Ymt_OrderInfo where iSellerId = @sellerId and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate and PaidTime < DATEADD(DAY, 1, dStatisticsDate) 
		 and OrderStatus = iOrderStatus and iDistributor = Distributor)),0),
		 fProductPrice = ISNULL((select sum(case when (i.sCatalogId is null) then (o.fPaidAmountOfCash + o.fPaidAmountOfCoupon + o.fPaidAmountOfGift) when (i.sCatalogId is not null) then i.fProductPrice end) from Ymt_OrderState o, #temp_orderinfo i 
		 where o.iOrderId = i.iOrderId and exists (select Orderid from #temp_orders where o.iOrderId = OrderId and PaidTime >= dStatisticsDate and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor)),0),
		 fOrderDiscount = ISNULL((select SUM(fOrderDiscount + s.fPostPadiAmountOfCoupon + s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift) from Ymt_Orders o, Ymt_OrderState s where o.iOrderId = s.iOrderId and iSellerId = @sellerId and o.iBuyerId = @sellerId
		  and o.dPaidTime >= dStatisticsDate and o.dPaidTime < DATEADD(DAY, 1, dStatisticsDate) and iTradingStatus = iOrderStatus and Ymt_StatisticsOrderInfo.iDistributor = o.iDistributor), 0),
		 fFreight = ISNULL((select SUM(fFreight) from Ymt_Orders o  where iSellerId = @sellerId and o.iBuyerId = @sellerId and o.dPaidTime >= dStatisticsDate and o.dPaidTime < DATEADD(DAY, 1, dStatisticsDate) 
		 and iTradingStatus = iOrderStatus and Ymt_StatisticsOrderInfo.iDistributor = o.iDistributor), 0),
		 fOrderPirce = ISNULL((select SUM(o.fOrderPrice + o.fOrderDiscount + o.fFreight + s.fPostPadiAmountOfCoupon + s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift) from Ymt_Orders o, Ymt_OrderState s 
		 where o.iOrderId = s.iOrderId and iSellerId = @sellerId and iBuyerId = @sellerId and o.dPaidTime >= dStatisticsDate and o.dPaidTime < DATEADD(DAY, 1, dStatisticsDate) and iTradingStatus = iOrderStatus 
		 and Ymt_StatisticsOrderInfo.iDistributor = o.iDistributor), 0),
		 dLastUpdateTime = GETDATE()
	where iSellerId = @sellerId and dStatisticsDate >= @minOrderTime and dStatisticsDate < @maxOrderTime and exists (select #temp_orderStatus.iStatus from #temp_orderStatus where iOrderStatus = iStatus) 
	and exists (select Distributor from #temp_distributors where Distributor = iDistributor)
		 and dLastUpdateTime < @needUpdateTime
	
		 
	update Ymt_StatisticsOrderState
	set
		fRefundedAmount = ISNULL((select SUM(s.fRefundedAmountOfCash + s.fRefundedAmountOfCoupon + s.fRefundedAmountOfGift) from Ymt_OrderState s where iSellerId = @sellerId 
			and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor)), 0),	
		fPaidAmount = ISNULL((select SUM(s.fPaidAmountOfCash + s.fPaidAmountOfCoupon + s.fPaidAmountOfGift) from Ymt_OrderState s where iSellerId = @sellerId 
			and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor)), 0),	
		fPostPaidAmount = ISNULL((select SUM(s.fPostPadiAmountOfCoupon + s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift) from Ymt_OrderState s where iSellerId = @sellerId 
			and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor)), 0),	
		fReceivableAmount = ISNULL((select SUM(s.fPostPadiAmountOfCoupon + s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift + s.fPaidAmountOfCash + s.fPaidAmountOfCoupon + s.fPaidAmountOfGift - s.fRefundedAmountOfCash - 
			s.fRefundedAmountOfCoupon -s.fRefundedAmountOfGift - fQuickTurnoverAmount - fNeedCommissionFee) from Ymt_OrderState s where iSellerId = @sellerId 
			and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor and OrderStatus <> 4)), 0),	
		fReceivedAmount = ISNULL((select SUM(s.fPostPadiAmountOfCoupon + s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift + s.fPaidAmountOfCash + s.fPaidAmountOfCoupon + s.fPaidAmountOfGift 
		- s.fRefundedAmountOfCash - s.fRefundedAmountOfCoupon -s.fRefundedAmountOfGift - fQuickTurnoverAmount - fCommissionFee) from Ymt_OrderState s where iSellerId = @sellerId and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate 
			and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor and OrderStatus = 4)), 0),	
		dLastUpdateTime = GETDATE()
	where iSellerId = @sellerId and dStatisticsDate >= @minOrderTime and dStatisticsDate < @maxOrderTime and exists (select #temp_orderStatus.iStatus from #temp_orderStatus where iOrderStatus = iStatus) 
		and exists (select Distributor from #temp_distributors where Distributor = iDistributor)
		 and dLastUpdateTime < @needUpdateTime
		 
		 
    update Ymt_StatisticsOrderPayment
    set 
		fPayableBillFee = 0,
		fPaidBillFee = 0,
		fPayableCommissionFee = ISNULL((select SUM(s.fNeedCommissionFee) from Ymt_OrderState s where iSellerId = @sellerId and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate 
		and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor) and iOrderStatus <> 4), 0),	
		fPaidCommissionFee = ISNULL((select SUM(s.fCommissionFee) from Ymt_OrderState s where iSellerId = @sellerId and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate 
		and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor)), 0),	
		fPayableQuickTurnoverFee = 0,
		fPaidQuickTurnoverFee = ISNULL((select SUM(s.fQuickTurnoverAmount) from Ymt_OrderState s where iSellerId = @sellerId and exists (select Orderid from #temp_orders where iOrderId = OrderId and PaidTime >= dStatisticsDate 
		and PaidTime < DATEADD(DAY, 1, dStatisticsDate) and OrderStatus = iOrderStatus and iDistributor = Distributor)), 0),	
		dLastUpdateTime = GETDATE()
	where iSellerId = @sellerId and dStatisticsDate >= @minOrderTime and dStatisticsDate < @maxOrderTime and exists (select #temp_orderStatus.iStatus from #temp_orderStatus where iOrderStatus = iStatus) 
	and exists (select Distributor from #temp_distributors where Distributor = iDistributor)
		 and dLastUpdateTime < @needUpdateTime
	
	
	--查询结果
	select so.iDistributor Distributor,								--	渠道
		   SUM(so.iOrderAmount) OrderAmount,						--	订单数
		   SUM(so.iProductAmount) ProductAmount,					--	商品数
		   SUM(so.fProductPrice) ProductPrice,						-- 商品金额
		   SUM(so.fOrderDiscount) DiscountPrice,					--	修改价格
		   SUM(so.fFreight) FreightPrice,							--	订单运费
		   SUM(ss.fRefundedAmount) RefundFee,						--	退款金额	
		   SUM(sp.fPayableQuickTurnoverFee) PayableFee,				--	应付费用(快周)
		   SUM(sp.fPaidQuickTurnoverFee) PaidFee,					--	已付费用(快周)
		   SUM(sp.fPayableCommissionFee) PayableCommissionFee,		--  应付佣金
		   SUM(sp.fPaidCommissionFee) PaidCommissionFee,			--	已付佣金
		   SUM(ss.fReceivableAmount) ReceivableFee,					--	应收款
		   SUM(ss.fReceivedAmount) ReceivedFee						--	已收款
	from Ymt_StatisticsOrderInfo so, Ymt_StatisticsOrderPayment sp, Ymt_StatisticsOrderState ss
	where so.iSellerId = @sellerId and exists (select * from #temp_orderStatus where #temp_orderStatus.iStatus = so.iOrderStatus) and so.dStatisticsDate >= @minOrderTime and so.dStatisticsDate < @maxOrderTime
		and so.iSellerId = sp.iSellerId and so.iDistributor = sp.iDistributor and so.iOrderStatus = sp.iOrderStatus and so.dStatisticsDate = sp.dStatisticsDate
		and so.iSellerId = ss.iSellerId and so.iDistributor = ss.iDistributor and so.iOrderStatus = ss.iOrderStatus and so.dStatisticsDate = ss.dStatisticsDate
	group by so.iDistributor 
	
		
	--删除临时表
	drop table #temp_distributors
	drop table #temp_orderStatus
	drop table #temp_orders
	drop table #temp_statistics
	drop table #temp_orderinfo

END

