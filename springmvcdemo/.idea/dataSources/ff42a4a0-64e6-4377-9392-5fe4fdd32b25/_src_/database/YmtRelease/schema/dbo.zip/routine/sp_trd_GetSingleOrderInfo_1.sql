

-- =============================================            



-- Author:  fanwei , zhangyifan        



-- Create date: 2015-9-16



-- Description: 交易服务SP     



-- Update date: 2016-06-24



-- 20160615：商品信息添加fProductOriginalPrice by dengpeng@ymatou.com



-- 20160616：添加RemarkLevel by dengpeng@ymatou.com



-- 20160624：添加促销活动相关数据信息 by dengpeng@ymatou.com



-- 20160628：订单商品详细信息追加:ReducedAmount , bSupportRtnWithoutReason



-- 20160705：添加fFreighFree



-- 20160725：添加业务类型BusynessType



-- 20160805：添加新老客订单字段bNewSellerOrder,bNewCustomerOrder



-- 20161012：添加首单字段bIsFirstOrder



-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetSingleOrderInfo_1]
  @userId  INT,
  @orderId INT

AS

--------------process--------------



IF @userId = -1
  BEGIN

    SELECT @userId = iUserId
    FROM ymt_orders( NOLOCK )
    WHERE iorderid = @orderId
  END

SELECT

  o.[iOrderId],



  o.[iUserId],



  o.[iBuyerId],



  o.[sMarkId],



  o.[dAddTime],



  o.[fOrderPrice],



  o.[fOrderDiscount],



  o.[fFreight],



  o.[fDiscount],



  o.[iTradingId],



  o.[iOperate],



  o.[dOperateExpireTime],



  o.[sAddress],



  o.[sPostCode],



  o.[sReceivePerson],



  o.[sPhone],



  o.[sTelephone],



  o.[sQQ],



  o.[sEmail],



  o.[sLeaveWord],



  o.[iUnfreezeStatus],



  o.[dDispathTime],



  o.[iTopicId],



  o.[sTitle],



  o.[iReplyTopicWhenOrderPaid],



  o.[bPaidInFull],



  o.[fUseGiftAmount],



  o.[sCouponCode],



  o.[CouponValue],



  o.[iCouponType],



  o.[dPaidTime],



  o.[dApplyPostPayTime],



  o.[dPostPaidTime],



  o.[dConfirmedTime],



  o.[dChangeAddressTime],



  o.[iDistributor],



  o.[sThirdOrderId],



  o.[iType],



  o.[fOldFreight],



  o.[dDiscountTime],



  o.[fOldDiscount],



  o.[fAutoCancelOrderHours],



  o.[dCancelTime],



  o.[bShangouOrder],



  o.[sBuyerLoginId],



  o.[sBuyerLoginEmail],



  o.[sSellerLoginId],



  o.[sSellerLoginEmail],



  o.[iIsMerchant],



  o.[sBuyerNickName],



  o.[fTotalPrice],



  o.[fUseFreeCardAmount],



  o.[sHostRef],



  o.[bIncludeActivityProducts],



  o.[bShippedByXlobo],



  o.[dAcceptTime],



  o.[sCurType],



  o.[bCanLocalReturn],



  o.[bApplyLocalReturn],



  o.[dApplyLocalReturnTime],



  o.[iRiskVerifiedStatus],



  o.[dLastUpdateTime],



  o.[iThirdPartyRefundStatus],



  o.[iCouponChannel],



  o.[iSalesRefundStatus],



  o.[bDomesticDelivered],



  CASE WHEN r.iProcessStatus IS NULL



    THEN o.iTradingStatus



  WHEN r.iProcessStatus = 0



    THEN 3



  ELSE o.iTradingStatus END    AS iTradingStatus,



  (SELECT TOP 1 sReason



   FROM Ymt_OrderReason( NOLOCK )



   WHERE iOrderId = @orderId)  AS sReason,



   o.[sYmtCouponCode],



   o.[sSellerCouponCode],



   o.[fYmtCouponAmount],



   o.[fSellerCouponAmount],



   o.[fPayableAmount],

   o.[iMainOrderId],
	 o.[bPreSale],
	 o.[bCanEvaluate],


   [RealPay].*,



   [BusynessTypes] = (select cast(BusynessType as varchar(10)) + ',' from [dbo].[Ymt_OrderFrozenDetail] as [frozen] where [frozen].[OrderId]=o.[iOrderId] and [frozen].[IsFrozen]=1 for xml path('') )



FROM Ymt_Orders( NOLOCK ) o



  LEFT JOIN Temp_ReceivedOrders20151109( NOLOCK ) r ON o.iOrderId = r.iOrderId

  outer apply (

	select

		[RealSettlementAmountOfCoupon] = sum(case [t3].[SalesRefundStatus] when 10 then [SettlementAmountOfCoupon] else 0 end ),
		[TotalSalesRefundAmount] = sum(t3.[RefundAmount])


	from [dbo].[Ymt_RefundBill] as t3 with(nolock) where t3.[OrderId] = o.[iOrderId]



  ) as [RealPay]



WHERE o.iOrderId = @orderId AND (o.iUserId = @userId OR o.iBuyerId = @userId)







IF (@@ROWCOUNT = 0)



  RETURN;







--print 'ymt_orderext';



SELECT



  iOrderId,



  iOrderType,



  sOrderSource,



  bIsNeedUploadIdCard,



  bHaveUploadedIdCard,



  bNewSellerOrder,



  bNewCustomerOrder,



  bIsFirstOrder



FROM Ymt_OrderExt( NOLOCK )



WHERE iOrderId = @orderId







--print 'ymt_creditdetail'   



--获取评价列表  
select * from ymt_creditdetail( nolock ) where 1=0

--print 'ymt_o_ordernote'



--获取备注列表  

SELECT



  iOrderId,



  sContent,



  iRemarkLevel



FROM Ymt_O_OrderNote( NOLOCK )



WHERE iuserid = @userId AND iorderid = @orderId







--print 'ymt_orderstate'



--获取订单金额详情列表  Ymt_OrderState



SELECT *
FROM Ymt_OrderState( NOLOCK )
WHERE iorderid = @orderId







--print 'ymt_orderpostpay'



--获取订单补款列表  



SELECT *

FROM Ymt_OrderPostPay( NOLOCK )

WHERE iorderid = @orderId


--获取订单商品详情列表

--print 'ymt_orderinfo'


SELECT
  i.*,
  e.sOrderInfoId AS sOrderInfoExtId,
  e.iActivityId,
  e.iActivityTemplateId,
  r.RefundBillNo,
  s.[PromotionId] , s.[PromotionType] , s.[PromotionName] , s.[MatchCondition] , s.[PromotionValue],s.[ReducedAmount]

FROM Ymt_OrderInfo as i with( NOLOCK )

LEFT JOIN Ymt_OrderInfoExt as e with(nolock) on i.sOrderInfoId = e.sOrderInfoId

LEFT JOIN Ymt_RefundProduct as r with(nolock) on i.sOrderInfoId = r.OrderInfoId

left join [dbo].[Ymt_SellerPromotion] as s with(nolock) on i.[iOrderId] = s.[OrderId] and i.[sOrderInfoId] = s.[OrderInfoId]

WHERE i.iOrderId = @orderId

--print 'ymt_ordersummary'



--获取订单物流信息  



SELECT

  iOrderId,

  iBillType,

  sSummary



FROM Ymt_OrderSummary( NOLOCK )



WHERE iorderid = @orderId




--print 'ymt_order_frozen'



--获取订单冻结信息  



SELECT *

FROM Ymt_Order_Frozen( NOLOCK )

WHERE iorderid = @orderId



IF (EXISTS(SELECT TOP 1



             item.iOrderId,



             item.iTradingId



           FROM Ymt_TradingItem( NOLOCK ) item



             JOIN Ymt_TradingInfo( NOLOCK ) info ON item.iTradingId = info.iTradingId



           WHERE iorderid = @orderId AND info.iTradingStatus = 2))



  BEGIN



    SELECT TOP 1



      item.iOrderId,



      item.iTradingId



    FROM Ymt_TradingItem( NOLOCK ) item



      JOIN Ymt_TradingInfo( NOLOCK ) info



        ON item.iTradingId = info.iTradingId



    WHERE iorderid = @orderId



          AND info.iTradingStatus = 2



  END



ELSE
  BEGIN
    SELECT TOP 1
      iOrderId,
      iTradingId
    FROM Ymt_TradingItem( NOLOCK )
    WHERE iorderid = @orderId
    ORDER BY dUpdateTime DESC
  END


 --DECLARE @orderToBills TABLE(iOrderId INT NOT NULL, sBillId VARCHAR(36) NOT NULL)

 --print 'ymt_ordertobill'
 SELECT * FROM Ymt_OrderToBill( NOLOCK ) WHERE 1=0


--print 'ymt_bill'

--获取订单账单信息  

 SELECT * FROM Ymt_Bill( NOLOCK ) where 1=0