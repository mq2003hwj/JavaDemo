-- =============================================
-- Author:		<dengpeng@ymatou.com>
-- Create date: <2016-07-18>
-- Description:	<订单状态统计数据>
-- Last-modified:2016-07-19
-- =============================================
CREATE procedure [dbo].[sp_trd_GetSellerOrderStatusCount]
	@SellerId int,
	@OrderStatusXml xml = null,
	@AddBeginTime datetime = null,
	@AddEndTime datetime = null
as

-- 订单状态条件特定值转换说明：
-- 状态17：分全款与定金，定金部分[bPaidInFull]=1说明已付全款，反之为101
-- 状态2：跟风控有关，当[iRiskVerifiedStatus]=1说明还要付款
-- 即分组统计跟 订单状态，全款定金，已付全款，风控相关

create table #statistics ([iTradingStatus] int not null,[bShangouOrder] bit not null,[num] int not null, [bPaidInFull] bit not null)

--统计当前卖家下所有订单
if @AddBeginTime is null and @AddEndTime is null begin
	insert into #statistics([iTradingStatus], [bShangouOrder], [num], [bPaidInFull])
	select [iTradingStatus] = case 
			when [iTradingStatus] = 17 and [bPaidInFull] = 0 then 101
			when [iTradingStatus] = 2 and [iRiskVerifiedStatus] = 1 and [bPaidInFull] =0 then 1
			else [iTradingStatus] end,
		[bShangouOrder] = case 
			when [iTradingStatus] in (12,13,18) then 0
			when [iTradingStatus] = 17 and [bShangouOrder] = 1 and [bPaidInFull] = 1 then 0
			else 0 end, 
		count(1)  ,[bPaidInFull]
	from dbo.Ymt_Orders with(nolock) 
	where [iBuyerId] = @SellerId
	group by [iTradingStatus],[bShangouOrder],[bPaidInFull],[iRiskVerifiedStatus]

end 
--通过下单时间范围来统计
else begin
	insert into #statistics([iTradingStatus], [bShangouOrder], [num], [bPaidInFull])
	select [iTradingStatus] = case 
			when [iTradingStatus] = 17 and [bPaidInFull] = 0 then 101
			when [iTradingStatus] = 2 and [iRiskVerifiedStatus] = 1 and [bPaidInFull] =0 then 1
			else [iTradingStatus] end,
		[bShangouOrder] = case 
			when [iTradingStatus] in (12,13,18) then 0
			when [iTradingStatus] = 17 and [bShangouOrder] = 1 and [bPaidInFull] = 1 then 0
			else 0 end, 
		count(1)  ,[bPaidInFull]
	from dbo.Ymt_Orders with(nolock) 
	where [iBuyerId] = @SellerId and [dAddTime] >= @AddBeginTime and [dAddTime] < @AddEndTime
	group by [iTradingStatus],[bShangouOrder],[bPaidInFull],[iRiskVerifiedStatus]

end

select [iTradingStatus], num=sum([num]) into #result
from #statistics group by [iTradingStatus],[bShangouOrder]


if(@OrderStatusXml is null) begin
	select [iTradingStatus],[num] from #result
	union
	select 0, sum([num]) from #statistics
end

else begin
	select t2.[iTradingStatus],t2.[num] from @orderStatusXml.nodes('/root/x') as tbl(col)
	inner join #result as t2 on tbl.col.value('@s','int') = t2.[iTradingStatus]
	union
	select 0, sum([num]) from #statistics
end

drop table #result
drop table #statistics

