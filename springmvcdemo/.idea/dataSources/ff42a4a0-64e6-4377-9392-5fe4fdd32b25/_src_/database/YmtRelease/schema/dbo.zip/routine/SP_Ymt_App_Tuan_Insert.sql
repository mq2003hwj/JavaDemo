
-- =============================================
-- Author:		张建涛
-- Create date: 2015-6-14
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Ymt_App_Tuan_Insert]
	@GroupCode varchar(5),
	@TopicId int,
	@EndDate datetime,
	@CreatedByUserId int
AS
BEGIN
	declare @tuanCount int =(select count(1) from Ymt_App_Tuan where iTopicId=@TopicId and sGroupCode=@GroupCode)
	
	if (@tuanCount=0)
	begin
	   INSERT INTO Ymt_APP_Tuan
       ([sGroupCode],[iTopicId],[dStartDate],[dEndDate],[sStatus],[iCreatedByUserId],[dCreatedDate]) 
	   VALUES
       (@GroupCode,@TopicId,GETDATE(),@EndDate,1,@CreatedByUserId,GETDATE())
	end
END

