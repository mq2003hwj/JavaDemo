-- =============================================
-- Author:	<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetCatalogs]
	@area varchar(36),
	@catalogIdXml xml,-- = '<root><x s=''d1db9d45-684b-4beb-a459-91ee0dabeccc'' /></root>'
	@now datetime 
AS
BEGIN
	
	SET NOCOUNT ON;

    DECLARE @activityStockNum INT;
	DECLARE @singleCatalogId varchar(36)
	DECLARE @singleProductId varchar(36);
	declare @TemplateIds table(templateId varchar(36));
	
	select @singleCatalogId = tbl.col.value('@s', 'varchar(36)') from @catalogIdXml.nodes('/root/x') tbl(col)

	IF @@ROWCOUNT = 1 Begin
		select @singleProductId = sProductId from ymt_catalogs with(nolock) where scatalogid = @singleCatalogId

		SET @activityStockNum = (SELECT TOP 1 b.iStockNum from Ymt_ProductActivityStock (nolock) b
			LEFT JOIN dbo.Ymt_ProductsInActivity c WITH(NOLOCK) ON b.sProductId = c.sProductId AND b.iProductInActivityId = c.iProductInActivityId
			WHERE c.dEndTime > @now AND c.dBeginTime < @now AND b.sProductId = @singleProductId AND b.sCatalogID = @singleCatalogId);

		--Catalogs
		SELECT sCatalogId, sProductId, fQuotePrice, iAction, iNum, ISNULL(@activityStockNum, 0) AS iActivityStockNum from Ymt_Catalogs(nolock) 
		WHERE sCatalogId = @singleCatalogId

		--Products
		select sProductId, iCatalogStatus, deliveryTemplateId, iCatalogType, validStart, validEnd, iAction, iLimitNum, dLimitNumStartTime, iBondedArea, fFlight, fWeight from Ymt_Products(nolock) where sProductId = @singleProductId

		--Activitys
		select
		---Ymt_ProductsInActivity
		p.sProductId, p.iProductInActivityId, p.fPromotion, p.fPromotion1, p.fPromotion2, p.fPromotion3, p.iPromotionType,p.dBeginTime,p.dEndTime,
		---Ymt_Activity
		a.iActivityId, a.sName,a.iLimitNum,
		---iActivityTemplateId
		t.iActivityTemplateId, t.bOnly4VIP, t.bGiftAvail4OrderDeduct, t.bGiftAvail4Reward, t.bCouponAvail4OrderDeduct,
		---Ymt_ProductsSubsidy
		s.iProductsSubsidyId, s.fSubsidyPrice, s.iSubsidyType, ISNULL((SELECT SUM(iStockNum) FROM dbo.Ymt_ProductActivityStock WITH(NOLOCK) WHERE iProductInActivityId = p.iProductInActivityId AND sProductID= p.sProductId AND iAction > -1),0) AS iActivityStock
		from Ymt_ProductsInActivity(nolock) p 
		join Ymt_Activity(nolock) a on p.iStatus = 2
		and p.dBeginTime < @now and p.dEndTime > @now 
		and p.iActivityId = a.iActivityId
		and a.iAction = 1 and a.dBeginTime < @now and a.dEndTime > @now 
		left join dbo.Ymt_ActivityTemplate(nolock) t on
		a.iActivityTemplateId = t.iActivityTemplateId
		left join Ymt_ProductsSubsidy(nolock) s on
		p.iProductInActivityId = s.iProductInActivityId
		where p.sProductId = @singleProductId

		--Templates
		insert into @TemplateIds select deliveryTemplateId from Ymt_Products(nolock) where sProductId = @singleProductId and deliveryTemplateId is not null
		if @@ROWCOUNT > 0
		begin
			select t.sId, t.sName, t.iTemplateType, t.iTemplateCategory, f.sDestination, f.fStartFee, f.fAddFee, f.iStartStandard, f.iAddStandard 
			from ymt_deliverytemplate(nolock) t
			join ymt_deliveryfee(nolock) f
			on t.sId = f.sDeliveryTemplateId
			where exists (select * from @TemplateIds where t.sId = templateId)
			and (f.sDestination like @area or f.sDestination = 'default')
			order by f.sDestination asc
		end
	end
	else
	begin
		declare @catalogIds table(id varchar(36))
		declare @tCatalogIDs table(catalogId varchar(36), productId varchar(36))
		--declare @TemplateIds table(templateId varchar(36))

		insert into @catalogIds select tbl.col.value('@s', 'varchar(36)') from @catalogIdXml.nodes('/root/x') tbl(col)
		insert into @tCatalogIDs select sCatalogId, sProductId from Ymt_Catalogs(nolock) where sCatalogId in (select id from @catalogIds)

		SET @activityStockNum = (SELECT TOP 1 b.iStockNum from Ymt_ProductActivityStock (nolock) b
		 LEFT JOIN dbo.Ymt_ProductsInActivity c WITH(NOLOCK) ON b.sProductId = c.sProductId AND b.iProductInActivityId = c.iProductInActivityId
		 WHERE c.dEndTime > @now AND c.dBeginTime < @now AND b.sProductId IN (select ProductId from @tCatalogIDs) AND b.sCatalogID in (select catalogId from @tCatalogIDs));

		--Catalogs
		SELECT sCatalogId, sProductId, fQuotePrice, iAction, iNum, ISNULL(@activityStockNum, 0) AS iActivityStockNum from Ymt_Catalogs(nolock) 
		WHERE sCatalogId IN (select catalogId from @tCatalogIDs)

		--Products
		select sProductId, iCatalogStatus, deliveryTemplateId, iCatalogType, validStart, validEnd, iAction, iLimitNum, dLimitNumStartTime, iBondedArea, fFlight, fWeight from Ymt_Products(nolock) where sProductId in (select productId from @tCatalogIDs)

		--Activitys
		select
		---Ymt_ProductsInActivity
		p.sProductId, p.iProductInActivityId, p.fPromotion, p.fPromotion1, p.fPromotion2, p.fPromotion3, p.iPromotionType,
		---Ymt_Activity
		a.iActivityId, a.sName,a.iLimitNum,
		---iActivityTemplateId
		t.iActivityTemplateId, t.bOnly4VIP, t.bGiftAvail4OrderDeduct, t.bGiftAvail4Reward, t.bCouponAvail4OrderDeduct,
		---Ymt_ProductsSubsidy
		s.iProductsSubsidyId, s.fSubsidyPrice, s.iSubsidyType, ISNULL((SELECT SUM(iStockNum) FROM dbo.Ymt_ProductActivityStock WITH(NOLOCK) WHERE iProductInActivityId = p.iProductInActivityId AND sProductID= p.sProductId AND iAction > -1),0) AS iActivityStock
		from Ymt_ProductsInActivity(nolock) p 
		join Ymt_Activity(nolock) a on p.iStatus = 2
		and p.dBeginTime < @now and p.dEndTime > @now 
		and p.iActivityId = a.iActivityId
		and a.iAction = 1 and a.dBeginTime < @now and a.dEndTime > @now 
		left join dbo.Ymt_ActivityTemplate(nolock) t on
		a.iActivityTemplateId = t.iActivityTemplateId
		left join Ymt_ProductsSubsidy(nolock) s on
		p.iProductInActivityId = s.iProductInActivityId
		where p.sProductId in (select productId from @tCatalogIDs)

		--Templates
		insert into @TemplateIds select deliveryTemplateId from Ymt_Products(nolock) where sProductId in (select productId from @tCatalogIDs) and deliveryTemplateId is not null
		if @@ROWCOUNT > 0
		begin
			select t.sId, t.sName, t.iTemplateType, t.iTemplateCategory, f.sDestination, f.fStartFee, f.fAddFee, f.iStartStandard, f.iAddStandard 
			from ymt_deliverytemplate(nolock) t
			join ymt_deliveryfee(nolock) f
			on t.sId = f.sDeliveryTemplateId
			where exists (select * from @TemplateIds where t.sId = templateId)
			and (f.sDestination like @area or f.sDestination = 'default')
			order by f.sDestination asc
		end
	end
END
