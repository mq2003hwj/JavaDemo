-- =============================================
-- Author:		adu	
-- Create date: 2013-12-19
-- Description:	获取活动下的产品列表信息
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetProductsByActivityId]
	@ActivityId int,
	@ProductNum int,
	@ProductId varchar(36) 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--SET TRANSACTION ISOLATION LEVEL READ COMMITTED
DECLARE @SQL nvarchar(3250)

if(@ProductId is null)
begin
	SET @SQL = N'SELECT top '+ CAST(@ProductNum AS VARCHAR(10))+' p.sProductId as ProductId,[t1].Earnest,[t1].GetPrice,p.validStart as AddTime,p.validEnd as ExpireTime,p.sProduct as Description,
	   dbo.GetProductPicUrlSplitJoint(p.sProductId) as ProductPics,p.iStockNum as StockNum, p.fFlight as Flight,
		[t2].CommentNum,p.iOrderIndex as OrderValue,p.bNoticeRisk as NoticeRisk,p.iTariffType as TariffType
		
		FROM dbo.Ymt_Products p with(nolock)
		INNER JOIN dbo.Ymt_ProductsInActivity pa with(nolock) ON p.sProductId = pa.sProductId 
		cross apply
		(
			select top 1 fEarnestPrice as Earnest,fQuotePrice as GetPrice from App_Catalog with(nolock)
			where App_Catalog.sProductId=p.sProductId
		) as [t1]
		 CROSS APPLY 
		(
			SELECT COUNT(iCommentId) as CommentNum
			FROM	dbo.App_Comment cm with(nolock)
			WHERE	cm.sProductId = p.sProductId
			
		) AS [t2]
		
	WHERE pa.iActivityId = ' + CAST(@ActivityId AS VARCHAR(10)) + ' and (GETDATE() between p.validStart and p.validEnd) and p.iAction>-1
	 order by p.iOrderIndex desc,p.dAddTime desc'
 end 
 else 
 begin
 
		SET @SQL = N'SELECT top '+ CAST(@ProductNum AS VARCHAR(10))+' p.sProductId as ProductId,[t1].Earnest,[t1].GetPrice,p.validStart as AddTime,p.validEnd as ExpireTime,p.sProduct as Description,
		   dbo.GetProductPicUrlSplitJoint(p.sProductId) as ProductPics,p.iStockNum as StockNum, p.fFlight as Flight,
			[t2].CommentNum,p.iOrderIndex as OrderValue,p.bNoticeRisk as NoticeRisk,p.iTariffType as TariffType
			,[t3].curOrderIndex  
			FROM dbo.Ymt_Products p with(nolock)
			INNER JOIN dbo.Ymt_ProductsInActivity as pa ON p.sProductId = pa.sProductId 
			cross apply
			(
				select top 1 fEarnestPrice as Earnest,fQuotePrice as GetPrice from App_Catalog with(nolock)
				where App_Catalog.sProductId=p.sProductId
			) as [t1]
			 CROSS APPLY 
			(
				SELECT COUNT(iCommentId) as CommentNum
				FROM	dbo.App_Comment cm with(nolock)
				WHERE	cm.sProductId = p.sProductId
				
			) AS [t2]
			CROSS APPLY 
			(
				SELECT iOrderIndex as curOrderIndex
				FROM	dbo.Ymt_Products with(nolock)
				WHERE	sProductId = '''+@ProductId + ''' 		
			) AS [t3]
		WHERE pa.iActivityId = ' + CAST(@ActivityId AS VARCHAR(10)) + ' and p.iOrderIndex<[t3].curOrderIndex and (GETDATE() between p.validStart and p.validEnd) and p.iAction>-1
		 order by p.iOrderIndex desc,p.dAddTime desc'
 end
--print(@SQL)
EXEC (@SQL)   
END
