
-- =============================================
-- Author:		Kevin
-- Create date: 2015-3-5
-- Description:	支持多币种，资金操作SP化，事务死锁的快速解决方案
-- =============================================
CREATE PROCEDURE [dbo].[spAccountFreezeChangeByCurrency]
	@userId		int,			--资金账号
	@amount		decimal(10, 2),	--金额
	@operator	varchar(50),	--资金科目
	@useage		varchar(50),	--付款凭据
	@memo		varchar(200),	--备注
	@currency		int = 1		--币种
AS
BEGIN
	--更新账户余额
	Update Ymt_AccountInfo Set fFreezeAmount = fFreezeAmount + @amount Where iUserId = @userId And iCurrencyType = @currency

	--账户资金流水
	Insert Into Ymt_AccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select NewId(), @amount, 1, iUserId, fBalance, fFreezeAmount - @amount, fAvailAmount, getdate(), @operator, @useage, @memo 
	From Ymt_AccountInfo with(rowlock)
	Where iUserId = @userId And iCurrencyType = @currency
END

