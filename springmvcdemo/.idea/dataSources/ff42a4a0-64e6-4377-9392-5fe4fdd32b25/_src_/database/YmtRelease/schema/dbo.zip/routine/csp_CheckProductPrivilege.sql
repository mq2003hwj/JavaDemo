-- =============================================
-- Author:		陈鹏煊
-- Create date: 2015年12月24日21:44:52
-- Description:	用于防止砍价团商品活动库存售罄时变成普通商品下单
-- =============================================
CREATE PROCEDURE [dbo].[csp_CheckProductPrivilege]
	@BuyerId INT,--买家id
	@ProductId NVARCHAR(36),--商品id
	@ActivityId INT,--活动id
	@PrePurchaseNum INT,--即将要购买的数量
	@CanBuyPrivilege INT OUTPUT --特权商品剩余活动库存	  
AS
BEGIN	
	SET NOCOUNT ON;
	DECLARE @tempPrivilegeProductCount INT;
	DECLARE @tempResultForPrivilegeUser INT;
	
	IF EXISTS(SELECT 1 FROM Ymt_ProductPrivilege WITH(NOLOCK) WHERE sProductId = @ProductId)--如果此特权商品存在
	BEGIN
		IF EXISTS(SELECT 1 FROM Ymt_ProductPrivilege WITH(NOLOCK) WHERE sProductId = @ProductId AND iUserId = @BuyerId)--如果当前用户拥有此特权
		BEGIN
				--检查检验活动有效日期及商品在活动中的有效日期以及活动商品库存量是否大于0
				SET @CanBuyPrivilege = (SELECT ps.iStockNum FROM 
				Ymt_ProductsInActivity pa INNER JOIN
				Ymt_ProductActivityStock ps ON pa.iProductInActivityId = ps.iProductInActivityId --根据活动id关联商品活动库存表与活动表
				WHERE pa.iActivityId = @ActivityId --商品必须在对应的活动内
				AND ps.sProductId = CAST(@ProductId AS VARCHAR(36))
				AND ps.iAction > -1 --活动商品库存必须有效
				AND pa.iStatus = 2 --当前商品在活动中有效				
				AND GETDATE() BETWEEN pa.dBeginTime AND pa.dEndTime	--当前日期必须在商品参加活动有效期内
				AND ps.iStockNum > 0 --商品对应的活动库存必须大于0
				AND ps.iStockNum >= @PrePurchaseNum) --商品对应的活动库存必须足够支撑当前要购买的数量（砍价团目前设置的购买数量为1，但是基于扩展性的角度，此处设置成变量
				SET @CanBuyPrivilege = ISNULL(@CanBuyPrivilege,0)				
		END
		ELSE --特权商品存在，当前用户没有此权限
		BEGIN
				SET @CanBuyPrivilege = 0;
		END
	END
	ELSE --如果此商品不是特权商品，则不做检查
	BEGIN
		SET @CanBuyPrivilege = 1;
	END	
	SET NOCOUNT OFF  
END
