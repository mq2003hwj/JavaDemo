
-- =============================================
-- Author:		Lasko.li
-- Create date: 2010-05-28
-- Description:	根据分类、品牌、页码获取商品列表。
--  输入 分类Id，品牌Id，页数
--  输出 商品信息， 页数，记录数
-- =============================================
CREATE PROCEDURE [dbo].[spGetPaggingProductsForList]
	-- Add the parameters for the stored procedure here
	@categoryId int=0,
	@brandId int=0,
	@pageSize int=20,
	@page int =1 out,
	@pageCount int =0 out,
	@recordCount int =0 out
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	--全局声明
	DECLARE @strSQL nvarchar(4000);
	DECLARE @strCountSQL nvarchar(4000);
	DECLARE @strCondition nvarchar(500);
	DECLARE @orderCondition nvarchar(500)='';
	SET @recordCount = 0;
	
	SET @strCondition ='';
	IF(@brandId<>0)
	BEGIN
		SET @strCondition += ' AND a.iBrandId=' + CAST(@brandId AS VARCHAR);
	END
	IF(@categoryId <>0)
	BEGIN
		DECLARE @strCategoryIds nvarchar(500)='';
		SELECT top 1 @strCategoryIds=(sCategoryWithSub) FROM Trig_CategorysIndex WHERE iCategoryId=@categoryId;
		--print '分类为'+ @strCategoryIds;
		
		SET @strCondition += ' AND a.iCategoryId in (' + @strCategoryIds + ')';
	END
	
	--计算总计录数
	DECLARE @innerParaCount nvarchar(500); --声明内部函数
	SET @innerParaCount = N'@recCount int out';
	SET @strCountSQL = 'SELECT @recCount=COUNT(*) FROM Ymt_Products a '
	SET @strCountSQL += ' LEFT JOIN Ymt_ProductCategory b on a.iCategoryId=b.iCategoryId';
	SET @strCountSQL += ' LEFT JOIN Ymt_ProductBrand c on a.iBrandId=c.iBrandId';
	SET @strCountSQL += ' WHERE a.iAction>-1 AND b.iAction>-1 AND c.iAction>-1'
	SET @strCountSQL += @strCondition;
	EXECUTE sp_executesql @strCountSQL,@innerParaCount,@recCount=@recordCount out
	

	--分页参数处理
	IF(@pageSize<1)
	BEGIN
		SET @pageSize = 20;
	END
	
	IF(@recordCount%@pageSize<>0)
	BEGIN
		SET @pageCount = @recordCount/@pageSize +1;
	END
	ELSE
	BEGIN
		SET @pageCount = @recordCount/@pageSize;
	END
	
	IF(@page<1)
	BEGIN
		SET @page = 1;
	END
	IF(@page>@pageCount)
	BEGIN
		SET @page = @pageCount;
	END
	
	DECLARE @recordBegin int,@recordEnd int
	SET @recordBegin = (@page-1)*@PageSize+1;
	SET @recordEnd = @recordBegin + @PageSize -1;
	--分页参数处理结束
	
	SET @orderCondition += 'dbo.DiffTimeIsBefore(getdate(),a.dLastCatalogTime) desc,dbo.DiffTimeIsBefore(getdate(),a.dLastAgentTime) desc,a.dLastCatalogTime desc,a.iTranslateState desc'
	SET @strSQL = 'WITH OrderedProducts AS (';
	SET @strSQL += 'SELECT a.*,b.sCategory,b.sCategoryEn,c.sBrand,c.sBrandEn,ROW_NUMBER() OVER (ORDER BY ';
	--SET @strSQL += 'a.sProductId';
	SET @strSQL += @orderCondition;
	SET @strSQL += ') AS RowNumber';
	SET @strSQL += ' FROM Ymt_Products AS a ';
	SET @strSQL += ' LEFT JOIN Ymt_ProductCategory AS b on a.iCategoryId=b.iCategoryId ';
	SET @strSQL += ' LEFT JOIN Ymt_ProductBrand AS c on a.iBrandId=c.iBrandId ';
	SET @strSQL += ' WHERE a.iAction>-1 AND  b.iAction>-1 AND c.iAction>-1 ';	
	SET @strSQL += @strCondition;
	SET @strSQL += ')';
	SET @strSQL += 'SELECT * FROM OrderedProducts';
	SET @strSQL += ' WHERE RowNumber BETWEEN '+cast(@recordBegin as varchar)+' AND '+cast(@recordEnd as varchar);
	
	--Print @strSQL;
	EXEC (@strSQL);
	
    -- Insert statements for procedure here
	--SELECT top 10 * from Ymt_Products
END

