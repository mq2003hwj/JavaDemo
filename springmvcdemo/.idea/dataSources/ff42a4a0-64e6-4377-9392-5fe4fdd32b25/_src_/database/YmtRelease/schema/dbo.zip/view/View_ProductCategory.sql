CREATE VIEW dbo.View_ProductCategory
AS
SELECT      dbo.View_CountProductGroupByCategory.iProductCount, dbo.Ymt_ProductCategory.iCategoryId, dbo.Ymt_ProductCategory.iMasterCategory, 
                        dbo.Ymt_ProductCategory.sCategory, dbo.Ymt_ProductCategory.sCategoryEn, dbo.Ymt_ProductCategory.sOpeator, dbo.Ymt_ProductCategory.iType, 
                        dbo.Ymt_ProductCategory.iLevel, dbo.Ymt_ProductCategory.sMark, dbo.Ymt_ProductCategory.dAddTime, dbo.Ymt_ProductCategory.iAction
FROM          dbo.Ymt_ProductCategory LEFT OUTER JOIN
                        dbo.View_CountProductGroupByCategory ON dbo.Ymt_ProductCategory.iCategoryId = dbo.View_CountProductGroupByCategory.iCategoryId
