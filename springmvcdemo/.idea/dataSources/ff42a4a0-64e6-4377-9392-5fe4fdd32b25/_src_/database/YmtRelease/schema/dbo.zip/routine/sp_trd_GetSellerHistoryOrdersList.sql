
-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-1
-- Description: 交易服务SP       
-- 20160819：取消根据风控状态做的特殊查询逻辑   
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerHistoryOrdersList]

@sellerId int,
@activityId int,
@time datetime,
@orderEstablishStatus int,
@lastProductId varchar(36),
@orderStatusXml xml,
@top int,
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit

AS

-------------variables-------------
declare @orderStatus table([value] int primary key)

--------------process--------------
if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

if @lastProductId is not null begin
  select top 1 @time = o.dAddTime from Ymt_Orders(nolock) o 
  join Ymt_OrderInfo(nolock) i on o.iOrderId = i.iOrderId
  join Ymt_OrderInfoExt(nolock) e on i.sOrderInfoId = e.sOrderInfoId and e.iActivityId != @activityId
  where o.iBuyerId = @sellerId and i.sProductId = @lastProductId
  order by o.dAddTime desc
end

;with t as(
  select i.sProductId, o.dAddTime,
  /*
  case when o.iTradingStatus = @orderEstablishStatus 
  or (@considerRiskVerfiedStatus = 0 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1)
  then i.iAmount else 0 end as notPaidCount,
  case when isnull(o.iTradingStatus, 0) != @orderEstablishStatus 
  and (@considerRiskVerfiedStatus = 0 or (o.iTradingStatus <> 2 or o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2))
  then i.iAmount else 0 end as soldCount
  */
 case when o.iTradingStatus = @orderEstablishStatus  then i.iAmount else 0 end as notPaidCount,
 case when isnull(o.iTradingStatus, 0) != @orderEstablishStatus then i.iAmount else 0 end as soldCount
  from Ymt_OrderInfo(nolock) i
  join Ymt_Orders(nolock) o on o.iOrderId = i.iOrderId
  join Ymt_OrderInfoExt(nolock) e on i.sOrderInfoId = e.sOrderInfoId and e.iActivityId != @activityId
  where o.iBuyerId = @sellerId and o.bShangouOrder = 1 and o.dAddTime < @time and
  (@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))
  /*
  (@considerOrderStatus = 0 or
    (
      (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
      or
      (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
      or
      (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
    )
  )
  */
)
select top (@top) sProductId as [productId], sum(soldCount) as [soldCount], sum(notPaidCount) as [notPaidCount], max(dAddTime) as lastOrderTime 
from t group by sProductId 
order by lastOrderTime desc

