
CREATE PROCEDURE [dbo].[spCreateTransfer]
    @bIsOriginalBox bit               -- 是否原箱, 传入参数，必填
    ,@dEstimateArriveDate datetime    -- 预计到达时间，传入参数，必填
    ,@vUsShipName nvarchar(500)       -- 美国境内物流商, 传入参数，必填
    ,@sUsExpressCode nvarchar(512)    -- 美国境内物流单号，传入参数，必填
    ,@iPackageCount int               -- 内含包裹数，传入参数，必填
    ,@result int=0 out                -- 返回值,0表示成功,非表示失败
    ,@sCreaterName nvarchar(50)
    ,@message varchar(max) out
AS
BEGIN

EXEC 
	[XloboRelease].[dbo].[spCreateTransfer]
	@bIsOriginalBox=  @bIsOriginalBox    
    ,@dEstimateArriveDate = @dEstimateArriveDate  
    ,@vUsShipName =  @vUsShipName     
    ,@sUsExpressCode=@sUsExpressCode   
    ,@iPackageCount =   @iPackageCount        
    ,@result= @result  out   
    ,@sCreaterName  = @sCreaterName
    ,@message =@message out
END
