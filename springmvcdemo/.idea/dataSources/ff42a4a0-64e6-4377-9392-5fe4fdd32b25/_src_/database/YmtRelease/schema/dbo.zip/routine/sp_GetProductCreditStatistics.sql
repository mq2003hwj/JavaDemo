-- =============================================
-- Author:		adu
-- Create date: 2014-10-24
-- Description:	获取商品的被评价的订单总数，其中好评数，差评数，中评数
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetProductCreditStatistics] 
	-- Add the parameters for the stored procedure here
	@ProductId varchar(36)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @iOrderCount INT,@CountOfOk INT ,@CountOfNormal INT ,@CountOfBad INT 
   SELECT @iOrderCount=iOrderCount ,@CountOfOk=iCountOfOk, @CountOfNormal= iCountOfNormal, @CountOfBad = iCountOfBad  
   FROM dbo.Ymt_ProductCredit 
   WHERE sProductId=@ProductId

   SELECT ISNULL(@iOrderCount,0) AS OrderCount,ISNULL(@CountOfOk,0) AS CountOfOk
		 ,ISNULL(@CountOfNormal,0) AS CountOfNormal, ISNULL(@CountOfBad,0) AS CountOfBad

/*
   select	Count(*) as OrderCount, 
			CountOfOk=sum(case when c.iPoint3 = 3 then 1 else 0 end),
			CountOfNormal=sum(case when c.iPoint3 = 2 then 1 else 0 end),
			CountOfBad=sum(case when c.iPoint3 = 1 then 1 else 0 end)
	from	Ymt_OrderInfo o
	inner join Ymt_CreditDetail c on c.sTargetId= o.iOrderId
	where	c.iType=1
	and		o.sProductId=@ProductId
*/

END
