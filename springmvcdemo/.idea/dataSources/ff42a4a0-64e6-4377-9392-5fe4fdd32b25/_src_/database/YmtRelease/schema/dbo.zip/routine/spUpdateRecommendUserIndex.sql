-- =============================================
-- Author:		jmtek
-- Create date: 2013-8-6
-- Last update: 2013-8-6
-- Modify log:	
--		2013-8-6: 新增SP
-- Description:	统计用户偏好指数
-- =============================================
CREATE PROCEDURE [dbo].[spUpdateRecommendUserIndex]
	@UserId	INT
AS
BEGIN
	Delete From Ymt_RecommendUserIndex Where iUserId = @UserId

	/*
	用户偏好指数 = 下单频次 * 权重
	
	下单频次（buyfreq）：
	在一个订单明细中出现一次即为一个频次。
	比如一个订单中购买了A商品（分类1，品牌x）3件、B商品（分类2，品牌x）2件、C商品（分类1，品牌y）1件。
	则分类1下单频次为2，分类2下单频次为1，品牌x下单频次为2，品牌y下单频次为1，分类1+品牌x、分类2+品牌x、分类1+品牌y三个组合下单频次分别为1
	
	权重（timeweight）：
	按照最近下单时间的权重设定：30天内为3，大于30天且在180天以内为2，大于180天为1
	*/
	
	-- 针对类目的偏好指数计算
	Insert Into Ymt_RecommendUserIndex (iUserId, iBrandId, iThirdCategoryId, iIndex)
	select @UserId as UserId, 0 as BrandId, iProductThirdCategoryId as CategoryId, sum(timeweight*buyfreq) as ThisIndex
	from
	(
		select o.iOrderId, oi.iProductThirdCategoryId, count(*) as buyfreq,
			case when max(o.dAddTime) >= dateadd(dd,-30,getdate()) then 3
				when max(o.dAddTime) >= dateadd(dd,-180,getdate()) then 2
			else 1 end timeweight
		from dbo.Ymt_OrderInfo oi with(nolock), dbo.Ymt_Orders o
		where o.iUserId = @UserId and oi.iOrderId = o.iOrderId and o.dAddTime >= '2012-7-1' and bShangouOrder <> 1
			and iProductBrandId > 0 and iProductThirdCategoryId > 0
			-- and o.iTradingStatus in (2,3,4,16,17)
		group by o.iOrderId, oi.iProductThirdCategoryId
	) as a
	group by iProductThirdCategoryId
	union 
	-- 针对品牌的偏好指数计算
	select @UserId as UserId, iProductBrandId as BrandId, 0 as CategoryId, sum(timeweight*buyfreq) as ThisIndex
	from
	(
		select o.iOrderId, oi.iProductBrandId, count(*) buyfreq,
			case when max(o.dAddTime) >= dateadd(dd,-30,getdate()) then 3
				when max(o.dAddTime) >= dateadd(dd,-180,getdate()) then 2
			else 1 end timeweight
		from dbo.Ymt_OrderInfo oi with(nolock), dbo.Ymt_Orders o
		where o.iUserId = @UserId and oi.iOrderId = o.iOrderId and o.dAddTime >= '2012-7-1' and bShangouOrder <> 1
			and iProductBrandId > 0 and iProductThirdCategoryId > 0
			-- and o.iTradingStatus in (2,3,4,16,17)
		group by o.iOrderId, oi.iProductBrandId
	) as a
	group by iProductBrandId
	union
	-- 针对类目+品牌的偏好指数计算
	select @UserId as UserId, iProductBrandId as BrandId, iProductThirdCategoryId as CategoryId, sum(timeweight*buyfreq) as ThisIndex
	from
	(
		select o.iOrderId, oi.iProductBrandId, oi.iProductThirdCategoryId, count(*) buyfreq,
			case when max(o.dAddTime) >= dateadd(dd,-30,getdate()) then 3
				when max(o.dAddTime) >= dateadd(dd,-180,getdate()) then 2
			else 1 end timeweight
		from dbo.Ymt_OrderInfo oi with(nolock), dbo.Ymt_Orders o with(nolock)
		where o.iUserId = @UserId and oi.iOrderId = o.iOrderId and o.dAddTime >= '2012-7-1' and bShangouOrder <> 1
			and iProductBrandId > 0 and iProductThirdCategoryId > 0
			-- and o.iTradingStatus in (2,3,4,16,17)
		group by o.iOrderId, oi.iProductBrandId, oi.iProductThirdCategoryId
	) as a
	group by iProductBrandId, iProductThirdCategoryId
	
	
END
