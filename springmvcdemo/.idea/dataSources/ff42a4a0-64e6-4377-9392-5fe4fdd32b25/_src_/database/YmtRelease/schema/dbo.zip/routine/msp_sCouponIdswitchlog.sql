/*
author :CL
Date:2015-09-16
function: switch scoupon and Ymt_CouponPrivateUserBound expired logs to history table 
*/
create procedure msp_sCouponIdswitchlog
as

select Top 100000 sCouponId
into #Temp
from Ymt_Coupon with (Nolock)
where dValidStart < convert(varchar(10),getdate() - 180,120) and dValidEnd < convert(varchar(10),getdate() - 30,120)

while @@Rowcount > 0
Begin

	delete top (100) a
	output deleted.* into Ymt_CouponPrivateUserBound_his
	from Ymt_CouponPrivateUserBound a
	where a.sCouponId in (Select b.sCouponId from #Temp b)
End

select getdate()

while @@Rowcount > 0
Begin

	delete top (1000) a
	output deleted.* into Ymt_Coupon_His
	from Ymt_Coupon a
	where a.sCouponId in (Select b.sCouponId from #Temp b)
End
