-- =============================================            

-- Author:  Deng Peng        

-- Create date: 2016-06-03

-- Description: 通过订单ID获取卖家订单信息   

-- 20160621：添加促销活动相关数据信息    

-- 20160628：订单商品详细信息追加:ReducedAmount , bSupportRtnWithoutReason

-- 20160805：添加新老客订单字段bNewSellerOrder,bNewCustomerOrder

-- 20161021：修改[TotalSalesRefundAmount]含义,只取退款成功的

-- =============================================

CREATE procedure [dbo].[sp_trd_GetSellerOrdersByOrderIds_v1]

@orderdt Int32Array readonly,

@sellerId int = null,

@totalCount int = 0

as



declare @orderIds table ([iOrderId] int not null);

declare @orderToBills table([iOrderId] int not null, [sBillId] varchar(36) not null);

declare @orderTradingIds table([iOrderId] int not null, [iTradingId] int not null, [virtualTime] datetime not null);



declare @rowsCount int = 0;



insert into @orderIds ([iOrderId])

select [Value] from @orderDt

--统计当前页订单数量 

select @rowsCount = count(1) from @orderIds



--统计订单总量

select @totalCount as TotalCount

----------------------------------------------------------------------------------------------------------------------

--当页订单的详细信息

select t2.* ,

	[RealPay].* ,

	[OrderNote].*

from @orderIds as t1

inner join [dbo].[Ymt_Orders] as t2 with(nolock) on [t2].[iOrderId] = [t1].[iOrderId]

outer apply (

	select

		[RealSettlementAmountOfCoupon] = sum(t3.[SettlementAmountOfCoupon]),

		[TotalSalesRefundAmount] = sum(t3.[RefundAmount]),

		[TotalRefundThirdPartyDiscount] = sum(isnull(t3.RefundedDiscountOfThirdParty,0))

	from [dbo].[Ymt_RefundBill] as t3 with(nolock) where t3.[OrderId] = t1.[iOrderId] AND t3.[SalesRefundStatus] = 10

) as [RealPay]

outer apply (

	select top 1 [note].[iRemarkLevel] , [RemarkContent] = [note].[sContent]

	from [dbo].[Ymt_O_OrderNote] as [note] with(nolock) 

	where [note].[iOrderId] = t2.[iOrderId] and [note].[iUserId] = t2.[iBuyerId]

) as [OrderNote]

order by t2.[iMainOrderId] desc ,t1.[iOrderId] asc, [t2].[sYmtCouponCode] desc option(recompile);



----------------------------------------------------------------------------------------------------------------------

--获取评价列表  

select * from [dbo].[Ymt_CreditDetail] with(nolock) where 1=0 ;



----------------------------------------------------------------------------------------------------------------------

--获取备注列表  

select [iOrderId], [sContent] , [iRemarkLevel] from [dbo].[Ymt_O_OrderNote] with(nolock) where @rowsCount > 0 and [iUserId] = @sellerId and [iOrderId] in (select [iOrderId] from @orderIds) ; 



----------------------------------------------------------------------------------------------------------------------

--获取订单金额详情列表

select * from [dbo].[Ymt_OrderState] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取订单补款列表  

select * from [dbo].[Ymt_OrderPostPay] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取订单商品详情列表

select

	i.[iOrderId] , i.sOrderInfoId , i.fOriginalPrice , i.iPriceType , i.iAmount , i.iBondedArea , i.iCatalogStatus , i.iCatalogType , i.iProductSubCategoryId

	, i.iSailProtected , i.iType , i.sCatalogId , i.sDescription , i.sPictureUrl , i.sProductId , i.sPropertyInfo , i.sReferenceUrl , i.sSKU , i.sTitle 

	, e.sOrderInfoId as sOrderInfoExtId , e.bGiftAvail4Reward , e.iActivityId , e.iActivityTemplateId , i.iSalesType

	, i.fProductPrice , i.fProductOriginalPrice , i.fSellerCouponAmount , i.fYmtCouponAmount , i.fDiscount , i.fFreight

	, i.[fSellerPromotionAmount] , s.[PromotionId] , s.[PromotionType] , s.[PromotionName] , s.[MatchCondition] , s.[PromotionValue]

	, s.ReducedAmount , i.bSupportRtnWithoutReason,i.bPreSale,i.fThirdPartyDiscount

from [dbo].[Ymt_OrderInfo] as i with(nolock) 

inner join @orderIds as o on i.[iOrderId] = o.[iOrderId]

left join [dbo].[Ymt_OrderInfoExt] as e with(nolock) on i.[sOrderInfoId] = e.[sOrderInfoId]

left join [dbo].[Ymt_SellerPromotion] as s with(nolock) on i.[iOrderId] = s.[OrderId] and i.[sOrderInfoId] = s.[OrderInfoId]

where @rowsCount > 0 ;



----------------------------------------------------------------------------------------------------------------------

--获取订单物流信息  

select [iOrderId], [iBillType], [sSummary] from [dbo].[Ymt_OrderSummary] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取订单冻结信息  

select * from [dbo].[Ymt_Order_Frozen] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取订单账单信息

--insert into @orderToBills([iOrderId], [sBillId])

--select [iOrderid], [sBillId] from [dbo].[Ymt_OrderToBill] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) and iaction >= 0 ;

select [iOrderid], [sBillId] from [dbo].[Ymt_OrderToBill] with(nolock) where 1=0;



----------------------------------------------------------------------------------------------------------------------

--获取码头在线做单信息  

select * from [dbo].[Ymt_Bill] with(nolock) where 1=0 ;



----------------------------------------------------------------------------------------------------------------------

--订单有效的交易ID  

if @rowsCount > 0 begin



	insert into @orderTradingIds([iOrderId], [iTradingId], [virtualTime])

	select [iOrderId], [iTradingId], [dUpdateTime] from [dbo].[Ymt_TradingItem] with(nolock) where [iOrderId] in (select [iOrderId] from @orderIds) ;



	-----------------------update virtaulTime from ymt_tradinginfo-------------------------------

	update [target] set [virtualTime] = '9999-1-1'

	from @orderTradingIds as [target] , [dbo].[Ymt_TradingInfo] as [source] with(nolock)

	where [target].[iTradingId] = [source].[iTradingId] and [source].[iTradingStatus] = 2 ;



  ;with t as(

    select ROW_NUMBER() over(partition by [iOrderId] order by [virtualTime] desc) as n, * from @orderTradingIds

  ) 

  select [iOrderId], [iTradingId] from t where n = 1 order by [iOrderId] ;



end

else begin

  select top 0 0 as iOrderId, 0 as iTradingId ;

end



select [iOrderId], [bIsNeedUploadIdCard], [bHaveUploadedIdCard], [bNewSellerOrder], [bNewCustomerOrder]

from [dbo].[Ymt_OrderExt] with(nolock) where [iOrderId] in (select [iOrderId] from @orderIds) ;
