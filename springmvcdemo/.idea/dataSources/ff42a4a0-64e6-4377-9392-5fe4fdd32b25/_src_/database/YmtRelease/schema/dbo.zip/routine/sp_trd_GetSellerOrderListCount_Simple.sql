

-- =============================================            
-- Author:  fanwei        
-- ALTER date: 2015-9-1
-- Description: 交易服务SP      
-- update by cl 2015-12-03 
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderListCount_Simple]

@sellerId int,
@timeType int,
@beginTime  datetime,
@endTime datetime,
@timeoutType bit,
@timeoutType1 tinyint,
@timeoutType2 tinyint,
@timeoutType3 tinyint,
@timeoutBegin1 datetime,
@timeoutEnd1 datetime,
@timeoutBegin2 datetime,
@timeoutEnd2 datetime,
@timeoutBegin3 datetime,
@timeoutEnd3 datetime,
@shangou bit,
@orderStatusXml xml,
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@salesRefundOrderOnly bit = 0,
@domesticDelivered bit = null

AS

if @timeType = 0
Begin
  --select @beginTime = getdate() - 90 , @endTime = getdate()
  Exec sp_trd_GetSellerOrderListCount_Simple_NoTime @sellerId, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly
End

if  @timeType = 1
Begin
  Exec sp_trd_GetSellerOrderListCount_Simple_daddtime @sellerId, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

  return
End

if  @timeType = 2
Begin
  Exec sp_trd_GetSellerOrderListCount_Simple_dPaidTime @sellerId, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

  return
End

if  @timeType = 3
Begin
  Exec sp_trd_GetSellerOrderListCount_Simple_dDispathTime @sellerId, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

  return
End

if  @timeType = 4
Begin
  Exec sp_trd_GetSellerOrderList_Simple_dApplyPostPayTime @sellerId, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

  return
End
