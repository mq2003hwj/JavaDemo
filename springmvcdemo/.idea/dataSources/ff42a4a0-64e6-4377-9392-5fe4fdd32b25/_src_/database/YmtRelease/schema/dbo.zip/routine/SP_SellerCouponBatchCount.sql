
-- =============================================
-- Author:		zhangzhiqiang
-- Create date: 2015-11-29
-- Description:	查询商家优惠券批次数量
-- =============================================
CREATE PROCEDURE [dbo].[SP_SellerCouponBatchCount]
	@BatchStatus INT,
	@SellerId INT
AS
BEGIN
	DECLARE @ValidBatchCount INT = 0   --有效批次数量
		,@InvalidBatchCount INT = 0    --无效批次数量
		,@SendingBatchCount INT = 0   --发放中批次数量
		,@SentBatchCount    INT = 0   --发放完成批次数量
		,@StopSendingBatchCount    INT = 0   --停止发放批次数量

	--无效优惠券数量
	SELECT @InvalidBatchCount= COUNT(A.sBatchCode) FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) 
    INNER JOIN dbo.Ymt_CouponSetting B WITH(NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId
	WHERE A.iOperatorId = @SellerId AND A.iBatchCreateType=2 AND B.dValidEnd < GetDATE()
		
	--有效优惠券数量
	SELECT @ValidBatchCount= COUNT(A.sBatchCode) FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) 
    INNER JOIN dbo.Ymt_CouponSetting B WITH(NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId
	WHERE A.iOperatorId = @SellerId AND A.iBatchCreateType=2 AND B.dValidEnd >= GetDATE()

	-- 2：领取中 3：已领完 4：停止发放
	IF @BatchStatus = 2 OR @BatchStatus = 3 OR @BatchStatus = 4
	BEGIN
		--领取中
		SELECT @SendingBatchCount= COUNT(A.sBatchCode) FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) 
		INNER JOIN dbo.Ymt_CouponSetting B WITH(NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId
		WHERE A.iOperatorId = @SellerId AND A.iBatchCreateType=2 AND B.dValidEnd >= GetDATE() 
			AND ISNULL(A.bInvalidStatus,0)=0 AND B.iUseTotalCount>B.iReceiveCount

		--已领完
		SELECT @SentBatchCount= COUNT(A.sBatchCode) FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) 
		INNER JOIN dbo.Ymt_CouponSetting B WITH(NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId
		WHERE A.iOperatorId = @SellerId AND A.iBatchCreateType=2 AND B.dValidEnd >= GetDATE() 
			AND ISNULL(A.bInvalidStatus,0)=0 AND B.iUseTotalCount=B.iReceiveCount

		--停止发放
		SELECT @StopSendingBatchCount= COUNT(A.sBatchCode) FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) 
		INNER JOIN dbo.Ymt_CouponSetting B WITH(NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId
		WHERE A.iOperatorId = @SellerId AND A.iBatchCreateType=2 AND B.dValidEnd >= GetDATE() AND A.bInvalidStatus=1
	END

	SELECT @ValidBatchCount AS ValidBatchCount,@InvalidBatchCount AS InvalidBatchCount,@SendingBatchCount AS SendingBatchCount
		,@SentBatchCount AS SentBatchCount,@StopSendingBatchCount AS StopSendingBatchCount
END

