
-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-1
-- Description: 交易服务SP       
-- 20160819：取消根据风控状态做的特殊查询逻辑 
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOderInfoByProductId]

@sellerId int,
@orderEstablishStatus int,
@productId varchar(36),
@orderStatusXml xml,
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit

AS

-------------variables-------------
declare @orderStatus table([value] int primary key)

--------------process--------------
if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

--set statistics time on;set statistics io on;

select i.sCatalogId as catalogId, 
max(i.dAddTime) as lastOrderTime,
count(i.sCatalogId) as orderCount,
sum(case when o.iTradingStatus = @orderEstablishStatus 
/*or (@considerRiskVerfiedStatus = 0 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1)*/
then i.iAmount else 0 end) as notPaidCount,
sum(case when o.iTradingStatus = @orderEstablishStatus 
/*or (@considerRiskVerfiedStatus = 0 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1)*/
then 1 else 0 end) as notPaidOrderCount,
sum(case when isnull(o.iTradingStatus, 0) != @orderEstablishStatus 
/*and (@considerRiskVerfiedStatus = 0 or (o.iTradingStatus <> 2 or o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2))*/
then i.iAmount else 0 end) as soldCount,
sum(case when isnull(o.iTradingStatus, 0) != @orderEstablishStatus 
/*and (@considerRiskVerfiedStatus = 0 or (o.iTradingStatus <> 2 or o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2))*/
then 1 else 0 end) as soldOrderCount
into #catalogOrders
from Ymt_OrderInfo(nolock) i
join Ymt_Orders(nolock) o on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and i.sProductId = @productId and
(@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))
/*
(@considerOrderStatus = 0 or
  (
    (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
    or
    (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
    or
    (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
  )
)
*/
group by i.sCatalogId

select catalogId, orderCount, soldCount from #catalogOrders

select max(lastOrderTime) as lastOrderTime,
sum(notPaidCount) as notPaidCount,
sum(notPaidOrderCount) as notPaidOrderCount,
sum(soldCount) as soldCount,
sum(soldOrderCount) as soldOrderCount
from #catalogOrders

drop table #catalogOrders

--set statistics time off; set statistics io off;
--fd28d1a9-17ff-4a0f-b8c9-91d1f6c65e66   6040
--485453bf-f5fc-4760-89e2-260a905962ba   4494
--cc3063aa-d63a-436c-9225-f72fb6665294   4025
--ab806fe1-fc5f-4935-9db2-88b00f3b533e   3745
--54bf0bf4-21ba-4ac2-9c73-f85954889a2d   3636


