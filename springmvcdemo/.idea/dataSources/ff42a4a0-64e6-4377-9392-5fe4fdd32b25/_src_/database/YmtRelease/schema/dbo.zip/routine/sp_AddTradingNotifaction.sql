
-- =============================================            
-- Author:  zhangzhiqiang        
-- Create date: 2015-10-12
-- Description: 添加交易通知    
-- =============================================     

CREATE PROC [dbo].[sp_AddTradingNotifaction]
	@OrderId int
	,@ReceiveUserId int
	,@CurrentPrice  decimal(18,2)
	,@NotificationType int
	,@OperatorType int
	,@Operator varchar(50)
	,@Remark varchar(500)
AS

DECLARE @Now datetime = getdate()
	,@ProductNum int
	,@OrderTitle varchar(300)

UPDATE Ymt_TradingNotifaction SET bIsNewest = 0 WHERE iOrderId=@OrderId and iReceiveUserId=@ReceiveUserId

SELECT TOP 1 @OrderTitle=sTitle FROM Ymt_OrderInfo WITH(NOLOCK) WHERE iOrderId=@OrderId

SELECT @ProductNum=COUNT(1) FROM Ymt_OrderInfo WITH(NOLOCK) WHERE iOrderId=@OrderId

--添加交易通知
INSERT INTO [Ymt_TradingNotifaction]
           ([sTradingNotifactionId],[iReceiveUserId],[iOrderId],[sOrderTitle],[iProductNum] ,[fOrderCurrentPrice],[iTradingOperatorType]
           ,[sTradingOperate],[dTradingTime],[sRemark],[bIsNewest],[iAction])
     VALUES
           (newid(),@ReceiveUserId,@OrderId ,@OrderTitle,@ProductNum,@CurrentPrice,@OperatorType ,@Operator
           ,@Now ,@Remark,1 ,0)

--记录交易通知数量
IF EXISTS(SELECT 1 FROM Ymt_NotificationCount WITH(NOLOCK) WHERE iUserId=@ReceiveUserId AND NotificationType=@NotificationType)
BEGIN
	UPDATE Ymt_NotificationCount SET NotificationCOunt=NotificationCOunt+1 WHERE iUserId=@ReceiveUserId AND NotificationType=@NotificationType
END
ELSE
BEGIN
	INSERT INTO [Ymt_NotificationCount] ([iUserId] ,[NotificationType],[NotificationCOunt])
     VALUES (@ReceiveUserId,@NotificationType,1)
END