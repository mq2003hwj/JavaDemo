-- =============================================            

-- Author:  zhangzhiqiang        

-- Create date: 2016-03-31

-- Description: 创建订单       

-- =============================================     

CREATE PROC [dbo].[sp_PlaceOrder]

	@UserId INT,

	@OrderType INT,

	@OrderSource VARCHAR(128),

	@OrderSourceIp VARCHAR(128),

	@DeviceId VARCHAR(200) = null,

	@TerminalSource VARCHAR(128),

	@AppTerminalSource VARCHAR(128),

	@IsNeedUploadIdCard BIT,

	@SellerId INT,

	@Address VARCHAR(1000),

	@PostCode VARCHAR(10),

	@Phone VARCHAR(20),

	@Telephone VARCHAR(20),

	@ReceivePerson VARCHAR(50),

	@Freight DECIMAL(18,2),

	@LeaveWord NVARCHAR(2000),

	@AutoCancelOrderHours DECIMAL(18,2),

	@IncludeActivity BIT,

	@OrderPrice DECIMAL(18,2),

	@TotalPrice DECIMAL(18,2),

	@CouponCode VARCHAR(36) = null,

	@CouponType INT = null,

	@CouponValue DECIMAL(18,2) = null,

	@CouponChannel INT = null,

	@CommissionFee DECIMAL(18,2),

	@IsFirstOrder BIT,

	@IsPaidFull BIT,

	@IsMerchant int = 0,  --0：买手

	@EquipmentId VARCHAR(200) = null,

	@OrderInfos TempOrderProducts READONLY

AS



declare @OrderId int = 0

		,@IsShangouOrder bit = 0  --0默认为M订单

		,@SalesType int = 1  --1默认为现货商品

		,@SellerCouponCode varchar(36) = null

		,@SellerCouponAmount decimal(18,2) = 0

		,@YmtCouponCode varchar(36) = null

		,@YmtCouponAmount decimal(18,2) = 0

		,@PayableAmount decimal(18,2) = 0  --应付金额



		,@OrderInfoId varchar(36)

		,@ProductNum int

		,@PropetyInfo varchar(2000)

		,@ProductPrice decimal(18,2)

		,@EarnestPrice decimal(18,2)

		,@PictureUrl varchar(1000)

		,@ProductName varchar(500)

		,@SailProtected int = 0

		,@CatalogId varchar(36)

		,@CatalogStatus int

		,@CatalogType int

		,@SKU varchar(300)

		,@ProductId varchar(36)

		,@MainCategoryId int

		,@SubCategoryId int

		,@ThirdCategoryId int

		,@BrandId int

		,@BondedArea int

		,@ProductCode varchar(50)

		,@TariffType int

		,@PackageNo varchar(50)

		,@RefundChannel int

		,@IsUseCoupon bit

		,@IsFeeFree bit

		,@ActivityId int

		,@ActivityTemplateId int

		,@PromotionType int

		,@Promotion decimal(18,2)

		,@CommissionRate decimal(18,2)

		,@Premium decimal(18,2)

		,@IsCost bit

		,@PriceType int

		,@ProductInfo varchar(500)

		,@RowId int

		,@Now datetime = getdate()



	--生成新订单号

	EXEC @OrderId = spGenerateOrderId 


	IF @OrderType = 1   --1:扫货订单 0:M订单

	BEGIN

		SET @IsShangouOrder = 1

		SET @SalesType = 2  --2--直播商品

	END



	IF @CouponValue IS NULL

	BEGIN

		SET @CouponValue = 0

	END

	IF @CouponChannel = 1   --码头自有优惠券=1

	BEGIN

		SET @YmtCouponCode = @CouponCode

		SET @YmtCouponAmount = @CouponValue

	END

	IF @CouponChannel = 2   --商家优惠券=2

	BEGIN

		SET @SellerCouponCode = @CouponCode

		SET @SellerCouponAmount = @CouponValue

	END

	SET @PayableAmount =@TotalPrice+@Freight-@CouponValue

	--插入订单数据Ymt_Orders

	INSERT INTO [Ymt_Orders]

           ([iOrderId],[iUserId],[iBuyerId],[dAddTime],[fOrderPrice],[fOrderDiscount] ,[fFreight],[fDiscount],[iTradingStatus] ,[sAddress],[sPostCode]

           ,[sReceivePerson],[sPhone],[sTelephone],[sLeaveWord],[bPaidInFull],[sCouponCode],[CouponValue]

           ,[iCouponType],[iCouponChannel],[fAutoCancelOrderHours],[bShangouOrder],[iIsMerchant],[fTotalPrice],[bIncludeActivityProducts],[bCanLocalReturn]

		   ,[sSellerCouponCode],[fSellerCouponAmount],[sYmtCouponCode],[fYmtCouponAmount],[fPayableAmount],[fSellerPromotionAmount])

     VALUES

           (@OrderId,@UserId,@SellerId,@Now,@OrderPrice,0,@Freight,0,1,@Address,@PostCode,@ReceivePerson,@Phone,@Telephone,@LeaveWord,@IsPaidFull

           ,@CouponCode,@CouponValue,@CouponType,@CouponChannel,@AutoCancelOrderHours,@IsShangouOrder

           ,@IsMerchant,@TotalPrice,@IncludeActivity,1,@SellerCouponCode,@SellerCouponAmount,@YmtCouponCode,@YmtCouponAmount,@PayableAmount,0)

	

	--插入订单资金数据Ymt_OrderState

	INSERT INTO [Ymt_OrderState]

           ([iOrderId],[fRefundedAmountOfCash],[fRefundedAmountOfGift],[fPaidAmountOfCash],[fPaidAmountOfGift],[fPostPaidAmountOfCash]

           ,[fPostPaidAmountOfGift],[fPaidAmountOfCoupon],[fNeedCommissionFee],[fPaidAmountOfSellerCoupon],[fPaidAmountOfYmtCoupon]

		   ,[dAddTime],[dUpdateTime])

     VALUES

           (@OrderId, 0, 0, 0, 0, 0, 0, @CouponValue, @CommissionFee,@SellerCouponAmount,@YmtCouponAmount,@Now,@Now)

	

	--插入订单扩展信息Ymt_OrderExt

	INSERT INTO [Ymt_OrderExt]

           ([iOrderId],[sOrderSource],[sOrderSourceIP],[iOrderType],[sTerminalSource],[bIsNeedUploadIdCard],[sAppTerminalSource],[sDeviceId]

			,[bIsFirstOrder],[dAddTime],[sInterfaceVersion],[sEquipmentId])

    VALUES

           (@OrderId,@OrderSource,@OrderSourceIP,@OrderType,@TerminalSource,@IsNeedUploadIdCard,@AppTerminalSource,@DeviceId,@IsFirstOrder,@Now,'PlaceOrder',@EquipmentId)



	SET @RowId = 1

	WHILE EXISTS(SELECT 1 FROM @OrderInfos WHERE RowId=@RowId)

	BEGIN

		SET @OrderInfoId = newid()



		SELECT @CatalogId=CatalogId,@PropetyInfo=PropetyInfo,@ProductName=ProductName,@PictureUrl=PictureUrl

			,@ProductPrice=ProductPrice,@EarnestPrice=EarnestPrice,@ProductNum=ProductNum,@SKU=SKU,@PackageNo=PackageNo

			,@CatalogType=CatalogType,@CatalogStatus=CatalogStatus,@ProductId=ProductId,@MainCategoryId=MainCategoryId

			,@SubCategoryId=SubCategoryId,@ThirdCategoryId=ThirdCategoryId,@BrandId=BrandId,@BondedArea=BondedArea

			,@ProductCode=ProductCode,@TariffType=TariffType,@ActivityId=ActivityId

			,@ActivityTemplateId=ActivityTemplateId,@PromotionType=PromotionType,@Promotion=Promotion

			,@IsUseCoupon=IsUseCoupon,@PriceType=PriceType,@ProductInfo=ProductInfo

			,@IsFeeFree=IsFeeFree,@CommissionRate=CommissionRate,@Premium=Premium,@IsCost=IsCost

			,@RefundChannel=RefundChannel

		FROM @OrderInfos WHERE RowId=@RowId



		IF @CatalogStatus = 3

			SET @SailProtected = 1

		--插入订单商品信息Ymt_OrderInfo

		INSERT INTO [Ymt_OrderInfo]

			   ([sOrderInfoId],[iOrderId],[sCatalogId],[sPropertyInfo],[sTitle],[sPictureUrl],[fOriginalPrice],[iAmount]

			   ,[fTotalPrice],[iSailProtected],[sSKU],[iCatalogType],[iCatalogStatus],[sProductId],[iProductMainCategoryId],[iProductSubCategoryId]

			   ,[iProductThirdCategoryId],[iProductBrandId],[iBondedArea],[sProductCode],[iTariffType],[fFlight],[iPriceType],[sProductInfo],[sPackageNo]

			   ,[iProductRefundChannel],[fProductPrice],[fSubsidyAmount],[dAddTime],[dUpdateTime],[iSalesType],[fSellerPromotionAmount])

		 VALUES

			   (@OrderInfoId,@OrderId,@CatalogId,@PropetyInfo,@ProductName,@PictureUrl,@EarnestPrice,@ProductNum,0,@SailProtected

			   ,@SKU,@CatalogType,@CatalogStatus,@ProductId,@MainCategoryId,@SubCategoryId,@ThirdCategoryId,@BrandId,@BondedArea

			   ,@ProductCode,@TariffType,0,@PriceType,@ProductInfo,@PackageNo,@RefundChannel,@ProductPrice,0,@Now,@Now,@SalesType,0)



		IF @ActivityId > 0  --插入订单商品活动信息Ymt_OrderInfoExt

		BEGIN

			INSERT INTO [Ymt_OrderInfoExt]

				([sOrderInfoId],[iActivityId],[iActivityTemplateId],[iPromotionType],[fPromotion]

				,[bCouponAvail4OrderDeduct],[bFeeFree],[fCommissionRate],[fPremium],[bIsCost])

			VALUES

				(@OrderInfoId,@ActivityId,@ActivityTemplateId,@PromotionType,@Promotion

				,@IsUseCoupon,@IsFeeFree,@CommissionRate,@Premium,@IsCost)

		END

		SET @RowId = @RowId + 1

	END



SELECT @OrderId AS iOrderId
