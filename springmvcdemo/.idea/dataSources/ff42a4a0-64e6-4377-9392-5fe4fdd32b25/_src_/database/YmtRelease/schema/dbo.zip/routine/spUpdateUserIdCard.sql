
CREATE PROCEDURE [dbo].[spUpdateUserIdCard] 
    @sBillCode nvarchar(50)              -- 面单的面单号
    ,@sReceiverName nvarchar(50)        -- 收件人名字，传入参数，可填
    ,@sReceiverPhone nvarchar(50)       -- 收件人电话，传入参数，可填
    ,@sReceiverProvince nvarchar(64)    -- 收件人所在省，传入参数，可填
    ,@sReceiverCity nvarchar(64)        -- 收件人所在市，传入参数，可填
    ,@sIdCardNum nvarchar(50) = null          -- 身份证号,可填
    ,@sIdPicRightSide nvarchar(500)     -- 身份证正面图片，传入参数，必填
    ,@sIdPicReverseSide nvarchar(500)   -- 身份证反面图片，传入参数，必填
    ,@result int=0 out                  -- 返回值,0表示成功,非表示失败
    ,@message varchar(max) out          -- 错误消息
    
AS
BEGIN
	DECLARE	@return_value int
	EXEC	@return_value = [XloboRelease].[dbo].[spCreateIdPicWithIdCode]
			@sBillCode = @sBillCode, @sReceiverName = @sReceiverName, @sReceiverPhone = @sReceiverPhone, @sReceiverProvince = @sReceiverProvince
			,@sReceiverCity = @sReceiverCity, @sIdPicRightSide = @sIdPicRightSide, @sIdPicReverseSide = @sIdPicReverseSide, @sIdCode = @sIdCardNum, @result = @result output, @message = @message output
END

