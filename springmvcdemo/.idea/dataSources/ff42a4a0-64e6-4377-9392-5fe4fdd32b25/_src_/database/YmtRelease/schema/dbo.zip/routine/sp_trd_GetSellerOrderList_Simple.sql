

-- =============================================            
-- Author:  fanwei        
-- ALTER date: 2015-8-13
-- Description: 交易服务SP       
-- update by cl 2015-12-03
-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderList_Simple]

@sellerId int,
@orderType int,
@sortType int,
@timeType int,
@timeoutType int,
@beginTime  datetime,
@endTime datetime,
@timeoutBegin datetime,
@timeoutEnd datetime,
@shangou bit,
@orderStatusXml xml,
@paidInFull bit,
@rowFrom int,
@rowTo int,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@salesRefundOrderOnly bit = 0,
@domesticDelivered bit = null

AS 

if @timeType = 0
Begin
  select @beginTime = getdate() - 90 , @endTime = getdate()
  Exec sp_trd_GetSellerOrderList_Simple_daddtime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @paidInFull, @rowFrom,
   @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

   return
End

if  @timeType = 1
Begin
  Exec sp_trd_GetSellerOrderList_Simple_daddtime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @paidInFull, @rowFrom,
   @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

  return
End

if  @timeType = 2
Begin
  Exec sp_trd_GetSellerOrderList_Simple_dPaidTime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @paidInFull, @rowFrom,
   @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

  return
End

if  @timeType = 3
Begin
  Exec sp_trd_GetSellerOrderList_Simple_dDispathTime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @paidInFull, @rowFrom,
   @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

  return
End

if  @timeType = 4
Begin
  Exec sp_trd_GetSellerOrderList_Simple_dApplyPostPayTime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @paidInFull, @rowFrom,
   @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly

  return
End
