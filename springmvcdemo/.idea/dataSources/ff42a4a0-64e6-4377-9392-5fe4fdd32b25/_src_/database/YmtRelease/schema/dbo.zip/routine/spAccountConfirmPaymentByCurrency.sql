
-- =============================================
-- Author:		Kevin
-- Create date: 2015-3-5
-- Description:	支持多币种，资金操作SP化，事务死锁的快速解决方案
-- Change log:
-- 2015-10-16 移除截面账减少锁定时长，同时去掉中间账户逻辑 By Jmtek
-- =============================================
CREATE PROCEDURE [dbo].[spAccountConfirmPaymentByCurrency]
	@userId			int,				--收款方账号
	@payAmount		decimal(10, 2),		--付款金额
	@operator		varchar(50),		--资金科目
	@useage			varchar(50),		--付款凭据
	@memo			varchar(200),		--备注
	@currency		int = 1,			--币种
	@clearAmount	decimal(10,2) = 0	--结算金额
AS
Declare
	@TransferAccountUserId	int,
	@DefaultCurrency		int
BEGIN
	--SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
	--BEGIN TRANSACTION

	Set @TransferAccountUserId = -1
	SET @DefaultCurrency = 1		--默认币种 RMB
	
	--更新用户账户余额开始
	If @currency = 1
		Begin
			Update Ymt_AccountInfo Set fFreezeAmount = fFreezeAmount - @payAmount, fAvailAmount = fAvailAmount + @payAmount Where iUserId = @userId And iCurrencyType = @currency

			--取消冻结的资金流水
			Insert Into Ymt_AccountRunningTally 
			([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
			Select NewId(), -@payAmount, 1, @userId, 0, 0, 0, getdate(), @operator, @useage, @memo, @currency, @payAmount
			--Select NewId(), -@payAmount, 1, @userId, fBalance, fFreezeAmount + @payAmount, fAvailAmount, getdate(), @operator, @useage, @memo, @currency, @payAmount
			--From Ymt_AccountInfo with(rowlock)
			--Where iUserId = @userId AND iCurrencyType = @currency
	
			--确认入账的资金流水
			Insert Into Ymt_AccountRunningTally 
			([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
			Select NewId(), @payAmount, 2, @userId, 0, 0, 0, getdate(), @operator, @useage, @memo, @currency, @payAmount
			--Select NewId(), @payAmount, 2, @userId, fBalance, fFreezeAmount, fAvailAmount - @payAmount, getdate(), @operator, @useage, @memo, @currency, @payAmount
			--From Ymt_AccountInfo with(rowlock)
			--Where iUserId = @userId AND iCurrencyType = @currency
		End
	Else  -- 以结算金额更新对应的币种账户的账户余额
		Begin
			Update Ymt_AccountInfo Set fFreezeAmount = fFreezeAmount - @clearAmount, fAvailAmount = fAvailAmount + @clearAmount Where iUserId = @userId And iCurrencyType = @currency

			--取消冻结的资金流水
			Insert Into Ymt_AccountRunningTally 
			([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
			Select NewId(), -@clearAmount, 1, @userId, 0, 0, 0, getdate(), @operator, @useage, @memo, @currency, @payAmount
			--Select NewId(), -@clearAmount, 1, @userId, fBalance, fFreezeAmount + @clearAmount, fAvailAmount, getdate(), @operator, @useage, @memo, @currency, @payAmount
			--From Ymt_AccountInfo with(rowlock)
			--Where iUserId = @userId AND iCurrencyType = @currency
	
			--确认入账的资金流水
			Insert Into Ymt_AccountRunningTally 
			([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
			Select NewId(), @clearAmount, 2, @userId, 0, 0, 0, getdate(), @operator, @useage, @memo, @currency, @payAmount
			--Select NewId(), @clearAmount, 2, @userId, fBalance, fFreezeAmount, fAvailAmount - @clearAmount, getdate(), @operator, @useage, @memo, @currency, @payAmount
			--From Ymt_AccountInfo with(rowlock)
			--Where iUserId = @userId AND iCurrencyType = @currency
		End
	--更新用户账户余额结束

	/*
	--更新担保账户余额
	Update Ymt_AccountInfo Set fAvailAmount = fAvailAmount - @payAmount Where iUserId = @TransferAccountUserId AND iCurrencyType = @DefaultCurrency
	--担保账户资金流水
	Insert Into Ymt_AccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
	Select NewId(), -@payAmount, 2, @TransferAccountUserId, fBalance, fFreezeAmount, fAvailAmount + @payAmount, getdate(), @operator, @useage, @memo, @DefaultCurrency, @payAmount 
	From Ymt_AccountInfo with(rowlock)
	Where iUserId = @TransferAccountUserId AND iCurrencyType = @DefaultCurrency
	*/
	
	--COMMIT TRANSACTION
END


