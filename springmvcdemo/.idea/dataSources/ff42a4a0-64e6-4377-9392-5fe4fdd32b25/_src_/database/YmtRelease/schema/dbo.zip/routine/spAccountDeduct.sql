
 
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spAccountDeduct] 
	-- Add the parameters for the stored procedure here
	--<@Param1, sysname, @p1> <Datatype_For_Param1, , int> = <Default_Value_For_Param1, , 0>, 
	--<@Param2, sysname, @p2> <Datatype_For_Param2, , int> = <Default_Value_For_Param2, , 0>
@userloginid varchar(200),--用户登录id	
 @amount decimal(8,2),	--扣款金额(单位:人民币元)
@operator varchar(200),--操作类型,例如 物流扣款
@usage varchar(max),--用途,一般为订单号,流水之类,
 @memo varchar(max),--备注,保留
 @addtime datetime,--添加时间
	@result int=0 out,--返回值,1表示成功,非1 表示失败
	@message varchar(max) out--错误消息

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
set @result=0
set @message=''
--get user id
--declare @userloginid varchar(50)='lotosbin'
if @amount<=0.0 begin
--金额不能小于等于0
 set @result=0
 set @message='金额不能小于等于0'
end 
else begin
--用户不存在
declare @userexist int
declare @userid int
select   @userexist=count(*),@userid=min(u.iUserId) from  ymt_users u where u.sloginid=@userloginid
--print @userid
if	@userexist<=0  begin
 set @result=0
 set @message='用户不存在'
end
else begin
--检查可用资金是否足够
declare @availamount decimal(8,2)
select @availamount=Convert(decimal(8,2),ai.fAvailAmount) from Ymt_AccountInfo ai join Ymt_Users u on ai.iUserId=u.iUserId where u.iUserId=@userid
if @availamount is null or convert(decimal(8,2),@availamount)<@amount begin
--print @availamount
 set @result=0
 set @message='余额不足'
end 
else begin
--插入流水
INSERT INTO [Ymt_AccountRunningTally]
		   ([sRunningTallyId]
		   ,[fOccurredAmount]
		   ,[iType]
		   ,[iUserId]
		   ,[fBalance]
		   ,[fFreezeAmount]
		   ,[fAvailAmount]
		   ,[dAddTime]
		   ,[sOperator]
		   ,[sUseage])
	 VALUES
		   (NEWID()
		   ,@amount*-1
		   ,2--可用资金
		   ,@userid
		   ,0
		   ,0
		   ,0
		   ,@addtime
		   ,@operator
		   ,@usage)
--更新用户帐户
UPDATE Ymt_AccountInfo SET fAvailAmount = (SELECT SUM(fOccurredAmount) FROM Ymt_AccountRunningTally WHERE iType in (2, 3) and iUserId =@userid) WHERE iUserId =@userid 
UPDATE Ymt_AccountInfo SET fAvailAmount=0   WHERE iUserId =@userid AND fAvailAmount IS NULL 
UPDATE Ymt_AccountInfo SET fFreezeAmount = (SELECT SUM(fOccurredAmount) FROM Ymt_AccountRunningTally WHERE iType=1 and iUserId =@userid) WHERE iUserId =@userid
UPDATE Ymt_AccountInfo SET fFreezeAmount = 0  WHERE iUserId =@userid AND fFreezeAmount IS NULL
UPDATE Ymt_AccountInfo SET fBalance = fAvailAmount + fFreezeAmount WHERE iUserId =@userid 
set @result=1

end--if @availamount<=@amount begin
end --if	@userexist<=0  begin
end --if @amount<=0 begin
SELECT @result as result,@message as message
end --ALTER PROCEDURE
	
