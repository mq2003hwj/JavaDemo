/**********************************************
**** Author:		Rain.Xiao              ****
**** Create date:   2015-10-14             ****
**** Description:	PK赛投票存储过程       ****
**********************************************/
CREATE PROC SP_PKGameVote
  @iUserId INT,
  @sPKId VARCHAR(36),
  @sVoteProductId VARCHAR(36),
  @iPointNumber INT
AS
  BEGIN TRAN
   BEGIN TRY
    DECLARE @RId VARCHAR(36),@BId VARCHAR(36)
	SELECT @RId=sRedProductId,@BId=sBlueProductId FROM Ymt_PKGame WHERE sPKId=@sPKId
    INSERT INTO Ymt_PKGameVotes(iUserId,sPKId,sVoteProductId) VALUES(@iUserId,@sPKId,@sVoteProductId)
	INSERT INTO Ymt_PKGamePoint(iUserId,iPointNumber,iPointType) VALUES(@iUserId,@iPointNumber,1)
	IF @RId=@sVoteProductId
	BEGIN
	 UPDATE Ymt_PKGame SET iRedNumberOfVotes=iRedNumberOfVotes+1 WHERE sPKId=@sPKId
	END
	ELSE IF @BId=@sVoteProductId
	BEGIN
	 UPDATE Ymt_PKGame SET iBlueNumberOfVotes=iBlueNumberOfVotes+1 WHERE sPKId=@sPKId
	END
   END TRY
   BEGIN CATCH
      SELECT
	   ERROR_NUMBER() AS ErrorNumber,
       ERROR_SEVERITY() AS ErrorSeverity,
       ERROR_STATE() as ErrorState,
	   ERROR_PROCEDURE() as ErrorProcedure,
	   ERROR_LINE() as ErrorLine,
	   ERROR_MESSAGE() as ErrorMessage;
     IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
   END CATCH
   IF @@TRANCOUNT > 0
    COMMIT TRANSACTION