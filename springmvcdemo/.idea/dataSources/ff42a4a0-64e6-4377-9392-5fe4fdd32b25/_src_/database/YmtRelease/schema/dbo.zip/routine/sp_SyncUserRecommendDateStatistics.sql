
-- =============================================
-- Author:		adu
-- Create date: 2015-06-11
-- Description:	同步用户推荐统计数
-- =============================================
CREATE PROCEDURE [dbo].[sp_SyncUserRecommendDateStatistics]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	 
    --统计有户推荐数
    select YEAR(dCreatedAt)  AS [Year],MONTH(dCreatedAt) AS [Month],DAY(dCreatedAt) AS [Day],	
	  COUNT(iActivityRecordId) as RecommendCount 
    INTO #temp1
	from dbo.Ymt_UserRecommendActivityRecord 
	WHERE iOrderId IS NOT NULL AND fGiftAmount IS NOT NULL
	group by YEAR(dCreatedAt),MONTH(dCreatedAt),DAY(dCreatedAt)

	--SELECT * FROM #temp1
	--DROP TABLE #temp1

	--清空旧的按日期统计用户推荐数据
	TRUNCATE TABLE Ymt_UserRecommendDateStatistics

	--更新用户推荐中已经存在的用户推荐统计数
	--UPDATE dbo.Ymt_UserRecommendDateStatistics SET RecommendCount=#temp1.RecommendCount,UpdateTime=GETDATE()
	--FROM #temp1 
	--WHERE #temp1.Year=Ymt_UserRecommendDateStatistics.YEAR AND #temp1.Month=Ymt_UserRecommendDateStatistics.Month AND #temp1.Day=Ymt_UserRecommendDateStatistics.Day

	--找出临时表中有但在统计表中没有统计记录插入表中
	INSERT Ymt_UserRecommendDateStatistics
	(
		Year,
		Month,
		Day,
		RecommendCount,
		AddTime,
		UpdateTime
	)
	SELECT Year,Month,Day,RecommendCount,GETDATE() AS AddTime,GETDATE() AS UpdateTime 
	FROM #temp1
	
END

