
-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-10-9
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetBuyerOrders]

@orderId int,
@userId int,
@orderNum int,
@lastOrderId int,
@orderStatusUsingMethod int,
@orderStatusXml xml,
@refundedOrderOnly bit

AS

-------------variables-------------
declare @tTradingStatus table([value] int)

--------------process--------------
if @orderStatusUsingMethod > 0
begin
    insert into @tTradingStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

--set statistics io on;set statistics time on;

if @orderId > 0 begin

  select o.iOrderId, o.iUserId,o.dAddTime,o.fOrderPrice,o.fOrderDiscount,o.fAutoCancelOrderHours,o.iTradingStatus,o.fUseGiftAmount,o.sLeaveWord,o.iBuyerId,o.dDispathTime,o.bPaidInFull,o.fFreight,o.dConfirmedTime
    ,o.bCanLocalReturn,o.dApplyLocalReturnTime,o.sAddress, o.fTotalPrice,c.sId as IdCardUploadedKey,e.bIsNeedUploadIdCard,e.sOrderSource,e.iOrderType
    ,oi.iAmount,oi.sProductId,oi.sPropertyInfo,oi.iCatalogStatus,oi.iPriceType,oi.sTitle,oi.sPictureUrl,oi.fOriginalPrice,oi.iBondedArea
    ,ie.iActivityId
    ,frozen.dFrozenTime,frozen.iUserId as iFrozenUserId
	,p.fAmount as postpayAmount,p.fUseGiftAmount as postpayUseGiftAmount
	,o.iThirdPartyRefundStatus
  from Ymt_Orders(nolock) o 
  join Ymt_OrderInfo(nolock) oi on o.iOrderId = oi.iOrderId
  left join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId
  left join Ymt_OrderInfoExt(nolock) ie on oi.sOrderInfoId = ie.sOrderInfoId
  left join Ymt_Order_Frozen(nolock) frozen on frozen.iOrderId = o.iOrderId
  left join Ymt_IdPic(nolock) c on o.iUserId = c.iUserId and o.sReceivePerson = c.sName and e.bIsNeedUploadIdCard = 1
  left join Ymt_OrderPostPay(nolock) p on o.iOrderId = p.iOrderId and p.iAction = 0
  where o.iOrderId = @orderId and (o.iUserId = @userId or o.iBuyerId = @userId)

end else begin

  select top (@orderNum) o.iOrderId, o.iUserId,o.dAddTime,o.fOrderPrice,o.fOrderDiscount,o.fAutoCancelOrderHours,o.iTradingStatus,o.fUseGiftAmount,o.sLeaveWord,o.iBuyerId,o.dDispathTime,o.bPaidInFull,o.fFreight,o.dConfirmedTime
    ,o.bCanLocalReturn,o.dApplyLocalReturnTime,o.sAddress, o.fTotalPrice,c.sId as IdCardUploadedKey,e.bIsNeedUploadIdCard,e.sOrderSource,e.iOrderType
    ,oi.iAmount,oi.sProductId,oi.sPropertyInfo,oi.iCatalogStatus,oi.iPriceType,oi.sTitle,oi.sPictureUrl,oi.fOriginalPrice,oi.iBondedArea
    ,ie.iActivityId
    ,frozen.dFrozenTime,frozen.iUserId as iFrozenUserId
	,p.fAmount as postpayAmount,p.fUseGiftAmount as postpayUseGiftAmount
	,o.iThirdPartyRefundStatus
  from Ymt_Orders(nolock) o 
  join Ymt_OrderInfo(nolock) oi on o.iOrderId = oi.iOrderId
  left join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId
  left join Ymt_OrderInfoExt(nolock) ie on oi.sOrderInfoId = ie.sOrderInfoId
  left join Ymt_Order_Frozen(nolock) frozen on frozen.iOrderId = o.iOrderId
  left join Ymt_IdPic(nolock) c on o.iUserId = c.iUserId and o.sReceivePerson = c.sName and e.bIsNeedUploadIdCard = 1
  left join Ymt_OrderPostPay(nolock) p on o.iOrderId = p.iOrderId and p.iAction = 0
  where 
  o.iUserId = @userId
  and (o.bShangouOrder = 1 or e.sOrderSource in ('C2CAPP','C2CWAP','C2CWechat'))
  and(
    @orderStatusUsingMethod =0 or (
       (@orderStatusUsingMethod=1 and (o.iTradingStatus=17 and o.bPaidInFull=1))
    or (@orderStatusUsingMethod=2 and (o.iTradingStatus=17 and o.bPaidInFull=0))
    or o.iTradingStatus in (select [value] from @tTradingStatus)
    )
  )
  and (@lastOrderId=0 or o.iOrderId < @lastOrderId)
  and (@refundedOrderOnly = 0 or o.dApplyLocalReturnTime is not null)
  order by o.iOrderId desc
end

--set statistics io off;set statistics time off;

