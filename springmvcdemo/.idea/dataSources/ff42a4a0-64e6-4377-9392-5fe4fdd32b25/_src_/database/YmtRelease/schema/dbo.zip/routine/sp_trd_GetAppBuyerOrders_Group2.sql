-- =============================================

-- Author:  fanwei

-- Create date: 2016-6-23

-- Description: 交易服务SP

-- Update date: 2016-11-28

-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetAppBuyerOrders_Group2]



@userId int,



@orderNum int,



@lastOrderId int,



@orderStatusUsingMethod int,



@orderStatusXml xml = null,



@refundedOrderOnly int = 0,



@evaluatedDays int = null,



@lastOrderIdIsRealOrderId bit = 0,



@orderStatus Int32Array READONLY,



@productId varchar(36) = null,



@title varchar(200) = null



AS



-------------variables-------------



declare @tTradingStatus table([value] int)







declare @exsitsShippedStatus bit = 0



declare @exsitsReceivedStatus bit = 0







declare @considerShippedStatus bit = 0



declare @considerReceivedStatus bit = 0



declare @considerRestStatus bit = 1



declare @considerProductId bit = 0

declare @considerTitle bit = 0



--------------process--------------



if @orderStatusUsingMethod > 0



begin



	if @orderStatusXml is not null



		begin



		insert into @tTradingStatus



		select tbl.col.value('@s','int')



		from @orderStatusXml.nodes('/root/x') tbl(col)



	end



	else begin



		insert into @tTradingStatus select [value] from @orderStatus



	end



end







--set statistics io on;set statistics time on;















if exists(select top 1 1 from @tTradingStatus where [value] = 3) begin



  set  @exsitsShippedStatus = 1



end







if exists(select top 1 1 from @tTradingStatus where [value] = 4) begin



  set  @exsitsReceivedStatus = 1



end



IF @productId is not null and @productId <> ''

BEGIN

	set @considerProductId = 1

END

IF @title is not null and @title <> ''

BEGIN

	set @considerTitle = 1

END





if not (@exsitsShippedStatus = 1 and @exsitsReceivedStatus = 1) begin



  if @exsitsShippedStatus = 1 begin



    delete @tTradingStatus where [value] = 3



    set @considerShippedStatus = 1



    select @considerRestStatus = case when count(*)>0 then 1 else 0 end from @tTradingStatus



  end







  if @exsitsReceivedStatus = 1 begin



    delete @tTradingStatus where [value] = 4



    set @considerReceivedStatus = 1



    select @considerRestStatus = case when count(*)>0 then 1 else 0 end from @tTradingStatus



  end



end







declare @evaluatedDateBase datetime = null



if @evaluatedDays is not null begin



  set @evaluatedDateBase = getdate() - @evaluatedDays



end







declare @maxCount int;



set @maxCount = @orderNum * 10;







declare @orderGroupId int = 0



declare @orderGroups table(groupId int, id int, refund int);







if isnull(@lastOrderId, 0) <> 0 begin







	if @lastOrderIdIsRealOrderId = 1 begin







		select @orderGroupId = iMainOrderId from Ymt_Orders(nolock) where iOrderId = @lastOrderId



	end else begin







		set @orderGroupId = @lastOrderId



	end







end



IF(@considerProductId = 1 or @considerTitle = 1)

BEGIN

		insert into @orderGroups

		select top (@maxCount) o.iMainOrderId, o.iOrderId, o.iSalesRefundStatus from Ymt_Orders(nolock) o

		join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId

		join Ymt_OrderInfo(nolock) oi  on o.iorderid=oi.iorderid

		where o.iUserId = @userId

		and(@orderStatusUsingMethod =0 or ((@orderStatusUsingMethod=1 and (o.iTradingStatus=17 and o.bPaidInFull=1))

		or(@orderStatusUsingMethod=2 and (o.iTradingStatus=17 and o.bPaidInFull=0)) or ((@considerShippedStatus = 1 and o.iTradingStatus = 3)

		 or (@considerReceivedStatus = 1 and o.iTradingStatus = 4) or (@considerRestStatus = 1 and o.iTradingStatus in (select [value] from @tTradingStatus))))

		)

		and (@orderGroupId = 0 or o.iMainOrderId < @orderGroupId)

		and (@refundedOrderOnly = 0 or (@refundedOrderOnly = 1 and o.dApplyLocalReturnTime is not null) or (@refundedOrderOnly = 2 and o.iSalesRefundStatus is not null))

		and (@evaluatedDateBase is null or (o.iTradingStatus = 4 and isnull(o.bEvaluated, 0) = 0 and @evaluatedDateBase < o.dConfirmedTime))

		and o.bDeleted is null

		and (@considerProductId = 0 or oi.sProductId=@productId)

		and (@considerTitle = 0 or oi.sTitle like '%'+@title+'%')

		order by o.iMainOrderId desc

END

ELSE

BEGIN

		insert into @orderGroups

		select top (@maxCount) o.iMainOrderId, o.iOrderId, o.iSalesRefundStatus from Ymt_Orders(nolock) o

		join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId

		where o.iUserId = @userId



		and(@orderStatusUsingMethod =0 or ((@orderStatusUsingMethod=1 and (o.iTradingStatus=17 and o.bPaidInFull=1))

		or(@orderStatusUsingMethod=2 and (o.iTradingStatus=17 and o.bPaidInFull=0)) or ((@considerShippedStatus = 1 and o.iTradingStatus = 3)

		 or (@considerReceivedStatus = 1 and o.iTradingStatus = 4) or (@considerRestStatus = 1 and o.iTradingStatus in (select [value] from @tTradingStatus))))

		)

		and (@orderGroupId = 0 or o.iMainOrderId < @orderGroupId)

		and (@refundedOrderOnly = 0 or (@refundedOrderOnly = 1 and o.dApplyLocalReturnTime is not null) or (@refundedOrderOnly = 2 and o.iSalesRefundStatus is not null))

		and (@evaluatedDateBase is null or (o.iTradingStatus = 4 and isnull(o.bEvaluated, 0) = 0 and @evaluatedDateBase < o.dConfirmedTime))

		and o.bDeleted is null

		order by o.iMainOrderId desc

END











declare @orderIds table(id int, refund int);



insert into @orderIds



select id, refund from @orderGroups where groupId in (select top (@orderNum) groupId from @orderGroups group by groupId order by groupId desc)











select o.iMainOrderId,o.iOrderId,o.iTradingId,o.iUserId,o.sBuyerLoginId,o.dAddTime,o.fOrderPrice,o.fOrderDiscount,o.fAutoCancelOrderHours,bEvaluated



  ,iTradingStatus



  ,o.fUseGiftAmount,o.sLeaveWord,o.iBuyerId,o.dDispathTime,o.bPaidInFull,o.fFreight,o.dConfirmedTime



  ,o.sReceivePerson,o.sAddress,o.sPostCode,o.sPhone,o.sTelephone



  ,o.bCanLocalReturn,o.dApplyLocalReturnTime, o.fTotalPrice,e.bIsNeedUploadIdCard,e.sOrderSource,e.iOrderType 
  ,CASE when isnull(e.bDeliveredOfChina,0) = 1 then 1 ELSE e.bHaveUploadedIdCard END AS bHaveUploadedIdCard


  ,o.bShangouOrder


  ,o.iThirdPartyRefundStatus



  ,o.sSellerLoginId



  ,o.CouponValue,o.iCouponChannel,o.sCouponCode,o.sYmtCouponCode,o.sSellerCouponCode,o.fYmtCouponAmount,o.fSellerCouponAmount


  ,frozen.dFrozenTime,frozen.iUserId as iFrozenUserId,frozen.bFrozen,frozen.bFrozenAutoReceive,frozen.bPause



  ,(select top 1 concat(p.fAmount,'|',p.fUseGiftAmount) from Ymt_OrderPostPay(nolock) p where p.iOrderId = o.iOrderId and (p.iAction = 0 or p.iAction = 1) order by p.iAction desc) postpayAccountAndGiftInfo



    ,s.*



  ,o.iSalesRefundStatus,o.dPaidTime,o.dAcceptTime,o.dPostPaidTime



  ,0 AS 'iProcessStatus'



  ,o.fSellerPromotionAmount



  ,o.bCanEvaluate



from Ymt_Orders(nolock) o



left join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId



left join Ymt_Order_Frozen(nolock) frozen on frozen.iOrderId = o.iOrderId



left join Ymt_OrderState(nolock) s on o.iOrderId = s.iOrderId



where o.iOrderId in (select id from @orderIds)



order by o.iMainOrderId desc, o.sSellerCouponCode desc







if @@ROWCOUNT > 0 begin



  select oi.iOrderId,oi.iAmount,oi.sProductId,oi.sPropertyInfo,oi.sCatalogId,oi.iCatalogStatus,oi.iPriceType,oi.sTitle,oi.sPictureUrl,oi.fOriginalPrice,oi.iBondedArea,oi.iTariffType



  ,oi.iProductRefundChannel,oi.iProductRefundStatus,oi.sPackageNo,oi.sProductInfo,oi.fYmtCouponAmount,oi.fSellerCouponAmount,oi.iSalesType,oi.fProductPrice,oi.fProductOriginalPrice



  ,ie.iActivityId



  ,oi.fSellerPromotionAmount, oi.bSupportRtnWithoutReason, oi.bFreightFree



  ,sp.PromotionId,sp.PromotionName,sp.PromotionType,sp.MatchCondition,sp.PromotionValue,sp.ReducedAmount



  ,oi.bPreSale



  from Ymt_OrderInfo(nolock) oi



  left join Ymt_OrderInfoExt(nolock) ie on oi.sOrderInfoId = ie.sOrderInfoId



  left join Ymt_SellerPromotion(nolock) sp on sp.OrderInfoId = oi.sOrderInfoId



  where oi.iOrderId in (select id from @orderIds)







  select * from Ymt_RefundBill(nolock) where OrderId in (select id from @orderIds where refund is not null)



end







--set statistics io off;set statistics time off;
