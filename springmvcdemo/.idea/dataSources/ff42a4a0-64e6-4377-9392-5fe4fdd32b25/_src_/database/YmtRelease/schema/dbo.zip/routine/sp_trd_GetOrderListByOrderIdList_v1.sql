
-- =============================================            

-- Author:  zhangyifan      

-- From [sp_trd_GetOrderListByOrderIdList]

-- Create date: 2016-9-9

-- Description: 交易服务SP       

-- 20160717：获取订单商品详情列表新增字段

-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetOrderListByOrderIdList_v1]

@sellerId int,

@orderIds Int32Array READONLY


AS

-------------variables-------------

declare @orderTradingIds table(orderId int not null, tradingId int not null, virtualTime datetime not null)


declare @rowCount int = 0;



--------------process--------------

--set statistics time on;set statistics io on;

   

set nocount off;

--print 'ymt_orders';

select * from ymt_orders(nolock) where iBuyerId = @sellerId and iOrderId in (select [Value] from @orderIds) order by iOrderId asc

set @rowCount = @@ROWCOUNT;

set nocount on;



--print 'ymt_orderext';

select iOrderId,iOrderType,sOrderSource,[bIsNeedUploadIdCard], [bHaveUploadedIdCard] from Ymt_OrderExt(nolock) where @rowCount > 0 and iOrderId in (select [Value] from @orderIds) 



--print 'ymt_o_ordernote'

--获取备注列表  

select iOrderId,sContent,[iRemarkLevel] from Ymt_O_OrderNote(nolock) where @rowCount > 0 and iorderid in (select [Value] from @orderIds)  



--print 'ymt_orderstate'

--获取订单金额详情列表  ymt_orderinfo

select * from Ymt_OrderState(nolock) where @rowCount > 0 and  iorderid in (select [Value] from @orderIds)  



--print 'ymt_orderpostpay'

--获取订单补款列表  

select iOrderId,fAmount,fUseGiftAmount from Ymt_OrderPostPay(nolock) where @rowCount > 0 and  iorderid in (select [Value] from @orderIds)



--获取订单商品详情列表

--print 'ymt_orderinfo'

select

	i.[iOrderId] , i.sOrderInfoId , i.fOriginalPrice , i.iPriceType , i.iAmount , i.iBondedArea , i.iCatalogStatus , i.iCatalogType , i.iProductSubCategoryId

	, i.iSailProtected , i.iType , i.sCatalogId , i.sDescription , i.sPictureUrl , i.sProductId , i.sPropertyInfo , i.sReferenceUrl , i.sSKU , i.sTitle 

	, e.sOrderInfoId as sOrderInfoExtId , e.bGiftAvail4Reward , e.iActivityId , e.iActivityTemplateId , i.iSalesType

	, i.fProductPrice , i.fProductOriginalPrice , i.fSellerCouponAmount , i.fYmtCouponAmount , i.fDiscount , i.fFreight

	, i.[fSellerPromotionAmount] , s.[PromotionId] , s.[PromotionType] , s.[PromotionName] , s.[MatchCondition] , s.[PromotionValue]

	, s.ReducedAmount , i.bSupportRtnWithoutReason,i.bPreSale,fThirdPartyDiscount

from [dbo].[Ymt_OrderInfo] as i with(nolock) 

inner join @orderIds as o on i.[iOrderId] = o.[Value]

left join [dbo].[Ymt_OrderInfoExt] as e with(nolock) on i.[sOrderInfoId] = e.[sOrderInfoId]

left join [dbo].[Ymt_SellerPromotion] as s with(nolock) on i.[iOrderId] = s.[OrderId] and i.[sOrderInfoId] = s.[OrderInfoId]

where @rowCount > 0 ;



--print 'ymt_ordersummary'

--获取订单物流信息  

select iOrderId, iBillType, sSummary from Ymt_OrderSummary(nolock) where @rowCount > 0 and iorderid in (select [Value] from @orderIds)  



--print 'ymt_order_frozen'

--获取订单冻结信息  

select * from Ymt_Order_Frozen(nolock) where @rowCount > 0 and  iorderid in (select [Value] from @orderIds)  



--print 'orderTradingId'

--订单有效的交易ID  

if @rowCount > 0 begin

  insert into @orderTradingIds select iOrderId, iTradingId, dUpdateTime from Ymt_TradingItem(nolock) where iOrderId in (select [Value] from @orderIds)

  update @orderTradingIds set virtualTime = '9999-1-1' where tradingId in (select iTradingId from Ymt_TradingInfo(nolock) where iTradingId in (select tradingId from @orderTradingIds) and iTradingStatus = 2)

  ;with t as(

    select ROW_NUMBER() over(partition by orderId order by virtualTime desc) as n, orderId, tradingId from @orderTradingIds

  ) 

  select orderId as iOrderId, tradingId as iTradingId from t where n = 1 order by orderId;

end

else begin

  select top 0 0 as iOrderId, 0 as iTradingId ;

end



set nocount off;



--set statistics time off;set statistics io off;


