CREATE VIEW dbo.View_AccountInfo
AS
SELECT     dbo.Ymt_AccountInfo.*, dbo.Ymt_Users.sLoginId
FROM         dbo.Ymt_AccountInfo INNER JOIN
                      dbo.Ymt_Users ON dbo.Ymt_AccountInfo.iUserId = dbo.Ymt_Users.iUserId
