
-- =============================================            
-- Author:  Deng Peng        
-- Create date: 2016-06-16
-- Last-modified: 2016-06-22
-- Description: 导出订单信息：通过订单列表
-- 20160622：添加iRemarkLevel的输出
-- =============================================
create procedure  [dbo].[sp_trd_GetExportOrderInfoByOrderIds_v1]
	@orderIds Int32Array readonly,
	@sellerId int
as 

set nocount on;

declare @rowCount int 
set @rowCount = (select count(1) from @orderIds)

--Orders Detailed Information
-------------------------------------------------------------------------------------------------
select [iOrderId] , [fFreight] , [fOrderPrice] , [iTradingStatus] , [iRiskVerifiedStatus] , [bPaidInFull] 
	, [dAddTime] , [dPaidTime] , [dApplyPostPayTime] , [dDispathTime] , [sLeaveWord] , [sBuyerLoginId] 
	, [sReceivePerson] , [sPhone] , [sTelephone] , [sAddress] , [sPostCode] , [bShangouOrder] 
	, [bDomesticDelivered] , [dPostPaidTime]
from [dbo].[Ymt_Orders] as [order] with(nolock) 
inner join @orderIds as [listid] on [order].[iOrderId] = [listid].[Value]
where @rowCount > 0

--Products Detailed Information
-------------------------------------------------------------------------------------------------
select [iOrderId] , [iCatalogStatus] , [iCatalogType] , [sTitle] , [iAmount] , [fOriginalPrice] 
	, [sSKU] , [sPropertyInfo] , [iCatalogStatus] , [iCatalogType] , [iBondedArea]
	, [sCatalogId] = case when sCatalogId is null then null else '1' end  
from [dbo].[Ymt_OrderInfo] as [product] with(nolock)
inner join @orderIds as [listid] on [product].[iOrderId] = [listid].[Value]
where @rowCount > 0

--Orders Note Detailed Information
-------------------------------------------------------------------------------------------------
select [note].[iOrderId] , [note].[sContent], [note].[iRemarkLevel]
from [dbo].[Ymt_O_OrderNote] as [note] with(nolock) 
inner join @orderIds as [listid] on [note].[iOrderId] = [listid].[Value]
where @rowCount > 0 and iuserid = @sellerId

--Orders State Detailed Information
-------------------------------------------------------------------------------------------------
select [state].* 
from [dbo].[Ymt_OrderState] as [state] with(nolock) 
inner join @orderIds as [listid] on [state].[iOrderId] = [listid].[Value]
where @rowCount > 0

--获取订单物流信息
-------------------------------------------------------------------------------------------------
select [iOrderId] , [sLogisticsProvider] , [sSummary]
from [dbo].[Ymt_OrderSummary] as [summary] with(nolock) 
inner join @orderIds as [listid] on [summary].[iOrderId] = [listid].[Value]
where @rowCount > 0

set nocount off;