-- =============================================            

-- Author:  fanwei        

-- Create date: 2015-5-20

-- Description: 交易服务SP       

-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetAppBuyerOrder]


@id int,

@userId int,

@group bit = false

AS

-------------variables-------------



declare @orderIds table(id int)



--------------process--------------



if @group = 1 begin



  insert into @orderIds select iorderid from ymt_orders(nolock) where iMainOrderId = @id



end else begin

    insert into @orderIds values (@id)

end

--set statistics io on;set statistics time on;

select o.iMainOrderId,o.iOrderId,o.iTradingId,o.iUserId,o.sBuyerLoginId,o.dAddTime,o.fOrderPrice,o.fOrderDiscount,o.fAutoCancelOrderHours,bEvaluated



  ,case when r.iProcessStatus is null then o.iTradingStatus when r.iProcessStatus = 0 then 3 else o.iTradingStatus end as iTradingStatus



  ,o.fUseGiftAmount,o.sLeaveWord,o.iBuyerId,o.dDispathTime,o.bPaidInFull,o.fFreight,o.dConfirmedTime



  ,o.sReceivePerson,o.sAddress,o.sPostCode,o.sPhone,o.sTelephone



  ,o.bCanLocalReturn,o.dApplyLocalReturnTime, o.fTotalPrice,e.bIsNeedUploadIdCard,e.sOrderSource,e.iOrderType
  ,CASE when isnull(e.bDeliveredOfChina,0) = 1 then 1 ELSE e.bHaveUploadedIdCard END AS bHaveUploadedIdCard

  ,o.bShangouOrder

  ,frozen.dFrozenTime,frozen.iUserId as iFrozenUserId,frozen.bFrozen,frozen.bFrozenAutoReceive,frozen.bPause

  ,p.fAmount as postpayAmount,p.fUseGiftAmount as postpayUseGiftAmount


  ,o.iThirdPartyRefundStatus


  ,o.sSellerLoginId



  ,o.CouponValue,o.iCouponChannel,o.sCouponCode,o.sYmtCouponCode,o.sSellerCouponCode,o.fYmtCouponAmount,o.fSellerCouponAmount


  ,n.sContent as sellerNote



  ,(select top 1 sReason from Ymt_OrderReason(nolock) where iOrderId = o.iOrderId) as sReason



  ,s.*



  ,o.iSalesRefundStatus,o.dPaidTime,o.dAcceptTime,o.dPostPaidTime,o.bPreSale,o.bCanEvaluate



  --,(select top 1 [sId] from Ymt_IdPic(nolock) c where o.iUserId = c.iUserId and o.sReceivePerson = c.sName and e.bIsNeedUploadIdCard = 1) as IdCardUploadedKey



  ,(select top 1 concat(IIF(isnull(s.fPaidAmountOfThirdParty, 0) > 0, s.fPaidAmountOfThirdParty, fAmount),'|',sPayChannel) from ymt_tradinginfo(nolock) where s.fPaidAmountOfCash > 0 and iTradingId = o.iTradingId and iTradingStatus = 2) as ThirdPartyPaidInfo



  ,(select top 1 concat(IIF(isnull(s.fPostPaidAmountOfThirdParty, 0) > 0, s.fPostPaidAmountOfThirdParty, Amount),'|',p.sPayChannel) from Ymt_PostPayTradingInfo(nolock) where s.fPostPaidAmountOfCash > 0 and p.iAction = 1 and PostPayTradingId = p.sPostPayTradingId and OrderId = o.iorderId and iAction = 1) as ThirdPartyPostpaidInfo



  ,o.fSellerPromotionAmount



from Ymt_Orders(nolock) o



left join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId



left join Ymt_Order_Frozen(nolock) frozen on frozen.iOrderId = o.iOrderId



left join Ymt_O_OrderNote(nolock) n on o.iOrderId = n.iOrderId and o.iBuyerId = n.iUserId



left join Ymt_OrderState(nolock) s on o.iOrderId = s.iOrderId



left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId



outer apply (select top 1 fAmount,fUseGiftAmount,iAction,sPostPayTradingId,sPayChannel from Ymt_OrderPostPay(nolock) where iOrderId = o.iOrderId and (iAction = 0 or iAction = 1) order by iAction desc) p



where o.iOrderId in (select id from @orderIds) and (o.iUserId = @userId or o.iBuyerId = @userId)



--and e.sOrderSource != 'PC'



order by o.sSellerCouponCode desc







if @@ROWCOUNT > 0 begin



  select oi.iOrderId,oi.iAmount,oi.sProductId,oi.sPropertyInfo,oi.iCatalogStatus,oi.sCatalogId,oi.iPriceType,oi.sTitle,oi.sPictureUrl,oi.fOriginalPrice,oi.iBondedArea,oi.iTariffType



  ,oi.iProductRefundChannel,oi.iProductRefundStatus,oi.sProductInfo,oi.fYmtCouponAmount,oi.fSellerCouponAmount,oi.iSalesType,oi.fProductPrice,oi.fProductOriginalPrice



  ,ie.iActivityId



  ,oi.fSellerPromotionAmount, oi.bSupportRtnWithoutReason, oi.bFreightFree,oi.bPreSale,oi.fThirdPartyDiscount



  ,sp.PromotionId,sp.PromotionName,sp.PromotionType,sp.MatchCondition,sp.PromotionValue,sp.ReducedAmount



  from Ymt_OrderInfo(nolock) oi



  left join Ymt_OrderInfoExt(nolock) ie on oi.sOrderInfoId = ie.sOrderInfoId



  left join Ymt_SellerPromotion(nolock) sp on sp.OrderInfoId = oi.sOrderInfoId



  where oi.iOrderId in (select id from @orderIds)


  select * from Ymt_RefundBill(nolock) where OrderId in (select iOrderId from Ymt_Orders(nolock) where iOrderId in (select id from @orderIds) and iSalesRefundStatus is not null)



end


--set statistics io off;set statistics time off;
