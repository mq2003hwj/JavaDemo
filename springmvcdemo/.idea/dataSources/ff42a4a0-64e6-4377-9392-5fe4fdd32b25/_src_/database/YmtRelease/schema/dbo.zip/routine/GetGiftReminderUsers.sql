/****** 
Author : ghu
Create Date:2015.12.18
Description : 获取需要发送站内信的 用户信息（Userid,红包金额,过期时间） 
******/
CREATE PROCEDURE dbo.GetGiftReminderUsers
AS
BEGIN
SELECT 
	iUserId,
	fAvailAmount,
	ExpiredDate
FROM Ymt_GiftAccountInfo
WHERE fAvailAmount > 0
	AND ExpiredDate between cast(getdate() + 3 as date) and cast(getdate() + 4 as date) 
	AND ExpiredDate IS NOT NULL
ORDER BY ExpiredDate DESC
END
