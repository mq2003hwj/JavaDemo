



 -- =============================================
-- Author:		chenfei
-- Create date: 2015-04-29
-- Description:	获取增量下单发送召回的用户
-- =============================================
create proc [dbo].[sp_GetOrderCanCallingUsers]
 @startDate date,
 @endDate date,
 @pageIndex int,--start by 1
 @pageSize int
 as 
 begin
declare @iBeginRow int, @iEndRow int 
--by page
select @iBeginRow = (@pageIndex-1)*@pageSize
select @iEndRow = @pageIndex*@pageSize;
--前第60天下单但至今未下单的user
select * from 
(select ROW_NUMBER() over(order by iUserId desc) as num,[iUserId],(select top 1 sAccountName from Ymt_MobilePhoneAccount mc where mc.iUserId = u2.iUserId) as [sPhone],[dAddtime],[sLoginEmail],(select max(dAddTime)  from Ymt_Orders where dAddTime > @startDate and iUserId = u2.iUserId) as LastOrderTime,2 as UserType,0 as SendStatus,null as SendTime from [Ymt_Users] as u2
where  iType = 0 and  iUserId in ( select iUserId from Ymt_Orders  where dAddTime > @startDate  and dAddTime < @endDate and bShangouOrder = 1 ) 
and  iUserId not in (
select distinct iUserId from Ymt_Orders where dAddTime > @endDate and dAddTime <  CONVERT(varchar(10), GETDATE(), 23) and bShangouOrder = 1
 )) as tb
where num between @iBeginRow and @iEndRow 
 end
