---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- =============================================

-- Author:		adu

-- Create date: 2014-11-24

-- Description:	在码头或是贝海数据找到该人的身份证信息则同步身份证是否有的状态

-- 2015-03-18, 修改从贝海库同步码头身份证同步记录，增加身份证号码， 祝金峰
-- 2015-11-19, 优化更新方式,由游标改为单次批量更新

-- =============================================

CREATE PROCEDURE [dbo].[sp_SyncIdCardState]	

AS

BEGIN
--抓取待更新的订单
	SELECT distinct o.iUserId, o.iOrderId, sReceivePerson, sPhone into #temp1
	from ymt_orders o with(nolock) 
	inner join Ymt_OrderExt oe with(nolock)  on oe.iOrderId=o.iOrderId
	where 	oe.bIsNeedUploadIdCard=1 and iTradingStatus not in (1, 12, 13, 18) 
	and (oe.bHaveUploadedIdCard is null or oe.bHaveUploadedIdCard=0)  And o.dAddTime > getdate() - 21
	Order By o.iOrderId Desc

	if @@ROWCOUNT>0
	begin
		
		select #temp1.*,b.HasPic into #temp2 from #temp1 
		left join Ymt_IdCardinfo as b with(nolock) on b.BuyerId=#temp1.iUserId and b.Name=#temp1.sReceivePerson and b.HasPic=1

		--更新订单上新的身份证状态
		update Ymt_OrderExt set bHaveUploadedIdCard =1 from #temp2
		where  Ymt_OrderExt.iOrderId=#temp2.iOrderId and  #temp2.HasPic=1 

		----更新订单上老的身份证状态
		--insert into Ymt_OrderIdCard
		--SELECT iOrderId, iUserId, 1 from #temp2 where  HasPic=1 and bIdCardUploaded is null


		--update Ymt_OrderIdCard set bIdCardUploaded=1 from #temp2
		-- where  Ymt_OrderIdCard.iOrderId=#temp2.iOrderId and  #temp2.HasPic=1 and #temp2.bIdCardUploaded=0 and #temp2.iUserId=Ymt_OrderIdCard.iUserId
		 

		 ----抓取贝海数据
		 SELECT #temp2.*,A.sRightSideUrl sIdPicRightSide,A.sReverseSideUrl sIdPicReverseSide,sIdCode into #temp3 FROM #temp2
		 JOIN [172.16.101.151].XloboRelease.[dbo].IdMatchPhone B WITH(NOLOCK) ON  B.sPhone = #temp2.sPhone 
		 join [172.16.101.151].XloboRelease.[dbo].IdentityCard A WITH(NOLOCK) on A.Id = B.iIdentityCardId And A.sName = #temp2.sReceivePerson
		 where #temp2.HasPic is null
  
		  if @@ROWCOUNT>0
		  begin
				--更新订单上新的身份证状态
				update Ymt_OrderExt set bHaveUploadedIdCard =1 from #temp3
			    where  Ymt_OrderExt.iOrderId=#temp3.iOrderId

				----更新订单上老的身份证状态
				--insert into Ymt_OrderIdCard
				--SELECT iOrderId, iUserId, 1 from #temp3 where  bIdCardUploaded is null
		
				--update Ymt_OrderIdCard set bIdCardUploaded=1 from #temp3
				-- where  Ymt_OrderIdCard.iOrderId=#temp3.iOrderId  and #temp3.bIdCardUploaded=0 and #temp3.iUserId=Ymt_OrderIdCard.iUserId


				select distinct iUserId,sReceivePerson, sIdPicRightSide, sIdPicReverseSide,sIdCode into #temp4 from #temp3
				
				 --新增身份证同步码头表
				INSERT dbo.Ymt_IdPic 
				SELECT  NEWID(), iUserId,sReceivePerson, sIdPicRightSide, sIdPicReverseSide, 1, GETDATE(), sIdCode  from #temp4 

				INSERT dbo.Ymt_IdCardinfo (CardId,BuyerId,name,CardNumber,CardType,Status,HasPic,Operater,UpdateTime,UploadTime,CreateTime)
				SELECT  NEWID(), iUserId,sReceivePerson,sIdCode,1, 0,1, 'system',getdate(),getdate(),getdate()   from #temp4 
				left join Ymt_IdCardinfo as b with(nolock) on #temp4.iUserId=b.BuyerId and #temp4.sReceivePerson=b.Name
				where b.CardId is null

		end
end

end
