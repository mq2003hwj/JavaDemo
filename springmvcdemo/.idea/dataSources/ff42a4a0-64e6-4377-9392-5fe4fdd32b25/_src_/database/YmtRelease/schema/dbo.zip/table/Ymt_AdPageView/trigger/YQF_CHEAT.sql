-- =============================================
-- Author:		Jmtek
-- Create date: 2012/5/18
-- Description:	DELETE ILLEGAL CPS Cookie
-- =============================================
CREATE TRIGGER [dbo].[YQF_CHEAT] 
ON [dbo].[Ymt_AdPageView]
AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	Declare @iAdUserRefID int
	Declare @iAdPageViewID int
	Declare @sReferrerUrl varchar(500)
	Declare @sSiteCode varchar(200)
	Select @iAdPageViewID = p.iAdPageViewId, @iAdUserRefID = p.iAdUserRefID, @sReferrerUrl = p.sReferrerUrl, @sSiteCode = sSiteCode From inserted p inner join Ymt_AdUserRef u on u.iAdUserRefID = p.iAdUserRefID
	
	/*
	IF CHARINDEX('yiqifa.com',@sReferrerUrl) <= 0 And @sSiteCode = 'yiqifa' begin	-- illegal ref url
		IF NOT EXISTS (Select iAdUserRefID From Ymt_AdPageView WHERE iAdUserRefID = @iAdUserRefID and sReferrerUrl like '%yiqifa.com%') begin
			delete from ymt_aduserref where iAdUserRefID = @iAdUserRefID
		end
	end
	
	IF CHARINDEX('weiyi.com',@sReferrerUrl) <= 0 And @sSiteCode = 'weiyi' begin	-- illegal ref url
		IF NOT EXISTS (Select iAdUserRefID From Ymt_AdPageView WHERE iAdUserRefID = @iAdUserRefID and sReferrerUrl like '%weiyi.com%') begin
			delete from ymt_aduserref where iAdUserRefID = @iAdUserRefID
		end
	end
	*/
	--IF EXISTS (Select iAdUserRefID From Ymt_AdPageView WHERE iAdUserRefID = @iAdUserRefID and DATEDIFF(SECOND, dVisitDateTime, GetDate()) < 2) begin
		--delete from Ymt_AdPageView where iAdPageViewId = @iAdPageViewID
	--end

END
