-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE TEMPCOUNT
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TempCatList TABLE(categoryid int)
	
	--DECLARE @masterId int = 0
	DECLARE @CategoryId int = 0
	DECLARE @UpdateIds varchar = ''
	DECLARE @TEMPSQL nvarchar(2000)=''
	
	--SELECT @categoryId=(iCategoryId) FROM inserted
	SET @categoryId=44
	
	SELECT iMasterCategory FROM Ymt_ProductCategory WHERE iCategoryId=@CategoryId
		--insert into @TempCatList values (@categoryId)
		
	WHILE @@ROWCOUNT<>0
	BEGIN
		INSERT INTO @TempCatList values (@categoryId)
		SELECT @CategoryId=(iMasterCategory) FROM Ymt_ProductCategory WHERE iCategoryId=@CategoryId AND iMasterCategory<>0		
		print @@ROWCOUNT
	END
	
	--Select @TempCatList
	SELECT @UpdateIds=@UpdateIds+','+CAST(categoryid AS VARCHAR) FROM @TempCatList
	SET @UpdateIds=STUFF(@UpdateIds,1,1,'')
	--SELECT @categoryId FROM Ymt_Product
	
	SET @TEMPSQL = 'UPDATE Trig_CategorysIndex SET iProductCount=iProductCount+1 WHERE iCategoryId IN ('+@UpdateIds+')'
	print @TEMPSQL
	
	EXECUTE SP_EXECUTESQL @TEMPSQL
END
