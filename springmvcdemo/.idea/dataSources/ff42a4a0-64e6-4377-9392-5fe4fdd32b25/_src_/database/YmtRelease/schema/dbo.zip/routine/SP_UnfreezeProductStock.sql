-- =============================================
-- Author:		zhujinfeng
-- Create date: 2016-2-28
-- Description:	解冻商品库存
-- =============================================
CREATE PROCEDURE [dbo].[SP_UnfreezeProductStock]  
    @FreezeId VARCHAR(20),
	@FreezeType INT,
	@ProductId VARCHAR(36),
	@CatalogId VARCHAR(36),
	@StoreType INT,
	@Sku VARCHAR(60),
	@ActivityId INT,
	@FreezeNum INT,
	@ProductInActivityId INT,
	@Status INT,
	@OperateType INT  
AS
BEGIN
	
	SET NOCOUNT ON;


	BEGIN TRANSACTION

	-- 扣减冻结量
	UPDATE dbo.Ymt_ProductFreezeStock SET FreezeNum = FreezeNum - @FreezeNum, [Status] = @OperateType WHERE FreezeId = @FreezeId AND CatalogId = @CatalogId AND FreezeNum >= @FreezeNum;

	IF(@@RowCount > 0)
	BEGIN 

		-- 解冻到活动库存
		IF(@Status = 2)
		BEGIN
			UPDATE dbo.Ymt_ProductActivityStock SET iStockNum = iStockNum + @FreezeNum WHERE iProductInActivityId = @ProductInActivityId AND sCatalogId = @CatalogId;
		END

		-- 解冻返回共享库存
		ELSE IF (@Status = 3)
		BEGIN
			UPDATE dbo.Ymt_Catalogs SET iNum = iNum + @FreezeNum WHERE sCatalogId = @CatalogId;	
		END
		
		-- 写入冻结日志表
		INSERT INTO dbo.Ymt_ProductFreezeStockLog (FreezeId, ProductId, CatalogId, OperateType, ActivityId,	FreezeNum, ProductInActivityId, AddTime)
		VALUES (@FreezeId, @ProductId ,@CatalogId , @OperateType ,@ActivityId , 0 - @FreezeNum , @ProductInActivityId ,GETDATE()) 
		
		COMMIT TRANSACTION;
		
		-- 解冻成功
		SELECT 1 AS Result;      
	END
	ELSE
	BEGIN
		ROLLBACK TRANSACTION
  
		-- 解冻失败
		SELECT -1 AS Result;      
	END  

END
