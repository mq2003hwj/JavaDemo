-- =============================================
-- Author:		Jmtek
-- Create date: 2014-7-8
-- Description:	补贴账户打款
-- =============================================
CREATE PROCEDURE [dbo].[spAccountManualCharge]
	@UserName	Varchar(50),
	@Amount		Decimal(18,2),
	@Useage		nVarchar(500) = Null,
	@Memo		nVarchar(500) = Null
AS
BEGIN
	Print @UserName
	Print @Amount
	SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
	BEGIN TRANSACTION

	If @Useage is Null Begin
		Set @Useage = N'运费补贴'
	End

	If @Memo is Null Begin
		Set @Memo = N'运费补贴'
	End

	INSERT INTO [Ymt_AccountRunningTally]([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select newid(),@Amount,3,u.iUserId,fBalance,fAvailAmount,fFreezeAmount,getdate(),N'运费补贴',@Useage,@Memo from ymt_users u inner join ymt_accountinfo a on u.iuserid = a.iuserid where sloginid = @UserName

	update ymt_accountinfo set fAvailAmount = fAvailAmount + @Amount, fRewardAmount = fRewardAmount + @Amount where iuserid in (select iuserid from ymt_users where sloginid = @UserName)

	COMMIT
END
