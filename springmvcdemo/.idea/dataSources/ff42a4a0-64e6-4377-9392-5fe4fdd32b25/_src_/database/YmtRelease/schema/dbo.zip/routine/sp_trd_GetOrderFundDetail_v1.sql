-- =============================================            

-- Author:  Deng Peng, code from fanwei            

-- Create date: 2016-06-23

-- Last-modified: 2016-06-23

-- Description: 交易服务SP

-- 20160623：代码规整，添加取消订单数据

-- 20160624：

--    1. 逻辑更新：存在付款时间的都提取至客户端

--    2. 新增取消统计

-- 20160629：输出追加促销活动的优惠总金额字段

-- =============================================

CREATE procedure [dbo].[sp_trd_GetOrderFundDetail_v1]

	@orderId int,

	@summary bit = 0

as


if @orderId is null or @orderId = 0 

	return ; 



declare @shangou bit ,		-- 定金+尾款、全额

			@status int ,			-- 订单状态 (取消状态为12,13,18)

			@refund int ;		-- 是否存在退款



select @shangou = [bShangouOrder] 

	, @status = [iTradingStatus]

	, @refund = [iSalesRefundStatus]

from [dbo].[Ymt_Orders] where [iOrderId] = @orderId ;



if @status is null

	return ;



---------------------------------------------------------------------------

--获取相关数据

declare @FundDetails table (

	[Time] datetime

	,[Cash] decimal(18,2)

	,[Gift] decimal(18,2)

	,[FreeCard] decimal(18,2)

	,[Coupon] decimal(18,2)

	,[CouponChannel] decimal(18,2)

	,[CouponCode] varchar(50)

	,[Total] decimal(18,2)

	,[OccurredPrice] decimal(18,2)

	,[PriceChange] decimal(18,2)

	,[Freight] decimal(18,2)

	,[Evidence] varchar(50)

	,[IsIncoming] bit

	,[Operation] int

	,[SellerCouponCode] varchar(50)

	,[SellerCoupon] decimal(18,2)

	,[AccountPaidAmount] decimal(18,2)

	,[ThirdPartyPaidAmount] decimal(18,2)

	,[ThirdPartyName] varchar(50)

  ,[ThirdPartyDiscount] decimal(18,2)

) ;



---------------------------------------------------------------------------

--资金明细 : 付款方式：定金+尾款 or 全额

--if @status in (2,3,4,16,17) begin

--只要付款时间不为NULL就表明发生了交易

	insert into @FundDetails ( 

		[Time] ,[Cash] ,[Gift] ,[FreeCard] ,[Coupon] ,

		[CouponChannel] ,[CouponCode] ,[Total] ,[OccurredPrice] ,[PriceChange] ,

		[Freight] ,[Evidence] ,[IsIncoming] ,[Operation] , [SellerCouponCode] ,

		[SellerCoupon] ,[AccountPaidAmount] ,[ThirdPartyPaidAmount] ,[ThirdPartyName],[ThirdPartyDiscount]

	)

	select top 1 [Time] = [order].dPaidTime 

		, [Cash] = [orderState].fPaidAmountOfCash , [Gift] = fPaidAmountOfGift , [FreeCard] = fPaidAmountOfFreeCard , [Coupon] = [orderState].fPaidAmountOfYmtCoupon

		, [CouponChannel] = iif([order].fYmtCouponAmount > 0 and [order].fSellerCouponAmount > 0 , 3 , [order].iCouponChannel)

		, [CouponCode] = [order].sCouponCode

		, [Total] = isnull([orderState].fPaidAmountOfCash, 0) + isnull([orderState].fPaidAmountOfGift, 0) + isnull([orderState].fPaidAmountOfFreeCard, 0) + isnull([orderState].fPaidAmountOfYmtCoupon, 0)

		, [OccurredPrice] = [order].fOrderPrice , [PriceChange] = [order].fOrderDiscount , [Freight] = [order].fFreight

		, [Evidence] = null , [IsIncoming] = 1 , [Operation] = 1 , [SellerCouponCode] = [order].sSellerCouponCode

		, [SellerCoupon] = [orderState].fPaidAmountOfSellerCoupon

		, [AccountPaidAmount] = isnull([orderState].fPaidAmountOfCash, 0) - isnull(IIF(isnull([orderState].fPaidAmountOfThirdParty, 0) > 0, [orderState].fPaidAmountOfThirdParty, [tradingInfo].fAmount), 0)

		, [ThirdPartyPaidAmount] = iif(isnull([orderState].fPaidAmountOfThirdParty, 0) > 0, [orderState].fPaidAmountOfThirdParty, [tradingInfo].fAmount)

		, [ThirdPartyName] = [tradingInfo].[sPayChannel]
		, [ThirdPartyDiscount]= ISNULL([orderState].fDiscountOfThirdParty, 0)

	from [dbo].[Ymt_OrderState] as [orderState] with(nolock)

	join [dbo].[Ymt_Orders] as [order] with(nolock) on [orderState].[iOrderId] = [order].[iOrderId] and [order].[dPaidTime] is not null

	outer apply (

		select top 1 [fAmount], [sPayChannel] 

		from [dbo].[Ymt_TradingInfo] with(nolock)

		where [orderState].[fPaidAmountOfCash] > 0 and [iTradingId] = [order].iTradingId and [iTradingStatus] = 2

	) as [tradingInfo]

	where [orderState].[iOrderId] = @orderId ;

--end

 

---------------------------------------------------------------------------

--定金：需要追加尾款

if @shangou = 1 and @status in (3,4,17) begin

	----------------尾款----------------

	insert into @FundDetails ( 

			[Time] ,[Cash] ,[Gift] ,[FreeCard] ,[Coupon] ,

			[CouponChannel] ,[CouponCode] ,[Total] ,[OccurredPrice] ,[PriceChange] ,

			[Freight] ,[Evidence] ,[IsIncoming] ,[Operation] , [SellerCouponCode] ,

			[SellerCoupon] ,[AccountPaidAmount] ,[ThirdPartyPaidAmount] ,[ThirdPartyName],[ThirdPartyDiscount]

	)

	select top 1 [Time] = [order].dPostPaidTime

		, [Cash] = [orderState].fPostPaidAmountOfCash , [Gift] = fPostPaidAmountOfGift , [FreeCard] = 0 , [Coupon] = 0

		, [CouponChannel] = 0 , [CouponCode] = null 

		, [Total] = [orderState].fPostPaidAmountOfCash + [orderState].fPostPaidAmountOfGift

		, [OccurredPrice] = [orderState].fPostPaidAmountOfCash+[orderState].fPostPaidAmountOfGift

		, [PriceChange] = [orderState].fPostPaidAmountOfCash+[orderState].fPostPaidAmountOfGift-([order].fTotalPrice-[order].fOrderPrice) 

		, [Freight] = 0 , [Evidence] = null , [IsIncoming] = 1 , [Operation] = 2 , [SellerCouponCode] = null

		, [SellerCoupon] = 0

		, [AccountPaidAmount] = isnull([orderState].fPostPaidAmountOfCash, 0) - isnull(IIF(isnull([orderState].fPostPaidAmountOfThirdParty, 0) > 0, [orderState].fPostPaidAmountOfThirdParty, [tradingInfo].Amount), 0)

		, [ThirdPartyPaidAmount] = iif(isnull([orderState].fPostPaidAmountOfThirdParty, 0) > 0, [orderState].fPostPaidAmountOfThirdParty, [tradingInfo].Amount)

		, [ThirdPartyName] = [tradingInfo].sPayChannel
		, [ThirdPartyDiscount]= ISNULL([orderState].fDiscountOfThirdParty, 0)

	from [dbo].[Ymt_OrderState] as [orderState] with(nolock)

	join [dbo].[Ymt_Orders] as [order] with(nolock) on [orderState].[iOrderId] = [order].[iOrderId]

	outer apply (

		select top 1 b.[Amount] , a.[sPayChannel] 

		from [dbo].[Ymt_OrderPostPay] as a with(nolock)

		left join Ymt_PostPayTradingInfo as b with(nolock) on b.PostPayTradingId = a.sPostPayTradingId

		where [orderState].fPostPaidAmountOfCash > 0 and a.iOrderId = [order].iOrderId and a.iAction = 1 and b.OrderId = [order].iOrderId and b.[Action] = 1

	) as [tradingInfo]

	where [orderState].iorderid = @orderId and [order].bPaidInFull = 1 and [orderState].fPostPaidAmountOfCash > 0 ;

end



---------------------------------------------------------------------------

if @status in (12,13,18) begin

--取消：12. 买家责任取消；13. 卖家责任取消；18. 自动取消。

	insert into @FundDetails ( 

			[Time] ,[Cash] ,[Gift] ,[FreeCard] ,[Coupon] ,

			[CouponChannel] ,[CouponCode] ,[Total] ,[OccurredPrice] ,[PriceChange] ,

			[Freight] ,[Evidence] ,[IsIncoming] ,[Operation] , [SellerCouponCode] ,

			[SellerCoupon] ,[AccountPaidAmount] ,[ThirdPartyPaidAmount] ,[ThirdPartyName],[ThirdPartyDiscount]

	)

	select [Time] = [SettlementTime] 

		, [Cash] = [CashAmount] , [Gift] = 0 , [FreeCard] = 0 , [CouponAmount] 

		, [CouponChannel] = 0 ,[CouponCode] =null , [Total] = [CashAmount] + isnull([CouponAmount],0) ,[OccurredPrice] = 0 , [PriceChange] = 0

		, [Freight] = 0 , [Evidence] = null, [IsIncoming] = 0,  [Operation] = 4 , [SellerCouponCode] = null

		, [SellerCoupon] = 0 , [AccountPaidAmount] = 0 , [ThirdPartyPaidAmount] = 0 , [ThirdPartyName] =null,[ThirdPartyDiscount]= 0

	from [dbo].[Ymt_SettlementInvoice]  with(nolock)

	where [BusinessType] = 3 and [OrderId] = @orderId ;



end



---------------------------------------------------------------------------

if @refund is not null begin

--退款: ----------------

	insert into @FundDetails ( 

			[Time] ,[Cash] ,[Gift] ,[FreeCard] ,[Coupon] ,

			[CouponChannel] ,[CouponCode] ,[Total] ,[OccurredPrice] ,[PriceChange] ,

			[Freight] ,[Evidence] ,[IsIncoming] ,[Operation] , [SellerCouponCode] ,

			[SellerCoupon] ,[AccountPaidAmount] ,[ThirdPartyPaidAmount] ,[ThirdPartyName],[ThirdPartyDiscount]

	)

	select [Time] = AddTime

		, [Cash] = RefundedAmountOfCash , [Gift] = RefundedAmountOfGift, [FreeCard] = 0 , [Coupon] = SettlementAmountOfCoupon

		, [CouponChannel] = iif(SettlementAmountOfCoupon > 0, 1, 0) , [CouponCode] = null

		, [Total]= RefundAmount + isnull(SettlementAmountOfCoupon, 0) , [OccurredPrice] = RefundAmount , [PriceChange] = 0

		, [Freight] = 0 , [Evidence] = RefundBillNo, [IsIncoming] = 0, [Operation] = 3 , [SellerCouponCode] = null

		, [SellerCoupon] = 0 , [AccountPaidAmount] = 0 , [ThirdPartyPaidAmount] = 0 , [ThirdPartyName] = null
		, [ThirdPartyDiscount] = ISNULL(RefundedDiscountOfThirdParty, 0)

	from [dbo].[Ymt_RefundBill] with(nolock)

	where [OrderId] = @orderId and [SalesRefundStatus] = 10 ;

end







---------------------------------------------------------------------------

--结果数据：订单的付款类型

select @orderId as OrderId, @shangou as NeedPayTwiceOrMore



---------------------------------------------------------------------------

--结果数据：资金明细

select * from @FundDetails



if @summary is null or @summary <> 1 

	return;



--结果数据：统计信息

select s.fPaidAmountOfCash as PaidCash

	,s.fPaidAmountOfGift as PaidGift

	,s.fPaidAmountOfFreeCard as PaidFreeCard

	,s.fPaidAmountOfYmtCoupon as PaidYmtCoupon

	,s.fPaidAmountOfSellerCoupon as PaidSellerCoupon

	,s.fPostPaidAmountOfCash as PostPaidCash

	,s.fPostPaidAmountOfGift as PostPaidGift

	,ISNULL(s.fDiscountOfThirdParty, 0) as TotalThirdPartyDiscount

  ,ISNULL(s.fRefundedDiscountOfThirdParty,0) as TotalRefundedThirdPartyDiscount

	,o.fTotalPrice as TotalProductPrice

	,o.fOrderPrice as FirstPayProductPrice

	,o.fFreight as Freight

	,o.fOrderDiscount as OrderDiscount

	,o.fDiscount as PostPayDiscount

	,o.[fSellerPromotionAmount] as TotalActivityPrice

	,[refund].TotalRefundedCash

	,[refund].TotalRefundedGift 

	,[refund].TotalRefundedYmtCoupon

	,[cancel].*

from [dbo].[Ymt_OrderState] as s with(nolock) 

join [dbo].[Ymt_Orders] as o with(nolock) on s.iorderid = o.iorderid

outer apply (

	select sum(isnull(RefundedAmountOfCash,0)) as TotalRefundedCash

		, sum(isnull(RefundedAmountOfGift,0)) as TotalRefundedGift

		, sum(isnull(SettlementAmountOfCoupon,0)) as TotalRefundedYmtCoupon

	from [dbo].[Ymt_RefundBill] with(nolock)

	where OrderId = o.iOrderId and SalesRefundStatus = 10

) as [refund]

outer apply (

	select sum(isnull([CashAmount],0)) as TotalCanceledCash

		, sum(isnull([CouponAmount],0)) as TotalCanceledYmtCoupon

	from [dbo].[Ymt_SettlementInvoice]  with(nolock)

	where [BusinessType] = 3 and [OrderId] = @orderId

) as [cancel]

where s.iorderid = @orderId ;