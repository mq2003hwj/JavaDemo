-- =============================================
-- Author:		lzh
-- Create date: <Create Date,,>
-- Description:	create trading
-- =============================================

CREATE PROCEDURE sp_CreateTradingSingleOrder 
@userId int,
@orderId int,
@tradingStatus int,
@sumPrePayAmount  decimal(18,2),
@now datetime

AS
BEGIN
	declare @tradingId int
	exec @tradingId = [dbo].[spGenerateTradingId]
	if @tradingId = -1 
	begin
		select @tradingId
		return;
	end

	begin try
		begin transaction 
			insert into Ymt_TradingInfo
			(iTradingId,dAddTime,iTradingStatus,fAmount,iUserId,dUpdateTime,fPayableAmount)
			values (@tradingId,@now,@tradingStatus,@sumPrePayAmount,@userId,@now,@sumPrePayAmount)

			insert into Ymt_TradingItem([sId],iOrderId,dAddTime,iTradingId,dUpdateTime,iTradingResult,iTradingType)
			select NEWID(),@orderId,@now,@tradingId,@now,0,0 
		commit
	end try 

	begin catch
		rollback;
		throw;
	end catch

	select @tradingId
END