CREATE VIEW dbo.viewOrdersList
AS
SELECT     TOP (100) PERCENT dbo.Ymt_TradingInfo.iTradingId, dbo.Ymt_TradingInfo.iUserId, dbo.Ymt_TradingInfo.dAddTime, dbo.Ymt_Orders.iBuyerId, 
                      dbo.Ymt_Orders.dAddTime AS Expr1, dbo.Ymt_Orders.fFreight, dbo.Ymt_Orders.fDiscount, dbo.Ymt_OrderInfo.sCatalogId, dbo.Ymt_OrderInfo.iAmount, 
                      dbo.Ymt_OrderInfo.sPropertyInfo, dbo.Ymt_OrderInfo.fOriginalPrice, dbo.Ymt_OrderInfo.fDiscount AS Expr2, dbo.Ymt_OrderInfo.fTotalPrice
FROM         dbo.Ymt_Orders RIGHT OUTER JOIN
                      dbo.Ymt_TradingInfo ON dbo.Ymt_Orders.iTradingId = dbo.Ymt_TradingInfo.iTradingId LEFT OUTER JOIN
                      dbo.Ymt_OrderInfo ON dbo.Ymt_Orders.iOrderId = dbo.Ymt_OrderInfo.iOrderId
ORDER BY dbo.Ymt_TradingInfo.iUserId
