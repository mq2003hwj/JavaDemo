-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-12-21
-- Description: 交易服务SP       
-- 20160801：添加减促销满减金额
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerSalesDetail_v2]

@sellerId int,
@date datetime = NULL

AS

if @date is null set @date = getdate();

SET DATEFIRST 1
declare @today datetime = DATEADD(day, DATEDIFF(day,0,@date),0)
declare @yesterday datetime = DATEADD(day, DATEDIFF(day,0,@today-1), 0)
declare @tomorrow datetime = DATEADD(day,1,@today)
declare @week datetime = DATEADD(day, DATEDIFF(day,0,@today-(DATEPART(weekday, @today)-1)),0)
declare @month datetime = DATEADD(month, DATEDIFF(month,0,@today),0)

--set statistics io on;set statistics time on;


select 'yesterday' as TimeSpan,--昨天
--未付款
sum(case s.fPaidAmountOfCash when 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Unpaid_Spot,
sum(case s.fPaidAmountOfCash when 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Unpaid_Shangou,
sum(case s.fPaidAmountOfCash when 0 then isnull(i.fSellerCouponAmount,0) else 0 end) Unpaid_SellerCoupon,
--已付定金
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) PartialPaid_Spot,
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) PartialPaid_Shangou,
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then isnull(i.fSellerCouponAmount,0) else 0 end) PartialPaid_SellerCoupon,
--已付全款
------------
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) FullPaid_Spot,
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) FullPaid_Shangou,
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then isnull(i.fSellerCouponAmount,0) else 0 end) FullPaid_SellerCoupon,
--已取消 12,13,18
sum(case when o.iTradingStatus in (12,13,18) then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Cancelled_Spot,
sum(case when o.iTradingStatus in (12,13,18) then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Cancelled_Shangou,
sum(case when o.iTradingStatus in (12,13,18) then isnull(i.fSellerCouponAmount,0) else 0 end) Cancelled_SellerCoupon
------------
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime) 
join ymt_orderstate(nolock) s on o.iOrderId = s.iOrderId
join ymt_orderinfo(nolock) i on i.iOrderId = o.iOrderId
where o.iBuyerId = @sellerId and o.dAddTime >= @yesterday and o.dAddTime < @today

union all

select  'today' as TimeSpan,--今天
--未付款
sum(case s.fPaidAmountOfCash when 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Unpaid_Spot,
sum(case s.fPaidAmountOfCash when 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Unpaid_Shangou,
sum(case s.fPaidAmountOfCash when 0 then isnull(i.fSellerCouponAmount,0) else 0 end) Unpaid_SellerCoupon,
--已付定金
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) PartialPaid_Spot,
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) PartialPaid_Shangou,
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then isnull(i.fSellerCouponAmount,0) else 0 end) PartialPaid_SellerCoupon,
--已付全款
------------
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) FullPaid_Spot,
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) FullPaid_Shangou,
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then isnull(i.fSellerCouponAmount,0) else 0 end) FullPaid_SellerCoupon,
--已取消 12,13,18
sum(case when o.iTradingStatus in (12,13,18) then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Cancelled_Spot,
sum(case when o.iTradingStatus in (12,13,18) then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Cancelled_Shangou,
sum(case when o.iTradingStatus in (12,13,18) then isnull(i.fSellerCouponAmount,0) else 0 end) Cancelled_SellerCoupon
------------
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime) 
join ymt_orderstate(nolock) s on o.iOrderId = s.iOrderId
join ymt_orderinfo(nolock) i on i.iOrderId = o.iOrderId
where o.iBuyerId = @sellerId and o.dAddTime >= @today and o.dAddTime < @tomorrow

union all

select 'week' as TimeSpan,--本周
--未付款
sum(case s.fPaidAmountOfCash when 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Unpaid_Spot,
sum(case s.fPaidAmountOfCash when 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Unpaid_Shangou,
sum(case s.fPaidAmountOfCash when 0 then isnull(i.fSellerCouponAmount,0) else 0 end) Unpaid_SellerCoupon,
--已付定金
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) PartialPaid_Spot,
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) PartialPaid_Shangou,
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then isnull(i.fSellerCouponAmount,0) else 0 end) PartialPaid_SellerCoupon,
--已付全款
------------
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) FullPaid_Spot,
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) FullPaid_Shangou,
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then isnull(i.fSellerCouponAmount,0) else 0 end) FullPaid_SellerCoupon,
--已取消 12,13,18
sum(case when o.iTradingStatus in (12,13,18) then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Cancelled_Spot,
sum(case when o.iTradingStatus in (12,13,18) then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Cancelled_Shangou,
sum(case when o.iTradingStatus in (12,13,18) then isnull(i.fSellerCouponAmount,0) else 0 end) Cancelled_SellerCoupon
------------
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime) 
join ymt_orderstate(nolock) s on o.iOrderId = s.iOrderId
join ymt_orderinfo(nolock) i on i.iOrderId = o.iOrderId
where o.iBuyerId = @sellerId and o.dAddTime >= @week and o.dAddTime < @tomorrow

union all

select 'month' as TimeSpan, --本月
--未付款
sum(case s.fPaidAmountOfCash when 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Unpaid_Spot,
sum(case s.fPaidAmountOfCash when 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Unpaid_Shangou,
sum(case s.fPaidAmountOfCash when 0 then isnull(i.fSellerCouponAmount,0) else 0 end) Unpaid_SellerCoupon,
--已付定金
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) PartialPaid_Spot,
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) PartialPaid_Shangou,
sum(case when o.bShangouOrder = 1 and o.bPaidInFull = 0 and s.fPaidAmountOfCash > 0 and s.fPostPaidAmountOfCash = 0 then isnull(i.fSellerCouponAmount,0) else 0 end) PartialPaid_SellerCoupon,
--已付全款
------------
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) FullPaid_Spot,
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) FullPaid_Shangou,
sum(case when o.bPaidInFull = 1 and s.fPaidAmountOfCash > 0 then isnull(i.fSellerCouponAmount,0) else 0 end) FullPaid_SellerCoupon,
--已取消 12,13,18
sum(case when o.iTradingStatus in (12,13,18) then IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Cancelled_Spot,
sum(case when o.iTradingStatus in (12,13,18) then IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0) else 0 end) Cancelled_Shangou,
sum(case when o.iTradingStatus in (12,13,18) then isnull(i.fSellerCouponAmount,0) else 0 end) Cancelled_SellerCoupon
------------
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime) 
join ymt_orderstate(nolock) s on o.iOrderId = s.iOrderId
join ymt_orderinfo(nolock) i on i.iOrderId = o.iOrderId
where o.iBuyerId = @sellerId and o.dAddTime >= @month and o.dAddTime < @tomorrow

--set statistics io off;set statistics time off;