-- =============================================

-- Author:		gejianhua

-- Create date: 2016-8-5

-- Description:	生成虚拟优惠券编号

-- =============================================

CREATE PROCEDURE [dbo].[sp_CouponActivityPreGenerate]

	@activityCode int,	--活动编号

	@generateNum int,	--生成数量
	
	@prefix varchar(2)	--前缀

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	declare @i int

	declare @couponCode varchar(50)

	declare @failTimes int = 0

	declare @repliTimes int = 0

	set @i = 0;

	

	while(@i < @generateNum)

	begin

		while(1=1)

		begin

			begin try

				--生成优惠券编号

				set @couponCode = @prefix + substring(convert(varchar, rand()), 3, 4)

				+ substring(convert(varchar, rand()), 3, 4)

				+ substring(convert(varchar, rand()), 3, 4)

				+ substring(convert(varchar, rand()), 3, 4)



				--查看是否重复,重复则重新生成，否则添加过数据库

				if(not exists(select null from ymt_couponactivitypregenerate where precouponcode = @couponcode))

				begin

					insert into ymt_couponactivitypregenerate(activitycode, precouponcode)

					values(@activityCode, @couponCode)

					set @i = @i + 1

					if(@i % 10000 = 0)
					begin
						waitfor delay '00:00:30'
					end

					break;

				end

				else

				begin

					set @repliTimes += 1

				end

			end try

			begin catch

				print '生成优惠券失败：' + isnull(ERROR_MESSAGE(),'')

				set @failTimes += 1

			end catch

		end

	end



	print '成功次数：' + convert(varchar, @i);

	print '重复次数：' + convert(varchar, @repliTimes)

	print '失败次数：' + convert(varchar, @failTimes)

	



END



