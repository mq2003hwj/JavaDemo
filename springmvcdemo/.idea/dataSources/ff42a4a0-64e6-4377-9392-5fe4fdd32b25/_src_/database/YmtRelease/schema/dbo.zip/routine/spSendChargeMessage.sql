-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE spSendChargeMessage
	@BillId Varchar(36)	
AS
BEGIN
	declare @ToUserId int 
	Set @ToUserId = 0
	select @ToUserId = iFromUserId from Ymt_Bill where sBillId= @BillId
	
	If Exists (Select * From Ymt_NotificationCount Where iUserId = @ToUserId And NotificationType = 5)
	Begin
		declare @notificationCount int
		select @notificationCount = NotificationCOunt from Ymt_NotificationCount where  iUserId = @ToUserId And NotificationType = 5
		update Ymt_NotificationCount set NotificationCOunt = @notificationCount+1 where  iUserId = @ToUserId And NotificationType = 5
	End 
	
	else
		Begin
			insert into Ymt_NotificationCount(iUserId, NotificationType, NotificationCOunt)
			values(@ToUserId, 5, 1)
	   End 
	
END