CREATE VIEW dbo.View_TempOrderCountPerDay
AS
SELECT     TOP (100) PERCENT COUNT(*) AS OrderCountPerDay, MIN(dAddTime) AS perday
FROM         dbo.Ymt_Orders
GROUP BY CONVERT(date, dAddTime)
