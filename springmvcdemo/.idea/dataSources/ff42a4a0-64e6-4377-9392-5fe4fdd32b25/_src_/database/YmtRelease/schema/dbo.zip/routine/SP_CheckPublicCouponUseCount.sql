
-- =============================================            
-- Author:  刘宏        
-- Create date: 2015-07-17
-- Description: 校验公共优惠券使用次数
-- =============================================     
CREATE PROC [dbo].[SP_CheckPublicCouponUseCount]
	@CouponCode varchar(36),
	@UserId int
AS

DECLARE @IsNotError BIT=1
	,@MaxUseTime int = 0
	,@CouponUsedCount int = 0
	,@BatchId int
	,@MaxUseTimePerUser int
	,@CouponId varchar(36)
	,@CouponCount int
	,@TotalUsedCount int
	,@CouponCodeExist varchar(36) = NULL
	,@CouponUseTotalCount int = 0

BEGIN
	SELECT @MaxUseTime=iMaxUseTime,@MaxUseTimePerUser=iMaxUseTimePerUser,@CouponUseTotalCount=iCouponUseCount FROM Ymt_CouponSetting WITH(NOLOCK) 
		WHERE iCouponSettingId IN (SELECT iCouponSetting FROM Ymt_Coupon WITH(NOLOCK) WHERE sCouponCode=@CouponCode)

	IF @MaxUseTime <= 0
	BEGIN
		SELECT @IsNotError = 0
		SELECT @IsNotError
		RETURN
	END
	
	SELECT @BatchId=A.iBatchId,@CouponId=A.sCouponId,@CouponCodeExist=B.sCouponCode
	FROM Ymt_Coupon A WITH(NOLOCK) LEFT JOIN Ymt_CouponPublicUsed B WITH(NOLOCK) ON A.sCouponId=B.sCouponId
	WHERE A.sCouponCode=@CouponCode 

	SELECT @TotalUsedCount=COUNT(0) FROM Ymt_CouponPublicUsed WITH(NOLOCK) WHERE iBatchId=@BatchId AND sCouponCode=@CouponCode
	IF @TotalUsedCount>=@CouponUseTotalCount
	BEGIN
		SELECT @IsNotError = 0
		SELECT @IsNotError
		RETURN
	END
	
	SELECT @TotalUsedCount=ISNULL(SUM(@MaxUseTimePerUser-iCouponUsedCount),0) FROM Ymt_CouponPublicUsed WITH(NOLOCK) WHERE iBatchId=@BatchId AND sCouponCode=@CouponCode
	IF @CouponUseTotalCount <= @TotalUsedCount
	BEGIN
		SELECT @IsNotError = 0
		SELECT @IsNotError
		RETURN
	END 

	SELECT @TotalUsedCount=ISNULL(SUM(@MaxUseTimePerUser-iCouponUsedCount),0) FROM Ymt_CouponPublicUsed WITH(NOLOCK) WHERE iUserId=@UserId AND iBatchId=@BatchId
	IF @MaxUseTimePerUser <= @TotalUsedCount
	BEGIN
		SELECT @IsNotError = 0
		SELECT @IsNotError
		RETURN
	END

	SELECT @IsNotError
END
