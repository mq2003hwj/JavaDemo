CREATE VIEW dbo.ViewUserTradingDetailInfo
AS
SELECT     dbo.Ymt_TradingInfo.iTradingId, dbo.Ymt_TradingInfo.iUserId AS TradingUserId, dbo.Ymt_TradingInfo.dAddTime AS TradingAddTime, 
                      dbo.Ymt_TradingInfo.sReceiveAddress, dbo.Ymt_TradingInfo.sPostCode, dbo.Ymt_TradingInfo.sTelphone, dbo.Ymt_TradingInfo.sCellPhone, 
                      dbo.Ymt_Orders.iOrderId AS UserOrderId, dbo.Ymt_Orders.iBuyerId, dbo.Ymt_Orders.dAddTime AS OrderAddTime, dbo.Ymt_Orders.fOrderPrice AS OrderPrice, 
                      dbo.Ymt_Orders.fOrderDiscount AS OrderDiscount, dbo.Ymt_Orders.fFreight AS OrderFreight, dbo.Ymt_Orders.fDiscount AS OrderFreightDiscount, 
                      dbo.Ymt_OrderInfo.sCatalogId AS OrderCatalogId, dbo.Ymt_OrderInfo.iAmount, dbo.Ymt_OrderInfo.sPropertyInfo, dbo.Ymt_OrderInfo.fOriginalPrice AS CatalogPrice, 
                      dbo.Ymt_OrderInfo.fDiscount AS CatalogDiscount, dbo.Ymt_OrderInfo.fTotalPrice AS CatalogTotalPrice, dbo.Ymt_Catalogs.sCatalogId, 
                      dbo.Ymt_Catalogs.iUserId AS CatalogBuyerId, dbo.Ymt_Catalogs.sProductId AS CatalogProductId, dbo.Ymt_Products.iCategoryId, dbo.Ymt_Products.iBrandId, 
                      dbo.Ymt_Products.sProduct, dbo.Ymt_Orders.iTradingStatus AS OrderTradingStatus, dbo.Ymt_OrderInfo.sOrderInfoId AS UserOrderInfoId, 
                      dbo.Ymt_Catalogs.fQuotePrice AS CatalogQuotePrice, dbo.Ymt_Catalogs.fFlight AS CatalogFreight, dbo.Ymt_Catalogs.sPicUrl AS CatalogPicUrl, 
                      dbo.Ymt_Users.sLoginId AS CatalogCustomer, Ymt_Users_1.sLoginEmail AS SellerEmail, Ymt_Users_1.sLoginId AS CatalogBuyer
FROM         dbo.Ymt_Orders LEFT OUTER JOIN
                      dbo.Ymt_Catalogs LEFT OUTER JOIN
                      dbo.Ymt_Users AS Ymt_Users_1 ON dbo.Ymt_Catalogs.iUserId = Ymt_Users_1.iUserId LEFT OUTER JOIN
                      dbo.Ymt_Products ON dbo.Ymt_Catalogs.sProductId = dbo.Ymt_Products.sProductId RIGHT OUTER JOIN
                      dbo.Ymt_OrderInfo ON dbo.Ymt_Catalogs.sCatalogId = dbo.Ymt_OrderInfo.sCatalogId ON dbo.Ymt_Orders.iOrderId = dbo.Ymt_OrderInfo.iOrderId RIGHT OUTER JOIN
                      dbo.Ymt_Users RIGHT OUTER JOIN
                      dbo.Ymt_TradingInfo ON dbo.Ymt_Users.iUserId = dbo.Ymt_TradingInfo.iUserId ON dbo.Ymt_Orders.iTradingId = dbo.Ymt_TradingInfo.iTradingId
