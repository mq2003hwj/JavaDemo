CREATE  PROCEDURE [dbo].[spGetAllValidProductsV2]   
AS  
BEGIN  
 Select  
  p.sproductid,icategoryid,ibrandid,sproduct,isailprotected,validstart,validend,iismerchant,p.icatalogtype,ithirdcategoryid,isellnum,  
  irecentsellnum,min(fQuotePrice) as fquoteprice,sort,ipid as pid, p.dAddTime, s.iLiveCountry, IsNull(pic.iPicCount, 0) as iPicCount,  
  case p.itarifftype when 1 then 0 else 1 end as bIsNoTax, case p.fFlight when 0 then 1 else 0 end as bIsNoFreight, p.iUserId  
 From   
  Ymt_Products p with(nolock) inner join Ymt_Catalogs c with(nolock) on p.sProductId = c.sProductId   
  inner join dbo.Ymt_SellerInfo s with(nolock) on s.iuserid = p.iuserid  
  left join (Select sProductId, Count(*) as iPicCount From Ymt_ProductPicture pp with(Nolock) Where iAction = 0 Group By sProductId) pic on pic.sProductId = p.sProductId  
  left join dbo.Ymt_UserPunish up with(nolock) on up.iuserid = p.iuserid  
 Where   
  p.iAction = 0 And c.inum > 0 And c.iAction = 0 And bShangouProduct = 0 And    
  IsNull(up.iType, 0) Not In (1, 3) And IsNull(up.iAction, 0) <> 1 And   
  icategoryid not in (1368,1369,1370,1372,1383,1384) And     ---1174,1175,1176,   20150325 
  ibrandid <> 11702 And    
  validend > getdate() And  
  (s.iaction = 99 or iUserStatus=2) And   
  p.bhidden=0 And   
  p.iuserid in (   
   SELECT iuserid FROM dbo.Ymt_SellerInfo with(nolock) where ((iaction = 99 or iUserStatus=2) or  iuserid in (SELECT iuserid  FROM dbo.Ymt_FastTurnaroundAccount where iuservalidstatus=3)) or mshop =1  
  ) And  
  p.sProduct not like '%bioastin%'   
 Group By p.sproductid,icategoryid,ibrandid,sproduct,validstart,isailprotected,validend,iismerchant,p.icatalogtype,ithirdcategoryid,isellnum,irecentsellnum, sort, ipid, p.dAddTime, s.iLiveCountry, pic.iPicCount, p.itarifftype, p.fFlight, p.iUserId  
 Having min(fQuotePrice) > 30    or  p.iuserid = 2123229
END
