


-- =============================================
-- Author:                              <xxl>
-- Create date: <2015-09-17 18:39:23.977>
-- Description:       <switch partition>
-- =============================================
CREATE PROCEDURE [dbo].[msp_SwitchMonthlyPartition] @tablename varchar( 100),@suffix varchar(50 )='switchptn', @reversemonthnum int = 2
AS
BEGIN


if object_id ( 'tempdb.dbo.#tmp1', 'u' ) is not null
drop table #tmp1
if object_id ( 'tempdb.dbo.#tmp2', 'u' ) is not null
drop table #tmp2

declare @psdate datetime, @i int = 0, @sql varchar ( max ), @xsql varchar ( max),@partitionfunction varchar(100)
set @psdate =convert ( datetime, convert ( varchar ( 10 ), datepart (year ,( dateadd( month ,-@reversemonthnum , getdate ()))))+ '-' +right(convert ( varchar( 10 ),100 + datepart( month ,dateadd ( month,- @reversemonthnum , getdate ()))), 2)+ '-01 00:00:01' )

Select distinct object_name( i .object_id ) as objectName, fg .name as fgname ,ps . name as SchemeName , pf. name as FunctionName , --prv.value RangeValue,
t .partition , t. minval ,value = case when pf. boundary_value_on_right =1 then '<= val <' else '< val <=' end ,t . maxval, p .rows into #tmp1
from sys . destination_data_spaces dds
Left Join sys. partition_schemes ps   On dds .partition_scheme_id = ps .data_space_id
--Left Join sys.partition_range_values prv On ps.function_id = prv.function_id And prv.boundary_ID = dds.destination_ID
Left Join sys. filegroups fg On dds .data_space_id = fg .data_space_id
Left Join sys. indexes i on i .data_space_id = ps .data_space_id
Left Join sys. partition_functions pf on ps .function_id = pf .function_id
Left Join sys. partitions p On p .Partition_Number = dds .destination_id And p .object_ID = i .object_id
Left Join (
           select h . function_id
                 , partition = h . boundary_id
                 , minval    = l . value
                 , maxval    = h . value
             from sys . partition_range_values h
                     left join sys. partition_range_values l
               on h . function_id = l . function_id and h . boundary_id = l . boundary_id + 1
 
           union all
 
           select function_id
                 , partition = max ( boundary_id) + 1
                 , minval    = max ( value)
                 , maxval    = null
             from sys . partition_range_values
            group by function_id
           ) t ON pf .function_id = t .function_id And dds .destination_id = t .partition
                                   where isnull(minval,'1900-01-01') < @psdate and maxval > @psdate 
select @partitionfunction= (select top 1 FunctionName from #tmp1 where objectName=@tablename)

 ;with t_ps1 as (
select row_number () over( order by objectname) as fRank ,* from #tmp1 where objectname not like '%'+@suffix and objectname = @tablename )
select   fRank , 'alter table '+ objectname + ' switch partition ' + convert( varchar ( 10 ), partition)+ ' to '+ objectname+ '_'+@suffix +' partition ' +convert ( varchar ( 10 ), partition ) as delptn into
 #tmp2 from t_ps1
declare alterpartition_cursor cursor
                 for select delptn from #tmp2
                 Open alterpartition_cursor

            Fetch next From alterpartition_cursor
            Into @sql

            While (@@Fetch_Status = 0 )
                  Begin

                         Begin
                               exec (@sql )
                         End

                         Fetch next From alterpartition_cursor
                         Into @sql

                  End
            Close alterpartition_cursor
            Deallocate alterpartition_cursor

/*declare xsqlcurosr cursor for
SELECT 'truncate table ' + name as xsql FROM SYS .TABLES WHERE NAME LIKE '%switchptn%'
  Open xsqlcurosr

            Fetch next From xsqlcurosr
            Into @xsql

            While (@@Fetch_Status = 0 )
                  Begin

                         Begin
                               exec (@xsql )
                         End

                         Fetch next From xsqlcurosr
                         Into @xsql

                  End
            Close xsqlcurosr
            Deallocate xsqlcurosr*/


declare @pfname varchar( 100 ),@rangevalue varchar( 100 )
declare mergepartition cursor for
select distinct ps. name ,convert ( varchar ( 100 ), prv . value) value from sys . partition_functions ps inner join
sys . partition_range_values prv on ps . function_id= prv .function_id where ps.name = @partitionfunction and value <=@psdate
  Open mergepartition

            Fetch next From mergepartition
            Into @pfname , @rangevalue

            While (@@Fetch_Status = 0 )
                  Begin

                         Begin
                               print ('alter partition function ' + @pfname+ '() merge range(' + '''' + @rangevalue+ '''' +')' )
							   exec ('alter partition function ' + @pfname+ '() merge range(' + '''' + @rangevalue+ '''' +')' )
                         End

                         Fetch next From mergepartition
                         Into @pfname , @rangevalue

                  End
            Close mergepartition
            Deallocate mergepartition


if object_id ( 'tempdb.dbo.#tmp1', 'u' ) is not null
drop table #tmp1
if object_id ( 'tempdb.dbo.#tmp2', 'u' ) is not null
drop table #tmp2
END


