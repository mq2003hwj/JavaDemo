-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spGenerateTradingId]
	 
AS
BEGIN
	INSERT INTO Ymt_AutoTradingIds DEFAULT VALUES
	
	IF @@ERROR > 0
		Return -1
		
	RETURN SCOPE_IDENTITY()+2000000
END
