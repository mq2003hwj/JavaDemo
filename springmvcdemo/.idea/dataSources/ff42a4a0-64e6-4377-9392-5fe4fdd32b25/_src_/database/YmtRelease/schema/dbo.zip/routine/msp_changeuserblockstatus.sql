
/*auth :chenli
date: 20150731
function:人工封账号，账号为iuserid，以逗号分隔
*/
CREATE procedure msp_changeuserblockstatus
(@iuserids varchar(max),@status int,@operater varchar(100))
as

set @iuserids = @iuserids + ','
Declare @batchID varchar(50)
set @batchID = newID()

declare @p int

while charindex(',',@iuserids) >0
begin
	Set @p = charindex(',',@iuserids)

	update ymt_users
		set blocked = @status
		where iuserid = left(@iuserids,@p - 1)
			and bLocked <> @status

	if @@Rowcount >0 
	Begin
		insert into user_block_log(batchid, iuserid, updatestatus, insertdate, operater)
		select @batchID,left(@iuserids,@p - 1),@status,getdate(),@operater
	End
	
	Set @iuserids = right(@iuserids,len(@iuserids) - @p)
End

select count(1) as updatenum from user_block_log where batchid = @batchID

return

