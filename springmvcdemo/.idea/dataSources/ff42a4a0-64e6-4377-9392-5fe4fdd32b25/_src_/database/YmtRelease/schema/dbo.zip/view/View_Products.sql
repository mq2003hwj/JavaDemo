CREATE VIEW dbo.View_Products
AS
SELECT     dbo.Ymt_Products.sProductId, dbo.Ymt_Products.sProduct, MIN(dbo.Ymt_Catalogs.fQuotePrice) AS fMinimumQuotePrice, MAX(dbo.Ymt_Catalogs.fQuotePrice) 
                      AS fMaximumQuotePrice, COUNT(dbo.Ymt_Catalogs.sCatalogId) AS iSellerCount
FROM         dbo.Ymt_Products LEFT OUTER JOIN
                      dbo.Ymt_ProductCategory ON dbo.Ymt_Products.iCategoryId = dbo.Ymt_ProductCategory.iCategoryId LEFT OUTER JOIN
                      dbo.Ymt_ProductBrand ON dbo.Ymt_Products.iBrandId = dbo.Ymt_ProductBrand.iBrandId LEFT OUTER JOIN
                      dbo.Ymt_Catalogs ON dbo.Ymt_Products.sProductId = dbo.Ymt_Catalogs.sProductId
GROUP BY dbo.Ymt_Products.sProductId, dbo.Ymt_Products.sProduct
