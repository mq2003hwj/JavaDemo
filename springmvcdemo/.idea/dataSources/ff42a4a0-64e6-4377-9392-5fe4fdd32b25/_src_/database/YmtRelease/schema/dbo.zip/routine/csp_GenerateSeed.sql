create proc csp_GenerateSeed
(
	@SequenceType varchar(16),
	@Seed int output
)
as
begin
	set @Seed=0
	if exists(select 1 from dbo.SequenceSeed(nolock) where SequenceType=@SequenceType)
		update dbo.SequenceSeed 
			set @Seed=Sequence+1,Sequence=Sequence+1
				where SequenceType=@SequenceType
	else
		insert into dbo.SequenceSeed values(@SequenceType,@Seed)
end
