
-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-1
-- Description: 交易服务SP       
-- 20160819：取消根据风控状态做的特殊查询逻辑   
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrdersList]

@sellerId int,
@activityId int,
@orderEstablishStatus int,
@orderStatusXml xml,
@top int,
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit

AS

-------------variables-------------
declare @orderStatus table([value] int primary key)

--------------process--------------
set nocount on;

if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

--set statistics time on;set statistics io on;

select top (@top) i.sProductId as productId, max(o.dAddTime) as lastOrderTime,
sum(case when o.iTradingStatus = @orderEstablishStatus 
/*or (@considerRiskVerfiedStatus = 0 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1)*/
then i.iAmount else 0 end) as notPaidCount,
sum(case when isnull(o.iTradingStatus, 0) != @orderEstablishStatus 
/*and (@considerRiskVerfiedStatus = 0 or (o.iTradingStatus <> 2 or o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2))*/
then i.iAmount else 0 end) as soldCount
from Ymt_OrderInfo(nolock) i
join Ymt_Orders(nolock) o on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.bShangouOrder = 1 and
(@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))
/*
(@considerOrderStatus = 0 or
  (
    (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
    or
    (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
    or
    (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
  )
)
*/
and exists(select top 1 1 from Ymt_OrderInfoExt(nolock) e where i.sOrderInfoId = e.sOrderInfoId and e.iActivityId = @activityId)
group by i.sProductId
order by lastOrderTime desc
option(recompile)

set nocount off;

--set statistics time off;set statistics io off;

