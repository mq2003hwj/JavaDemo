-- =============================================
-- Author:		Jmtek.Wu
-- Create date: 2013-8-13
-- Description:	计算用户的个性化推荐的邮件EDM发送时间
-- =============================================
CREATE PROCEDURE [dbo].[spRefreshEDMUserSetting]
AS
BEGIN		
	BEGIN TRAN
	
	Truncate table EDM_UserSetting
	
	-- 建临时表，查询无用户偏好的用户数据
	SELECT Distinct u.iUserId, u.sLoginId, u.sLoginEmail INTO #PreferUser
	FROM Ymt_Users u Inner Join Ymt_RecommendUserIndex i on u.iUserId = i.iUserId
	WHERE u.iType = 0 And u.sLoginEmail Like '%@%.%'
	
	print '最近60天有下单行为，发送周期为一周'
	print '最近下单时间大于60天但小于等于180天，发送周期为两周'
	print '最近下单时间大于360天但小于等于720天，发送周期八周'
	
	INSERT INTO EDM_UserSetting (iUserId, sLoginId, sLoginEmail, dSendDate, iType, sGAParam)
	SELECT o.iUserId, u.sLoginId, u.sLoginEmail, dbo.GetNextEDMSendDate(e.dLastSendEDMTime, o.Period), 1, o.GAParam
	FROM #PreferUser u Inner Join EDM_Config e with(nolock) on u.iUserId = e.iUserId Inner Join (
		-- 最近60天有下单行为，发送周期为一周
		SELECT 
			iUserId, 
			Period = 7,
			'utm_source=edm&utm_medium=P_recmd&utm_campaign=60' as GAParam 
		FROM Ymt_Orders with(nolock)
		GROUP BY iUserId
		HAVING DateDiff(day, MAX(dPaidTime), GETDATE()) > 7 AND DateDiff(day, MAX(dAddTime), GETDATE()) <= 60
		UNION
		-- 最近下单时间大于60天但小于等于180天，发送周期为两周
		SELECT 
			iUserId, 
			Period = 14,
			'utm_source=edm&utm_medium=P_recmd&utm_campaign=180' as GAParam 
		FROM Ymt_Orders with(nolock)
		GROUP BY iUserId
		HAVING DateDiff(day, MAX(dAddTime), GETDATE()) > 60 AND DateDiff(day, MAX(dAddTime), GETDATE()) <= 180
		UNION
		-- 最近下单时间大于360天但小于等于720天，发送周期八周
		SELECT 
			iUserId, 
			Period = 56,
			'utm_source=edm&utm_medium=P_recmd&utm_campaign=720' as GAParam 
		FROM Ymt_Orders with(nolock)
		GROUP BY iUserId
		HAVING DateDiff(day, MAX(dAddTime), GETDATE()) > 360 AND DateDiff(day, MAX(dAddTime), GETDATE()) <= 720
	) o on o.iUserId = e.iUserId
	
	PRINT Cast(@@ROWCOUNT as Varchar(Max)) + ' Records Inserted!'
	
	IF @@ERROR > 0
	BEGIN
		PRINT 'ERROR: ' + Cast(@@ERROR as Varchar(Max))
		ROLLBACK
		RETURN
	END
		
	print '最近下单时间大于180天但小于等于360天，如最近30天有登录、访问记录，发送周期为两周，如最近30天无登录、访问记录，发送周期为四周'
	
	INSERT INTO EDM_UserSetting (iUserId, sLoginId, sLoginEmail, dSendDate, iType, sGAParam)
	SELECT 
		o.iUserId, u.sLoginId, u.sLoginEmail, 
		dbo.GetNextEDMSendDate(e.dLastSendEDMTime, 
			Case 
				When DATEDIFF(day, e.dLastVisitSiteTime, GETDATE()) <= 30 Then 14 
				Else 28 
			End), 
		1, 
		Case 
			When DATEDIFF(day, e.dLastVisitSiteTime, GETDATE()) <= 30 Then 'utm_source=edm&utm_medium=P_recmd&utm_campaign=360_log' 
			Else 'utm_source=edm&utm_medium=P_recmd&utm_campaign=360_nolog' 
		End
	FROM #PreferUser u Inner Join EDM_Config e with(nolock) on u.iUserId = e.iUserId Inner Join (
		SELECT iUserId
		FROM Ymt_Orders with(nolock)
		GROUP BY iUserId
		HAVING DateDiff(day, MAX(dAddTime), GETDATE()) > 180 AND DateDiff(day, MAX(dAddTime), GETDATE()) <= 360
	) o on o.iUserId = e.iUserId
	
	PRINT Cast(@@ROWCOUNT as Varchar(Max)) + ' Records Inserted!'
	
	IF @@ERROR > 0
	BEGIN
		PRINT 'ERROR: ' + Cast(@@ERROR as Varchar(Max))
		ROLLBACK
		RETURN
	END
		
	Drop Table #PreferUser
	
	-- 建临时表，查询无用户偏好的用户数据
	SELECT Distinct u.iUserId, u.sLoginId, u.sLoginEmail, u.dAddTime, u.iAction INTO #NoPreferUser
	FROM Ymt_Users u Left Join Ymt_RecommendUserIndex i on u.iUserId = i.iUserId
	WHERE i.iUserId is Null And u.iType = 0 And u.sLoginEmail Like '%@%.%'
		
	print '最近登录时间与注册时间间距大于72小时，如最近30天有登录、访问记录，发送周期为两周，如最近30天无登录、访问记录，发送周期为四周'
	
	INSERT INTO EDM_UserSetting (iUserId, sLoginId, sLoginEmail, dSendDate, iType, sGAParam)
	SELECT
		u.iUserId, u.sLoginId, u.sLoginEmail, 
		dbo.GetNextEDMSendDate(e.dLastSendEDMTime, 
			Case
				When DATEDIFF(day, e.dLastVisitSiteTime, GETDATE()) <= 30 Then 14
				Else 28
			End
		),
		0,
		Case
			When DATEDIFF(day, e.dLastVisitSiteTime, GETDATE()) <= 30 Then 'utm_source=edm&utm_medium=all_recmd&utm_campaign=log'
			Else 'utm_source=edm&utm_medium=all_recmd&utm_campaign=nolog'
		End		
	FROM #NoPreferUser u with(nolock) Inner Join EDM_Config e with(nolock) on u.iUserId = e.iUserId
	WHERE DATEDIFF(HOUR, u.dAddTime, e.dLastVisitSiteTime) > 72 And DATEDIFF(DAY, u.dAddTime, e.dLastVisitSiteTime) < 450 -- 最近登录时间与注册时间间距大于72小时		
	
	PRINT Cast(@@ROWCOUNT as Varchar(Max)) + ' Records Inserted!'
	
	IF @@ERROR > 0
	BEGIN
		PRINT 'ERROR: ' + Cast(@@ERROR as Varchar(Max))
		ROLLBACK
		RETURN
	END
	
	print '最近登录时间与注册时间间距小于等于72小时并且邮箱经过验证，如最近30天有登录、访问记录，发送周期为四周，如最近30天无登录、访问记录，发送周期为八周'
	
	INSERT INTO EDM_UserSetting (iUserId, sLoginId, sLoginEmail, dSendDate, iType, sGAParam)
	SELECT
		u.iUserId, u.sLoginId, u.sLoginEmail, 
		dbo.GetNextEDMSendDate(e.dLastSendEDMTime, 
			Case
				When DATEDIFF(day, e.dLastVisitSiteTime, GETDATE()) <= 30 Then 28
				Else 56
			End
		),
		0,
		Case
			When DATEDIFF(day, e.dLastVisitSiteTime, GETDATE()) <= 30 Then 'utm_source=edm&utm_medium=all_recmd&utm_campaign=log_reg'
			Else 'utm_source=edm&utm_medium=all_recmd&utm_campaign=nolog_reg'
		End	
	FROM #NoPreferUser u with(nolock) Inner Join EDM_Config e with(nolock) on u.iUserId = e.iUserId
	WHERE 
		DATEDIFF(HOUR, u.dAddTime, e.dLastVisitSiteTime) <= 72 And DATEDIFF(DAY, u.dAddTime, GetDate()) > 7 And -- 最近登录时间与注册时间间距小于等于72小时
		iAction = 1 -- 邮箱经过验证
	
	PRINT Cast(@@ROWCOUNT as Varchar(Max)) + ' Records Inserted!'
	
	IF @@ERROR > 0
	BEGIN
		PRINT 'ERROR: ' + Cast(@@ERROR as Varchar(Max))
		ROLLBACK
		RETURN
	END
	
	DROP Table #NoPreferUser
	
	UPDATE EDM_UserSetting SET dSendDate = DATEADD(YEAR, 1,  dSendDate) WHERE sLoginEmail like '%ymatou.com.cn'
	UPDATE EDM_UserSetting SET dSendDate = DATEADD(YEAR, 1,  dSendDate) WHERE sLoginEmail like '%ymatou.cn'
	
	COMMIT
END
