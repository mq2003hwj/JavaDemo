





-- =============================================            
-- Author:  fanwei        
-- Create date: 2016-6-15
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetOrderFundDetail]
@orderId int,
@summary bit = 0
AS

declare @shangou bit
declare @status int
declare @refund int

select @shangou = bshangouorder, @status = iTradingStatus, @refund = iSalesRefundStatus from ymt_orders where iorderid = @orderId
select @orderId as OrderId, @shangou as NeedPayTwiceOrMore where @status is not null

if @status is null
	return;

declare @t table(
[Time] datetime
,Cash decimal(18,2),Gift decimal(18,2),FreeCard decimal(18,2)
,Coupon decimal(18,2)
,CouponChannel decimal(18,2),CouponCode varchar(50)
,Total decimal(18,2)
,OccurredPrice decimal(18,2)
,PriceChange decimal(18,2),Freight decimal(18,2)
,Evidence varchar(50),IsIncoming bit,Operation int

,SellerCouponCode varchar(50)
,SellerCoupon decimal(18,2)
,AccountPaidAmount decimal(18,2)
,ThirdPartyPaidAmount decimal(18,2)
,ThirdPartyName varchar(50)
)

if @shangou = 1 begin
	if @status in (2,3,4,16,17) begin
		insert into @t
		select top 1
		o.dPaidTime
		,s.fPaidAmountOfCash,fPaidAmountOfGift,fPaidAmountOfFreeCard
		,s.fPaidAmountOfYmtCoupon
		,IIF(o.fYmtCouponAmount>0 and o.fSellerCouponAmount > 0, 3, o.iCouponChannel)
		,o.sCouponCode
		,isnull(s.fPaidAmountOfCash, 0) + isnull(s.fPaidAmountOfGift, 0) + isnull(s.fPaidAmountOfFreeCard, 0) + isnull(s.fPaidAmountOfYmtCoupon, 0)
		,o.fOrderPrice
		,o.fOrderDiscount ,o.fFreight
		,null,1,1

		,o.sSellerCouponCode
		,s.fPaidAmountOfSellerCoupon
		,isnull(s.fPaidAmountOfCash, 0) - isnull(IIF(isnull(s.fPaidAmountOfThirdParty, 0) > 0, s.fPaidAmountOfThirdParty, p.fAmount), 0)
		,IIF(isnull(s.fPaidAmountOfThirdParty, 0) > 0, s.fPaidAmountOfThirdParty, p.fAmount)
		,p.sPayChannel

		from Ymt_OrderState s join Ymt_Orders o
		on s.iorderid = o.iorderid
		outer apply (select top 1 fAmount, sPayChannel from ymt_tradinginfo where s.fPaidAmountOfCash > 0 and iTradingId = o.iTradingId and iTradingStatus = 2) p
		where s.iorderid = @orderId
	end
	
	if @status in (3,4,17) begin
		insert into @t
		select top 1
		o.dPostPaidTime
		,s.fPostPaidAmountOfCash,fPostPaidAmountOfGift,0
		,0,0,null
		,s.fPostPaidAmountOfCash+s.fPostPaidAmountOfGift
		,s.fPostPaidAmountOfCash+s.fPostPaidAmountOfGift
		,s.fPostPaidAmountOfCash+s.fPostPaidAmountOfGift-(o.fTotalPrice-o.fOrderPrice),0
		,null,1,2

		,null
		,0
		,isnull(s.fPostPaidAmountOfCash, 0) - isnull(IIF(isnull(s.fPostPaidAmountOfThirdParty, 0) > 0, s.fPostPaidAmountOfThirdParty, p.Amount), 0)
		,IIF(isnull(s.fPostPaidAmountOfThirdParty, 0) > 0, s.fPostPaidAmountOfThirdParty, p.Amount)
		,p.sPayChannel

		from Ymt_OrderState s join Ymt_Orders o
		on s.iorderid = o.iorderid
		outer apply (
			select top 1 b.Amount,a.sPayChannel from Ymt_OrderPostPay a
			left join Ymt_PostPayTradingInfo b on b.PostPayTradingId = a.sPostPayTradingId
			where s.fPostPaidAmountOfCash > 0 and a.iOrderId = o.iOrderId and a.iAction = 1
			and b.OrderId = o.iOrderId and b.[Action] = 1
		) p
		where s.iorderid = @orderId and o.bPaidInFull = 1 and s.fPostPaidAmountOfCash > 0
	end
	
	if @refund is not null begin
		insert into @t
		select
		AddTime
		,RefundedAmountOfCash,RefundedAmountOfGift,0
		,SettlementAmountOfCoupon, IIF(SettlementAmountOfCoupon > 0, 1, 0),null
		,RefundAmount + isnull(SettlementAmountOfCoupon, 0)
		,RefundAmount
		,0,0
		,RefundBillNo,0,3

		,null
		,0
		,0
		,0
		,null

		from Ymt_RefundBill
		where orderid = @orderId and SalesRefundStatus = 10 and RefundStatus = 1
	end


end else begin

	if @status in (2,3,4,16,17) begin
		insert into @t
		select top 1
		o.dPaidTime
		,s.fPaidAmountOfCash,fPaidAmountOfGift,fPaidAmountOfFreeCard
		,s.fPaidAmountOfYmtCoupon,IIF(o.fYmtCouponAmount>0 and o.fSellerCouponAmount > 0, 3, o.iCouponChannel),o.sCouponCode
		,isnull(s.fPaidAmountOfCash, 0) + isnull(s.fPaidAmountOfGift, 0) + isnull(s.fPaidAmountOfFreeCard, 0) + isnull(s.fPaidAmountOfYmtCoupon, 0)
		,o.fOrderPrice
		,o.fOrderDiscount,o.fFreight
		,null,1,1

		,o.sSellerCouponCode
		,s.fPaidAmountOfSellerCoupon
		,isnull(s.fPaidAmountOfCash, 0) - isnull(IIF(isnull(s.fPaidAmountOfThirdParty, 0) > 0, s.fPaidAmountOfThirdParty, p.fAmount), 0)
		,IIF(isnull(s.fPaidAmountOfThirdParty, 0) > 0, s.fPaidAmountOfThirdParty, p.fAmount)
		,p.sPayChannel

		from Ymt_OrderState s join Ymt_Orders o
		on s.iorderid = o.iorderid
		outer apply (select top 1 fAmount, sPayChannel from ymt_tradinginfo where s.fPaidAmountOfCash > 0 and iTradingId = o.iTradingId and iTradingStatus = 2) p
		where s.iorderid = @orderId
	end
	
	if @refund is not null begin
		insert into @t
		select
		AddTime
		,RefundedAmountOfCash,RefundedAmountOfGift,0
		,SettlementAmountOfCoupon, IIF(SettlementAmountOfCoupon > 0, 1, 0),null
		,RefundAmount + isnull(SettlementAmountOfCoupon, 0)
		,RefundAmount
		,0,0
		,RefundBillNo,0,3

		,null
		,0
		,0
		,0
		,null

		from Ymt_RefundBill
		where orderid = @orderId and SalesRefundStatus = 10 and RefundStatus = 1
	end

end

select * from @t

if @summary is null or @summary <> 1 
	return;

select s.fPaidAmountOfCash as PaidCash
,s.fPaidAmountOfGift as PaidGift
,s.fPaidAmountOfFreeCard as PaidFreeCard
,s.fPaidAmountOfYmtCoupon as PaidYmtCoupon
,s.fPaidAmountOfSellerCoupon as PaidSellerCoupon
,s.fPostPaidAmountOfCash as PostPaidCash
,s.fPostPaidAmountOfGift as PostPaidGift
,o.fTotalPrice as TotalProductPrice
,o.fOrderPrice as FirstPayProductPrice
,o.fFreight as Freight
,o.fOrderDiscount as OrderDiscount
,o.fDiscount as PostPayDiscount
,o.fSellerPromotionAmount as TotalActivityPrice
,r.TotalRefundedCash
,r.TotalRefundedGift 
,r.TotalRefundedYmtCoupon
from Ymt_OrderState s join Ymt_Orders o
on s.iorderid = o.iorderid
outer apply (
	select sum(RefundedAmountOfCash) as TotalRefundedCash, sum(RefundedAmountOfGift) as TotalRefundedGift, sum(SettlementAmountOfCoupon) as TotalRefundedYmtCoupon
	from Ymt_RefundBill where OrderId = o.iOrderId and SalesRefundStatus = 10 and RefundStatus = 1
) r
where s.iorderid = @orderId
