CREATE TRIGGER [dbo].[OrderAdded]
ON [dbo].[Ymt_Orders]
AFTER INSERT
AS
Begin
	Declare @iOrderId int
	Declare @iUserId int
	Declare @sName varchar(200)
	Select @sName = sReceivePerson, @iUserId = iUserId, @iOrderId = iOrderId From inserted

    --如果此订单对身份证有要求的则判断是否上传过身份证，目前目前护航直邮和保税商品为需要上传身份证
	--If Exists (Select 1 From dbo.Ymt_OrderExt with(nolock) Where bIsNeedUploadIdCard = 1 And iOrderId = @iOrderId) Begin
		Insert Into Ymt_OrderIdCard
		Select Top 1 @iOrderId, @iUserId, 1 
		From [Ymt_IdPic] with(nolock)
		Where iUserId = @iUserId And sName = @sName
	--End
End