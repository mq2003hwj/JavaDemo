-- ============================================= 

-- Author: ccw

-- Create date: 2015-06-11 

-- Description: 获取补偿数据

-- =============================================
CREATE proc [dbo].[csp_GetCallbackCompensateJobs]
(
	@MachineName varchar(64),
	@MaxRetryCount int=5,
	@MaxJobsPerDuration int=100,
	@MaxDayRange int=30
)
as
begin
	set rowcount @MaxJobsPerDuration

	select CompensateId into #Temp

	from CallbackCompensateProcessInfo a with (index = idx_CallbackCompensateProcessInfo_ProcessStatus)
	where CreatedTime between DATEADD(day,-@MaxDayRange,getdate()) and DATEADD(SECOND,-20,getdate())
		and RetryCount<@MaxRetryCount
		and (ProcessMachineName is null or ProcessMachineName=@MachineName)
		and ProcessStatus in (0,-1)

	update CallbackCompensateProcessInfo
		set ProcessMachineName=@MachineName
		where CompensateId in (select CompensateId from #temp)

	--update a
	--set ProcessMachineName=@MachineName
	--from  a with (index = idx_CallbackCompensateProcessInfo_ProcessStatus)
	--where CreatedTime between DATEADD(day,-@MaxDayRange,getdate()) and DATEADD(SECOND,-20,getdate())
	--	and RetryCount<@MaxRetryCount
	--	and (ProcessMachineName is null or ProcessMachineName=@MachineName)
	--	and ProcessStatus in (0,-1)

	select * from dbo.CallbackCompensateProcessInfo with (index = idx_CallbackCompensateProcessInfo_ProcessStatus)
		where CreatedTime between DATEADD(day,-@MaxDayRange,getdate()) and DATEADD(SECOND,-20,getdate())
		and RetryCount<@MaxRetryCount
		and ProcessMachineName=@MachineName
		and ProcessStatus in (0,-1)

end

