-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE spGetSubCategorys
	-- Add the parameters for the stored procedure here
	@CategoryId varchar(400) = '0'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    DECLARE @CategoryIds varchar(500);
	SELECT @CategoryIds=(sSubCategorys) FROM Trig_CategorysIndex WHERE iCategoryId=@CategoryId
	DECLARE @StrSQL varchar(4000);
	
	SET @StrSQL = 'SELECT * FROM Ymt_ProductCategory ';
	IF(@CategoryIds != '')
	BEGIN
		SET @StrSQL += ' WHERE iCategoryId IN ('+@CategoryIds+')';
	END
	SET @StrSQL += ' order by ilevel'
	EXEC (@StrSQL);
END
