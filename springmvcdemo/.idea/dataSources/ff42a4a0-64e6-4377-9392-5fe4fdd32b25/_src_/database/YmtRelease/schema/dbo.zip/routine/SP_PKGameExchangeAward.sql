/**********************************************
**** Author:		Rain.Xiao              ****
**** Create date:   2015-10-14             ****
**** Description:	PK赛奖品兑换存储过程   ****
**********************************************/
CREATE PROC SP_PKGameExchangeAward
 @iUserId INT,--用户Id
 @sAwardId VARCHAR(36)--奖品Id
AS
 BEGIN TRAN
  BEGIN TRY
   DECLARE @sAwardName NVARCHAR(200),@sNeedPoint INT,@iStock INT
   SELECT @sAwardName=sAwardName,@sNeedPoint=sNeedPoint,@iStock=iStock FROM Ymt_PKGameAward WHERE sAwardId=@sAwardId AND iStatus=1
   IF @iStock>0
   BEGIN
    INSERT INTO Ymt_PKGamePoint(iUserId,iPointNumber,iPointType,sAwardName) VALUES(@iUserId,@sNeedPoint,2,@sAwardName)
    INSERT INTO Ymt_PKGameAwardExchange(iUserId,sAwardId) VALUES(@iUserId,@sAwardId)
	UPDATE Ymt_PKGameAward SET iStock=iStock-1,iHasExchangeNumber=iHasExchangeNumber+1 WHERE sAwardId=@sAwardId
   END
  END TRY
  BEGIN CATCH
      SELECT
	   ERROR_NUMBER() AS ErrorNumber,
       ERROR_SEVERITY() AS ErrorSeverity,
       ERROR_STATE() as ErrorState,
	   ERROR_PROCEDURE() as ErrorProcedure,
	   ERROR_LINE() as ErrorLine,
	   ERROR_MESSAGE() as ErrorMessage;
     IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
   END CATCH
  IF @@TRANCOUNT > 0
   COMMIT TRANSACTION