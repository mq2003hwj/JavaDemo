-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE spSyncProductIsMerchant
	 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
update ymt_products set iIsMerchant=case when si.mshop IS null then 0 else si.mshop end
,
   ymt_products.iCatalogType=c.icatalogtype ,
   ymt_products.icatalogstatus=c.icatalogstatus
--select p.sproductid,case when si.mshop IS null then 0 else si.mshop end as mshop
 from ymt_products p 
join Ymt_Catalogs c on p.sProductId=c.sProductId and c.iAction>-1
join ymt_users u on c.iUserId=u.iUserId
join Ymt_SellerInfo si on u.iUserId=si.iUserId and si.iAction>-1
where p.iAction>-1 
END
