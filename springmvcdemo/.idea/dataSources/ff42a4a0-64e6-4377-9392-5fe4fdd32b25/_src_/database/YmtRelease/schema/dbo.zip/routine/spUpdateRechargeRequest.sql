
CREATE PROCEDURE [dbo].[spUpdateRechargeRequest]
@rechargeRequestId varchar(200),   --美金充值的recharge request id
@result int=0 out,                 --返回值,1表示成功,非1 表示失败
@message varchar(max) out          --错误消息
AS
BEGIN
	SET NOCOUNT ON;
	set @result=0
	set @message=''
	 
	--Recharge request不存在
	declare @requestexist int
	select   @requestexist=count(*) from  Ymt_RechargeRequest where sRechargeRequestId=@rechargeRequestId

	if	@requestexist<=0 
		begin
			 set @result=0
			 set @message='用户不存在'
		end
	else 
		begin
			--插入流水
			update Ymt_RechargeRequest set iaction=1  where sRechargeRequestId=@rechargeRequestId 
			set @result=1
		end 
SELECT @result as result,@message as message
end
	
