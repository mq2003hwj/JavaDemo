


CREATE proc [dbo].[csp_GetPaymentMiscInfo] 
( 
@TradeNo varchar(32) 
) 
as 
begin 
if exists( select 1 from dbo.PaymentOrder(nolock) where bizno=@TradeNo and PaymentStatus=1) 
select (case when a.PaymentMethod<9 then 1 
when a.PaymentMethod=10 then 3 
else 2 end) PayChannel,a.SettlementAmount as ActualPayPrice, a.PaymentId, 
(case when a.PaymentMethod = 11 then 14 
when a.PaymentMethod = 12 then 15 
when a.PaymentMethod = 13 then 14 
else 10 end) paytype, b.TradeNo as InstitutionPaymentId from dbo.PaymentOrder a(nolock) left join dbo.PaymentNotify b(nolock) on a.PaymentId = b.BizNo where a.bizno=@TradeNo 
else 
select ( 
case when a.PayType<14 then 1 
else 2 end 
) PayChannel,b.ActualPayPrice,b.PaymentId,a.PayType,b.InstitutionPaymentId 
from dbo.PP_BussinessOrder a (nolock) inner join dbo.PP_Payment b (nolock) on a.BussinessOrderId =b.BussinessOrderId 
where a.OrderId=@TradeNo and b.PayStatus=1 
end
