
-- =============================================            
-- Author:  zhangzhiqiang        
-- Create date: 2015-9-9
-- Description: 创建订单（M2C）       
-- =============================================     

CREATE PROC [dbo].[sp_CreateOrder_New]
	@UserId INT,
	@OrderType INT,
	@OrderSource VARCHAR(128),
	@OrderSourceIp VARCHAR(128),
	@TerminalSource VARCHAR(128),
	@AppTerminalSource VARCHAR(128),
	@DeviceId VARCHAR(200) = null,
	@IsNeedUploadIdCard BIT,
	@SellerId INT,
	@Address VARCHAR(1000),
	@PostCode VARCHAR(10),
	@Phone VARCHAR(20),
	@ReceivePerson VARCHAR(50),
	@Telephone VARCHAR(20),
	@Freight DECIMAL(18,2),
	@LeaveWord VARCHAR(2000),
	@AutoCancelOrderHours DECIMAL(18,2),
	@IncludeActivity BIT,
	@CanLocalReturn BIT,
	@CurType VARCHAR(50),
	@OrderPrice  DECIMAL(18,2),
	@UseGiftAmount DECIMAL(18,2),
	@UseFreeCardAmount DECIMAL(18,2),
	@CouponCode VARCHAR(36) = null,
	@CouponType INT = null,
	@CouponValue DECIMAL(18,2) = null,
	@CouponChannel INT = null,
	@CommissionFee DECIMAL(18,2),
	@OrderInfos TempOrderInfos2 READONLY
AS

declare @OrderId int
		,@QQ varchar(20)
		,@Email varchar(500)
		,@BuyerLoginId nvarchar(200)
		,@BuyerLoginEmail nvarchar(200)
		,@SellerLoginId nvarchar(200)
		,@SellerLoginEmail nvarchar(200)
		,@SellerType int
		,@IsMerchant int = 0  --0：非商家
		,@BuyerNickName nvarchar(200)

		,@OrderInfoId varchar(36)
		,@ProductNum int
		,@PropetyInfo varchar(2000)
		,@ProductPrice decimal(18,2)
		,@PictureUrl varchar(1000)
		,@ProductName varchar(500)
		,@SailProtected int
		,@CatalogId varchar(36)
		,@CatalogStatus int
		,@CatalogType int
		,@SKU varchar(300)
		,@ProductId varchar(36)
		,@MainCategoryId int
		,@SubCategoryId int
		,@ThirdCategoryId int
		,@ProductBrandId int
		,@BondedArea int
		,@ProductCode varchar(50)
		,@Flight decimal(18,2)
		,@TariffType int
		,@PackageNo VARCHAR(50)
		,@CouponAvail4OrderDeduct bit
		,@GiftAvail4Reward bit
		,@ActivityId int
		,@ActivityTemplateId int
		,@PromotionType int
		,@Promotion decimal(18,2)
		,@CommissionRate decimal(18,2)
		,@Premium decimal(18,2)
		,@IsCost bit
		,@GiftAvail4OrderDeduct bit
		,@FeeFree bit
		,@Only4Vip bit
		,@TotalPrice decimal(18,2)
		,@Id int
		,@Now datetime = getdate()


	--生成新订单号
	EXEC @OrderId = spGenerateOrderId 

	SELECT @QQ=sQQ,@Email=sLoginEmail,@BuyerLoginId=sLoginId,@BuyerLoginEmail=sLoginEmail,@BuyerNickName=sNickName
	FROM Ymt_Users WITH(NOLOCK) WHERE iUserId = @UserId

	SELECT @SellerLoginId=sLoginId,@SellerLoginEmail=sLoginEmail,@SellerType=iType
	FROM Ymt_Users WITH(NOLOCK) WHERE iUserId = @SellerId

	--验证此卖家是否是商家
	IF @SellerType=1 AND EXISTS(SELECT 1 FROM Ymt_SellerInfo WITH(NOLOCK) WHERE iUserId=@SellerId AND mshop = 1)
	BEGIN
		SET @IsMerchant = 1
	END

	--插入订单数据Ymt_Orders
	INSERT INTO [Ymt_Orders]
           ([iOrderId],[iUserId],[iBuyerId],[sMarkId],[dAddTime],[fOrderPrice],[fOrderDiscount] ,[fFreight],[fDiscount],[iTradingStatus] ,[sAddress],[sPostCode]
           ,[sReceivePerson],[sPhone],[sTelephone],[sQQ],[sEmail] ,[sLeaveWord],[iUnfreezeStatus],[bPaidInFull],[fUseGiftAmount],[sCouponCode],[CouponValue]
           ,[iCouponType],[iCouponChannel],[iDistributor],[fAutoCancelOrderHours],[bShangouOrder],[sBuyerLoginId],[sBuyerLoginEmail],[sSellerLoginId]
           ,[sSellerLoginEmail],[iIsMerchant],[sBuyerNickName],[fTotalPrice],[fUseFreeCardAmount],[bIncludeActivityProducts],[sCurType],[bCanLocalReturn])
     VALUES
           (@OrderId,@UserId,@SellerId,'',@Now,@OrderPrice,0,@Freight,0,1,@Address,@PostCode,@ReceivePerson,@Phone,@Telephone,@QQ,@Email,@LeaveWord,0,1
           ,@UseGiftAmount,@CouponCode,@CouponValue,@CouponType,@CouponChannel,1,@AutoCancelOrderHours,0,@BuyerLoginId,@BuyerLoginEmail,@SellerLoginId
           ,@SellerLoginEmail,@IsMerchant,@BuyerNickName,@OrderPrice,@UseFreeCardAmount,@IncludeActivity,@CurType,@CanLocalReturn)
	
	--插入订单资金数据Ymt_OrderState
	IF @CouponValue IS NULL OR (@CouponType IS NOT NULL AND @CouponType <> 1)
	BEGIN
		SET @CouponValue = 0
	END
	INSERT INTO [Ymt_OrderState]
           ([iOrderId],[fRefundedAmountOfCash],[fRefundedAmountOfGift],[fPaidAmountOfCash],[fPaidAmountOfGift],[fPostPaidAmountOfCash],[fPostPaidAmountOfGift]
           ,[fPaidAmountOfCoupon],[fRefundedAmountOfCoupon],[fPostPadiAmountOfCoupon],[fQuickTurnoverAmount],[fCommissionFee],[fNeedCommissionFee]
           ,[fPaidAmountOfFreeCard],[fBalanceAmount])
     VALUES
           (@OrderId, 0, 0, 0, @UseGiftAmount, 0, 0, @CouponValue, 0, 0, 0, 0, @CommissionFee, @UseFreeCardAmount, 0)
	
	--插入订单扩展信息Ymt_OrderExt
	INSERT INTO [Ymt_OrderExt]
           ([iOrderId],[sOrderSource],[sOrderSourceIP],[iOrderType],[sTerminalSource],[bIsNeedUploadIdCard],[sAppTerminalSource],[sDeviceId])
    VALUES
           (@OrderId,@OrderSource,@OrderSourceIP,@OrderType,@TerminalSource,@IsNeedUploadIdCard,@AppTerminalSource,@DeviceId)

	SET @Id = 1
	WHILE EXISTS(SELECT 1 FROM @OrderInfos WHERE RowId=@Id)
	BEGIN
		SET @OrderInfoId = newid()

		SELECT @CatalogId=CatalogId,@PropetyInfo=PropetyInfo,@ProductName=ProductName,@PictureUrl=PictureUrl
			,@ProductPrice=ProductPrice,@ProductNum=ProductNum,@SailProtected=SailProtected,@SKU=SKU,@PackageNo=PackageNo
			,@CatalogType=CatalogType,@CatalogStatus=CatalogStatus,@ProductId=ProductId,@MainCategoryId=MainCategoryId
			,@SubCategoryId=SubCategoryId,@ThirdCategoryId=ThirdCategoryId,@ProductBrandId=ProductBrandId,@BondedArea=BondedArea
			,@ProductCode=ProductCode,@TariffType=TariffType,@Flight=Flight,@ActivityId=ActivityId
			,@ActivityTemplateId=ActivityTemplateId,@PromotionType=PromotionType,@Promotion=Promotion,@GiftAvail4Reward=GiftAvail4Reward
			,@GiftAvail4OrderDeduct=GiftAvail4OrderDeduct,@CouponAvail4OrderDeduct=CouponAvail4OrderDeduct,@Only4VIP=Only4VIP
			,@FeeFree=FeeFree,@CommissionRate=CommissionRate,@Premium=Premium,@IsCost=IsCost
		FROM @OrderInfos WHERE RowId=@Id

		--插入订单商品信息Ymt_OrderInfo
		SET @TotalPrice = @ProductPrice * @ProductNum
		INSERT INTO [Ymt_OrderInfo]
			   ([sOrderInfoId],[iOrderId],[iType],[sCatalogId],[sPropertyInfo],[sTitle],[sPictureUrl],[fOriginalPrice],[fDiscount],[iAmount]
			   ,[fTotalPrice],[iSailProtected],[sSKU],[iCatalogType],[iCatalogStatus],[sProductId],[iProductMainCategoryId],[iProductSubCategoryId]
			   ,[iProductThirdCategoryId],[iProductBrandId],[iBondedArea],[sProductCode],[iTariffType],[fFlight],[iPriceType],[sPackageNo])
		 VALUES
			   (@OrderInfoId,@OrderId,0,@CatalogId,@PropetyInfo,@ProductName,@PictureUrl,@ProductPrice,0,@ProductNum,@TotalPrice
			   ,@SailProtected,@SKU,@CatalogType,@CatalogStatus,@ProductId,@MainCategoryId,@SubCategoryId,@ThirdCategoryId,@ProductBrandId
			   ,@BondedArea,@ProductCode,@TariffType,@Flight,0,@PackageNo)

		IF @ActivityId > 0  --插入订单商品活动信息Ymt_OrderInfoExt
		BEGIN
			INSERT INTO [Ymt_OrderInfoExt]
				([sOrderInfoId],[iActivityId],[iActivityTemplateId],[iPromotionType],[fPromotion],[bGiftAvail4OrderDeduct]
				,[bGiftAvail4Reward],[bCouponAvail4OrderDeduct],[bOnly4VIP],[bFeeFree],[fCommissionRate],[fPremium],[bIsCost])
			VALUES
				(@OrderInfoId,@ActivityId,@ActivityTemplateId,@PromotionType,@Promotion,@GiftAvail4OrderDeduct,@GiftAvail4Reward
				,@CouponAvail4OrderDeduct,@Only4VIP,@FeeFree,@CommissionRate,@Premium,@IsCost)
		END
		SET @Id = @Id + 1
	END

SELECT @OrderId AS iOrderId,@SellerId AS iBuyerId,@CouponCode AS sCouponCode,@CouponType AS iCouponType,@UseGiftAmount AS fUseGiftAmount
		,@UseFreeCardAmount AS fUseFreeCardAmount,@AutoCancelOrderHours AS fAutoCancelOrderHours,@OrderPrice AS fOrderPrice
