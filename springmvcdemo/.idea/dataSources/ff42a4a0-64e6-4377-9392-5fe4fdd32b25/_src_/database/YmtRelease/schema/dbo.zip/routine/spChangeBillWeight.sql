-- =============================================
-- Author:		Jeff
-- Create date: 2011-8-9
-- Description:	Change
-- =============================================
CREATE PROCEDURE [dbo].[spChangeBillWeight]
	@BillCode		varchar(20),
	@Weight			Decimal(10, 2)
AS
DECLARE
/* return codes */
	@ReturnCode Varchar(10),	
/* local variables & const */
	@WEIGHT_DUTY_TYPE Int,
	@BillId Varchar(36),
	@DeclareWeight Decimal(10, 2),
	@PAYMENT_STATUS_PENDING Int,
	@BILL_WEIGHTCHARGE_NONEED Int,
	@BILL_WEIGHTCHARGE_PENDING Int,
	@BILL_WEIGHTCHARGE_NEEDCALCULATE Int,
	@BILL_WEIGHTCHARGE_NEEDREFUND Int,
	@RC_BAD_BILL_CODE Int,
	@RC_BAD_BILL_STATUS Int,
	@RC_UNEXPECTED_ERROR Int
BEGIN
	
	Set @WEIGHT_DUTY_TYPE = 1
	Set @PAYMENT_STATUS_PENDING = 1
	Set @BILL_WEIGHTCHARGE_NONEED = 0
	Set @BILL_WEIGHTCHARGE_NEEDCALCULATE = 1
	Set @BILL_WEIGHTCHARGE_PENDING = 2
	Set @BILL_WEIGHTCHARGE_NEEDREFUND = 5
	Set @RC_BAD_BILL_CODE = -1001
	Set @RC_BAD_BILL_STATUS = -1002	
	Set @RC_UNEXPECTED_ERROR = -1
	Set @ReturnCode = 0
	
	Select @BillId = sBillId, @DeclareWeight = fDeclareWeight From Ymt_Bill Where sBillCode = @BillCode
	
	-- Check bill existance
	If @@ROWCOUNT <> 1 Or ISNULL(@BillId, '0') = '0'
	Begin
		Set @ReturnCode = @RC_BAD_BILL_CODE	-- no such bill code
		Return @ReturnCode
	End
	
	-- Check bill payment process
	If Exists (Select sBillId From Ymt_BillPaymentDuty Where sBillId = @BillId And iStatus = @PAYMENT_STATUS_PENDING And iType = @WEIGHT_DUTY_TYPE)
	Begin
		Set @ReturnCode = @RC_BAD_BILL_STATUS -- bill under paying
		Return @ReturnCode
	End
	
	If Exists (Select sBillId From Ymt_Bill Where sBillId = @BillId And (iWeightChargeStatu = @BILL_WEIGHTCHARGE_PENDING Or iWeightChargeStatu = @BILL_WEIGHTCHARGE_NEEDCALCULATE Or iWeightChargeStatu = @BILL_WEIGHTCHARGE_NEEDREFUND))
	Begin
		Set @ReturnCode = @RC_BAD_BILL_STATUS -- bill under paying
		Return @ReturnCode
	End

	If ROUND(@DeclareWeight, 1) < ROUND(@Weight, 1)
	Begin
		Update Ymt_Bill Set 
			fRealWeight = @Weight, 
			iWeightChargeStatu = @BILL_WEIGHTCHARGE_NEEDCALCULATE
		Where sBillId = @BillId
	End
	Else IF ROUND(@DeclareWeight, 1) > ROUND(@Weight, 1)
	Begin
		Update Ymt_Bill Set 
			fRealWeight = @Weight, 
			iWeightChargeStatu = @BILL_WEIGHTCHARGE_NEEDREFUND
		Where sBillId = @BillId
	End
	Else
	Begin
		Update Ymt_Bill Set 
			fRealWeight = @Weight, 
			iWeightChargeStatu = @BILL_WEIGHTCHARGE_NONEED
		Where sBillId = @BillId
	End

	If @@ERROR > 0 or @@ROWCOUNT <> 1
		Return @RC_UNEXPECTED_ERROR

	--发送消息
    exec dbo.spSendChargeMessage @billid=@BillId

	Return @ReturnCode
	
END
