-- =============================================
-- Author:		Jmtek
-- Create date: 2014-8-18
-- Description:	库存变更SP
-- =============================================
CREATE PROCEDURE [dbo].[spUpdateProductStock]
	@sCatalogId		Varchar(50),
	@iStockChange	Int
AS
BEGIN
	Update Ymt_Catalogs Set iNum = iNum + @iStockChange Where sCatalogId = @sCatalogId And iNum + @iStockChange >= 0

	If @@ROWCOUNT = 0 Begin
		RAISERROR('商品库存余额不足',16,1,'-99') 
	End
END
