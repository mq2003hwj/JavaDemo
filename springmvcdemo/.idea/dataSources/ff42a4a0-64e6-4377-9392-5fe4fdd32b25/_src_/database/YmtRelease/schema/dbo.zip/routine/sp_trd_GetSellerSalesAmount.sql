-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-1
-- Description: 交易服务SP       
-- 20160819：取消根据风控状态做的特殊查询逻辑
-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetSellerSalesAmount]

@sellerId int,

@paidInFull bit = null,

@orderSellerAcceptedStatus int,

@orderStatusXml xml = null,

@all bit,

@yearBegin datetime = null,

@yearEnd datetime = null,

@quarterBegin datetime = null,

@quarterEnd datetime = null,

@monthBegin datetime = null,

@monthEnd datetime = null,

@weekBegin datetime = null,

@weekEnd datetime = null,

@todayBegin datetime = null,

@todayEnd datetime = null,

@yesterdayBegin datetime = null,

@yesterdayEnd datetime = null,

@considerOrderStatus bit = null,

@considerRCOrderEstablish bit = null,

@considerRCAccountPaid bit = null,

@considerRestOrderStatus bit = null,

@dtOrderStatus Int32Array READONLY
AS

-------------variables-------------
declare @orderStatus table(value int);

create table #tPriceAndTime
(fTotalPrice decimal(18,2),dAddTime datetime)

--------------process--------------

if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)

	insert into #tPriceAndTime(fTotalPrice,dAddTime)
	select fTotalPrice, dAddTime from ymt_orders(nolock) o where iBuyerId = @sellerId
	and (
		(@paidInFull is not null and (o.iTradingStatus = @orderSellerAcceptedStatus and o.bPaidInFull = @paidInFull))
		or (o.iTradingStatus in (select [value] from @orderStatus))
	)
end
else
begin
	insert into #tPriceAndTime(fTotalPrice,dAddTime)
	select fTotalPrice, dAddTime from ymt_orders(nolock) o where iBuyerId = @sellerId
	and ((@paidInFull is not null and (o.iTradingStatus = @orderSellerAcceptedStatus and o.bPaidInFull = @paidInFull))
	or (o.iTradingStatus in (select [Value] from @dtOrderStatus)))
end


select 'all'  as duration, sum(fTotalPrice) as salesAmount from #tPriceAndTime where @all = 1

union all

select 'year', sum(fTotalPrice) from #tPriceAndTime where @yearBegin is not null and dAddTime >= @yearBegin and dAddTime < @yearEnd

union all

select 'quarter', sum(fTotalPrice) from #tPriceAndTime where @quarterBegin is not null and dAddTime >= @quarterBegin and dAddTime < @quarterEnd

union all

select 'month', sum(fTotalPrice) from #tPriceAndTime where @monthBegin is not null and dAddTime >= @monthBegin and dAddTime < @monthEnd

union all

select 'week', sum(fTotalPrice) from #tPriceAndTime where @weekBegin is not null and dAddTime >= @weekBegin and dAddTime < @weekEnd

union all

select 'today', sum(fTotalPrice) from #tPriceAndTime where @todayBegin is not null and dAddTime >= @todayBegin and dAddTime < @todayEnd

union all

select 'yesterday', sum(fTotalPrice) from #tPriceAndTime where @yesterdayBegin is not null and dAddTime >= @yesterdayBegin and dAddTime < @yesterdayEnd


drop table #tPriceAndTime;

--set statistics time off;set statistics io off;

