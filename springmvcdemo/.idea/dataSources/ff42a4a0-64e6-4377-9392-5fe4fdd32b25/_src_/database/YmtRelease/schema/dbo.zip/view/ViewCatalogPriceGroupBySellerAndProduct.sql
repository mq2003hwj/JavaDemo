CREATE VIEW dbo.ViewCatalogPriceGroupBySellerAndProduct
AS
SELECT     u.iUserId, dbo.Ymt_Products.sProductId, MIN(cc.fQuotePrice) AS fMinimumPrice, MAX(cc.fQuotePrice) AS fMaximumPrice, AVG(cc.fQuotePrice) AS fAveragePrice, 
                      u.sNickName, u.sQQ, MIN(cc.iCatalogStatus) AS iCatalogStatus, MIN(cc.iAcceptReturn) AS iAcceptReturn, MIN(cc.fFlight) AS fFlight, cc.iAction
FROM         dbo.Ymt_Users AS u INNER JOIN
                      dbo.Ymt_Catalogs AS cc ON u.iUserId = cc.iUserId AND cc.iAction > - 1 AND cc.dAddTime < GETDATE() AND DATEADD(day, cc.iExpire, cc.dAddTime) > GETDATE() 
                      INNER JOIN
                      dbo.Ymt_Products ON cc.sProductId = dbo.Ymt_Products.sProductId
GROUP BY u.iUserId, u.sQQ, u.sNickName, dbo.Ymt_Products.sProductId, u.sNickName, cc.iAction
