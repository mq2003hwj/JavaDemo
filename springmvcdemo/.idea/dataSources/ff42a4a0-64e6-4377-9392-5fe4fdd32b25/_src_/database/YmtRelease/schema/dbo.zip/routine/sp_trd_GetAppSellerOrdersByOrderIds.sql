-- =============================================            

-- Author:  fanwei        

-- Create date: 2016-5-17

-- Description: 根据订单号获取买手App端订单信息      

-- 20160729：新增促销活动金额字段:fSellerPromotionAmount

-- 20160808：添加新老客订单字段bNewSellerOrder,bNewCustomerOrder

-- 20160811：添加促销活动的相关信息

-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetAppSellerOrdersByOrderIds]

@orderIds Int32Array READONLY,

@sellerId int = null,

@detail bit = 0

AS

select o.iMainOrderId,o.iOrderId,o.iUserId,o.iTradingStatus,o.sBuyerLoginId,o.sLeaveWord,o.fOrderPrice,o.fTotalPrice,o.bPaidInFull,o.iRiskVerifiedStatus,n.sContent as sellerNote

,o.bShangouOrder

,p.fAmount as postpayAmount,p.fUseGiftAmount as postpayUseGiftAmount

,o.dAddTime,o.dApplyPostPayTime,o.dCancelTime,o.dConfirmedTime,o.dDispathTime,o.dPaidTime,o.dPostPaidTime

,o.fFreight,o.fOrderDiscount,o.fDiscount,o.fUseGiftAmount

,o.sCouponCode,o.CouponValue,o.iCouponChannel,o.sYmtCouponCode,o.fYmtCouponAmount,o.sSellerCouponCode,o.fSellerCouponAmount

,o.sReceivePerson,o.sPhone,o.sPostCode,o.sAddress,o.bPreSale

,e.bIsNeedUploadIdCard,e.bHaveUploadedIdCard,o.fSellerPromotionAmount

,e.bNewSellerOrder,e.bNewCustomerOrder

,case when bl.iSellerId is null then 0 else 1 end as buyerInBlacklist

,case @detail when 1 then (select top 1 sReason from Ymt_OrderReason(nolock) where iOrderId = o.iOrderId) else null end as sCancelReason

from Ymt_Orders(nolock) o

left join  Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId

left join Ymt_O_OrderNote(nolock) n on o.iOrderId = n.iOrderId and o.iBuyerId = n.iUserId

--left join Ymt_OrderPostPay(nolock) p on o.iOrderId = p.iOrderId and (p.iAction = 0 or p.iAction = 1)

left join Ymt_BlackListForSeller(nolock) bl on o.iBuyerId = bl.iSellerId and o.iUserId = bl.iBuyerId and bl.iAction = 0

outer apply (select top 1 fAmount,fUseGiftAmount from Ymt_OrderPostPay(nolock) where iOrderId = o.iOrderId and (iAction = 0 or iAction = 1) order by iAction desc) p

where o.iOrderId in (select [Value] from @orderIds) order by o.iOrderId desc



select i.iOrderId,i.sPictureUrl,i.sPropertyInfo,i.sCatalogId,i.sProductId,i.fProductPrice,i.fProductOriginalPrice,i.fOriginalPrice,i.sTitle,i.iAmount,i.iPriceType,i.iCatalogStatus,i.iProductRefundChannel,i.iProductRefundStatus 

	,i.fYmtCouponAmount,i.fSellerCouponAmount,i.fDiscount,i.fFreight

	,i.iTariffType,i.bFreightFree,i.bSupportRtnWithoutReason, i.fSellerPromotionAmount,i.bPreSale,fThirdPartyDiscount

	,case @detail when 1 then (select top 1 RefundBillNo from ymt_refundproduct(nolock) where OrderInfoId = i.sOrderInfoId) else null end as SalesRefundCode

	,case @detail when 1 then (select top 1 (b.RefundAmount+b.SettlementAmountOfCoupon+isnull(b.RefundedDiscountOfThirdParty,0)) 
					from ymt_refundproduct(nolock) p join Ymt_RefundBill(nolock) b on p.RefundBillNo = b.RefundBillNo 
					where p.OrderInfoId = i.sOrderInfoId and b.SalesRefundStatus=10) else null end as SalesRefundAmount

	, s.[PromotionId] , s.[PromotionType] , s.[PromotionName] , s.[MatchCondition] , s.[PromotionValue]

	, s.ReducedAmount

from Ymt_OrderInfo as i with(nolock)

inner join @orderIds as o on i.[iOrderId] = o.[Value]

left join [dbo].[Ymt_SellerPromotion] as s with(nolock) on i.[iOrderId] = s.[OrderId] and i.[sOrderInfoId] = s.[OrderInfoId]
