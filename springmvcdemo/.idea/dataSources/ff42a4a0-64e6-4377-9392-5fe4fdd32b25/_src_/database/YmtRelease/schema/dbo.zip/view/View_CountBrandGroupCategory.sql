CREATE VIEW dbo.View_CountBrandGroupCategory
AS
SELECT     dbo.Ymt_ProductCategory.iCategoryId, COUNT(dbo.Ymt_ProductBrand.iBrandId) AS iBrandCount
FROM         dbo.Ymt_ProductCategory LEFT OUTER JOIN
                      dbo.Ymt_CategoryForBrand ON dbo.Ymt_ProductCategory.iCategoryId = dbo.Ymt_CategoryForBrand.iCategoryId LEFT OUTER JOIN
                      dbo.Ymt_ProductBrand ON dbo.Ymt_CategoryForBrand.iBrandId = dbo.Ymt_ProductBrand.iBrandId
GROUP BY dbo.Ymt_ProductCategory.iCategoryId
