

-- =============================================
-- Author:		zhangzhiqiang
-- Create date: 2015-11-29
-- Description:	查询商家优惠券批次列表C2C
-- =============================================
CREATE PROCEDURE [dbo].[SP_SellerCouponBatchListC2C]
	@BatchStatus INT,
	@SellerId INT,
	@PageSize INT,
	@LastBatchTime DATETIME = NULL
AS
BEGIN
	
	DECLARE @SQL NVARCHAR(MAX)=''
			,@StartRow INT
			,@EndRow INT
			,@param_def NVARCHAR(MAX)=N'@SellerId INT'

	SET @SQL='SELECT TOP ('+ CONVERT(VARCHAR,@PageSize)+') A.sBatchCode BatchCode
		  ,A.sCouponName CouponName
		  ,A.iCouponTotalNum MaxSendNum
		  ,A.iCouponNumPerUser UserMaxReceiveNum
		  ,A.dInvalidTime InvalidTime
		  ,ISNULL(A.bInvalidStatus,0) InvalidStatus
		  ,B.iReceiveCount HaveSendNum
		  ,(B.iUseTotalCount-B.iMaxUseTime) HaveUsedNum
		  ,B.dValidStart ValidStart
		  ,B.dValidEnd ValidEnd
		  ,A.dAddTime CreateTime
		  ,A.iCouponSettingId CouponSettingId
	  FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) INNER JOIN dbo.Ymt_CouponSetting B WITH(NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId
	  WHERE A.iBatchCreateType=2 AND A.iOperatorId = @SellerId '

	IF @BatchStatus=1  --1-失效优惠券
		SET @SQL += ' AND B.dValidEnd < GetDATE()'
	ELSE IF @BatchStatus = 2  --2-领取中
		SET @SQL += ' AND B.dValidEnd >= GetDATE() AND ISNULL(A.bInvalidStatus,0)=0 AND B.iUseTotalCount>B.iReceiveCount'
	ELSE IF @BatchStatus = 3  --3-已领完
		SET @SQL += ' AND B.dValidEnd >= GetDATE() AND ISNULL(A.bInvalidStatus,0)=0 AND B.iUseTotalCount=B.iReceiveCount'
	ELSE IF @BatchStatus = 4  --停止发放
		SET @SQL += ' AND B.dValidEnd >= GetDATE() AND A.bInvalidStatus=1'

	IF @LastBatchTime IS NULL
	BEGIN
		SET @SQL += ' ORDER BY A.dAddTime DESC'
		EXEC sp_executesql @SQL, @param_def, @SellerId
	END
	ELSE
	BEGIN
		SET @SQL += ' AND A.dAddTime<@LastBatchTime ORDER BY A.dAddTime DESC'
		SELECT @param_def += N',@LastBatchTime DATETIME'
		EXEC sp_executesql @SQL, @param_def, @SellerId, @LastBatchTime
	END
END

