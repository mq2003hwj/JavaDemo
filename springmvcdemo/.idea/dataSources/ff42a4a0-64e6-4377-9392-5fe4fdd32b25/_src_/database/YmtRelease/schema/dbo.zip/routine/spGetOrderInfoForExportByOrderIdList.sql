

CREATE PROCEDURE [dbo].[spGetOrderInfoForExportByOrderIdList]
	@orderIdList varchar(3000),
	@buyerId int
AS
BEGIN
	SET NOCOUNT ON;
	--Declare @orderIdList varchar(3000)
	--set @orderIdList = '100005515,100005521,100004879, 100005018'

    -- Insert statements for procedure here
    SELECT I.iOrderId, U.sLoginId as UserLoginId, O.dAddTime, 
	   dbo.GetProductUrlByOrderInfoId(I.sOrderInfoId) AS sPictureUrl, I.sDescription, I.fOriginalPrice, i.iAmount, 
	   --N.sContent, O.iBuyerId, N.iUserId,
	   OrderNote = (Select sContent FROM Ymt_O_OrderNote N WHERE N.iOrderId = O.iOrderId and N.iUserId = O.iBuyerId),
	   O.iTradingStatus, O.sLeaveWord, 
       dbo.GetProductNameByOrderInfoId(I.sOrderInfoId) as sTitle, I.sOrderInfoId, 
       O.sReceivePerson, O.sAddress, O.sPostCode, O.sPhone, O.sTelephone,
       dbo.GetAmountOfRealPayByOrderId(I.iOrderId) AS RealPay,
       dbo.GetCountOfOrderInfoByOrderId(I.iOrderId) AS CountOfInfo,
       I.sReferenceUrl
	FROM dbo.Ymt_OrderInfo I 
		INNER JOIN dbo.Ymt_Orders O ON I.iOrderId = O.iOrderId
		INNER JOIN dbo.Ymt_Users U ON O.iUserId = U.iUserId
		--LEFT OUTER JOIN Ymt_O_OrderNote N ON O.iOrderId = N.iOrderId
	Where CHARINDEX(cast(O.iOrderId as varchar), @orderIdList) > 0 and O.iBuyerId=@buyerId
	ORDER BY O.iOrderId ASC
END
