
-- =============================================
-- Author:		adu
-- Create date: 2015-06-08
-- Description:	获取指定推荐人的所推荐的人用户名字，字段值用指这下的分隔符分开拼接起来，并返回
-- =============================================
CREATE FUNCTION [dbo].[GetLastRecommendedUserNameSplitBy]
(
	-- Add the parameters for the function here
	@UserId varchar(36),
	@Separator varchar(20)--分隔符	
)
RETURNS nvarchar(2000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @tmpRtn  nvarchar(2000)
	declare @str nvarchar(2000)
set @str=''
SELECT top 10 @str=@str+@Separator + r.sRecommendedUserName from dbo.Ymt_UserRecommendActivityRecord AS r 
WHERE	r.iRecommenderId = @UserId AND r.sCouponCode <> '' AND r.sCouponCode IS NOT NULL ORDER BY r.dUpdateTime DESC
--select @str
select @tmpRtn=STUFF(@str,1,len(@Separator),'')
return @tmpRtn
END

