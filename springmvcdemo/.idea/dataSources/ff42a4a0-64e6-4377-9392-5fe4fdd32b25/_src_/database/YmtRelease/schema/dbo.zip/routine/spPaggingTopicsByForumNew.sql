-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spPaggingTopicsByForumNew] 
	-- Add the parameters for the stored procedure here
	@Page int,
	@PageSize int,
	@ForumId varchar(36),
	@GoodStatu int,
	@Type varchar(36)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
declare @recordbegin int,@recordend int
set @recordbegin = (@page-1)*@pageSize+1;
set @recordend = @recordbegin + @pageSize -1;

declare @topKey int
if(@ForumId='')
	set @topKey=2
else
	set @topKey=1

select * from 
(
select * from (select *,(ROW_NUMBER() over(order by iTopStatu/@topKey desc, dLastPost desc)) as rowNumbers from Ymt_Topics where iTopStatu=2 or (sForumId=@ForumId or @ForumId='') and iDisplayStatus=0 and iAction>=0 and (iGoodStatu=@GoodStatu or @GoodStatu=0) and (sTopicTypeId=@Type or @Type='' or sTopicTypeId in (select sTopicTypeId from Ymt_TopicType where sTypeName=@Type))) as OrderedTopics where rowNumbers between @recordbegin and @recordend
) p left join Ymt_TopicType t on p.sTopicTypeId=t.sTopicTypeId
left join
(
select iTopicId,SUM(iAddScore) addScore from Ymt_TopicAddScoreRecord group by iTopicId
)s
on p.iTopicId=s.iTopicId

END
