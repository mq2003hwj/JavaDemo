-- =============================================
-- Author:		zhujinfeng
-- Create date: 2015-7-17
-- Description:	marge product pic
-- =============================================
CREATE FUNCTION [dbo].[MargeProductPic]
(
	@ProductId VARCHAR(36)
)
RETURNS NVARCHAR(2000)
AS
BEGIN
	DECLARE @sql VARCHAR(2000);
	SET @sql='';
	
	SELECT @sql=@sql+', '+  sOriUrl FROM Ymt_ProductPicture WITH(NOLOCK) WHERE sProductId = @ProductId AND iAction > -1
	SET @sql=STUFF(@sql,1,1,'') 
	RETURN @sql;
END