-- =============================================
-- Author:		zhujinfeng
-- Create date: 2016-02-18
-- Description:	写入商品库存冻结量
-- =============================================
CREATE PROCEDURE [dbo].[SP_FreezeProductStock]
	@FreezeId VARCHAR(20),
	@FreezeType INT,
	@ProductId VARCHAR(36),
	@CatalogId VARCHAR(36),
	@StoreType INT,
	@Sku VARCHAR(60),
	@ActivityId INT,
	@FreezeNum INT,
	@ProductInActivityId INT,
	@Status INT,
	@OperateType INT
AS
BEGIN

	SET NOCOUNT ON;

    -- 幂等验证
	--IF NOT EXISTS (SELECT * FROM dbo.Ymt_ProductFreezeStockLog WHERE FreezeId = @FreezeId AND CatalogId = @CatalogId AND OperateType = @OperateType AND FreezeNum = @FreezeNum)
	--BEGIN
	
		BEGIN TRANSACTION
		
		-- 扣减规格库存冻结量
		UPDATE dbo.Ymt_Catalogs SET iNum = iNum - @FreezeNum WHERE sCatalogId = @CatalogId AND iNum >=@FreezeNum;

		IF(@@ROWCOUNT = 1)
		BEGIN
		
			-- 写入冻结表
			INSERT INTO Ymt_ProductFreezeStock (FreezeId, FreezeType, ProductId, CatalogId, StoreType, Sku, ActivityId, FreezeNum, ProductInActivityId, Status, AddTime, UpdateTime)
			VALUES (@FreezeId, @FreezeType, @ProductId, @CatalogId, @StoreType, @Sku, @ActivityId, @FreezeNum, @ProductInActivityId, @Status, GETDATE(), GETDATE())

			-- 写入冻结日志表
			INSERT INTO dbo.Ymt_ProductFreezeStockLog (FreezeId, ProductId, CatalogId, OperateType, ActivityId,	FreezeNum, ProductInActivityId, AddTime)
			VALUES (@FreezeId, @ProductId ,@CatalogId , @OperateType ,@ActivityId , @FreezeNum , @ProductInActivityId ,GETDATE())

			IF @@ERROR <> 0
			BEGIN
				ROLLBACK TRANSACTION
	
				-- 插入冻结数据失败
				SELECT -1 AS [Result];        
			END  
			ELSE
			BEGIN
				COMMIT TRANSACTION
				
				-- 插入冻结成功      
				SELECT 1 AS [Result];      
			END
		END          
		ELSE
		BEGIN      
			ROLLBACK TRANSACTION
	
			-- 扣减规格库存失败
			SELECT -2 AS [Result];        
		END 
	--END
	--ELSE
	--BEGIN
		-- 冻结记录已存在，不能插入
		--SELECT 0 AS [Result];
	--END
END
