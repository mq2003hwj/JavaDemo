
-- =============================================            

-- Author:  fanwei        

-- Create date: 2015-9-13

-- Description: 交易服务SP 

-- 20160525：添加支持按订单来源进行条件筛选 @orderSourcesXml

-- 20160615：添加商品相关字段信息 by dengpeng

-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetBuyerOrderList]



@buyerId int,

@orderStatusXml xml,

@rowFrom int,

@rowTo int,

@complaintedOnly bit,

@tradingId int,

@uncommented bit,

@top int,

@lastOrderId int,

@noCreditDetail bit,

@receiver varchar(50),

@phone varchar(20),

@orderSourcesXml xml = null



AS



-------------variables-------------

declare @orderIds table(id int not null primary key clustered)

declare @orderStatus table(value int not null)

declare @orderToBills table(iOrderId int not null, sBillId varchar(36) not null)

declare @orderTradingIds table(orderId int not null, tradingId int not null, virtualTime datetime not null)

declare @orderSources table([sOrderSource] varchar(128) not null)



declare @orderStatusExists bit = 0

declare @totalCount int = 0

declare @rowsCount int = 0



declare @exsitsShippedStatus bit = 0

declare @exsitsReceivedStatus bit = 0



declare @considerShippedStatus bit = 0

declare @considerReceivedStatus bit = 0

declare @considerRestStatus bit = 1



--------------process--------------

if @orderStatusXml is not null

begin

    insert into @orderStatus 

    select tbl.col.value('@s','int')

    from @orderStatusXml.nodes('/root/x') tbl(col)

	

  	select top 1 @orderStatusExists = 1 from @orderStatus

	

	if @orderStatusExists = 1 begin 

		--

		if exists(select top 1 1 from @orderStatus where [value] = 3) begin

			set  @exsitsShippedStatus = 1

		end



		if exists(select top 1 1 from @orderStatus where [value] = 4) begin

			set  @exsitsReceivedStatus = 1

		end

	

		if not (@exsitsShippedStatus = 1 and @exsitsReceivedStatus = 1) begin

			if @exsitsShippedStatus = 1 begin

				delete @orderStatus where [value] = 3

				set @considerShippedStatus = 1

				select @considerRestStatus = case when count(*)>0 then 1 else 0 end from @orderStatus

			end

	

			if @exsitsReceivedStatus = 1 begin

				delete @orderStatus where [value] = 4

				set @considerReceivedStatus = 1

				select @considerRestStatus = case when count(*)>0 then 1 else 0 end from @orderStatus

			end

		end

		--

	end

end;



--添加来源部分

if @orderSourcesXml is not null begin

	insert into @orderSources([sOrderSource])

	select tbl.col.value('@s','varchar(128)') from @orderSourcesXml.nodes('/root/x') tbl(col)

end



--print 'insert';

--查出符合条件的订单ID及符合条件的订单总数

SET NOCOUNT OFF;



if @top = 0 begin



  if @uncommented = 0 begin



    ;with t(id, rowIndex) as (

		select o.iOrderId, row_number() over(order by o.dAddTime desc)

		from ymt_orders(nolock) o 

		inner join [dbo].[Ymt_OrderExt] as oe with(nolock) on oe.iOrderId = o.iOrderId

		left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId

		where o.iUserId = @buyerId

		and (@orderStatusExists = 0 or (

			--

			(@considerShippedStatus = 1 and (o.iTradingStatus = 3 or o.iTradingStatus = 4 and r.iProcessStatus = 0))

			or

			(@considerReceivedStatus = 1 and (o.iTradingStatus = 4 and (r.iProcessStatus is null or r.iProcessStatus > 0)))

			or

			(@considerRestStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))

			--

		))

		and (@receiver is null or sReceivePerson = @receiver)

		and (@phone is null or sPhone = @phone)

		and (@complaintedOnly = 0 or exists(select 1 from Ymt_OrderComplaint(nolock) c where o.iOrderId = c.iOrderId))

		and (@tradingId = 0 or o.iOrderId in (select iOrderId from Ymt_TradingItem(nolock) where iTradingId = @tradingId))

		and (@orderSourcesXml is null or oe.[sOrderSource] in ( select [sOrderSource] from @orderSources ))

    ),

    t2 as (

		select isnull(max(rowIndex), 0) as total from t

	)

    insert into @orderIds 

    select id from t where rowIndex between @rowFrom and @rowTo

    union all

    select -total from t2 where total > 0; --订单总量以负数表示,与订单ID区分开



    set @rowsCount = @@ROWCOUNT;

    if @rowsCount > 0 begin

      set @rowsCount = @rowsCount - 1; --减去多余的用来记录订单总量的行

      select @totalCount = -min(id) from @orderIds; --获取总数

      delete from @orderIds where @rowsCount > 0 and id = -@totalCount; --删除@orderIds中的总数

    end



  end 

  else begin



    ;with t(id, rowIndex) as (

		select o.iOrderId, row_number() over(order by o.dAddTime asc)

		from ymt_orders(nolock) o 

		inner join [dbo].[Ymt_OrderExt] as oe with(nolock) on oe.iOrderId = o.iOrderId

		left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId

		where o.iUserId = @buyerId 

		and (@orderStatusExists = 0 or (

			--

			(@considerShippedStatus = 1 and (o.iTradingStatus = 3 or o.iTradingStatus = 4 and r.iProcessStatus = 0))

			or

			(@considerReceivedStatus = 1 and (o.iTradingStatus = 4 and (r.iProcessStatus is null or r.iProcessStatus > 0)))

			or

			(@considerRestStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))

			--

		))

		and (@receiver is null or sReceivePerson = @receiver)

		and (@phone is null or sPhone = @phone)

		and (@complaintedOnly = 0 or exists(select 1 from Ymt_OrderComplaint(nolock) c where o.iOrderId = c.iOrderId))

		and (@tradingId = 0 or o.iOrderId in (select iOrderId from Ymt_TradingItem(nolock) where iTradingId = @tradingId))

		and not exists(select 1 from Ymt_CreditDetail(nolock) c where c.iUserId = @buyerId and c.iAction > -1 and cast(o.iOrderId as varchar(36)) = c.sTargetId)

		and (@orderSourcesXml is null or oe.[sOrderSource] in ( select [sOrderSource] from @orderSources ))

    ),

    t2 as (

		select isnull(max(rowIndex), 0) as total from t

	)

    insert into @orderIds 

    select id from t where rowIndex between @rowFrom and @rowTo

    union all

    select -total from t2 where total > 0; --订单总量以负数表示,与订单ID区分开



    set @rowsCount = @@ROWCOUNT;

    if @rowsCount > 0 begin

      set @rowsCount = @rowsCount - 1; --减去多余的用来记录订单总量的行

      select @totalCount = -min(id) from @orderIds; --获取总数

      delete from @orderIds where @rowsCount > 0 and id = -@totalCount; --删除@orderIds中的总数

    end



  end



end 

else begin

  

  insert into @orderIds

  select top (@top) o.iOrderId from Ymt_Orders(nolock) o

  inner join [dbo].[Ymt_OrderExt] as oe with(nolock) on oe.iOrderId = o.iOrderId

  left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId

  where o.iUserId = @buyerId 

  and ((@lastOrderId = 0 and o.iOrderId > 0) or (@lastOrderId <> 0 and o.iOrderId < @lastOrderId))

  and (@orderStatusExists = 0 or (

		--

		(@considerShippedStatus = 1 and (o.iTradingStatus = 3 or o.iTradingStatus = 4 and r.iProcessStatus = 0))

		or

		(@considerReceivedStatus = 1 and (o.iTradingStatus = 4 and (r.iProcessStatus is null or r.iProcessStatus > 0)))

		or

		(@considerRestStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))

		--

	))

	and (@orderSourcesXml is null or oe.[sOrderSource] in ( select [sOrderSource] from @orderSources ))

  order by iOrderId desc



  set @rowsCount = @@ROWCOUNT;

  set @totalCount = @rowsCount;



end



SET NOCOUNT ON;



--print '@totalCount'

--获取订单总数量  

select @totalCount as TotalCount;



--print 'ymt_orders';

select  

 	   o.[iOrderId]

      ,o.[iUserId]

      ,o.[iBuyerId]

      ,o.[sMarkId]

      ,o.[dAddTime]

      ,o.[fOrderPrice]

      ,o.[fOrderDiscount]

      ,o.[fFreight]

      ,o.[fDiscount]

      ,o.[iTradingId]

      ,case when r.iProcessStatus is null then o.iTradingStatus when r.iProcessStatus = 0 then 3 else o.iTradingStatus end as iTradingStatus

      ,o.[iOperate]

      ,o.[dOperateExpireTime]

      ,o.[sAddress]

      ,o.[sPostCode]

      ,o.[sReceivePerson]

      ,o.[sPhone]

      ,o.[sTelephone]

      ,o.[sQQ]

      ,o.[sEmail]

      ,o.[sLeaveWord]

      ,o.[iUnfreezeStatus]

      ,o.[dDispathTime]

      ,o.[iTopicId]

      ,o.[sTitle]

      ,o.[iReplyTopicWhenOrderPaid]

      ,o.[bPaidInFull]

      ,o.[fUseGiftAmount]

      ,o.[sCouponCode]

      ,o.[CouponValue]

      ,o.[iCouponType]

      ,o.[dPaidTime]

      ,o.[dApplyPostPayTime]

      ,o.[dPostPaidTime]

      ,o.[dConfirmedTime]

      ,o.[dChangeAddressTime]

      ,o.[iDistributor]

      ,o.[sThirdOrderId]

      ,o.[iType]

      ,o.[fOldFreight]

      ,o.[dDiscountTime]

      ,o.[fOldDiscount]

      ,o.[fAutoCancelOrderHours]

      ,o.[dCancelTime]

      ,o.[bShangouOrder]

      ,o.[sBuyerLoginId]

      ,o.[sBuyerLoginEmail]

      ,o.[sSellerLoginId]

      ,o.[sSellerLoginEmail]

      ,o.[iIsMerchant]

      ,o.[sBuyerNickName]

      ,o.[fTotalPrice]

      ,o.[fUseFreeCardAmount]

      ,o.[sHostRef]

      ,o.[bIncludeActivityProducts]

      ,o.[bShippedByXlobo]

      ,o.[dAcceptTime]

      ,o.[sCurType]

      ,o.[bCanLocalReturn]

      ,o.[bApplyLocalReturn]

      ,o.[dApplyLocalReturnTime]

      ,o.[iRiskVerifiedStatus]

      ,o.[dLastUpdateTime]

      ,o.[iThirdPartyRefundStatus]

      ,o.[iCouponChannel]

      ,o.[iSalesRefundStatus]

	  ,o.[sYmtCouponCode]

	  ,o.[fYmtCouponAmount]

	  ,o.[sSellerCouponCode]

	  ,o.[fSellerCouponAmount]

from ymt_orders(nolock) o

left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId

where @rowsCount > 0 and o.iOrderId in (select id from @orderids) order by o.iOrderId asc



--print 'ymt_orderext';

select iOrderId,iOrderType,sOrderSource from Ymt_OrderExt(nolock) where @rowsCount > 0 and iOrderId in (select id from @orderids) 



--print 'ymt_creditdetail'   

--获取评价列表  

select * from Ymt_CreditDetail(nolock) where @noCreditDetail = 0 and @rowsCount > 0 and stargetid in (select cast(id as varchar(36)) from @orderids)  



--print 'ymt_o_ordernote'

--获取备注列表  

select iOrderId,sContent from Ymt_O_OrderNote(nolock) where @rowsCount > 0 and iuserid = @buyerid and iorderid in (select id from @orderids)  



--print 'ymt_orderstate'

--获取订单金额详情列表  ymt_orderinfo

select * from Ymt_OrderState(nolock) where @rowsCount > 0 and iorderid in (select id from @orderids)  



--print 'ymt_orderpostpay'

--获取订单补款列表  

select iOrderId,fAmount,fUseGiftAmount from Ymt_OrderPostPay(nolock) where @rowsCount > 0  and iorderid in (select id from @orderids)



--获取订单商品详情列表

--print 'ymt_orderinfo'

select

i.[iOrderId],i.sOrderInfoId,i.fOriginalPrice,i.iPriceType,i.iAmount,i.iBondedArea,i.iCatalogStatus,i.iCatalogType,i.iProductSubCategoryId,

i.iSailProtected,i.iType,i.sCatalogId,i.sDescription,i.sPictureUrl,i.sProductId,i.sPropertyInfo,i.sReferenceUrl,i.sSKU,i.sTitle 

,e.sOrderInfoId as sOrderInfoExtId,e.bGiftAvail4Reward,e.iActivityId,e.iActivityTemplateId,i.iSalesType,

i.fProductPrice,i.fProductOriginalPrice,i.fSellerCouponAmount,i.fYmtCouponAmount,i.fDiscount,i.fFreight

from Ymt_OrderInfo i(nolock) 

left join Ymt_OrderInfoExt(nolock) e

on i.sOrderInfoId = e.sOrderInfoId

where @rowsCount > 0 and i.iOrderId in (select id from @orderIds)



--print 'ymt_ordersummary'

--获取订单物流信息  

select iOrderId, iBillType, sSummary from Ymt_OrderSummary(nolock) where @rowsCount > 0 and iorderid in (select id from @orderids)  



--print 'ymt_order_frozen'

--获取订单冻结信息  

select * from Ymt_Order_Frozen(nolock) where @rowsCount > 0 and iorderid in (select id from @orderids)  



 --print 'ymt_ordertobill'
 
 --获取订单账单信息
 
 insert into @orderToBills select iOrderid, sBillId from Ymt_OrderToBill(nolock) where @rowsCount > 0 and iorderid in (select id from @orderids) and iaction >= 0
 
 select iOrderid, sBillId from @orderToBills where @rowsCount > 0;
 
 
 
 --print 'ymt_bill'
 
 --获取订单账单信息  
 
 select * from Ymt_Bill(nolock) where @rowsCount > 0 and sbillid in (select sBillId from @orderToBills) and iaction >= 0



--print 'orderTradingId'

--订单有效的交易ID  

if @rowsCount > 0 begin

  insert into @orderTradingIds select iOrderId, iTradingId, dUpdateTime from Ymt_TradingItem(nolock) where iOrderId in (select id from @orderIds)

  update @orderTradingIds set virtualTime = '9999-1-1' where tradingId in (select iTradingId from Ymt_TradingInfo(nolock) where iTradingId in (select tradingId from @orderTradingIds) and iTradingStatus = 2)

  ;with t as(

    select ROW_NUMBER() over(partition by orderId order by virtualTime desc) as n, orderId, tradingId from @orderTradingIds

  ) 

  select orderId as iOrderId, tradingId as iTradingId from t where n = 1 order by orderId;

end



--print 'finished'

SET NOCOUNT OFF; 

--set statistics time off

--print datediff(ms,@t1,getdate())