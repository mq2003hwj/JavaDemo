
CREATE PROCEDURE [dbo].[SP_UpdateTuanStock]
@TopicSign varchar(20),
@OrderMinists int,
@GroupSuccessMemberCount int
AS
BEGIN

select tm.iUserId,ttp.sProductId into #userproduct from Ymt_App_Tuan t
left join Ymt_App_TuanMember tm on t.sGroupCode=tm.sGroupCode and t.iTopicId=tm.iTopicId
left join Ymt_App_TuanTopic tt on t.iTopicId=tt.iTopicId
left join Ymt_App_TuanTopicProduct ttp on ttp.iTopicId=t.iTopicId and ttp.sStatus='A'
where tt.sSign=@TopicSign and  GETDATE()> DATEADD(MI,@OrderMinists,t.dModifyDate) 

update Ymt_App_TuanTopic set 
iSoldStock = 
(
select isnull(sum(oi.iAmount),0) from Ymt_Orders o 
inner join Ymt_OrderInfo oi on o.iOrderId=oi.iOrderId
inner join #userproduct up on o.iUserId=up.iUserId and oi.sProductId=up.sProductId
where oi.sProductId in (select sProductId from #userproduct) 
and o.iTradingStatus in (1,2,3,4,15,16,17)
and dAddTime > Ymt_App_TuanTopic.dCreatedDate and oi.sProductId = (select top 1 sProductId from Ymt_App_TuanTopicProduct ttp where ttp.iTopicId=Ymt_App_TuanTopic.iTopicId and ttp.sStatus='A')
)
where sSign = @TopicSign

update Ymt_App_TuanTopic set 
iLockStock = 
(select isnull(COUNT(1)*@GroupSuccessMemberCount,0) from Ymt_App_Tuan t where t.iTopicId = Ymt_App_TuanTopic.iTopicId and GETDATE()<= DATEADD(MI,@OrderMinists,t.dModifyDate) and t.sStatus='2')
where sSign = @TopicSign

END