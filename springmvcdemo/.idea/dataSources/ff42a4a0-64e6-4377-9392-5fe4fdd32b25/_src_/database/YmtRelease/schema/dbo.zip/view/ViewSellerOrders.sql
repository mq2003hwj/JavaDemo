CREATE VIEW dbo.ViewSellerOrder
AS
SELECT     dbo.Ymt_Orders.*, dbo.Ymt_TradingStatus.iTradingStatus
FROM         dbo.Ymt_Orders INNER JOIN
                      dbo.Ymt_TradingStatus ON dbo.Ymt_Orders.iOrderId = dbo.Ymt_TradingStatus.iTraddingId
