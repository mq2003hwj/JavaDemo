-- =============================================
-- Author:		adu
-- Create date: 2013-12-19
-- Description:	把表里的指定的字段值拼接起来，并返回用|号隔开的字符串
-- =============================================
CREATE FUNCTION [dbo].[GetProductPicUrlSplitJoint]
(
	-- Add the parameters for the function here
	@ProductId varchar(36)	
)
RETURNS nvarchar(2000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @tmpRtn  nvarchar(2000)
	declare @str nvarchar(2000)
set @str=''
select @str=@str+'|'+pp.sOriUrl from dbo.Ymt_ProductPicture AS pp 
WHERE	pp.sProductId = @ProductId
--select @str
select @tmpRtn=STUFF(@str,1,1,'')
return @tmpRtn
END