
-- =============================================            
-- Author:  fanwei        
-- Create date: 2016-1-12
-- Description: 交易服务-获取拼邮M和C端指定国内配送状态订单的数量
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetPackageDeliveryOrdersCount]

@sellerId int,-- = 549772
@domesticDelivered bit, --= 0
@timeFrom datetime,-- = '2010-1-1'
@timeTo datetime-- = '2016-10-1'

AS

--set statistics io on;set statistics time on;

if @domesticDelivered is null begin

	with t as (
		select distinct o.iOrderId from ymt_orders o with(nolock,index=idx_Ymt_Orders_iBuyerId_iTradingStatus_bDomesticDelivered)
		join ymt_orderinfo i with(nolock,index=idx_Ymt_OrderInfo_iCatalogStatus)
		on o.iorderid = i.iorderid and i.iCatalogStatus = 7
		where o.iBuyerId = @sellerId and o.iTradingStatus = 3
	)
	select bShangouOrder as shangou, count(1) as [count]  
	from Ymt_Orders with (nolock,index = PK_Ymt_Orders) where iOrderId in (select iOrderId from t)
	and (@timeFrom is null or dAddTime >= @timeFrom)
	and (@timeTo is null or dAddTime < @timeTo)
	group by bShangouOrder

end else begin
	IF @domesticDelivered = 0 BEGIN

		with t as (
			select distinct o.iOrderId from ymt_orders o with(nolock,index=idx_Ymt_Orders_iBuyerId_iTradingStatus_bDomesticDelivered)
			join ymt_orderinfo i with(nolock,index=idx_Ymt_OrderInfo_iCatalogStatus)
			on o.iorderid = i.iorderid and i.iCatalogStatus = 7
			where o.iBuyerId = @sellerId and o.iTradingStatus = 3
			and o.bDomesticDelivered is NULL
		)
		select bShangouOrder as shangou, count(1) as [count] from Ymt_Orders with(nolock,index = PK_Ymt_Orders) where iOrderId in (select iOrderId from t)
		and (@timeFrom is null or dAddTime >= @timeFrom)
		and (@timeTo is null or dAddTime < @timeTo)
		group by bShangouOrder

	END ELSE BEGIN

		with t as (
			select distinct o.iOrderId from ymt_orders o with(nolock,index=idx_Ymt_Orders_iBuyerId_iTradingStatus_bDomesticDelivered)
			join ymt_orderinfo i with(nolock,index=idx_Ymt_OrderInfo_iCatalogStatus)
			on o.iorderid = i.iorderid and i.iCatalogStatus = 7
			where o.iBuyerId = @sellerId and o.iTradingStatus = 3
			and o.bDomesticDelivered = 1
		)
		select bShangouOrder as shangou, count(1) as [count]  from Ymt_Orders with (nolock,index = PK_Ymt_Orders) where iOrderId in (select iOrderId from t)
		and (@timeFrom is null or dAddTime >= @timeFrom)
		and (@timeTo is null or dAddTime < @timeTo)
		group by bShangouOrder

	END
	

end

--set statistics io off;set statistics time off;
