
-- =============================================
-- Author:		ZHUJINFENG
-- Create date: 2015-01-23
-- Description:	合并优惠券面值
-- =============================================
CREATE FUNCTION [dbo].[FUNC_MargeCouponValue] 
(
	@iCouponSettingId INT
)
RETURNS VARCHAR(2000)
AS
BEGIN
	DECLARE @Values VARCHAR(2000);
	SET @Values='';
	
	SELECT @Values = @Values +'|' + CONVERT(VARCHAR, fMinOrderValue) + ',' + CONVERT(VARCHAR, fCouponValue) 
		FROM Ymt_CouponValue WITH(NOLOCK)
		WHERE iCouponSettingId = @iCouponSettingId	
		ORDER BY fMinOrderValue DESC;		
		
	SET @Values=STUFF(@Values,1,1,'') 
	RETURN @Values;

END

