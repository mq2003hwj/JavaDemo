
CREATE PROCEDURE [dbo].[spGetIdPicFromXlobo]
	@lastUpdateTime datetime = null
AS
BEGIN
	
	SET NOCOUNT ON;
	
	declare @billCodes varchar(max)
	
	if(@lastUpdateTime = null)
	begin
		set @lastUpdateTime = '2010-01-01'
	end

	set @billCodes = ''

	--查询运单中需要更新的内容
	select @billCodes = @billCodes + ',' + b.sBillCode from Ymt_Bill b 
		where not exists (select * from Ymt_IdPic p where p.iUserId = b.iToUserId and p.sName = b.sReceiveName) 
			  and iToUserId is not null and b.sReceiveName is not null
			  and b.dAddTime > @lastUpdateTime
	
	select @billCodes = @billCodes + ',' + REPLACE(s.sSummary, '
', ',') from ymt_orders o, Ymt_OrderSummary s 
								where s.iOrderId = o.iOrderId and sSummary is not null and o.sReceivePerson is not null and sSummary like '%DB%US%'
									and not exists(select * from Ymt_OrderToBill where iOrderId = o.iOrderId) 
									and not exists (select * from Ymt_IdPic where sName = o.sReceivePerson and iUserId = o.iUserId)
									and o.dAddTime > @lastUpdateTime
	
	--Xlobo返回的信息表
	create table #returnInfo (sBillCode varchar(50), sReceiverName varchar(50), sIdCode varchar(50), sIdPicRightSide varchar(500), sIdPicReverseSide varchar(500))
	
	--调用Xlobo存储过程
    insert into #returnInfo Exec [XloboRelease0516].[dbo].[spGetBillIdCard] @billCodes
	
	select o.iUserId userid, r.sReceiverName name, r.sIdCode idCode, r.sIdPicRightSide rightSide, r.sIdPicReverseSide reverseSide into #Temp 
		from Ymt_OrderSummary s, ymt_orders o, #returnInfo r where s.iOrderId = o.iOrderId and s.sSummary like '%' + r.sBillCode + '%'
    
    --去除重复数据,插入数据库
    insert into Ymt_IdPic([sId], iUserId, sName, sIdPicRightSide, sIdPicReverseSide, iAction, dAddTime, sCardId)
		select NEWID(), userId, name, rightSide, reverseSide, 1, GETDATE(), idCode from #Temp t1 
			where not exists (select * from Ymt_IdPic p where p.iUserId = t1.userId and p.sName = t1.name)
				and exists (select * from (select MAX(rightSide) rightSide, userId, name from #Temp group by userId, name) t2 where t2.userId = t1.userId and t2.name = t1.name and t1.rightSide = t2.rightSide)

	drop table #returnInfo
	drop table #Temp
END

