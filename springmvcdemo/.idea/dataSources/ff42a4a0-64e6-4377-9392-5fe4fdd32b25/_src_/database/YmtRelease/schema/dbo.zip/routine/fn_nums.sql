-- =============================================
-- Author:		李主明
-- Create date: 2010/01/07
-- Description:	数字表
-- =============================================
CREATE FUNCTION dbo.[fn_nums](@n AS BIGINT) RETURNS TABLE
AS 
RETURN
	WITH
	L0 AS (SELECT 1 AS c UNION ALL SELECT 1),
	L1 AS (SELECT 1 AS c FROM L0 AS A, L0 AS B),
	L2 AS (SELECT 1 AS c FROM L1 AS A, L1 AS B),
	L3 AS (SELECT 1 AS c FROM L2 AS A, L2 AS B),
	L4 AS (SELECT 1 AS c FROM L3 AS A, L3 AS B),
	L5 AS (SELECT 1 AS c FROM L4 AS A, L4 AS B),
	Nums AS (SELECT ROW_NUMBER() OVER(ORDER BY C) AS n FROM L5)

	SELECT n FROM Nums WHERE n<=@n
