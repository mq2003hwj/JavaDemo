-- =============================================
-- Author:		Jeff
-- Create date: 2011-8-9
-- Description:	Create a payment duty
-- =============================================
CREATE PROCEDURE [dbo].[spAddTaxDuty4Bill]
	@BillCode		Varchar(20),
	@Amount			Decimal(10, 2),
	@Description	Varchar(max),
	@TaxCode		Varchar(128)
AS
DECLARE
/* return codes */
	@ReturnCode					Varchar(10),	
/* local variables & const */
	@BillId						Varchar(36),
	@TAX_DUTY_TYPE				Int,
	@PAYMENT_STATUS_PENDING		Int,
	@BILL_TAXCHARGE_PENDING		Int,
	@RC_BAD_BILL_CODE			Int,
	@RC_BAD_BILL_STATUS			Int,
	@RC_UNEXPECTED_ERROR		Int


BEGIN
	
	Set @TAX_DUTY_TYPE = 2
	Set @PAYMENT_STATUS_PENDING = 1
	Set @BILL_TAXCHARGE_PENDING = 1


	Set @RC_BAD_BILL_CODE = -1001
	Set @RC_BAD_BILL_STATUS = -1002	
	Set @RC_UNEXPECTED_ERROR = -1
	Set @ReturnCode = 0

	
	Select @BillId = sBillId From Ymt_Bill Where sBillCode = @BillCode
	
	-- Check bill existance
	If @@ROWCOUNT <> 1 Or ISNULL(@BillId, '0') = '0'
	Begin
		Set @ReturnCode = @RC_BAD_BILL_CODE	-- no such bill code
		Return @ReturnCode
	End
	
	-- Check bill payment process
	If Exists (Select sBillId From Ymt_BillPaymentDuty Where sBillId = @BillId And iStatus = @PAYMENT_STATUS_PENDING And iType = @TAX_DUTY_TYPE)
	Begin
		Set @ReturnCode = @RC_BAD_BILL_STATUS -- bill under paying
		Return @ReturnCode
	End
	
	-- Do the insert
	Insert Into Ymt_BillPaymentDuty (
		[sId], 
		[sBillId], 
		[iType], 
		[fAmount], 
		[sDescription], 
		[sTaxCode], 
		[iStatus],
		[dAddTime]
	) Values (
		NEWID(),
		@BillId,
		@TAX_DUTY_TYPE,
		@Amount,
		@Description,
		@TaxCode,
		@PAYMENT_STATUS_PENDING,
		GETDATE()
	)

	If @@ERROR > 0 or @@ROWCOUNT <> 1
		Return @RC_UNEXPECTED_ERROR
		
	Update Ymt_Bill Set 
		fTxtFee = @Amount,
		iTxtChargeStatu = @BILL_TAXCHARGE_PENDING
	Where sBillId = @BillId


	If @@ERROR > 0 or @@ROWCOUNT <> 1
		Return @RC_UNEXPECTED_ERROR


	--发送消息
    exec dbo.spSendChargeMessage @billid=@BillId

	Return @ReturnCode
	
END
