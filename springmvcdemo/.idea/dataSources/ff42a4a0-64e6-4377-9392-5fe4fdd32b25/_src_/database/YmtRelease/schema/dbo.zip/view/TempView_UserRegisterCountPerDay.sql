CREATE VIEW dbo.TempView_UserRegisterCountPerDay
AS
SELECT     COUNT(*) AS RegisterUserCount, MIN(dAddTime) AS RegisterDate
FROM         dbo.Ymt_Users
GROUP BY CONVERT(date, dAddTime)
