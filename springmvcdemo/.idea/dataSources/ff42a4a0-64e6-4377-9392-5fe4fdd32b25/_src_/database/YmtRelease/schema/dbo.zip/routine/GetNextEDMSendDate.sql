-- =============================================
-- Author:		Jmtek.Wu
-- Create date: 2013-8-13
-- Description:	计算下一次EDM发送的时间
-- =============================================
CREATE FUNCTION GetNextEDMSendDate
(
	@LastSendDate	Date,
	@Period			Int
)
RETURNS Date
AS
BEGIN
	RETURN Convert(
			Varchar(10), 
			Case 
				When @LastSendDate is Null Then GETDATE() 
				When @LastSendDate >= GETDATE() Then @LastSendDate
				Else DateAdd(day, @Period, @LastSendDate) 
			End,
			111)
END
