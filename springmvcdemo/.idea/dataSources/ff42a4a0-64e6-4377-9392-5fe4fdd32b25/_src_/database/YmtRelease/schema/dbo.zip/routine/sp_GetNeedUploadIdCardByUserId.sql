
-- =============================================
-- Author:		adu
-- Create date: 2014-11-21
-- Description:	获取买家名下需要上传身份证的订单数，不判断多个订单同一个需要上传身份证的收货人
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetNeedUploadIdCardByUserId] 
	-- 买家用户ID
	@UserId int
AS
BEGIN	
	SET NOCOUNT ON;
    ----o.iTradingStatus订单状态： 3-已发货,4-确认收货,12-用户接受取消交易,13-卖家接受取消交易,18-系统自动取消交易
    SELECT COUNT(*) as NeedCount--o.[iOrderId],oe.bIsNeedUploadIdCard,oc.bIdCardUploaded
    FROM [dbo].[Ymt_Orders] AS o with(nolock)
    inner join Ymt_OrderExt oe on o.iOrderId=oe.iOrderId
    left join Ymt_OrderIdCard oc on o.iOrderId=oc.iOrderId
    WHERE o.[iUserId] = @UserId and oe.bIsNeedUploadIdCard=1 and IsNull(oc.bIdCardUploaded,0)=0
    and o.iTradingStatus not in (3,4,12,13,18)

END

