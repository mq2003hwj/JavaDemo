
-- =============================================            

-- Author:  Deng Peng     

-- Create Time:2016-05-20

-- Last-modified:2016-06-28

-- Description: PC Seller 订单列表

-- 20160527：添加实际退平台优惠券金额的统计

-- 20160613：添加对订单卖家备注查询的支持

-- 20160615：变新Ext左联接查询规则：先关联查询再对结果做过滤

--		Ymt_Orders与Ymt_OrderExt记录不对等情况，查询情况分为：1.指定旗子，2.Ext没有或为NULL的

-- 20160621：添加促销活动相关数据信息

-- 20160623：添加对支付时间的查询判断（取最终支付时间），即存在尾款支付以尾款时间作为支付时间，反之支付时间

-- 20160628：订单商品详细信息追加:ReducedAmount , bSupportRtnWithoutReason

-- =============================================



CREATE procedure [dbo].[sp_trd_GetSellerOrderList_v1]

	@sellerId int,

	@orderType int,

	@shangou bit,

	@orderStatusXml xml,

	@catalogStatusXml xml,

	@addBeginTime datetime,

	@addEndTime datetime,

	@paidBeginTime datetime,

	@paidEndTime datetime,

	@paidInFull bit,

	@rowFrom int,

	@rowTo int,

	@buyerNickName nvarchar(20),

	@productName nvarchar(500),

	@considerOrderStatus bit,

	@considerRCOrderEstablish bit,

	@considerRCAccountPaid bit,

	@considerRestOrderStatus bit,

	@salesRefundOrderOnly bit = 0,

	@domesticDelivered bit = null,

	@mainOrderId int = null,

	@OrderId int = null,

	@RemarkLevel int = null

as 



-------------variables-------------

declare @orderIds table ([iOrderId] int not null);



declare @orderToBills table([iOrderId] int not null, [sBillId] varchar(36) not null);

declare @orderTradingIds table([iOrderId] int not null, [iTradingId] int not null, [virtualTime] datetime not null);



declare @totalCount int = 0;

declare @rowsCount int = 0;



set @ProductName = isnull(@ProductName,'');



create table #mainOrderIdFull ([iMainOrderId] int not null, [iOrderId] int not null);



declare @sqlCmd nvarchar(max) ;



-- 固定两表关联脚本开始

set @sqlCmd = '

	select '+ (case when @productName<>'' or @catalogStatusXml is not null then 'distinct' else '' end)+' [order].[iMainOrderId], [order].[iOrderId] from [dbo].[Ymt_Orders] as [order] with(nolock'+ case 

		when @addBeginTime is not null or  @addEndTime is not null then ',index = idx_Ymt_Orders_iBuyerId_dAddTime'

		when @paidBeginTime is not null or @paidEndTime is not null then ',index = idx_Ymt_Orders_iBuyerId_dPaidTime'

		else '' end + ')';



--看是否进行了关联查询

if @catalogStatusXml is not null or @ProductName <> '' begin

	set @sqlCmd = @sqlCmd + '

	inner loop join [dbo].[Ymt_OrderInfo] as [orderInfo] with(nolock) on [orderInfo].[iOrderId] = [order].[iOrderId]';



	--存在商品名称关键字查询

	if isnull(@ProductName,'') <> '' begin

		set @sqlCmd = @sqlCmd + ' and [orderInfo].[sTitle] like ''%'' + @ProductName + ''%''' ;

	end



	--存在物流方式查询

	if @catalogStatusXml is not null begin

		set @sqlCmd = @sqlCmd +'

		and [orderInfo].[iCatalogStatus] in (select tbl.col.value(''@s'',''int'') from @catalogStatusXml.nodes(''/root/x'') tbl(col))';

	end



end



--看是否进行了订单卖家备注关联查询

if @RemarkLevel is not null begin

	set @sqlCmd = @sqlCmd + '

	left join [dbo].[Ymt_O_OrderNote] as [orderNote] with(nolock) on [orderNote].[iOrderId] = [order].[iOrderId] and [orderNote].[iUserId] = [order].[iBuyerId]'

end



--固定参数

set @sqlCmd = @sqlCmd + '

	where [order].[iBuyerId] = @sellerId'



--指定了订单卖家血备注查询条件:Ext记录不对等情况只能先关联结果再过滤

if @RemarkLevel is not null begin

	set @sqlCmd = @sqlCmd + '

	  and [orderNote].[iRemarkLevel]' + case 

														when @RemarkLevel = 0 then ' is null ' 

														else ' = ' + cast(@RemarkLevel as varchar(8)) end;

end



--存在指定订单号查询

if @OrderId is not null begin

	set @sqlCmd = @sqlCmd + ' 

	and [order].[iOrderId] = ' + cast(@OrderId as varchar(36)) ;

end



--存在指定主订单号查询

if @MainOrderId is not null begin

	set @sqlCmd = @sqlCmd + ' 

	and [order].[iMainOrderId] = ' + cast(@MainOrderId as varchar(36)) ;

end



--下单开始时间

if( @addBeginTime is not null) begin

	set @sqlCmd = @sqlCmd + ' 

	and [order].[dAddTime] >= convert(varchar(10), @addBeginTime, 120)';

end



--下单结束时间

if( @addEndTime is not null) begin

	set @sqlCmd = @sqlCmd + ' 

	and [order].[dAddTime] < convert(varchar(10), dateadd(day,1,@addEndTime) , 120)';

end



--支付开始时间

if( @paidBeginTime is not null) begin

	set @sqlCmd = @sqlCmd + ' 

	and ( ([order].[dPostPaidTime] is null and [order].[dPaidTime] >= convert(varchar(10), @paidBeginTime, 120)) or [order].[dPostPaidTime] >= convert(varchar(10), @paidBeginTime, 120) )';

end



--支付结束时间

if( @paidEndTime is not null) begin

	set @sqlCmd = @sqlCmd + ' 

	and ( ([order].[dPostPaidTime] is null and [order].[dPaidTime] < convert(varchar(10), dateadd(day,1,@paidEndTime), 120)) or [order].[dPostPaidTime] < convert(varchar(10), dateadd(day,1,@paidEndTime), 120) )';

end



--买家名称

if( @BuyerNickName is not null) begin

	set @sqlCmd = @sqlCmd + ' 

	and [order].[sBuyerNickName] = @BuyerNickName';

end



--存在交易状态

set @sqlCmd = @sqlCmd +(case 

when @considerOrderStatus = 0 then ''

when @considerRCOrderEstablish = 1 then ' and ([order].[iTradingStatus] = 1 or [order].[iTradingStatus] = 2 and [order].[iRiskVerifiedStatus] = 1)'

when @considerRCAccountPaid = 1 then ' and ([order].[iTradingStatus] = 2 and ([order].[iRiskVerifiedStatus] is null or [order].[iRiskVerifiedStatus] = 2))'

when @considerRestOrderStatus = 1 then ' and [order].[iTradingStatus] in (select tbl.col.value(''@s'',''int'') from @orderStatusXml.nodes(''/root/x'') tbl(col))' 

else '' end);



--存在指定全款

if @paidInFull is not null begin

	set @sqlCmd = @sqlCmd + ' 

	and [order].[bPaidInFull] = ' + cast(@paidInFull as char(1));

end



if @domesticDelivered is not null begin

	set @sqlCmd = @sqlCmd +'

	and isnull([order].[bDomesticDelivered], 0) = '+ cast(@domesticDelivered as char(1));

end



if @salesRefundOrderOnly <> 0 begin

	set @sqlCmd = @sqlCmd +'

	and [order].[iSalesRefundStatus] is not null ';

end



set @sqlCmd = '

;with datatable as (

' + @sqlCmd + '

)

insert into #mainOrderIdFull([iMainOrderId], [iOrderId]) select [iMainOrderId], [iOrderId] from datatable ;'

--执行脚本

exec sp_executesql @sqlCmd

	, N'@sellerId int,@orderStatusXml xml,@catalogStatusXml xml,@buyerNickName nvarchar(20),@productName nvarchar(500),@addBeginTime datetime,@addEndTime datetime,@paidBeginTime datetime,@paidEndTime datetime'

	, @SellerId,@orderStatusXml,@catalogStatusXml,@buyerNickName,@productName,@addBeginTime,@addEndTime,@paidBeginTime,@paidEndTime



--分页数据:	获取当前页的所有订单ID

;with mainOrderIdFull as (

	select * from (

		select [iMainOrderId],row_number() over(order by [iMainOrderId] desc) as [row_number] from #mainOrderIdFull group by [iMainOrderId]

	) as t1 where t1.[row_number] between @rowFrom and @rowTo

)

insert into @orderIds ([iOrderId])

select t2.[iOrderId] from mainOrderIdFull as t1

inner join #mainOrderIdFull as t2 on t1.[iMainOrderId] = t2.[iMainOrderId]



--统计主订单总量

select @totalCount = count(distinct [iMainOrderId]) from #mainOrderIdFull;



drop table #mainOrderIdFull ;



--====================================================================

set nocount on;



--统计当前页订单数量 

select @rowsCount = count(1) from @orderIds



select @totalCount as TotalCount;



----------------------------------------------------------------------------------------------------------------------

--当页订单的详细信息

select t2.* ,

	[RealPay].* 

from @orderIds as t1

inner join [dbo].[Ymt_Orders] as t2 with(nolock) on [t2].[iOrderId] = [t1].[iOrderId]

outer apply (

	select

		[RealSettlementAmountOfCoupon] = sum(case [t3].[SalesRefundStatus] when 10 then [SettlementAmountOfCoupon] else 0 end ),

		[TotalSalesRefundAmount] = sum(t3.[RefundAmount])

	from [dbo].[Ymt_RefundBill] as t3 with(nolock) where t3.[OrderId] = t1.[iOrderId]

) as [RealPay]

order by t2.[iMainOrderId] desc ,t1.[iOrderId] asc, [t2].[sYmtCouponCode] desc option(recompile);



----------------------------------------------------------------------------------------------------------------------

--获取评价列表  

select * from [dbo].[Ymt_CreditDetail] with(nolock) where @rowsCount > 0 and [sTargetId] in (select cast([iOrderId] as varchar(36)) from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取备注列表  

select [iOrderId], [sContent],[iRemarkLevel] from [dbo].[Ymt_O_OrderNote] with(nolock) where @rowsCount > 0 and [iUserId] = @sellerId and [iOrderId] in (select [iOrderId] from @orderIds) ; 



----------------------------------------------------------------------------------------------------------------------

--获取订单金额详情列表

select * from [dbo].[Ymt_OrderState] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取订单补款列表  

select * from [dbo].[Ymt_OrderPostPay] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取订单商品详情列表

select

	i.[iOrderId] , i.sOrderInfoId , i.fOriginalPrice , i.iPriceType , i.iAmount , i.iBondedArea , i.iCatalogStatus , i.iCatalogType , i.iProductSubCategoryId

	, i.iSailProtected , i.iType , i.sCatalogId , i.sDescription , i.sPictureUrl , i.sProductId , i.sPropertyInfo , i.sReferenceUrl , i.sSKU , i.sTitle 

	, e.sOrderInfoId as sOrderInfoExtId , e.bGiftAvail4Reward , e.iActivityId , e.iActivityTemplateId , i.iSalesType

	, i.fProductPrice , i.fProductOriginalPrice , i.fSellerCouponAmount , i.fYmtCouponAmount , i.fDiscount , i.fFreight

	, i.[fSellerPromotionAmount] , s.[PromotionId] , s.[PromotionType] , s.[PromotionName] , s.[MatchCondition] , s.[PromotionValue]

	, s.ReducedAmount , i.bSupportRtnWithoutReason

from [dbo].[Ymt_OrderInfo] as i with(nolock) 

inner join @orderIds as o on i.[iOrderId] = o.[iOrderId]

left join [dbo].[Ymt_OrderInfoExt] as e with(nolock) on i.[sOrderInfoId] = e.[sOrderInfoId]

left join [dbo].[Ymt_SellerPromotion] as s with(nolock) on i.[iOrderId] = s.[OrderId] and i.[sOrderInfoId] = s.[OrderInfoId]

where @rowsCount > 0 ;



----------------------------------------------------------------------------------------------------------------------

--获取订单物流信息  

select [iOrderId], [iBillType], [sSummary] from [dbo].[Ymt_OrderSummary] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取订单冻结信息  

select * from [dbo].[Ymt_Order_Frozen] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) ;



----------------------------------------------------------------------------------------------------------------------

--获取订单账单信息

 insert into @orderToBills([iOrderId], [sBillId])
 
 select [iOrderid], [sBillId] from [dbo].[Ymt_OrderToBill] with(nolock) where @rowsCount > 0 and [iOrderId] in (select [iOrderId] from @orderIds) and iaction >= 0 ;
 
 select * from @orderToBills where @rowsCount > 0;
 
 
 
 ----------------------------------------------------------------------------------------------------------------------
 
 --获取码头在线做单信息  
 
 select * from [dbo].[Ymt_Bill] with(nolock) where @rowsCount > 0 and [sBillId] in (select [sBillId] from @orderToBills) and [iAction] >= 0 ;



----------------------------------------------------------------------------------------------------------------------

--订单有效的交易ID  

if @rowsCount > 0 begin



	insert into @orderTradingIds([iOrderId], [iTradingId], [virtualTime])

	select [iOrderId], [iTradingId], [dUpdateTime] from [dbo].[Ymt_TradingItem] with(nolock) where [iOrderId] in (select [iOrderId] from @orderIds) ;



	-----------------------update virtaulTime from ymt_tradinginfo-------------------------------

	update [target] set [virtualTime] = '9999-1-1'

	from @orderTradingIds as [target] , [dbo].[Ymt_TradingInfo] as [source] with(nolock)

	where [target].[iTradingId] = [source].[iTradingId] and [source].[iTradingStatus] = 2 ;



  ;with t as(

    select ROW_NUMBER() over(partition by [iOrderId] order by [virtualTime] desc) as n, * from @orderTradingIds

  ) 

  select [iOrderId], [iTradingId] from t where n = 1 order by [iOrderId] ;



end

else begin

  select top 0 0 as iOrderId, 0 as iTradingId ;

end



select [iOrderId], [bIsNeedUploadIdCard], [bHaveUploadedIdCard] from [dbo].[Ymt_OrderExt] with(nolock) where [iOrderId] in (select [iOrderId] from @orderIds) ;



set nocount off;