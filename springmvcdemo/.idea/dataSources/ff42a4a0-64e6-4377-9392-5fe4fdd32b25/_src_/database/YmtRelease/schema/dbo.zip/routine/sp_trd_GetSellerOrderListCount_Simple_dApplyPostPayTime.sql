-- =============================================            
-- Author:  CL
-- Create date: 2015-12-03
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderListCount_Simple_dApplyPostPayTime]

@sellerId int,
@timeType int,
@beginTime  datetime,
@endTime datetime,
@timeoutType bit,
@timeoutType1 tinyint,
@timeoutType2 tinyint,
@timeoutType3 tinyint,
@timeoutBegin1 datetime,
@timeoutEnd1 datetime,
@timeoutBegin2 datetime,
@timeoutEnd2 datetime,
@timeoutBegin3 datetime,
@timeoutEnd3 datetime,
@shangou bit,
@orderStatusXml xml,
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@salesRefundOrderOnly bit = 0

AS

-------------variables-------------
declare @orderStatus table(value int primary key);

--------------process--------------
set nocount on;

if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

--set statistics time on;set statistics io on;--set profile on;
if @considerRiskVerfiedStatus = 0 begin

select o.iTradingStatus, o.bPaidInFull, count(o.iOrderId) as num
from Ymt_Orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dApplyPostPayTime)
where o.iBuyerId = @sellerId
and o.dApplyPostPayTime between @beginTime and @endTime
--and (
--@timeType = 0
--or @timeType = 1 and o.dAddTime between @beginTime and @endTime
--or @timeType = 2 and o.dPaidTime between @beginTime and @endTime
--or @timeType = 3 and o.dDispathTime between @beginTime and @endTime
--or @timeType = 4 and o.dApplyPostPayTime between @beginTime and @endTime
--)
and (@shangou is null or o.bShangouOrder = @shangou)
and (@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))
and (
@timeoutType = 0 or(
    @timeoutType1 = 0 or (@timeoutType1 = 1 and (o.dPaidTime > @timeoutBegin1 and o.dPaidTime <= @timeoutEnd1 and o.iTradingStatus = 2) or @timeoutType1 = 2 and (o.dPaidTime <= @timeoutEnd1 and o.iTradingStatus = 2))
  and @timeoutType2 = 0 or (@timeoutType2 = 1 and (o.dAcceptTime > @timeoutBegin2 and o.dPaidTime <= @timeoutEnd2 and o.iTradingStatus = 17 and o.bPaidInFull = 0) 
	or @timeoutType2 = 2 and (o.dAcceptTime <= @timeoutEnd2 and o.iTradingStatus = 17 and o.bPaidInFull = 0))
  and @timeoutType3 = 0 or (@timeoutType3 = 1 and (isnull(o.dPostPaidTime,o.dPaidTime) > @timeoutBegin3 and isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd3 and o.iTradingStatus = 17 and o.bPaidInFull = 1) 
	or @timeoutType3 = 2 and (isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd3 and o.iTradingStatus = 17 and o.bPaidInFull = 1))
        )
)
and (@salesRefundOrderOnly = 0 or o.iSalesRefundStatus is not null)
group by o.iTradingStatus, o.bPaidInFull;

end else begin

select case 
when (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1) then 1
when (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)) then 2
else o.iTradingStatus end as iTradingStatus,
o.bPaidInFull, count(o.iOrderId) as num
from Ymt_Orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dApplyPostPayTime)
where o.iBuyerId = @sellerId
and o.dApplyPostPayTime between @beginTime and @endTime
--and (
--@timeType = 0
--or @timeType = 1 and o.dAddTime between @beginTime and @endTime
--or @timeType = 2 and o.dPaidTime between @beginTime and @endTime
--or @timeType = 3 and o.dDispathTime between @beginTime and @endTime
--or @timeType = 4 and o.dApplyPostPayTime between @beginTime and @endTime
--)
and (@shangou is null or o.bShangouOrder = @shangou)
and --(@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))
(
  @considerOrderStatus = 0 or
  (
    (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
    or
    (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
    or
    (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
  )
)
and (
@timeoutType = 0 or(
    @timeoutType1 = 0 or (@timeoutType1 = 1 and (o.dPaidTime > @timeoutBegin1 and o.dPaidTime <= @timeoutEnd1 and o.iTradingStatus = 2) or @timeoutType1 = 2 and (o.dPaidTime <= @timeoutEnd1 and o.iTradingStatus = 2))
  and @timeoutType2 = 0 or (@timeoutType2 = 1 and (o.dAcceptTime > @timeoutBegin2 and o.dPaidTime <= @timeoutEnd2 and o.iTradingStatus = 17 and o.bPaidInFull = 0) 
	or @timeoutType2 = 2 and (o.dAcceptTime <= @timeoutEnd2 and o.iTradingStatus = 17 and o.bPaidInFull = 0))
  and @timeoutType3 = 0 or (@timeoutType3 = 1 and (isnull(o.dPostPaidTime,o.dPaidTime) > @timeoutBegin3 and isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd3 and o.iTradingStatus = 17 and o.bPaidInFull = 1) 
	or @timeoutType3 = 2 and (isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd3 and o.iTradingStatus = 17 and o.bPaidInFull = 1))
        )
)
and (@salesRefundOrderOnly = 0 or o.iSalesRefundStatus is not null)
group by case 
when (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1) then 1
when (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)) then 2
else o.iTradingStatus end,
o.bPaidInFull;

end
set nocount off;

--set statistics time off;set statistics io off;

--print datediff(ms,@t1,getdate())