-- =============================================            

-- Author:  fanwei        

-- Create date: 2015-9-13

-- Description: 交易服务SP       

-- 20160819：取消根据风控状态做的特殊查询逻辑   

-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetBondedProductInfo]



@sellerId int,

@considerAcceptTime bit,

@now datetime,

@bondedTimeout int,

@tradingStatus xml,

@considerPaidInFull bit,

@paidInFull bit,

@considerPaidTime bit,

@startDate datetime,

@endDate datetime,

@considerCatalogStatus bit,

@catalogStatus int,

@catalogStatus2 int,

@considerBondedArea bit,

@bondedArea int,

@considerBondedNoResult bit,

@considerIdPic bit,

@needIdPic bit,

@considerIdPicAddTime bit,

@outputOrdersExistOnly bit,

@considerOrderStatus bit,

@considerRCOrderEstablish bit,

@considerRCAccountPaid bit,

@considerRestOrderStatus bit



AS



-------------variables-------------

declare @orders table(id int, [uid] int, receiver varchar(50), del smallint default 0);

declare @tTradingStatus table([value] int);

declare @next int = 1;

declare @toBeDeleted int = 0;

declare @withoutPic smallint;

--------------process--------------



if @tradingStatus is not null begin

  insert into @tTradingStatus

  select tbl.col.value('@s', 'int')

  from @tradingStatus.nodes('/root/x') tbl(col)

end;



insert into @orders(id, [uid], receiver)

select id, [uid], receiver from(

  select ROW_NUMBER() over(partition by o.iOrderId order by o.iOrderId) as n, o.iOrderId as id, o.iUserId as [uid], o.sReceivePerson as [receiver] 

  from Ymt_Orders(nolock) o join Ymt_OrderInfo(nolock) i on o.iBuyerId = @sellerId and o.iOrderId = i.iOrderId

  and (@considerAcceptTime != 1 or @considerAcceptTime = 1 and o.dAcceptTime is not null and datediff(n, o.dAcceptTime, @now) > @bondedTimeout)

  and (@tradingStatus is null or o.iTradingStatus in (select [value] from @tTradingStatus))

  /*

  and (@considerOrderStatus = 0 or ( 

  (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))

  or

  (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))

  or

  (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @tTradingStatus))

  ))*/

  and (@considerPaidInFull != 1 or @considerPaidInFull = 1 and o.bPaidInFull = @paidInFull)

  and (@considerPaidTime != 1 or @considerPaidTime = 1 and o.dPaidTime >= @startDate and o.dPaidTime < @endDate)

  and (@considerBondedArea != 1 or @considerBondedArea = 1 and i.iBondedArea = @bondedArea)

  and (@considerCatalogStatus != 1 or @considerCatalogStatus = 1 and (i.iCatalogStatus = @catalogStatus or i.iCatalogStatus = @catalogStatus2))

  and i.iCatalogType != 2 -- 排除FBX贝海代运

) t where t.n = 1;



if @@ROWCOUNT > 0 begin

  set @next = 0;

  if @considerBondedNoResult > 0 begin

    update @orders set del = 1 where id in(select iOrderId from Ymt_BondedResult(nolock) where iOrderId in (select id from @orders))

    set @toBeDeleted = @@ROWCOUNT;

    set @next = @toBeDeleted;

  end



  if @considerIdPic = 1 begin

    set @withoutPic = case @needIdPic when 1 then -1 else 1 end



    update o set o.del = @withoutPic

    from @orders o join ymt_idpic(nolock) p on o.[uid] = p.iUserId and o.receiver = p.sName and o.del != 1

    and (@considerIdPicAddTime != 1 or @considerIdPicAddTime = 1 and p.dAddTime >= @startDate and p.dAddTime < @endDate)



    set @toBeDeleted = @@ROWCOUNT;

    if @toBeDeleted > 0 begin

      if @needIdPic = 1 delete from @orders where del = 0;

      else set @next += @toBeDeleted;

    end

  end



  if @next > 0  delete from @orders where del = 1

end



set @next = 0;

select top 1 @next = 1 from @orders;



if @outputOrdersExistOnly = 1 begin

  select @next;

  return;

end



select iOrderId, iUserId, sReceivePerson, sAddress, sLeaveWord, sTelephone, iTradingStatus, iRiskVerifiedStatus, bPaidInFull, sBuyerLoginId, sEmail, fFreight, dAddTime, sPhone, sPostCode,sBuyerLoginEmail
from Ymt_Orders(nolock) where iOrderId in (select id from @orders)



if @next < 1 return;



select iOrderId, iBondedArea, iAmount, fOriginalPrice, sTitle, sProductCode, sProductId, sSKU, sCatalogId, sPropertyInfo from Ymt_OrderInfo(nolock)

where iOrderId in (select id from @orders) and (@considerBondedArea != 1 or @considerBondedArea = 1 and iBondedArea = @bondedArea)



select iOrderId, iTradingId, dUpdateTime from Ymt_TradingItem(nolock) where iOrderId in (select id from @orders)



select iTradingId, iTradingStatus from Ymt_TradingInfo(nolock) where iTradingId in (select iTradingId from Ymt_TradingItem(nolock) where iOrderId in (select id from @orders))



select iOrderId, fPaidAmountOfCash, fPostPaidAmountOfCash, fRefundedAmountOfCash from Ymt_OrderState(nolock) where iOrderId in (select id from @orders)



select 0 as iUserId, '' as sPhone,'' as sLoginEmail



select o.id as iOrderId, p.iUserId, p.sName, p.sCardId from @orders o join ymt_idpic(nolock) p on o.[uid] = p.iUserId and o.receiver = p.sName



;with t as(

  select ROW_NUMBER() over(partition by iOrderId order by dAddTime desc) as n, iOrderId, dAddTime, sContent from Ymt_O_OrderNote(nolock) where iOrderId in (select id from @orders)

) 

select iOrderId, dAddTime, sContent from t where n = 1;



with t as(

  select ROW_NUMBER() over(partition by iOrderId order by dAddTime desc) as n, iOrderId, sLogisticsProvider from Ymt_OrderSummary(nolock) where iOrderId in (select id from @orders)

) 

select iOrderId, sLogisticsProvider from t where n = 1;

