

-- =============================================   
-- Author:  ccw        
-- Create date: 2015-10-14
-- Description: 查询补偿SP      
-- =============================================
CREATE proc [dbo].[csp_FetchAndConfirmCompensateProcessInfo]
(
	@MachineName varchar(64),
	@MaxRetryCount int=13,
	@MaxJobsPerDuration int=100,
	@MaxDayRange int=30,
	@Delta int=6,
	@CompensateType int=null
)
as

declare @ids table(id bigint)

if @CompensateType is null
    insert into @ids
    select CompensateId from dbo.PP_CompensateProcessInfo(nolock) 
	where CreatedTime between DATEADD(day,-@MaxDayRange,getdate()) and DATEADD(SECOND,-ABS(@Delta),getdate())
		and RetryCount<@MaxRetryCount
		and (ProcessMachineName is null)
		and ProcessStatus in (0,-1)
		and CompensateType is null
else
	insert into @ids
    select CompensateId from dbo.PP_CompensateProcessInfo(nolock) 
	where CreatedTime between DATEADD(day,-@MaxDayRange,getdate()) and DATEADD(SECOND,-ABS(@Delta),getdate())
		and RetryCount<@MaxRetryCount
		and (ProcessMachineName is null)
		and ProcessStatus in (0,-1)
		and CompensateType =@CompensateType

if(@@ROWCOUNT > 0)
	update dbo.PP_CompensateProcessInfo 
	set ProcessMachineName=@MachineName
	where CompensateId in (select id from @ids)

select top (@MaxJobsPerDuration) * from dbo.PP_CompensateProcessInfo with(nolock)
where CreatedTime between DATEADD(day,-@MaxDayRange,getdate()) and DATEADD(SECOND,-ABS(@Delta),getdate())
	and RetryCount<@MaxRetryCount
	and (ProcessMachineName = @MachineName)
	and ProcessStatus in (0,-1)
	and( (@CompensateType is null and CompensateType is null) or CompensateType =@CompensateType)
