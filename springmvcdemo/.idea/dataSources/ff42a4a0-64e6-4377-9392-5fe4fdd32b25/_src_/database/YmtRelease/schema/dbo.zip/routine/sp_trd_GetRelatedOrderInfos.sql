

-- =============================================            
-- Author:  zhangyifan, fanwei      
-- Create date: 2016-6-28
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetRelatedOrderInfos]

@OrderID int

AS

--DECLARE @OrderID BIGINT;

DECLARE @MainOrderId INT;
DECLARE @OrdersTable TABLE(iOrderId INT NOT NULL);

SELECT @MainOrderId = iMainOrderId FROM Ymt_Orders ( NOLOCK ) WHERE iOrderId = @OrderID;

INSERT INTO @OrdersTable SELECT iOrderid FROM Ymt_Orders ( NOLOCK ) WHERE iMainOrderId = @MainOrderId;

SELECT a.iOrderId, a.iTradingStatus, a.iUserId, a.iBuyerId, a.sBuyerLoginId, a.sSellerLoginId, a.fPayableAmount, a.sYmtCouponCode, a.fYmtCouponAmount, a.sSellerCouponCode, a.fSellerCouponAmount, a.iMainOrderId
, a.fSellerPromotionAmount
FROM Ymt_Orders a ( NOLOCK )
  JOIN @OrdersTable b ON a.iOrderId = b.iOrderId;

SELECT a.iOrderId, a.sProductId, a.sCatalogId, a.sTitle, a.iAmount, a.fYmtCouponAmount, a.fSellerCouponAmount, a.fFreight, a.fDiscount, a.fProductPrice
, a.fSellerPromotionAmount, a.bSupportRtnWithoutReason
, c.PromotionId,c.PromotionName,c.PromotionType,c.MatchCondition,c.PromotionValue,c.ReducedAmount
FROM Ymt_OrderInfo a ( NOLOCK )
JOIN @OrdersTable b ON a.iOrderId = b.iOrderId
LEFT JOIN Ymt_SellerPromotion(nolock) c on c.OrderInfoId = a.sOrderInfoId
