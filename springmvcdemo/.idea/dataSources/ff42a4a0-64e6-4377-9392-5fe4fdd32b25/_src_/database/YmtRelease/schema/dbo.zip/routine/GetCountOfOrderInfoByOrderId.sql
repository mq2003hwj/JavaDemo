

CREATE FUNCTION [dbo].[GetCountOfOrderInfoByOrderId]
(	
	@orderId int
)
RETURNS int
AS

BEGIN
	--DECLARE @orderId int
	--SET @orderId = 100001759
	DECLARE @result int
	SET @result = 0;
	
	SET @result = (
					  SELECT count(*) 
					  FROM dbo.Ymt_OrderInfo 
					  where iOrderId=@orderId
				  )
--Select @result
	return @result;
END	



