
-- =============================================
-- Author:		adu
-- Create date: 2015-06-08
-- Description:	获取推荐人的用户信息，老推新站点用来检验推荐人是否有推荐的权限，推荐人的UserId加推荐人是否绑定手机，是否下过有效订单，userid是否是码头合法的用户ID
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetRecommenderInfo]
	-- Add the parameters for the stored procedure here
	@UserId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT m.iUserId AS UserId,m.sAccountName AS Mobile,[t0].OrderCount FROM Ymt_MobilePhoneAccount m
	CROSS APPLY 
	(
	    --查看订单的交易状态,iTradingStatus值：1-订单确立/（未付款） 2-已付款(等待发货) 3-已发货 4-确认收货 5-申请退货 6-同意退货(退货中) 7-收到退货 9-疑问交易 10-用户申请取消交易
--11-卖家申请取消交易 12-用户接受取消交易 13-卖家接受取消交易 18-系统自动取消交易 15-正在付款 16-申请补款中 17-卖家确认订单--
		SELECT COUNT(iOrderId) AS OrderCount FROM Ymt_Orders o WHERE m.iUserId=o.iUserId AND o.iTradingStatus IN (3,4) 
	) AS [t0]
	WHERE m.iUserId=@UserId
END

