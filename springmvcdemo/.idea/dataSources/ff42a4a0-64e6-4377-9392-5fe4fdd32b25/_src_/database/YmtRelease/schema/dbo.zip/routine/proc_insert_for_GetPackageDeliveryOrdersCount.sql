create proc proc_insert_for_GetPackageDeliveryOrdersCount(@orderId int, @orderInfoId int, @buyerId int)
as

declare @i int,@j int

set @i = 0

while @i < 500
begin

if(@i<300)
	begin
		exec proc_insert_ymt_orders_for_GetPackageDeliveryOrdersCount @orderId, @buyerId,NUll;
	end
else
	begin
		exec proc_insert_ymt_orders_for_GetPackageDeliveryOrdersCount @orderId, @buyerId,1;  
	end

	set @j = 0
	while @j < 10
	begin		
		exec proc_insert_ymt_orderinfo_for_GetPackageDeliveryOrdersCount @orderInfoId, @orderId;
		set @j = @j + 1
		set @orderInfoId=@orderInfoId+1
	end
	
	set @i=@i+1
	set @orderId=@orderId+1

end
