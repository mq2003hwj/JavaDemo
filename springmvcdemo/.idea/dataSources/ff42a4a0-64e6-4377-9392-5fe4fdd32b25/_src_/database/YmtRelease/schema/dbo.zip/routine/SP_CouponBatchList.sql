



-- =============================================

-- Author:		liuhong

-- Create date: 2015-10-20

-- Description:	查询优惠券批次列表

-- =============================================

CREATE PROCEDURE [dbo].[SP_CouponBatchList]

 @BatchCreateType INT

,@SellerId INT

,@BatchCode VARCHAR(36)

,@BatchPrefix VARCHAR(50)

,@CouponName NVARCHAR(50)

,@ValidStart DATETIME

,@ValidEnd DATETIME

,@CreateStart DATETIME

,@CreateEnd DATETIME

,@PageSize INT

,@CurPage INT

,@ScenarioType INT = 0

,@TotalCount INT OUTPUT

AS

BEGIN

	DECLARE @SQL NVARCHAR(MAX)='',

			@param_def NVARCHAR(MAX)=

			N'@BatchCreateType INT,@SellerId INT,@BatchCode VARCHAR(36),@BatchPrefix VARCHAR(50),@CouponName NVARCHAR(50),

			  @ValidStart DATETIME,@ValidEnd DATETIME,@CreateStart DATETIME,@CreateEnd DATETIME,@ScenarioType INT '

	SELECT @SQL='

	SELECT ROW_NUMBER() OVER(ORDER BY A.dAddTime DESC) RowNum

		  ,A.sBatchCode BatchCode

		  ,A.sBatchPrefix BatchPrefix

		  ,A.iOperatorId SellerId

		  ,A.sCouponName CouponName

		  ,B.sApplyMemo CouponDesc

		  ,A.iCouponTotalNum MaxSendNum

		  ,A.iCouponNumPerUser UserMaxReceiveNum

		  ,B.dValidStart ValidStart

		  ,B.dValidEnd ValidEnd

		  ,A.iCouponSettingId CouponSettingId

		  ,B.iReceiveCount HaveSendNum

		  ,ISNULL(B.iScenarioType,1) ScenarioType

		  ,cs.sUsePlatforms UsePlatforms

		  ,ISNULL(A.bInvalidStatus,0) InvalidStatus

		  ,A.dInvalidTime InvalidTime
		  ,ISNULL(d.IsOpen, 0) IsOpen
	  FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) 

	  INNER JOIN dbo.Ymt_CouponSetting B WITH(NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId

	  INNER JOIN Ymt_CouponScenario cs WITH(NOLOCK) ON cs.iCouponScenarioId = B.iScenarioId
	  INNER JOIN dbo.Ymt_CouponSellerPrefix d ON a.sBatchPrefix = d.sPrefix
	  WHERE 1=1'



	IF @BatchCreateType <> 0

	SELECT @SQL += ' AND A.iBatchCreateType = @BatchCreateType'



	IF @SellerId IS NOT NULL AND @SellerId <> 0

	SELECT @SQL += ' AND A.iOperatorId = @SellerId'



	IF @ScenarioType IS NOT NULL AND @ScenarioType <> 0

	SELECT @SQL += ' AND ISNULL(B.iScenarioType,1) = @ScenarioType'



	IF @BatchCode IS NOT NULL AND RTRIM(LTRIM(@BatchCode)) != ''

	SELECT @SQL += ' AND A.sBatchCode LIKE ''%'' + @BatchCode + ''%'''



	IF @BatchPrefix IS NOT NULL AND RTRIM(LTRIM(@BatchPrefix)) != ''

	SELECT @SQL += ' AND A.sBatchPrefix LIKE ''%'' + @BatchPrefix + ''%'''



	IF @CouponName IS NOT NULL AND RTRIM(LTRIM(@CouponName)) != ''

	SELECT @SQL += ' AND A.sCouponName LIKE ''%'' + @CouponName + ''%'''



	IF @CreateStart IS NOT NULL

	SELECT @SQL += ' AND A.dAddTime >= @CreateStart'



	IF @CreateEnd IS NOT NULL

	SELECT @SQL += ' AND A.dAddTime <= @CreateEnd'



	IF @ValidStart IS NOT NULL

	SELECT @SQL += ' AND B.dValidEnd >= @ValidStart'



	IF @ValidEnd IS NOT NULL

	SELECT @SQL += ' AND B.dValidStart <= @ValidEnd'





	--获取总记录数

	DECLARE @TOTALSQL NVARCHAR(MAX) = N'SELECT @TotalCount=COUNT(0) FROM (' + @SQL + ') TEMP '

		   ,@total_param_def NVARCHAR(MAX) = @param_def + N',@TotalCount INT OUTPUT'

	EXEC sp_executesql @TOTALSQL, @total_param_def, @BatchCreateType, @SellerId, @BatchCode, @BatchPrefix, @CouponName, @ValidStart, @ValidEnd,@CreateStart,@CreateEnd,@ScenarioType, @TotalCount OUTPUT



	--获取分页记录

	DECLARE @StartRow INT = (@CurPage - 1) * @PageSize + 1, @EndRow INT = @CurPage * @PageSize

	IF @PageSize > 0 AND @CurPage > 0

	BEGIN

		SELECT @SQL = N'SELECT * FROM (' + @SQL + ') TEMP WHERE RowNum BETWEEN @StartRow AND @EndRow'

		SELECT @param_def += N',@StartRow INT,@EndRow INT'

		EXEC sp_executesql @SQL, @param_def, @BatchCreateType, @SellerId, @BatchCode, @BatchPrefix, @CouponName, @ValidStart, @ValidEnd, @CreateStart,@CreateEnd,@ScenarioType, @StartRow, @EndRow

	END

	ELSE

	BEGIN

		EXEC sp_executesql @SQL, @param_def, @BatchCreateType, @SellerId, @BatchCode, @BatchPrefix, @CouponName, @ValidStart, @ValidEnd, @CreateStart,@CreateEnd,@ScenarioType

	END

END
