create PROCEDURE IM_GetLastMessage @FromUserID  int,@ToUserID     int
as
begin 
	select top 1 * from  [dbo].[Ymt_Message](nolock)
  where (iMsgFromId=@FromUserID and iMsgToId=@ToUserID and SSee=0)
  or (iMsgFromId=@ToUserID and iMsgToId=@FromUserID and RSee=0) order by dPostTime desc
end