CREATE function Func_ReplaceNElement
(
    @result varchar(500), --被替换元素的字符串
	@elment varchar(20), --替换字符串
	@number int --被移除掉的元素个数
)
returns varchar(500)
as
begin
   declare @newresult varchar(500)
   declare @lastcharindex int
   declare @reverseresult varchar(500)
   declare @location int
   declare @start int
   set @newresult=LTRIM(rtrim(@result))
   set @reverseresult=REVERSE(@newresult)
   set @location=CHARINDEX(',',@reverseresult)
   while @location<>0 and @number>1
   begin
       set @start=@location+1
	   set @location =CHARINDEX(',',@reverseresult,@start)	  
	   set @number=@number-1
   end
   --set @lastcharindex=LEN(@newresult)-CHARINDEX(',',Reverse(@newresult))+1
   set @lastcharindex=LEN(@newresult)-@location+1
   set @newresult= @elment+','+SUBSTRING(@newresult,0,@lastcharindex)
   return @newresult
   --return cast(@reverseresult as varchar(500))
end
