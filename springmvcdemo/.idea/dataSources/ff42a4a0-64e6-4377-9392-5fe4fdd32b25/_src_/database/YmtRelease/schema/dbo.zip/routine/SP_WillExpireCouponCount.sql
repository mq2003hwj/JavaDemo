
-- =============================================
-- Author:		zhangzhiqiang
-- Create date: 2015-12-17
-- Description:	获取即将过期的优惠券数量
-- =============================================
CREATE PROCEDURE [dbo].[SP_WillExpireCouponCount]
	@Days INT,
	@LastUserId INT,
	@PageSize INT
AS
BEGIN
	IF @LastUserId = 0
	BEGIN
		SELECT TOP (@PageSize) B.iUserId AS UserId,COUNT(0) AS CouponCount FROM dbo.Ymt_Coupon A WITH(NOLOCK)
		INNER JOIN dbo.Ymt_CouponPrivateUserBound B WITH(NOLOCK) ON A.iBatchId = B.iBatchId AND A.sCouponCode = B.sCouponCode AND A.sCouponId = B.sCouponId
		AND B.iCouponUsedCount>0 WHERE DATEADD(DAY,@Days,GETDATE())>A.dValidEnd AND A.iCouponType=2 AND A.dValidStart<=A.dValidEnd
		AND A.dValidEnd>=GETDATE() AND A.dValidStart > '2015-06-01'
		GROUP BY B.iUserId
		ORDER BY B.iUserId ASC
	END
	ELSE
	BEGIN
		SELECT TOP (@PageSize) B.iUserId AS UserId,COUNT(0) AS CouponCount FROM dbo.Ymt_Coupon A WITH(NOLOCK)
		INNER JOIN dbo.Ymt_CouponPrivateUserBound B WITH(NOLOCK) ON A.iBatchId = B.iBatchId AND A.sCouponCode = B.sCouponCode AND A.sCouponId = B.sCouponId
		AND B.iCouponUsedCount>0 WHERE DATEADD(DAY,@Days,GETDATE())>A.dValidEnd AND A.iCouponType=2 AND A.dValidStart<=A.dValidEnd 
		AND A.dValidEnd>=GETDATE() AND A.dValidStart > '2015-06-01' AND B.iUserId > @LastUserId
		GROUP BY B.iUserId
		ORDER BY B.iUserId ASC
	END
	
END
