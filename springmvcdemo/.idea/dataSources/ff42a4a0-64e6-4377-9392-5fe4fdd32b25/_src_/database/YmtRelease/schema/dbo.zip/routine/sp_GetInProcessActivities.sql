-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetInProcessActivities] 
	@ActivityTemplateId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   select a.iActivityId as ActivityId,a.sName as ActivityName,a.dBeginTime as StartTime,a.dEndTime as EndTime,a.iSellerId as SellerId,a.sPosition as Position,
   a.sTitlePrefix as Comment,a.iActivityTemplateId as ActivityTemplateId,at.sTemplateName as ActivityTemplateName,a.dAddTime as AddTime,a.iAction as Action,a.fDefaultFeeRate as DefaultFeeRate,
   u.sLoginId as Seller,t2.ProductCount
   from Ymt_Activity as a with(nolock)
   cross apply
   (
		select COUNT(pa.sProductId) as ProductCount from Ymt_Products p  with(nolock)
		inner join Ymt_ProductsInActivity pa with(nolock) on p.sProductId=pa.sProductId
		where pa.iActivityId=a.iActivityId and p.iAction>-1 and (GETDATE() between p.validStart and p.validEnd)
   ) as [t2]
   inner join Ymt_Users as u with(nolock) on a.iSellerId=u.iUserId
   inner join Ymt_ActivityTemplate as at with(nolock) on at.iActivityTemplateId=a.iActivityTemplateId
 
   where a.iAction=1 and [t2].ProductCount>0 and (GETDATE() between a.dBeginTime and a.dEndTime) and at.iActivityTemplateId=@ActivityTemplateId
END
