-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION GetActivityStockNumber 
(
	@ProductId VARCHAR(36),	
	@CatalogStockNum INT

)
RETURNS INT
AS
BEGIN
	
	DECLARE @AvgCataRegNum INT; -- 平均规格报名库存数
	DECLARE @ActRegNum INT;		-- 活动规格报名库存数
	DECLARE @CatalogCount INT;	-- 商品下有效规格总数
	
	DECLARE @x INT; -- 余量
	DECLARE @Result INT;

	SELECT @ActRegNum = iActivityStock, @CatalogCount= COUNT(b.sCatalogId) FROM ymt_productsInActivity a INNER JOIN dbo.Ymt_Catalogs b ON a.sProductId = b.sProductId 
	WHERE a.dEndTime>GETDATE() and a.iStatus= 2	AND b.iAction > -1 AND a.sProductId = @ProductId
	GROUP BY b.sCatalogId, a.iActivityStock;
	
	SET @AvgCataRegNum = FLOOR(@ActRegNum / @CatalogCount );


	IF(@AvgCataRegNum < @CatalogStockNum)
	BEGIN
		--报名库存量小于实际库存
		SET @Result = @AvgCataRegNum;
	END
	ELSE
	BEGIN
		--报名库存>=
		SET @x =  CEILING(@CatalogStockNum * 0.05)
		SET @Result = @CatalogStockNum - @x;
	END
   
	RETURN @Result;

END
