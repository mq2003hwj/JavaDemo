
-- =============================================            
-- Author:  zhangzhiqiang        
-- Create date: 2016-03-24
-- Description: 生成新交易号      
-- =============================================     

CREATE PROC [dbo].[sp_CreateNewTradingId]
	@Tradingid INT,
	@UserId INT,
	@PayAmount DECIMAL(18,2),
	@PayableAmount DECIMAL(18,2) = 0  --总应付金额
AS

DECLARE @NewTradingId int
	,@Now DateTime = getdate()

--生成新交易号
EXEC @NewTradingId = [dbo].[spGenerateTradingId]

INSERT INTO [dbo].[Ymt_TradingInfo]
           ([iTradingId]
           ,[iUserId]
           ,[dAddTime]
           ,[iTradingStatus]
           ,[fAmount]
           ,[dUpdateTime]
		   ,[fPayableAmount])
     VALUES
           (@NewTradingId
           ,@UserId
           ,@Now
           ,1
           ,@PayAmount
           ,@Now
		   ,@PayableAmount)


INSERT INTO [dbo].[Ymt_TradingItem]
           ([sId]
           ,[iTradingId]
           ,[iTradingType]
           ,[iOrderId]
           ,[iTradingResult]
           ,[dAddTime]
           ,[dUpdateTime])
SELECT NEWID(),@NewTradingId,0,iOrderId,0,@Now,@Now FROM Ymt_TradingItem (NOLOCK) WHERE iTradingId=@Tradingid

SELECT @NewTradingId AS NewTradingId