CREATE VIEW dbo.View_ProductRecentSellNum
AS
SELECT     oi.sProductId, SUM(oi.iAmount) AS sellnum
FROM         dbo.Ymt_OrderInfo AS oi INNER JOIN
                      dbo.Ymt_Orders AS o ON o.iOrderId = oi.iOrderId
WHERE     (o.iTradingStatus NOT IN (1, 12, 13, 18)) AND (DATEDIFF(month, o.dAddTime, GETDATE()) <= 2)
GROUP BY oi.sProductId
