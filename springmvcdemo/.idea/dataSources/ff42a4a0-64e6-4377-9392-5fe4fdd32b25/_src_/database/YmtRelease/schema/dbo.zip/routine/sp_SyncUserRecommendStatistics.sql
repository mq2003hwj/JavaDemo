-- =============================================
-- Author:		adu
-- Create date: 2015-06-11
-- Description:	同步用户推荐统计数
-- =============================================
CREATE PROCEDURE [dbo].[sp_SyncUserRecommendStatistics]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	 
    --统计有户推荐数
    SELECT r.iRecommenderId AS iUserId,r.sRecommenderUserName AS sUserName,COUNT(r.iActivityRecordId) AS iRecommendCount 
	INTO #temp1 
	FROM dbo.Ymt_UserRecommendActivityRecord r	
	GROUP BY r.iRecommenderId,r.sRecommenderUserName

	--SELECT * FROM #temp1
	--DROP TABLE #temp1
	--更新用户推荐中已经存在的用户推荐统计数
	UPDATE dbo.Ymt_UserRecommendStatistics SET iRecommendCount=#temp1.iRecommendCount,dUpdateTime=GETDATE()
	FROM #temp1 WHERE #temp1.iUserId=Ymt_UserRecommendStatistics.iUserId

	--找出临时表中有但在统计表中没有统计记录插入表中
	INSERT Ymt_UserRecommendStatistics
	(
		iUserId,
		sUserName,
		iRecommendCount,
		dAddTime,
		dUpdateTime
	)
	SELECT iUserId,sUserName,iRecommendCount,GETDATE() AS dAddTime,GETDATE() AS dUpdateTime 
	FROM #temp1
	WHERE iUserId NOT IN (SELECT iUserId FROM Ymt_UserRecommendStatistics)
END
