




-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-16
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSingleOrderInfo]

@userId int,
@orderId int

AS

--------------process--------------
if @userId = -1 begin
  select @userId = iUserId from ymt_orders(nolock) where iorderid = @orderId
end


select 
     o.[iOrderId]
      ,o.[iUserId]
      ,o.[iBuyerId]
      ,o.[sMarkId]
      ,o.[dAddTime]
      ,o.[fOrderPrice]
      ,o.[fOrderDiscount]
      ,o.[fFreight]
      ,o.[fDiscount]
      ,o.[iTradingId]
      ,o.[iOperate]
      ,o.[dOperateExpireTime]
      ,o.[sAddress]
      ,o.[sPostCode]
      ,o.[sReceivePerson]
      ,o.[sPhone]
      ,o.[sTelephone]
      ,o.[sQQ]
      ,o.[sEmail]
      ,o.[sLeaveWord]
      ,o.[iUnfreezeStatus]
      ,o.[dDispathTime]
      ,o.[iTopicId]
      ,o.[sTitle]
      ,o.[iReplyTopicWhenOrderPaid]
      ,o.[bPaidInFull]
      ,o.[fUseGiftAmount]
      ,o.[sCouponCode]
      ,o.[CouponValue]
      ,o.[iCouponType]
      ,o.[dPaidTime]
      ,o.[dApplyPostPayTime]
      ,o.[dPostPaidTime]
      ,o.[dConfirmedTime]
      ,o.[dChangeAddressTime]
      ,o.[iDistributor]
      ,o.[sThirdOrderId]
      ,o.[iType]
      ,o.[fOldFreight]
      ,o.[dDiscountTime]
      ,o.[fOldDiscount]
      ,o.[fAutoCancelOrderHours]
      ,o.[dCancelTime]
      ,o.[bShangouOrder]
      ,o.[sBuyerLoginId]
      ,o.[sBuyerLoginEmail]
      ,o.[sSellerLoginId]
      ,o.[sSellerLoginEmail]
      ,o.[iIsMerchant]
      ,o.[sBuyerNickName]
      ,o.[fTotalPrice]
      ,o.[fUseFreeCardAmount]
      ,o.[sHostRef]
      ,o.[bIncludeActivityProducts]
      ,o.[bShippedByXlobo]
      ,o.[dAcceptTime]
      ,o.[sCurType]
      ,o.[bCanLocalReturn]
      ,o.[bApplyLocalReturn]
      ,o.[dApplyLocalReturnTime]
      ,o.[iRiskVerifiedStatus]
      ,o.[dLastUpdateTime]
      ,o.[iThirdPartyRefundStatus]
      ,o.[iCouponChannel]
      ,o.[iSalesRefundStatus]
    ,o.[bDomesticDelivered]
      ,case when r.iProcessStatus is null then o.iTradingStatus when r.iProcessStatus = 0 then 3 else o.iTradingStatus end as iTradingStatus
    ,(select top 1 RefundAmount from ymt_refundbill(nolock) where orderid=o.iorderid) as TotalSalesRefundAmount 
    ,(select top 1 sReason from Ymt_OrderReason(nolock) where iOrderId = @orderId) as sReason
from Ymt_Orders(nolock) o
left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId
where o.iOrderId = @orderId and (o.iUserId = @userId or o.iBuyerId = @userId)

if(@@ROWCOUNT = 0)
return;

--print 'ymt_orderext';
select iOrderId,iOrderType,sOrderSource,bIsNeedUploadIdCard,bHaveUploadedIdCard from Ymt_OrderExt(nolock) where iOrderId = @orderId 

--print 'ymt_creditdetail'   
--获取评价列表  
select * from Ymt_CreditDetail(nolock) where stargetid = cast(@orderId as varchar(36))  

--print 'ymt_o_ordernote'
--获取备注列表  
select iOrderId,sContent from Ymt_O_OrderNote(nolock) where iuserid = @userId and iorderid = @orderId 

--print 'ymt_orderstate'
--获取订单金额详情列表  ymt_orderinfo
select * from Ymt_OrderState(nolock) where iorderid = @orderId 

--print 'ymt_orderpostpay'
--获取订单补款列表  
select * from Ymt_OrderPostPay(nolock) where iorderid = @orderId 

--获取订单商品详情列表
--print 'ymt_orderinfo'
select
i.iOrderId,i.sOrderInfoId,i.fOriginalPrice,i.iAmount,i.iBondedArea,i.iCatalogStatus,i.iCatalogType,i.iProductSubCategoryId,i.iSailProtected,i.iType,i.sCatalogId,i.sDescription,i.sPictureUrl,i.sProductId,i.sPropertyInfo,i.sReferenceUrl,i.sSKU,i.sTitle,i.iPriceType,
i.iProductRefundChannel,i.iProductRefundStatus,
e.sOrderInfoId as sOrderInfoExtId,e.bGiftAvail4Reward,e.iActivityId,e.iActivityTemplateId
from Ymt_OrderInfo i(nolock) 
left join Ymt_OrderInfoExt(nolock) e
on i.sOrderInfoId = e.sOrderInfoId
where i.iOrderId = @orderId 

--print 'ymt_ordersummary'
--获取订单物流信息  
select iOrderId, iBillType, sSummary from Ymt_OrderSummary(nolock) where iorderid = @orderId 

--print 'ymt_order_frozen'
--获取订单冻结信息  
select * from Ymt_Order_Frozen(nolock) where  iorderid = @orderId 

if(EXISTS(select top 1 item.iOrderId, item.iTradingId from Ymt_TradingItem(nolock) item join Ymt_TradingInfo(nolock) info on item.iTradingId = info.iTradingId where iorderid = @orderId and info.iTradingStatus = 2))
  begin
    select top 1 item.iOrderId, item.iTradingId
    from Ymt_TradingItem(nolock) item
    join Ymt_TradingInfo(nolock) info
    on   item.iTradingId = info.iTradingId   
    where  iorderid = @orderId 
    and    info.iTradingStatus = 2
  end
else
  begin
    select top 1 iOrderId, iTradingId
    from Ymt_TradingItem(nolock) 
    where  iorderid = @orderId 
    order by dUpdateTime desc
  end

declare @orderToBills table(iOrderId int not null, sBillId varchar(36) not null)

--print 'ymt_ordertobill'
--获取订单账单信息
insert into @orderToBills select iOrderid, sBillId from Ymt_OrderToBill(nolock) where iorderid = @orderId  and iaction >= 0
select iOrderid, sBillId from @orderToBills 

--print 'ymt_bill'
--获取订单账单信息  
select * from Ymt_Bill(nolock) where sbillid in (select sBillId from @orderToBills) and iaction >= 0

