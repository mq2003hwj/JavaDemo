CREATE function [dbo].[Func_GetDefaultYmtArriveTime]
(
    @elment varchar(20), --填充字符串
	@number int --填充元素个数
)
returns varchar(500)
as
begin
    declare @result varchar(500)
	declare @count int
	declare @lastIndex int
	set @count=0
	set @result=''
	set @lastIndex=28-@number
	while(@count<@lastIndex)
	begin
	  set @result=@result+'0'
	  if(@count!=(@lastIndex-1))
	  begin
		set @result=@result+','
	  end
	  set @count=@count+1
	end
	return ltrim(rtrim(@elment+','+@result))
end
