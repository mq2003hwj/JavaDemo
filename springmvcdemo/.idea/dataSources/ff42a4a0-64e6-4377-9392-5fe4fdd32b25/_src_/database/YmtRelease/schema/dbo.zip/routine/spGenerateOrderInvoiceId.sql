



-- =============================================
-- Author:		zhangzhiqiang
-- Create date: 2016-01-08
-- Description:	
-- =============================================
CREATE PROC [dbo].[spGenerateOrderInvoiceId]
	 
AS
BEGIN
	INSERT INTO Ymt_AutoOrderInvoiceIds DEFAULT VALUES
	
	RETURN SCOPE_IDENTITY() + 10000000
END

