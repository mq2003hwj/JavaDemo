
-- =============================================
-- Author:		liuhong
-- Create date: 2015-10-20
-- Description:	作废优惠券
-- =============================================
CREATE PROCEDURE [dbo].[SP_CouponExpire]
@BatchCode VARCHAR(36),
@OutputCode INT OUTPUT,
@OutputMsg NVARCHAR(500) OUTPUT
AS 
BEGIN
	BEGIN TRY
		DECLARE 
		@CouponSettingId INT = 0,
		@TotalCouponNum INT = 0,
		@ReceiveNum INT = 0,
		@ValidStart DATETIME,
		@ValidEnd DATETIME

		SELECT @OutputCode=0,@OutputMsg=N'优惠券作废成功'

		SELECT @TotalCouponNum=iUseTotalCount
			  ,@ReceiveNum=iReceiveCount
			  ,@CouponSettingId=iCouponSettingId
			  ,@ValidStart=dValidStart
			  ,@ValidEnd=dValidEnd
		  FROM dbo.Ymt_CouponSetting WITH (NOLOCK)
		 WHERE iCouponSettingId = (SELECT  iCouponSettingId FROM dbo.Ymt_CouponBatch WITH (NOLOCK) WHERE sBatchCode = @BatchCode)

		--判断批次号是否存在
		IF @TotalCouponNum=0
		BEGIN
			SELECT @OutputCode = -1,@OutputMsg = N'优惠券批次号不存在'
			RETURN;
		END

		--判断该批次是否已经作废
		IF DATEDIFF(DAY,@ValidStart,@ValidEnd) < 0
		BEGIN
			SELECT @OutputCode = -2,@OutputMsg = N'该批次优惠券已作废'
			RETURN;
		END

		--作废优惠券
		--UPDATE dbo.Ymt_CouponSetting SET dValidEnd = DATEADD(DAY,-1,dValidStart)
		--	WHERE iCouponSettingId = @CouponSettingId
		UPDATE Ymt_CouponBatch SET dInvalidTime=GETDATE(),bInvalidStatus=1 WHERE sBatchCode = @BatchCode
		SELECT @TotalCouponNum TotalCouponNum,@ReceiveNum ReceiveNum,@TotalCouponNum - @ReceiveNum AS InvalidNum

	END TRY
    
	BEGIN CATCH
		SELECT @OutputCode=ERROR_NUMBER(),@OutputMsg=ERROR_MESSAGE()
	END CATCH

END
