

CREATE procedure dbo.load_Seller_Growth_Info
as
begin
	set nocount on
	set fmtonly off
	
	declare @startDate date, @endDate date, @theFirstDay date

	select @startDate = GETDATE()-1, @endDate = GETDATE(),@theFirstDay = GETDATE()+1 - DAY(getdate())

	--如果是一个月的第一天，则统计整个上个月的。
	if DAY(getdate()) = 1 
		select @theFirstDay = DATEADD(mm, -1, @theFirstDay)

	if object_id('tempdb..#t') is not null
		drop table #t 

	create table #t
	(
		ID int not null primary key,
		iSellerId int,
		sSellerName nvarchar(50),
		sCategory	nvarchar(20),
		sAM	nvarchar(20),
		sType nvarchar(20),
		iAListing int, --在线商品数
		iNewListingM int, --本月新增商品数
		dGMVM float(18), --本月销售额
		iOrdersM int, --本月订单数
		dPaidGMVM float(18),--本月已付款销售金额
		iPaidOrderM int, --本月已付款订单数
		iNewListingY int, --昨天新增商品数
		dGMVY float(18), --昨天销售额
		iOrdersY int, --昨天订单数
		dPaidGMVY float(18), --昨天付款销售金额
		iPaidOrderY int,--昨天付款订单数
		dGMVM_App float(18), --本月销售额_App
		iOrdersM_App int, --本月订单数_App
		dPaidGMVM_App float(18),--本月已付款销售金额_App
		iPaidOrderM_App int, --本月已付款订单数_App
		dGMVY_App float(18), --昨天销售额_App
		iOrdersY_App int, --昨天订单数_App
		dPaidGMVY_App float(18), --昨天付款销售金额_App
		iPaidOrderY_App int,--昨天付款订单数_App
		sCountry nvarchar(200)--国家
	)

	insert into #t(ID,iSellerId, sCountry, sSellerName, sCategory, sAM, sType)
	values
(1,383835,N'美国纽约州',N'LaLaBaBy',N'母婴保健',N'小米',N'商家'),
(2,380969,N'美国纽约州',N'ladybar',N'母婴保健',N'小米',N'商家'),
(3,376574,N'美国加利福尼亚州',N'加州宝贝',N'母婴保健',N'小米',N'商家'),
(4,421446,N'美国加利福尼亚州',N'MGM美高美',N'母婴保健',N'小米',N'商家'),
(5,393899,N'美国北卡罗来纳州',N'SuperDad',N'母婴保健',N'小米',N'商家'),
(6,436792,N'美国纽约州',N'USA全美购',N'母婴保健',N'小米',N'商家'),
(7,434766,N'美国加利福尼亚州',N'MMI生活馆',N'母婴保健',N'小米',N'商家'),
(8,454808,N'美国纽约州',N'Mayflower',N'母婴保健',N'小米',N'商家'),
(9,488720,N'美国新泽西州',N'环球杂货铺',N'母婴保健',N'小米',N'商家'),
(10,505831,N'美国加利福尼亚州',N'泡芙家',N'母婴保健',N'小米',N'商家'),
(11,524029,N'美国加利福尼亚州',N'加州TTM',N'母婴保健',N'小米',N'商家'),
(12,479601,N'美国马萨诸塞州',N'猫拉拉美国优品生活',N'母婴保健',N'小米',N'商家'),
(13,508726,N'新西兰奥克兰',N'纽澳康源新西兰专营店',N'母婴保健',N'小米',N'商家'),
(14,322365,N'美国加利福尼亚州',N'TiTi干嘛',N'母婴保健',N'小米',N'买手'),
(15,469831,N'美国纽约州',N'anet',N'母婴保健',N'小米',N'买手'),
(16,180177,N'美国北卡罗来纳州',N'tjjtds',N'母婴保健',N'小米',N'买手'),
(17,425854,N'美国纽约州',N'纽约麦克',N'母婴保健',N'小米',N'买手'),
(18,566271,N'德国',N'ginochu8',N'母婴保健',N'小米',N'买手'),
(19,538042,N'澳大利亚',N'澳洲1号海外旗舰店',N'母婴保健',N'小米',N'商家'),
(20,531966,N'德国',N'Babynovo官方旗舰店',N'母婴保健',N'小米',N'商家'),
(21,451893,N'美国加利福尼亚州',N'Hiimart',N'母婴保健',N'小米',N'商家'),
(22,546835,N'美国内华达州',N'Aquasana_USA',N'母婴保健',N'小米',N'商家'),
(23,541019,N'美国亚利桑那州',N'虎猫猫全球精选',N'母婴保健',N'小米',N'商家'),
(24,558443,N'英国',N'cc英国奶粉代购',N'母婴保健',N'小米',N'商家'),
(25,583652,N'美国得克萨斯州',N'常青海外旗舰店',N'母婴保健',N'小米',N'商家'),
(26,566553,N'美国内华达州',N'KNCnaturemade旗舰店',N'母婴保健',N'小米',N'商家'),
(27,540206,N'澳大利亚',N'环球e站海外购',N'母婴保健',N'小米',N'商家'),
(28,574590,N'新西兰奥克兰',N'洋包裹_新西兰',N'母婴保健',N'小米',N'商家'),
(29,446826,N'美国加利福尼亚州',N'Caltrust',N'母婴保健',N'杨英',N'商家'),
(30,451475,N'美国加利福尼亚州',N'Fairy品质生活',N'母婴保健',N'杨英',N'商家'),
(31,433300,N'美国加利福尼亚州',N'farfarawaymarket',N'母婴保健',N'杨英',N'商家'),
(32,455409,N'美国加利福尼亚州',N'至爱母婴生活馆',N'母婴保健',N'杨英',N'商家'),
(33,434293,N'美国纽约州',N'天鹰国际',N'母婴保健',N'杨英',N'商家'),
(34,428939,N'美国 密歇根州',N'聚优生活家',N'母婴保健',N'杨英',N'商家'),
(35,476218,N'美国加利福尼亚州',N'HealthNBeauty',N'母婴保健',N'杨英',N'商家'),
(36,403679,N'美国',N'BabyGarden',N'母婴保健',N'杨英',N'商家'),
(37,457957,N'美国纽约州',N'曼哈顿宝贝',N'母婴保健',N'杨英',N'商家'),
(38,474888,N'美国加利福尼亚州',N'USA全美淘 ',N'母婴保健',N'杨英',N'商家'),
(39,374808,N'美国纽约州',N'小文文妈妈',N'母婴保健',N'杨英',N'买手'),
(40,14806,N'美国科罗拉多州',N'小木头妈妈',N'母婴保健',N'杨英',N'买手'),
(41,278179,N'美国纽约州',N'小蜜蜂姐妹',N'母婴保健',N'杨英',N'买手'),
(42,416876,N'美国康涅狄格州',N'康涅狄格的小窝',N'母婴保健',N'杨英',N'买手'),
(43,410024,N'美国加利福尼亚州',N'安琪代购',N'母婴保健',N'杨英',N'买手'),
(44,24615,N'美国加利福尼亚州',N'美国直通车',N'母婴保健',N'杨英',N'买手'),
(45,393053,N'美国得克萨斯州',N'美丽佳人淘22',N'母婴保健',N'杨英',N'买手'),
(46,411078,N'美国加利福尼亚州',N'fairywudi',N'母婴保健',N'杨英',N'买手'),
(47,464507,N'美国纽约州',N'GreenTree',N'母婴保健',N'杨英',N'商家'),
(48,539649,N'德国',N'superde',N'母婴保健',N'杨英',N'商家'),
(49,539416,N'澳大利亚',N'树熊屋',N'母婴保健',N'杨英',N'商家'),
(50,567927,N'德国',N'易为诚品',N'母婴保健',N'杨英',N'商家'),
(51,581956,N'澳大利亚',N'大叔小孩儿',N'母婴保健',N'杨英',N'商家'),
(52,570914,N'澳大利亚',N'KIKI澳洲海淘旗舰店',N'母婴保健',N'杨英',N'商家'),
(53,552846,N'澳大利亚',N'海淘e站',N'母婴保健',N'杨英',N'商家'),
(54,579040,N'澳大利亚',N'DrCan康博士',N'母婴保健',N'杨英',N'商家'),
(55,578357,N'新西兰',N'Kiwi购',N'母婴保健',N'杨英',N'商家'),
(56,607735,N'澳大利亚',N'澳索美海外旗舰店',N'母婴保健',N'杨英',N'商家'),
(57,440983,N'美国新泽西州',N'FASHION',N'时尚',N'Helen',N'商家'),
(58,414660,N'美国马里兰州',N'E购美东',N'时尚',N'Helen',N'商家'),
(59,455515,N'美国加利福尼亚州',N'1号公路',N'时尚',N'Helen',N'商家'),
(60,437444,N'美国加利福尼亚州',N'依美尚品',N'时尚',N'Helen',N'商家'),
(61,446886,N'美国加利福尼亚州',N'哆啦USA梦',N'时尚',N'Helen',N'商家'),
(62,439276,N'美国加利福尼亚州',N'美东美西',N'时尚',N'Helen',N'商家'),
(63,455220,N'美国伊利诺斯州',N'美米卉旗舰店',N'时尚',N'Helen',N'商家'),
(64,369157,N'美国北卡罗来纳州',N'UBeauty',N'时尚',N'Helen',N'商家'),
(65,494697,N'美国加利福尼亚州',N'美晰BOX',N'时尚',N'Helen',N'买手'),
(66,443006,N'美国佛罗里达州',N'美国E购',N'时尚',N'Helen',N'买手'),
(67,3975,N'美国马萨诸塞州',N'ozyman',N'时尚',N'Helen',N'买手'),
(68,568334,N'美国加利福尼亚州',N'maomaozai',N'时尚',N'Helen',N'商家'),
(69,563171,N'美国得克萨斯州',N'茜品国际海外购',N'时尚',N'Helen',N'商家'),
(70,563601,N'美国北卡罗来纳州',N'71217总店',N'时尚',N'Helen',N'商家'),
(71,372155,N'美国加利福尼亚州',N'cocona',N'时尚',N'Helen',N'买手'),
(72,568115,N'美国新罕布什尔州',N'cherry北美购',N'时尚',N'Helen',N'买手'),
(73,314622,N'美国纽约州',N'zoey1010',N'时尚',N'Helen',N'买手'),
(74,441917,N'美国加利福尼亚州',N'danadana',N'时尚',N'Helen',N'买手'),
(75,378110,N'美国纽约州',N'xj19848790',N'时尚',N'Helen',N'买手'),
(76,453258,N'美国加利福尼亚州',N'SherryLike全球购',N'时尚',N'Pearl',N'商家'),
(77,437607,N'美国加利福尼亚州',N'琥珀小馆',N'时尚',N'Pearl',N'商家'),
(78,408823,N'美国得克萨斯州',N'优美生活',N'时尚',N'Pearl',N'商家'),
(79,404198,N'美国',N'USA小妖鞋店',N'时尚',N'Pearl',N'商家'),
(80,403672,N'美国',N'FriendsCircle',N'时尚',N'Pearl',N'商家'),
(81,449390,N'美国康涅狄格州',N'奶牛萌萌',N'时尚',N'Pearl',N'商家'),
(82,4733,N'美国马萨诸塞州',N'BostonExpress',N'时尚',N'Pearl',N'买手'),
(83,358355,N'美国佛罗里达州',N'cyber',N'时尚',N'Pearl',N'买手'),
(84,477980,N'美国科罗拉多州',N'sister美国购',N'时尚',N'Pearl',N'商家'),
(85,334123,N'美国加利福尼亚州',N'游走洛杉矶',N'时尚',N'Pearl',N'买手'),
(86,2003,N'美国加利福尼亚州',N'lovechloe',N'时尚',N'Pearl',N'买手'),
(87,579027,N'英国',N'欧意海外旗舰店',N'母婴保健',N'Pearl',N'商家'),
(88,579821,N'英国',N'欧淘国际',N'时尚',N'Pearl',N'商家'),
(89,584957,N'美国加利福尼亚州',N'洋精灵',N'母婴保健',N'pearl',N'商家'),
(90,591566,N'日本',N'mrzx12345',N'母婴保健',N'麦子',N'商家'),
(91,513749,N'韩国首尔',N'vickyrong',N'母婴保健',N'PF',N'买手'),
(92,530423,N'韩国首尔',N'浣熊正品韩国代购',N'母婴保健',N'PF',N'买手'),
(93,489080,N'英国伯明翰',N'Twinklelands',N'母婴保健',N'PF',N'买手'),
(94,466910,N'英国纽卡斯尔',N'elvauk',N'时尚',N'PF',N'买手'),
(95,481896,N'日本名古屋市',N'名古屋的妞 ',N'时尚',N'PF',N'买手'),
(96,534871,N'德国',N'欧洲有机达人 ',N'时尚',N'Pearl',N'商家'),
(97,574544,N'德国',N'洋包裹_德国',N'母婴保健',N'小米',N'商家'),
(98,628208,N'日本',N'可淘乐',N'母婴保健',N'小米',N'商家'),
(99,614719,N'英国',N'洋精灵英伦旗舰店',N'时尚',N'Pearl',N'商家'),
(100,638030,N'日本东京',N'一本堂',N'母婴保健',N'麦子',N'商家'),
(101,683580,N'日本东京',N'33号农场',N'母婴保健',N'麦子',N'商家')


	--采集数据的当日0时的在线商品数
	update #t 
	set	iAListing = Number 
	from #t 
	inner join
	(
		select	#t.iSellerId, COUNT(0) Number
		from #t 
		inner join Ymt_Products YP with(nolock)
		on	#t.iSellerId = YP.iUserId 
		where	YP.iAction = 0
		and		YP.dAddTime <= @endDate
		and		YP.validEnd >= @endDate 
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 

	--本月新增商品数
	update #t 
	set	iNewListingM = Number 
	from #t 
	inner join
	(
		select #t.iSellerId, COUNT(0) Number
		from #t 
		inner join Ymt_Products YP with(nolock)
		on #t.iSellerId = YP.iUserId 
		where	YP.dAddTime >= @theFirstDay
		and		YP.dAddTime < @endDate 
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 

	--本月销售额, 本月订单数
	update #t 
	set	dGMVM = total, iOrdersM =iOrdersNumber
	from #t 
	inner join
	(
		select #t.iSellerId, total = 
			SUM(YO.fOrderPrice),
			COUNT(0) iOrdersNumber
		from #t 
		inner join Ymt_Orders YO with(nolock)
		on #t.iSellerId = YO.iBuyerId 
		where	YO.bShangouOrder = 0
		and		YO.dAddTime >= @theFirstDay
		and		YO.dAddTime < @endDate
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 
	
	--update #t 
	--set	dGMVM = total, iOrdersM =iOrdersNumber
	--from #t 
	--inner join
	--(
	--	select #t.iSellerId, total = 
	--		SUM(case YO.bShangouOrder when 0 then YO.fOrderPrice when 1 then YO.fTotalPrice end),
	--		COUNT(0) iOrdersNumber
	--	from #t 
	--	inner join Ymt_Orders YO with(nolock)
	--	on #t.iSellerId = YO.iBuyerId 
	--	where YO.dAddTime >= @theFirstDay
	--	and	 YO.dAddTime < @endDate
	--	group by #t.iSellerId 
	--) AA
	--on #t.iSellerId = AA.iSellerId 

	--本月已付款销售金额, 本月已付款订单数
	update #t 
	set	dPaidGMVM = total, iPaidOrderM = iOrders
	from #t 
	inner join
	(
		select	#t.iSellerId, 
				Total =  SUM(YO.fOrderPrice), --sum(fPaidAmountOfCash + fPaidAmountOfGift + fPostPaidAmountOfCash + fPostPaidAmountOfGift + fPaidAmountOfCoupon + fPostPadiAmountOfCoupon),
				iOrders=COUNT(0)
		from #t 
		inner join Ymt_Orders YO with(nolock)
		on #t.iSellerId = YO.iBuyerId 
		--inner join Ymt_OrderState YOS with(nolock)
		--on	YO.iOrderId = YOS.iOrderId 
		where	YO.bShangouOrder =0
		and		YO.iTradingStatus in (2,3,4,16,17)
		and		YO.dAddTime >= @theFirstDay
		and	 YO.dAddTime < @endDate
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 	

	--昨天新增商品数
	update #t 
	set	iNewListingY = Number 
	from #t 
	inner join
	(
		select #t.iSellerId, COUNT(0) Number
		from #t 
		inner join Ymt_Products YP with(nolock)
		on #t.iSellerId = YP.iUserId 
		where	YP.dAddTime >= @startDate 
		and		YP.dAddTime < @endDate 
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 	

	--昨天销售额, 昨天订单数
	update #t 
	set	dGMVY = total, iOrdersY =iOrdersNumber
	from #t 
	inner join
	(
		select #t.iSellerId, total = 
			SUM(YO.fOrderPrice),
			COUNT(0) iOrdersNumber
		from #t 
		inner join Ymt_Orders YO with(nolock)
		on #t.iSellerId = YO.iBuyerId 
		where	YO.bShangouOrder = 0
		and		YO.dAddTime >= @startDate 
		and		YO.dAddTime < @endDate
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 

	--昨天付款销售金额, 昨天付款订单数
	update #t 
	set	dPaidGMVY = total, iPaidOrderY = iOrders
	from #t 
	inner join
	(
		select	#t.iSellerId, 
				Total = SUM(YO.fOrderPrice),--sum(fPaidAmountOfCash + fPaidAmountOfGift + fPostPaidAmountOfCash + fPostPaidAmountOfGift + fPaidAmountOfCoupon + fPostPadiAmountOfCoupon),
				iOrders=COUNT(0)
		from #t 
		inner join Ymt_Orders YO with(nolock)
		on #t.iSellerId = YO.iBuyerId 
		where	YO.bShangouOrder = 0
		and		YO.iTradingStatus in (2,3,4,16,17)
		and		YO.dAddTime >= @startDate 
		and		YO.dAddTime < @endDate
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 		
	
	--本月销售额(App), 本月订单数(App)
	update #t 
	set	dGMVM_App = total, iOrdersM_App = iOrdersNumber
	from #t 
	inner join
	(
		select #t.iSellerId, total = 
			SUM(YO.fTotalPrice),
			COUNT(0) iOrdersNumber
		from #t 
		inner join Ymt_Orders YO with(nolock)
		on #t.iSellerId = YO.iBuyerId 
		where	YO.bShangouOrder = 1
		and		YO.dAddTime >= @theFirstDay
		and		YO.dAddTime < @endDate
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 
	
	
	--本月已付款销售金额(App), 本月已付款订单数(App)
	update #t 
	set	dPaidGMVM_App = total, iPaidOrderM_App = iOrders
	from #t 
	inner join
	(
		select	#t.iSellerId, 
				Total =  SUM(YO.fTotalPrice), 
				iOrders=COUNT(0)
		from #t 
		inner join Ymt_Orders YO with(nolock)
		on #t.iSellerId = YO.iBuyerId 
		where	YO.bShangouOrder = 1
		and		YO.iTradingStatus in (2,3,4,16,17)
		and		YO.dAddTime >= @theFirstDay
		and	 YO.dAddTime < @endDate
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 	

	--昨天销售额(App), 昨天订单数(App)
	update #t 
	set	dGMVY_App = total, iOrdersY_App = iOrdersNumber
	from #t 
	inner join
	(
		select #t.iSellerId, total = 
			SUM(YO.fTotalPrice),
			COUNT(0) iOrdersNumber
		from #t 
		inner join Ymt_Orders YO with(nolock)
		on #t.iSellerId = YO.iBuyerId 
		where	YO.bShangouOrder = 1
		and		YO.dAddTime >= @startDate 
		and		YO.dAddTime < @endDate
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 

	--昨天付款销售金额(App), 昨天付款订单数(App)
	update #t 
	set	dPaidGMVY_App = total, iPaidOrderY_App = iOrders
	from #t 
	inner join
	(
		select	#t.iSellerId, 
				Total = SUM(YO.fTotalPrice),
				iOrders=COUNT(0)
		from #t 
		inner join Ymt_Orders YO with(nolock)
		on #t.iSellerId = YO.iBuyerId 
		where	YO.bShangouOrder = 1
		and		YO.iTradingStatus in (2,3,4,16,17)
		and		YO.dAddTime >= @startDate 
		and		YO.dAddTime < @endDate
		group by #t.iSellerId 
	) AA
	on #t.iSellerId = AA.iSellerId 	
	
	
	
	select * from #t 	
	drop table #t 
end

