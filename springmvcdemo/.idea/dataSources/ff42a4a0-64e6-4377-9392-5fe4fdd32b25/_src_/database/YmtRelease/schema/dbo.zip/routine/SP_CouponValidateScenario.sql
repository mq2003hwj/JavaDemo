
-- =============================================
-- Author:		ZHUJINFENG
-- Create date: 2015-01-22
-- Description:	取优惠券使用场景，用于验证单个优惠券可用性。
-- =============================================
CREATE PROCEDURE [dbo].[SP_CouponValidateScenario]
	@CouponCode VARCHAR(36), -- 优惠券号
	@BuyerUserId INT		 -- 使用优惠券的买家用户编号
AS
BEGIN
	
	SET NOCOUNT ON;
	DECLARE @CouponType INT;

	SET @CouponType = (SELECT iCouponType FROM dbo.Ymt_Coupon WHERE sCouponCode = @CouponCode);
	IF(@CouponType = 1)
	BEGIN 

		SELECT a.sCouponCode, b.sBatchCode,  a.iCouponType, dbo.FUNC_MargeCouponValue(a.iCouponSetting) AS CouponValue, c.iCouponUseType, c.iMaxUseTime, a.dValidStart, a.dValidEnd, 
			ISNULL(f.iCouponUsedCount,1) AS iCouponUsedCount, e.iUserType,
			e.sSellerIds, e.sLogisticsTypes, e.sStockStatus, e.sProductCategories, e.sSpecificProducts, e.sProductBrands, e.sActivityIds, e.sUserLevels, e.sUsePlatforms
			,c.iCouponUseCount,c.iMaxUseTimePerUser,c.bIsMobileVerify,b.iBatchCreateType
		FROM Ymt_Coupon a WITH(NOLOCK) 
			LEFT JOIN Ymt_CouponBatch b WITH(NOLOCK) ON a.iBatchId = b.iBatchId
			LEFT JOIN Ymt_CouponSetting c WITH(NOLOCK) ON a.iCouponSetting = c.iCouponSettingId			
			LEFT JOIN Ymt_CouponScenario e WITH(NOLOCK) ON c.iScenarioId = e.iCouponScenarioId
			LEFT JOIN Ymt_CouponPublicUsed f WITH(NOLOCK) ON a.sCouponCode = f.sCouponCode AND f.iUserId = @BuyerUserId
		WHERE a.sCouponCode = @CouponCode 

	END
	ELSE
	BEGIN
		
		SELECT a.sCouponCode, b.sBatchCode, a.iCouponType, dbo.FUNC_MargeCouponValue(a.iCouponSetting) AS CouponValue, c.iCouponUseType, c.iMaxUseTime, a.dValidStart, a.dValidEnd, f.iCouponUsedCount, e.iUserType, 
			e.sSellerIds, e.sLogisticsTypes, e.sStockStatus, e.sProductCategories, e.sSpecificProducts, e.sProductBrands, e.sActivityIds, e.sUserLevels, e.sUsePlatforms
			,c.iCouponUseCount,c.iMaxUseTimePerUser,c.bIsMobileVerify,b.iBatchCreateType
		FROM Ymt_Coupon a WITH(NOLOCK) 
			LEFT JOIN Ymt_CouponBatch b WITH(NOLOCK) ON a.iBatchId = b.iBatchId
			LEFT JOIN Ymt_CouponSetting c WITH(NOLOCK) ON a.iCouponSetting = c.iCouponSettingId
			LEFT JOIN Ymt_CouponScenario e WITH(NOLOCK) ON c.iScenarioId = e.iCouponScenarioId
			LEFT JOIN Ymt_CouponPrivateUserBound f WITH(NOLOCK) ON a.sCouponCode = f.sCouponCode AND f.iUserId = @BuyerUserId
		WHERE a.sCouponCode = @CouponCode 

	END    
END

