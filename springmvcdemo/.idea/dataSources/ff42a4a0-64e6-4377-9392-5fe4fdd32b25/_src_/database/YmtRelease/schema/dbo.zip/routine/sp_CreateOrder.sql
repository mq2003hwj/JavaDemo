
-- =============================================            
-- Author:  zhangzhiqiang        
-- Create date: 2015-8-7
-- Description: 创建订单(M2C)       
-- =============================================     

CREATE PROC [dbo].[sp_CreateOrder]
	@UserId int,
	@OrderType int,
	@OrderSource varchar(128),
	@OrderSourceIP varchar(128),
	@TerminalSource varchar(128),
	@AppTerminalSource varchar(128),
	@DeviceId  varchar(200)=null,
	@OrdersXml xml,
	@OrderInfosXml xml
AS

declare @OrderId int
		,@Id int
		,@SubId int
		,@PaidInFull bit
		,@IsNeedUploadIdCard bit
		,@SellerId int
		,@Address varchar(1000)
		,@PostCode varchar(10)
		,@ReceivePerson varchar(50)
		,@Phone varchar(20)
		,@Telephone varchar(20)
		,@Freight decimal(18,2)
		,@LeaveWord varchar(2000)
		,@AutoCancelOrderHours decimal(18,2)
		,@IncludeActivityProducts bit
		,@CurType varchar(50)
		,@OrderPrice decimal(18,2)
		,@UseGiftAmount decimal(18,2)
		,@UseFreeCardAmount decimal(18,2)
		,@CommissionFee decimal(18,2)
		,@QQ varchar(20)
		,@Email varchar(500)
		,@CouponCode varchar(36)
		,@CouponValue decimal(18,2)
		,@CouponType int
		,@ShangouOrder bit
		,@BuyerLoginId nvarchar(200)
		,@BuyerLoginEmail nvarchar(200)
		,@SellerLoginId nvarchar(200)
		,@SellerLoginEmail nvarchar(200)
		,@SellerType int
		,@IsMerchant int = 0  --0：非商家
		,@BuyerNickName nvarchar(200)
		,@CanLocalReturn bit

		,@OrderInfoId varchar(36)
		,@PriceType int
		,@ProductNum int
		,@PropetyInfo varchar(2000)
		,@ProductPrice decimal(18,2)
		,@TotalPrice decimal(18,2)
		,@PictureUrl varchar(1000)
		,@ProductName varchar(500)
		,@SailProtected int
		,@CatalogId varchar(36)
		,@CatalogStatus int
		,@CatalogType int
		,@SKU varchar(300)
		,@ProductId varchar(36)
		,@MainCategoryId int
		,@SubCategoryId int
		,@ThirdCategoryId int
		,@ProductBrandId int
		,@BondedArea int
		,@ProductCode varchar(50)
		,@Flight decimal(18,2)
		,@TariffType int
		,@IncludeActivity int
		,@CouponAvail4OrderDeduct bit
		,@GiftAvail4Reward bit
		,@ActivityId int
		,@ActivityTemplateId int
		,@PromotionType int
		,@Promotion decimal(18,2)
		,@CommissionRate decimal(18,2)
		,@Premium decimal(18,2)
		,@IsCost bit
		,@GiftAvail4OrderDeduct bit
		,@FeeFree bit
		,@Only4Vip bit
		,@Now datetime = getdate()

SELECT item.value('Id[1]','INT') AS Id
	,item.value('PaidInFull[1]','bit') AS PaidInFull
	,item.value('IsNeedUploadIdCard[1]','bit') AS IsNeedUploadIdCard
	,item.value('SellerId[1]','int') AS SellerId
	,item.value('Address[1]','varchar(1000)') AS [Address]
	,item.value('PostCode[1]','varchar(10)') AS PostCode
	,item.value('Phone[1]','varchar(20)') AS Phone
	,item.value('ReceivePerson[1]','varchar(50)') AS ReceivePerson
	,item.value('Telephone[1]','varchar(20)') AS Telephone
	,item.value('Freight[1]','decimal(18,2)') AS Freight
	,item.value('LeaveWord[1]','varchar(2000)') AS LeaveWord
	,item.value('AutoCancelOrderHours[1]','decimal(18,2)') AS AutoCancelOrderHours
	,item.value('IncludeActivityProducts[1]','bit') AS IncludeActivityProducts
	,item.value('CurType[1]','varchar(50)') AS CurType
	,item.value('OrderPrice[1]','decimal(18,2)') AS OrderPrice
	,item.value('UseGiftAmount[1]','decimal(18,2)') AS UseGiftAmount
	,item.value('UseFreeCardAmount[1]','decimal(18,2)') AS UseFreeCardAmount
	,item.value('CommissionFee[1]','decimal(18,2)') AS CommissionFee
	,item.value('CouponCode[1]','varchar(36)') AS CouponCode
	,item.value('CouponValue[1]','decimal(18,2)') AS CouponValue
	,item.value('CouponType[1]','int') AS CouponType
	,item.value('ShangouOrder[1]','bit') AS ShangouOrder
	,item.value('CanLocalReturn[1]','bit') AS CanLocalReturn
INTO #TempOrders
FROM  @OrdersXml.nodes('/Orders/Order') T (item)

SELECT item.value('Id[1]','int') AS Id
	,item.value('SubId[1]','int') AS SubId
	,item.value('PriceType[1]','int') AS PriceType
	,item.value('ProductNum[1]','int') AS ProductNum
	,item.value('PropetyInfo[1]','varchar(2000)') AS PropetyInfo
	,item.value('ProductPrice[1]','decimal(18,2)') AS ProductPrice
	,item.value('TotalPrice[1]','decimal(18,2)') AS TotalPrice
	,item.value('PictureUrl[1]','varchar(1000)') AS PictureUrl
	,item.value('ProductName[1]','varchar(500)') AS ProductName
	,item.value('SailProtected[1]','int') AS SailProtected
	,item.value('CatalogId[1]','varchar(36)') AS CatalogId
	,item.value('CatalogStatus[1]','int') AS CatalogStatus
	,item.value('CatalogType[1]','int') AS CatalogType
	,item.value('SKU[1]','varchar(300)') AS SKU
	,item.value('ProductId[1]','varchar(36)') AS ProductId
	,item.value('MainCategoryId[1]','int') AS MainCategoryId
	,item.value('SubCategoryId[1]','int') AS SubCategoryId
	,item.value('ThirdCategoryId[1]','int') AS ThirdCategoryId
	,item.value('ProductBrandId[1]','int') AS ProductBrandId
	,item.value('BondedArea[1]','int') AS BondedArea
	,item.value('ProductCode[1]','varchar(50)') AS ProductCode
	,item.value('Flight[1]','decimal(18,2)') AS Flight
	,item.value('TariffType[1]','int') AS TariffType
	,item.value('IncludeActivity[1]','bit') AS IncludeActivity
	,item.value('CouponAvail4OrderDeduct[1]','bit') AS CouponAvail4OrderDeduct
	,item.value('GiftAvail4Reward[1]','bit') AS GiftAvail4Reward
	,item.value('ActivityId[1]','int') AS ActivityId
	,item.value('ActivityTemplateId[1]','int') AS ActivityTemplateId
	,item.value('PromotionType[1]','int') AS PromotionType
	,item.value('Promotion[1]','decimal(18,2)') AS Promotion
	,item.value('CommissionRate[1]','decimal(18,2)') AS CommissionRate
	,item.value('Premium[1]','decimal(18,2)') AS Premium
	,item.value('IsCost[1]','bit') AS IsCost
	,item.value('GiftAvail4OrderDeduct[1]','bit') AS GiftAvail4OrderDeduct
	,item.value('FeeFree[1]','bit') AS FeeFree
	,item.value('Only4Vip[1]','bit') AS Only4Vip
INTO #TempOrderInfos
FROM @OrderInfosXml.nodes('/OrderInfos/OrderInfo') T (item)

CREATE TABLE #RetOrders (
	[index] int
	,iOrderId int
	,iBuyerId int
	,sCouponCode varchar(36)
	,iCouponType int
	,fUseGiftAmount decimal(18,2)
	,fUseFreeCardAmount decimal(18,2)
	,fAutoCancelOrderHours decimal(18,2)
	,fOrderPrice decimal(18,2))

WHILE EXISTS(SELECT 1 FROM #TempOrders)
BEGIN
	--生成新订单号
	EXEC @OrderId = spGenerateOrderId 

	SELECT TOP 1 @Id=Id,@PaidInFull=PaidInFull,@IsNeedUploadIdCard=IsNeedUploadIdCard,@SellerId=SellerId,@Address=[Address],@PostCode=PostCode
		,@Phone=Phone,@ReceivePerson=ReceivePerson,@Telephone=Telephone,@Freight=Freight,@LeaveWord=LeaveWord,@UseGiftAmount=UseGiftAmount
		,@IncludeActivityProducts=IncludeActivityProducts,@CurType=CurType,@OrderPrice=OrderPrice,@AutoCancelOrderHours=AutoCancelOrderHours
		,@UseFreeCardAmount=UseFreeCardAmount,@CommissionFee=CommissionFee,@CouponCode=CouponCode,@CouponValue=CouponValue,@CouponType=CouponType
		,@ShangouOrder=ShangouOrder,@CanLocalReturn=CanLocalReturn
	FROM #TempOrders

	SELECT @QQ=sQQ,@Email=sLoginEmail,@BuyerLoginId=sLoginId,@BuyerLoginEmail=sLoginEmail,@BuyerNickName=sNickName
	FROM Ymt_Users WITH(NOLOCK) WHERE iUserId = @UserId

	SELECT @SellerLoginId=sLoginId,@SellerLoginEmail=sLoginEmail,@SellerType=iType
	FROM Ymt_Users WITH(NOLOCK) WHERE iUserId = @SellerId

	--验证此卖家是否是商家
	IF @SellerType=1 AND EXISTS(SELECT 1 FROM Ymt_SellerInfo WITH(NOLOCK) WHERE iUserId=@SellerId AND mshop = 1)
	BEGIN
		SET @IsMerchant = 1
	END

	--插入订单数据Ymt_Orders
	INSERT INTO [Ymt_Orders]
           ([iOrderId],[iUserId],[iBuyerId],[sMarkId],[dAddTime],[fOrderPrice],[fOrderDiscount] ,[fFreight],[fDiscount],[iTradingStatus] ,[sAddress],[sPostCode]
           ,[sReceivePerson],[sPhone],[sTelephone],[sQQ],[sEmail] ,[sLeaveWord],[iUnfreezeStatus],[bPaidInFull],[fUseGiftAmount],[sCouponCode],[CouponValue]
           ,[iCouponType],[iDistributor],[fAutoCancelOrderHours],[bShangouOrder],[sBuyerLoginId],[sBuyerLoginEmail],[sSellerLoginId],[sSellerLoginEmail]
           ,[iIsMerchant],[sBuyerNickName],[fTotalPrice],[fUseFreeCardAmount],[bIncludeActivityProducts],[sCurType],[bCanLocalReturn])
     VALUES
           (@OrderId,@UserId,@SellerId,'',@Now,@OrderPrice,0,@Freight,0,1,@Address,@PostCode,@ReceivePerson,@Phone,@Telephone,@QQ,@Email,@LeaveWord,0,@PaidInFull
           ,@UseGiftAmount,@CouponCode,@CouponValue,@CouponType,1,@AutoCancelOrderHours,@ShangouOrder,@BuyerLoginId,@BuyerLoginEmail,@SellerLoginId
           ,@SellerLoginEmail,@IsMerchant,@BuyerNickName,@OrderPrice,@UseFreeCardAmount,@IncludeActivityProducts,@CurType,@CanLocalReturn)
	
	--插入订单资金数据Ymt_OrderState
	IF @CouponValue IS NULL OR (@CouponType IS NOT NULL AND @CouponType <> 1)
	BEGIN
		SET @CouponValue = 0
	END
	INSERT INTO [Ymt_OrderState]
           ([iOrderId],[fRefundedAmountOfCash],[fRefundedAmountOfGift],[fPaidAmountOfCash],[fPaidAmountOfGift],[fPostPaidAmountOfCash],[fPostPaidAmountOfGift]
           ,[fPaidAmountOfCoupon],[fRefundedAmountOfCoupon],[fPostPadiAmountOfCoupon],[fQuickTurnoverAmount],[fCommissionFee],[fNeedCommissionFee]
           ,[fPaidAmountOfFreeCard],[fBalanceAmount])
     VALUES
           (@OrderId, 0, 0, 0, @UseGiftAmount, 0, 0, @CouponValue, 0, 0, 0, 0, @CommissionFee, @UseFreeCardAmount, 0)
	
	--插入订单扩展信息Ymt_OrderExt
	INSERT INTO [Ymt_OrderExt]
           ([iOrderId],[sOrderSource],[sOrderSourceIP],[iOrderType],[sTerminalSource],[bIsNeedUploadIdCard],[sAppTerminalSource],[sDeviceId])
    VALUES
           (@OrderId,@OrderSource,@OrderSourceIP,@OrderType,@TerminalSource,@IsNeedUploadIdCard,@AppTerminalSource,@DeviceId)

	SELECT * INTO #OrderInfoList 
	FROM #TempOrderInfos WHERE Id = @Id

	WHILE EXISTS(SELECT 1 FROM #OrderInfoList)
	BEGIN
		SET @OrderInfoId = newid()

		SELECT TOP 1 @PriceType=PriceType,@CatalogId=CatalogId,@PropetyInfo=PropetyInfo,@ProductName=ProductName,@PictureUrl=PictureUrl
			,@ProductPrice=ProductPrice,@ProductNum=ProductNum,@TotalPrice=TotalPrice,@SailProtected=SailProtected,@SKU=SKU
			,@CatalogType=CatalogType,@CatalogStatus=CatalogStatus,@ProductId=ProductId,@MainCategoryId=MainCategoryId
			,@SubCategoryId=SubCategoryId,@ThirdCategoryId=ThirdCategoryId,@ProductBrandId=ProductBrandId,@BondedArea=BondedArea
			,@ProductCode=ProductCode,@TariffType=TariffType,@Flight=Flight,@IncludeActivity=IncludeActivity,@ActivityId=ActivityId
			,@ActivityTemplateId=ActivityTemplateId,@PromotionType=PromotionType,@Promotion=Promotion,@GiftAvail4Reward=GiftAvail4Reward
			,@GiftAvail4OrderDeduct=GiftAvail4OrderDeduct,@CouponAvail4OrderDeduct=CouponAvail4OrderDeduct,@Only4VIP=Only4VIP
			,@FeeFree=FeeFree,@CommissionRate=CommissionRate,@Premium=Premium,@IsCost=IsCost,@SubId=SubId
		FROM #OrderInfoList

		--插入订单商品信息Ymt_OrderInfo
		INSERT INTO [Ymt_OrderInfo]
			   ([sOrderInfoId],[iOrderId],[iType],[sCatalogId],[sPropertyInfo],[sTitle],[sPictureUrl],[fOriginalPrice],[fDiscount],[iAmount]
			   ,[fTotalPrice],[iSailProtected],[sSKU],[iCatalogType],[iCatalogStatus],[sProductId],[iProductMainCategoryId],[iProductSubCategoryId]
			   ,[iProductThirdCategoryId],[iProductBrandId],[iBondedArea],[sProductCode],[iTariffType],[fFlight],[iPriceType])
		 VALUES
			   (@OrderInfoId,@OrderId,0,@CatalogId,@PropetyInfo,@ProductName,@PictureUrl,@ProductPrice,0,@ProductNum,@TotalPrice
			   ,@SailProtected,@SKU,@CatalogType,@CatalogStatus,@ProductId,@MainCategoryId,@SubCategoryId,@ThirdCategoryId,@ProductBrandId
			   ,@BondedArea,@ProductCode,@TariffType,@Flight,@PriceType)

		IF @IncludeActivity = 1  --插入订单商品活动信息Ymt_OrderInfoExt
		BEGIN
			INSERT INTO [Ymt_OrderInfoExt]
				([sOrderInfoId],[iActivityId],[iActivityTemplateId],[iPromotionType],[fPromotion],[bGiftAvail4OrderDeduct]
				,[bGiftAvail4Reward],[bCouponAvail4OrderDeduct],[bOnly4VIP],[bFeeFree],[fCommissionRate],[fPremium],[bIsCost])
			VALUES
				(@OrderInfoId,@ActivityId,@ActivityTemplateId,@PromotionType,@Promotion,@GiftAvail4OrderDeduct,@GiftAvail4Reward
				,@CouponAvail4OrderDeduct,@Only4VIP,@FeeFree,@CommissionRate,@Premium,@IsCost)
		END
		DELETE FROM #OrderInfoList WHERE Id = @Id AND SubId=@SubId
	END

	DELETE FROM #TempOrders WHERE Id = @Id
	DROP TABLE #OrderInfoList

	INSERT INTO #RetOrders([index],iOrderId,iBuyerId,sCouponCode,iCouponType,fUseGiftAmount,fUseFreeCardAmount,fAutoCancelOrderHours,fOrderPrice) 
		VALUES(@Id,@OrderId,@SellerId,@CouponCode,@CouponType,@UseGiftAmount,@UseFreeCardAmount,@AutoCancelOrderHours,@OrderPrice)
END

SELECT * FROM #RetOrders

DROP TABLE #TempOrders
DROP TABLE #TempOrderInfos
DROP TABLE #RetOrders

