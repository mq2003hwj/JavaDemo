create proc proc_insert_all_for_GetPackageDeliveryOrdersCount
as

declare @i int,@orderId numeric,@orderInfoId int,@buyerId int

set @orderId=2000000000
set @orderInfoId = 6000

declare buyercursor cursor 
for  select  distinct  top 200 ibuyerID  from ymt_orders order by ibuyerID asc   --为所获得的数据集指定游标

open buyercursor                   --打开游标
fetch next from buyercursor into @buyerId   --开始抓第一条数据
while(@@fetch_status=0)     --如果数据集里一直有数据
begin
	exec proc_insert_for_GetPackageDeliveryOrdersCount @orderId, @orderInfoId,@buyerId;
	
	set @i = @i + 1
	set @orderId=@orderId+500
	set @orderInfoId = @orderInfoId+500*10

	fetch next from buyercursor into @buyerId     --跳到下一条数据
end
close buyercursor        --关闭游标
deallocate buyercursor --删除游标

