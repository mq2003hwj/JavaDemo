CREATE PROCEDURE [dbo].[GetSellerProducts]
(
	@VerifyTime DATETIME
)
AS

;WITH P AS
(
	SELECT 
	   P.sProductId, 
	   P.sProduct,
		P.dAddTime,
		P.Checker, 
		P.CheckDate,
		P.CheckStatus,
		u.sLoginId,
		C.iCountryId,
		C.sCountryNameZh,
		P.dLastUpdate,
		(SELECT SUM(iNum) FROM Ymt_Catalogs WHERE sProductId = p.sProductId and iAction > -1) AS Num
	FROM Ymt_Users AS U
	INNER JOIN Ymt_Products AS P
		ON U.iUserId = P.iUserId
	INNER JOIN Ymt_SellerInfo AS S
		ON S.iUserId = P.iUserId
	INNER JOIN Ymt_Country AS C
		ON C.iCountryId = S.iLiveCountry
	WHERE P.dAddTime > @VerifyTime
		AND GETDATE() BETWEEN P.validStart AND P.validEnd
		OR
		(P.validStart < GETDATE() AND (P.CheckStatus = 4 OR P.CheckStatus = -1))
)
SELECT 
	sProductId, 
	sProduct,
	dAddTime,
	Checker, 
	CheckDate,
	CheckStatus,
	sLoginId,
	iCountryId,
	sCountryNameZh,
	dLastUpdate
FROM P 
WHERE Num > 0