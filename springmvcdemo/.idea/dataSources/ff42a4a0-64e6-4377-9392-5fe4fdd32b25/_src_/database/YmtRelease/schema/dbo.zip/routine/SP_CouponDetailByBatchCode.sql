
-- =============================================
-- Author:		liuhong
-- Create date: 2015-10-21
-- Description:	根据优惠券批次号查询优惠券详情
-- =============================================
CREATE PROCEDURE [dbo].[SP_CouponDetailByBatchCode]
@BatchCode VARCHAR(36),
@PageSize INT,
@CurPage INT,
@CreateUserId INT,
@TotalCount INT OUTPUT
AS
BEGIN
	
DECLARE
@BatchId INT = 0,
@CouponName NVARCHAR(50)='',
@MaxSendNum INT=0,
@ReceiveNum INT=0,
@UsedNum INT=0,
@CouponUseCount INT=0,
@ValidBegin DATETIME=NULL,
@ValidEnd DATETIME=NULL,
@InvalidTime DATETIME=NULL,
@InvalidStatus BIT = NULL

SELECT  @BatchCode=A.sBatchCode,@BatchId = A.iBatchId,@CouponName = A.sCouponName,
        @MaxSendNum = iCouponTotalNum,@ReceiveNum = B.iReceiveCount,@CouponUseCount=iCouponUseCount,
		@ValidBegin=B.dValidStart,@ValidEnd=b.dValidEnd,@InvalidTime=A.dInvalidTime,@InvalidStatus=A.bInvalidStatus
FROM    dbo.Ymt_CouponBatch A WITH (NOLOCK)
        INNER JOIN dbo.Ymt_CouponSetting B WITH (NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId
WHERE   sBatchCode = @BatchCode AND (A.iOperatorId = @CreateUserId OR ISNULL(@CreateUserId,-1)=-1)

SELECT @UsedNum=SUM(@CouponUseCount - iCouponUsedCount) FROM Ymt_CouponPrivateUserBound WITH(NOLOCK) WHERE iBatchId=@BatchId

DECLARE @tableCouponBatch TABLE (RowNum INT,
								 CouponCode VARCHAR(36),
								 UserId INT,
								 ValidBegin DATETIME,
								 ValidEnd DATETIME,
								 CouponUseCount INT,
								 CouponState INT)

SELECT @BatchCode BatchCode,@CouponName CouponName,@MaxSendNum MaxSendNum,@ReceiveNum ReceiveNum,@UsedNum UsedNum,@ValidBegin ValidBegin,@ValidEnd ValidEnd,@InvalidTime InvalidTime,@InvalidStatus InvalidStatus
SELECT @TotalCount=COUNT(0) FROM dbo.Ymt_CouponPrivateUserBound A WITH(NOLOCK) INNER JOIN dbo.Ymt_Coupon C ON A.sCouponId=C.sCouponId AND C.dValidStart<=dValidEnd WHERE A.iBatchId=@BatchId


--获取分页记录
DECLARE @StartRow INT = (@CurPage - 1) * @PageSize + 1, @EndRow INT = @CurPage * @PageSize
IF @PageSize > 0 AND @CurPage > 0
	--SELECT *,B.sLoginId UserName FROM @tableCouponBatch A INNER JOIN dbo.Ymt_Users B WITH(NOLOCK) ON A.UserId = B.iUserId WHERE RowNum BETWEEN @StartRow AND @EndRow
	INSERT INTO @tableCouponBatch
	SELECT RowNum,CouponCode,UserId,ValidBegin,ValidEnd,CouponUsedCount,CouponState FROM (
	SELECT ROW_NUMBER() OVER(ORDER BY A.dAddTime DESC) RowNum
		  ,A.sCouponCode CouponCode
		  ,A.iUserId UserId
		  ,C.dValidStart ValidBegin 
		  ,C.dValidEnd ValidEnd
		  ,A.iCouponUsedCount CouponUsedCount
		  ,CASE
			WHEN A.iCouponUsedCount>0 AND C.dValidStart<=GETDATE() AND C.dValidEnd>=GETDATE() THEN 1
			WHEN A.iCouponUsedCount>0 AND C.dValidStart>GETDATE() THEN 2
			WHEN A.iCouponUsedCount=0 THEN 3
			WHEN A.iCouponUsedCount>0 AND C.dValidStart<=C.dValidEnd AND C.dValidEnd<GETDATE() THEN 4
		   END CouponState
	  FROM dbo.Ymt_CouponPrivateUserBound A WITH(NOLOCK)
	  INNER JOIN dbo.Ymt_Coupon C ON A.sCouponId=C.sCouponId AND C.dValidStart<=dValidEnd
	 WHERE A.iBatchId=@BatchId) TEMP WHERE RowNum BETWEEN @StartRow AND @EndRow
ELSE
	INSERT INTO @tableCouponBatch
	SELECT ROW_NUMBER() OVER(ORDER BY A.dAddTime DESC) RowNum
		  ,A.sCouponCode CouponCode
		  ,A.iUserId UserId
		  ,C.dValidStart ValidBegin 
		  ,C.dValidEnd ValidEnd
		  ,A.iCouponUsedCount CouponUsedCount
		  ,CASE
			WHEN A.iCouponUsedCount>0 AND C.dValidStart<=GETDATE() AND C.dValidEnd>=GETDATE() THEN 1
			WHEN A.iCouponUsedCount>0 AND C.dValidStart>GETDATE() THEN 2
			WHEN A.iCouponUsedCount=0 THEN 3
			WHEN A.iCouponUsedCount>0 AND C.dValidStart<=C.dValidEnd AND C.dValidEnd<GETDATE() THEN 4
		   END CouponState
	  FROM dbo.Ymt_CouponPrivateUserBound A WITH(NOLOCK)
	  INNER JOIN dbo.Ymt_Coupon C ON A.sCouponId=C.sCouponId AND C.dValidStart<=dValidEnd
	 WHERE A.iBatchId=@BatchId
END
SELECT *,B.sLoginId UserName FROM @tableCouponBatch A INNER JOIN dbo.Ymt_Users B WITH(NOLOCK) ON A.UserId = B.iUserId
