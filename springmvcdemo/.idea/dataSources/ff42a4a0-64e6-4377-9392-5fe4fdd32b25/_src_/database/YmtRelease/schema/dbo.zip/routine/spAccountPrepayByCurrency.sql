-- =============================================
-- Author:		Kevin
-- Create date: 2015-3-5
-- Description:	新增支持多币种，资金操作SP化，事务死锁的快速解决方案
-- 2015-10-20 移除截面账减少锁定时长，同时去掉中间账户逻辑 By Jmtek
-- =============================================
CREATE PROCEDURE [dbo].[spAccountPrepayByCurrency]
	@payerUserId	int,				--付款方账号
	@payeeUserId	int,				--收款方账号
	@payAmount		decimal(10,2),		--付款金额
	@operator		varchar(50),		--资金科目
	@useage			varchar(50),		--付款凭据
	@memo			varchar(200),		--备注
	@currency		int	= 1,			--币种
	@clearAmount	decimal(10,2)	= 0	--结算币种
AS
DECLARE 
@TransferAccountUserId	int,
@DefaultCurrency		int

BEGIN
	--SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
	--BEGIN TRANSACTION
	
	SET @TransferAccountUserId = -1	--系统内置中转账户
	SET @DefaultCurrency = 1		--默认币种 RMB

	--更新买家账户余额
	UPDATE Ymt_AccountInfo SET fAvailAmount = fAvailAmount - @payAmount WHERE iUserId = @payerUserId AND iCurrencyType = @DefaultCurrency
	--扣款资金流水
	INSERT INTO Ymt_AccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
	SELECT NEWID(), -@payAmount, 2, @payerUserId, 0, 0, 0, GETDATE(), @operator, @useage, @memo, @DefaultCurrency, @payAmount 
	--SELECT NEWID(), -@payAmount, 2, @payerUserId, fBalance, fFreezeAmount, fAvailAmount + @payAmount, GETDATE(), @operator, @useage, @memo, @DefaultCurrency, @payAmount 
	--FROM Ymt_AccountInfo WITH(ROWLOCK)
	--WHERE iUserId = @payerUserId AND iCurrencyType = @DefaultCurrency

	
	IF @currency = 1
		BEGIN
			--更新卖家账户余额
			UPDATE Ymt_AccountInfo SET fFreezeAmount = fFreezeAmount + @payAmount WHERE iUserId = @payeeUserId AND iCurrencyType = @currency
			--冻结资金流水
			INSERT INTO Ymt_AccountRunningTally 
			([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
			SELECT NEWID(), @payAmount, 1, @payeeUserId, 0, 0, 0, GETDATE(), @operator, @useage, @memo, @currency, @payAmount 
			--SELECT NEWID(), @payAmount, 1, @payeeUserId, fBalance, fFreezeAmount - @payAmount, fAvailAmount, GETDATE(), @operator, @useage, @memo, @currency, @payAmount 
			--FROM Ymt_AccountInfo WITH(ROWLOCK)
			--WHERE iUserId = @payeeUserId AND iCurrencyType = @currency
		END
	ELSE
		BEGIN
			--更新卖家账户余额(其他币种，比如USD)
			UPDATE Ymt_AccountInfo SET fFreezeAmount = fFreezeAmount + @clearAmount WHERE iUserId = @payeeUserId AND iCurrencyType = @currency
			--冻结资金流水
			INSERT INTO Ymt_AccountRunningTally 
			([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
			SELECT NEWID(), @clearAmount, 1, @payeeUserId, 0, 0, 0, GETDATE(), @operator, @useage, @memo, @currency, @payAmount 
			--SELECT NEWID(), @clearAmount, 1, @payeeUserId, fBalance, fFreezeAmount - @clearAmount, fAvailAmount, GETDATE(), @operator, @useage, @memo, @currency, @payAmount 
			--FROM Ymt_AccountInfo WITH(ROWLOCK)
			--WHERE iUserId = @payeeUserId AND iCurrencyType = @currency
		END
	
	/*
	--更新担保账户余额
	UPDATE Ymt_AccountInfo SET fAvailAmount = fAvailAmount + @payAmount WHERE iUserId = @TransferAccountUserId AND iCurrencyType = @DefaultCurrency
	--担保账户资金流水
	INSERT INTO Ymt_AccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo],[iCurrencyType],[fClearAmount])
	SELECT NEWID(), @payAmount, 2, @TransferAccountUserId, fBalance, fFreezeAmount, fAvailAmount - @payAmount, getdate(), @operator, @useage, @memo, @DefaultCurrency, @payAmount
	FROM Ymt_AccountInfo WITH(ROWLOCK)
	WHERE iUserId = @TransferAccountUserId AND iCurrencyType = @DefaultCurrency
	*/

	--COMMIT TRANSACTION
END
