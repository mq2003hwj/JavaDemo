
-- =============================================
-- Author:		adu
-- Create date: 2014-11-27
-- Description:	使用临时表统计商品评价数
-- =============================================
CREATE PROCEDURE [dbo].[sp_SyncProductCreditStatistic]
	-- Add the parameters for the stored procedure here	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    --如果统计表中已经存在该商品的统计记录，则更新统计信息
    SELECT sProductId,Count(*) as iOrderCount, 
				iCountOfOk=sum(case when c.iPoint3 = 3 then 1 else 0 end),
				iCountOfNormal=sum(case when c.iPoint3 = 2 then 1 else 0 end),
				iCountOfBad=sum(case when c.iPoint3 = 1 then 1 else 0 end)
				INTO #temp1
			from	Ymt_OrderInfo o
			inner join Ymt_CreditDetail c on c.sTargetId= o.iOrderId	
			where	c.iType=1 AND o.sProductId IS NOT null
			GROUP BY sProductId

	
	UPDATE Ymt_ProductCredit SET iOrderCount=#temp1.iOrderCount,iCountOfOk=#temp1.iCountOfOk,iCountOfNormal=#temp1.iCountOfNormal,iCountOfBad=#temp1.iCountOfBad	 
    from #temp1 where #temp1.sProductId=Ymt_ProductCredit.sProductId	

   --找出临时表中有但在统计表中没有统计记录插入表中
	INSERT dbo.Ymt_ProductCredit
	( sProductId ,
	  iOrderCount ,
	  iCountOfOk ,
	  iCountOfNormal ,
	  iCountOfBad
	) 	
	SELECT *
	FROM #temp1
	WHERE sProductId NOT IN(SELECT sProductId FROM  Ymt_ProductCredit)
	
	
END

