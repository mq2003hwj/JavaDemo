create function GetAllCategoryId(@id int)
returns @t table(id int,Level int)
as
begin
declare @i int
set @i=1
insert into @t select @Id,0
insert into @t select iCategoryId,@i from Ymt_ProductCategory where iMasterCategory=@Id

while @@ROWCOUNT<>0
begin
set @i=@i+1
insert into @t select iCategoryId,@i from Ymt_ProductCategory,@t b where iMasterCategory=id and b.Level=@i-1
end

return

end
