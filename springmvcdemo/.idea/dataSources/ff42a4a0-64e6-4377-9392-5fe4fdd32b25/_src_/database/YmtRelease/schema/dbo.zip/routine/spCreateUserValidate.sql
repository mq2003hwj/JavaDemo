

CREATE PROCEDURE [dbo].[spCreateUserValidate] 
	@sValidateId  varchar(36),    -- 唯一标志
	@validateCode varchar(64),	  -- 激活码
	@sActionId    varchar(200),	  -- 激活码发送的对象，如手机号。
	@iAction int,                 -- 激活码类型
	@iType int,                   -- 激活码用途, 如：V帐户激活。
	@iUserId int,                 -- 激活码关联的用户Id。
	@result int out,              -- 返回值,0表示成功,非0 表示失败
	@message varchar(max) out     -- 错误消息
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SET @result = 0
	SET @message = '创建激活码成功'
	
	SELECT * FROM Ymt_UserValidate 
	WHERE sValidateCode = @validateCode and iType = @iType	
		
	-- Check bill existance
	If @@ROWCOUNT > 0
	Begin
		SET @result = 1
		SET @message = '激活码重复'
	End
	ELSE BEGIN
		INSERT INTO [Ymt_UserValidate]
				   ([sValidateId]
				   ,[sValidateCode]
				   ,[sActionId]
				   ,[iAction]
				   ,[iType]
				   ,[iUserId]
				   ,[dAddTime])
			 VALUES
				   (@sValidateId
				   ,@validateCode
				   ,@sActionId
				   ,@iAction
				   ,@iType
				   ,@iUserId
				   ,GETDATE())
	END
END



