
--=====
-- 重量补款完成，调用[XloboRelease].[dbo].[spFinishRemaining] 来修改补款状态。
-- 返回参数@result定义： 
-- 成功, 返回0
-- 失败, 返回非零, 错误代码含义看下面：  
-- 1 参数错误，找不到补款记录
-- 2 参数错误，找不到面单记录
-- 3 参数错误，该补款已经完成，不能重复补款
-- 4 参数错误，虚拟用户名错误
-- 5 参数错误，补款类型错误
--=====

CREATE PROCEDURE [dbo].[spFinishRemaining] 
	@billCode nvarchar(50),
	@remainingType int,                -- 补款类型，0是重量补款，1是缴税补款。
	@userName nvarchar(50),           -- 传入ymt虚拟用户的名字，（考虑不用传入，直接写死在sp里面）
	@result int=0 out,                -- 返回值
	@message varchar(max) out         -- 错误消息
AS
DECLARE
	@RC Int
BEGIN

	EXECUTE @RC = [XloboRelease].[dbo].[spFinishRemaining] 
		@billCode
		,@remainingType
		,@userName
		,@result OUTPUT
		,@message OUTPUT

END
