-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-1
-- Description: 交易服务SP     
--update by CL 2015-12-01  
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderListCount_Full_CL]

@sellerId int,
@orderType int,
@timeType int,
@beginTime  datetime,
@endTime datetime,
@timeoutType bit,
@timeoutType1 tinyint,
@timeoutType2 tinyint,
@timeoutType3 tinyint,
@timeoutBegin1 datetime,
@timeoutEnd1 datetime,
@timeoutBegin2 datetime,
@timeoutEnd2 datetime,
@timeoutBegin3 datetime,
@timeoutEnd3 datetime,
@shangou bit,
@orderStatusXml xml,
@catalogStatusXml xml,
@keyword varchar(200),
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit

AS

if @considerRiskVerfiedStatus = 0 
begin
	if @catalogStatusXml is null 
	begin
		if @orderStatusXml is null 
		begin
		goto select1
		end else
		begin
		goto select2
		end
	end else
	begin 
		if @orderStatusXml is null 
		begin
		goto select3
		end else 
		begin
		goto select4
		end
	end
end else
begin
	if @catalogStatusXml is null 
	begin
		if @considerOrderStatus = 1 and @considerRestOrderStatus = 1
		begin
		goto select5
		end else
		begin
		goto select6
		end
	end else
	begin 
		if @considerOrderStatus = 1 and @considerRestOrderStatus = 1
		begin
		goto select7
		end else
		begin
		goto select8
		end
	end
end

select1:
exec sp_trd_GetSellerOrderListCount_Full1 @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2, 
@timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, 
@considerRestOrderStatus

return 

select2:
exec sp_trd_GetSellerOrderListCount_Full2 @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2, 
@timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, 
@considerRestOrderStatus

return 

select3:
exec sp_trd_GetSellerOrderListCount_Full3 @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2, 
@timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, 
@considerRestOrderStatus

return 

select4:
exec sp_trd_GetSellerOrderListCount_Full4 @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2, 
@timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, 
@considerRestOrderStatus

return 

select5:
exec sp_trd_GetSellerOrderListCount_Full5 @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2, 
@timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, 
@considerRestOrderStatus

return 

select6:
exec sp_trd_GetSellerOrderListCount_Full6 @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2, 
@timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, 
@considerRestOrderStatus

return 

select7:
exec sp_trd_GetSellerOrderListCount_Full7 @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2, 
@timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, 
@considerRestOrderStatus

return 

select8:
exec sp_trd_GetSellerOrderListCount_Full8 @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2, 
@timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, 
@considerRestOrderStatus

return 


