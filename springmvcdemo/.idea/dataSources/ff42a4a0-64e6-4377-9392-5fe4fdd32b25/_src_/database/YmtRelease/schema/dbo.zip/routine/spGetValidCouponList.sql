-- =============================================          
-- Author:  zhangzhiqiang          
-- Create date: 2014-8-22      
-- Description: 根据用户ID获取可使用的优惠券列表          
-- =============================================    
CREATE PROCEDURE [dbo].[spGetValidCouponList]  
	@BuyerId INT,
	@UserType INT,    --用户类型 0-所有买家  1-新用户  2-老用户
	@Amount DECIMAL(18,2),
	@UserLevel VARCHAR(20),
	@SellerId VARCHAR(20),
	@IsHaveActivity INT,  --0-购物车没有活动商品  1-购物车有活动商品
	@UsePlatform VARCHAR(100) = NULL
AS  
BEGIN
    SET NOCOUNT ON
    SET LOCK_TIMEOUT 3000
    DECLARE @CurrentDate VARCHAR(10)
    SET @CurrentDate = CONVERT(VARCHAR(10),GETDATE(),120)
    SET @UserLevel = ',' + @UserLevel + ','
    SET @SellerId = ',' + @SellerId + ','
    SET @UsePlatform = ',' + ISNULL(@UsePlatform,'') + ','
	
	IF @IsHaveActivity = 0   --购物车没有活动商品
	BEGIN
		SELECT Coupon.sCouponCode,Coupon.dValidEnd,CValue.fMinOrderValue,CValue.fCouponValue,Scenario.iUserType
			,Scenario.sActivityIds,Scenario.sLogisticsTypes,Scenario.sProductBrands,Scenario.sProductCategories
			,CSetting.iCouponUseType,Scenario.sSpecificProducts
		FROM Ymt_CouponPrivateUserBound CBound WITH(NOLOCK) 
			JOIN Ymt_Coupon Coupon WITH(NOLOCK) ON Coupon.sCouponCode = CBound.sCouponCode
			JOIN Ymt_CouponSetting CSetting WITH(NOLOCK) ON Coupon.iCouponSetting = CSetting.iCouponSettingId
			JOIN Ymt_CouponValue CValue WITH(NOLOCK) ON Coupon.iCouponSetting = CValue.iCouponSettingId
			JOIN Ymt_CouponScenario Scenario WITH(NOLOCK) ON CSetting.iScenarioId = Scenario.iCouponScenarioId
		WHERE CBound.iUserId=@BuyerId
			AND CBound.iCouponUsedCount > 0
			AND CValue.fMinOrderValue <= @Amount
			AND Coupon.dValidStart <= @CurrentDate AND Coupon.dValidEnd >= @CurrentDate
			AND (Scenario.iUserType = 0 OR Scenario.iUserType = @UserType)
			AND Scenario.sActivityIds IS NULL
			AND (ISNULL(Scenario.sUserLevels,'')='' OR CHARINDEX(@UserLevel,','+Scenario.sUserLevels+',')>0)
			AND (ISNULL(Scenario.sSellerIds,'')='' OR CHARINDEX(@SellerId,','+Scenario.sSellerIds+',')>0)
			AND (ISNULL(Scenario.sUsePlatforms,'')='' OR CHARINDEX(@UsePlatform,','+Scenario.sUsePlatforms+',')>0)
			ORDER BY Coupon.dValidEnd ASC
	END
	ELSE
	BEGIN
		SELECT Coupon.sCouponCode,Coupon.dValidEnd,CValue.fMinOrderValue,CValue.fCouponValue,Scenario.iUserType
			,Scenario.sActivityIds,Scenario.sLogisticsTypes,Scenario.sProductBrands,Scenario.sProductCategories
			,CSetting.iCouponUseType,Scenario.sSpecificProducts
		FROM Ymt_CouponPrivateUserBound CBound WITH(NOLOCK) 
			JOIN Ymt_Coupon Coupon WITH(NOLOCK) ON Coupon.sCouponCode = CBound.sCouponCode
			JOIN Ymt_CouponSetting CSetting WITH(NOLOCK) ON Coupon.iCouponSetting = CSetting.iCouponSettingId
			JOIN Ymt_CouponValue CValue WITH(NOLOCK) ON Coupon.iCouponSetting = CValue.iCouponSettingId
			JOIN Ymt_CouponScenario Scenario WITH(NOLOCK) ON CSetting.iScenarioId = Scenario.iCouponScenarioId
		WHERE CBound.iUserId=@BuyerId
			AND CBound.iCouponUsedCount > 0
			AND CValue.fMinOrderValue <= @Amount
			AND Coupon.dValidStart <= @CurrentDate AND Coupon.dValidEnd >= @CurrentDate
			AND (Scenario.iUserType = 0 OR Scenario.iUserType = @UserType)
			AND (ISNULL(Scenario.sUserLevels,'')='' OR CHARINDEX(@UserLevel,','+Scenario.sUserLevels+',')>0)
			AND (ISNULL(Scenario.sSellerIds,'')='' OR CHARINDEX(@SellerId,','+Scenario.sSellerIds+',')>0)
			AND (ISNULL(Scenario.sUsePlatforms,'')='' OR CHARINDEX(@UsePlatform,','+Scenario.sUsePlatforms+',')>0)
			ORDER BY Coupon.dValidEnd ASC
	END
    SET NOCOUNT OFF
END