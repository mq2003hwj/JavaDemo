CREATE VIEW dbo.ViewOrderOne
AS
SELECT        dbo.Ymt_Catalogs.sCatalogId, dbo.Ymt_Catalogs.sProductId, dbo.Ymt_Catalogs.sUser, dbo.Ymt_Catalogs.iAction, dbo.Ymt_Catalogs.iAcceptReturn, 
                         dbo.Ymt_Catalogs.iCatalogStatus, dbo.Ymt_Catalogs.sPicUrl, dbo.Ymt_Catalogs.sProductName, dbo.Ymt_OrderInfo.sOrderInfoId, dbo.Ymt_OrderInfo.iAmount, 
                         dbo.Ymt_OrderInfo.fTotalPrice, dbo.Ymt_Orders.iOrderId, dbo.Ymt_Orders.dAddTime, dbo.Ymt_Orders.fFreight, dbo.Ymt_Orders.fDiscount, 
                         dbo.Ymt_Orders.iTradingId, dbo.Ymt_OrderInfo.fOriginalPrice, dbo.Ymt_Catalogs.iUserId
FROM            dbo.Ymt_Catalogs INNER JOIN
                         dbo.Ymt_OrderInfo ON dbo.Ymt_Catalogs.sCatalogId = dbo.Ymt_OrderInfo.sCatalogId INNER JOIN
                         dbo.Ymt_Orders ON dbo.Ymt_OrderInfo.iOrderId = dbo.Ymt_Orders.iOrderId
