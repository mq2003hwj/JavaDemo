
  CREATE PROCEDURE CANCEL_ORDER
   @OrderId INT
 AS
 BEGIN
         DECLARE
		    @UseGiftAmount DECIMAL(18,2)
           ,@CashAmount DECIMAL(18,2)
           ,@BuyerId int
           ,@UserId int
           ,@StrOrderId  VARCHAR(10)
           ,@OrderStatu int
         
    SELECT TOP 1 @OrderStatu=iTradingStatus FROM Ymt_Orders WHERE iOrderId=@OrderId
    
    IF  @OrderStatu = 2
    
    BEGIN
         
    SET @StrOrderId = CONVERT(VARCHAR,@OrderId)
	SELECT top 1 @UseGiftAmount=fUseGiftAmount,@BuyerId=iBuyerId,@UserId=iUserId FROM ymt_orders where iOrderId=@OrderId
	SELECT top 1 @CashAmount=fPaidAmountOfCash+fPostPaidAmountOfCash FROM Ymt_OrderState where iOrderId=@OrderId
	--更新账户余额
	IF @UseGiftAmount > 0
	BEGIN
	
	Update Ymt_GiftAccountInfo Set fFreezeAmount = fFreezeAmount - @UseGiftAmount Where iUserId = @BuyerId
	
	Insert Into Ymt_GiftAccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select NewId(), -@UseGiftAmount, 1, iUserId, fBalance, fFreezeAmount + @UseGiftAmount, fAvailAmount, getdate(), 'CancelOrder', @StrOrderId, @StrOrderId 
	From Ymt_GiftAccountInfo with(rowlock)
	Where iUserId = @BuyerId
	
	Update Ymt_GiftAccountInfo Set fAvailAmount = fAvailAmount + @UseGiftAmount Where iUserId = @UserId
	
	Insert Into Ymt_GiftAccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select NewId(), @UseGiftAmount, 2, iUserId, fBalance, fFreezeAmount, fAvailAmount - @UseGiftAmount, getdate(), 'CancelOrder', @StrOrderId, @StrOrderId 
	From Ymt_GiftAccountInfo with(rowlock)
	Where iUserId = @UserId
	
	Update Ymt_GiftAccountInfo Set fAvailAmount = fAvailAmount - @UseGiftAmount Where iUserId = -1
	
	Insert Into Ymt_GiftAccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select NewId(), -@UseGiftAmount, 2, iUserId, fBalance, fFreezeAmount, fAvailAmount + @UseGiftAmount, getdate(), 'CancelOrder', @StrOrderId, @StrOrderId 
	From Ymt_GiftAccountInfo with(rowlock)
	Where iUserId = -1
	
	END
	
	IF @CashAmount > 0
	BEGIN
	
	Update Ymt_AccountInfo set fFreezeAmount = fFreezeAmount - @CashAmount Where iUserId=@BuyerId
	
	Insert Into Ymt_AccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select NewId(), -@CashAmount, 1, iUserId, fBalance, fFreezeAmount + @CashAmount, fAvailAmount, getdate(), 'CancelOrder', @StrOrderId, @StrOrderId 
	From Ymt_AccountInfo with(rowlock)
	Where iUserId = @BuyerId
	
	Update Ymt_AccountInfo Set fAvailAmount = fAvailAmount + @CashAmount Where iUserId = @UserId
	
	Insert Into Ymt_AccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select NewId(), @CashAmount, 2, iUserId, fBalance, fFreezeAmount, fAvailAmount - @CashAmount, getdate(), 'CancelOrder', @StrOrderId, @StrOrderId 
	From Ymt_GiftAccountInfo with(rowlock)
	Where iUserId = @UserId
	
	Update Ymt_AccountInfo Set fAvailAmount = fAvailAmount - @CashAmount Where iUserId = -1
	
	Insert Into Ymt_AccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select NewId(), -@CashAmount, 2, iUserId, fBalance, fFreezeAmount, fAvailAmount + @CashAmount, getdate(), 'CancelOrder', @StrOrderId, @StrOrderId 
	From Ymt_GiftAccountInfo with(rowlock)
	Where iUserId = -1
	
	END

	UPDATE Ymt_Orders set iTradingStatus=18 where iOrderId=@OrderId

	END
END