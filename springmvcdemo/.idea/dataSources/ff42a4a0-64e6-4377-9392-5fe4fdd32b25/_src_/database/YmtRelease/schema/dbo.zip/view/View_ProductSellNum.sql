CREATE VIEW dbo.VIEW_SELLNUM
AS
SELECT     sProductId, SUM(iAmount) AS sellnum
FROM         dbo.Ymt_OrderInfo
GROUP BY sProductId
