-- =============================================            
-- Author: fanwei
-- ALTER date: 2015-8-13
-- Description: 交易服务SP       
-- update by cl 2015-12-03
-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderList_Full]

@sellerId int,
@orderType int,
@sortType int,
@timeType int,
@timeoutType int,
@beginTime  datetime,
@endTime datetime,
@timeoutBegin datetime,
@timeoutEnd datetime,
@shangou bit,
@orderStatusXml xml,
@catalogStatusXml xml,
@paidInFull bit,
@keyword varchar(200),
@rowFrom int,
@rowTo int,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@salesRefundOrderOnly bit = 0,
@domesticDelivered bit = null

AS 

if @timeType = 0
Begin
  select @beginTime = getdate() - 90 , @endTime = getdate()
  Exec sp_trd_GetSellerOrderList_Full_daddtime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @catalogStatusXml,
   @paidInFull, @keyword, @rowFrom, @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
End

if  @timeType = 1
Begin
  Exec sp_trd_GetSellerOrderList_Full_daddtime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @catalogStatusXml,
   @paidInFull, @keyword, @rowFrom, @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
End

if  @timeType = 2
Begin
  Exec sp_trd_GetSellerOrderList_Full_dPaidTime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @catalogStatusXml,
   @paidInFull, @keyword, @rowFrom, @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
End

if  @timeType = 3
Begin
  Exec sp_trd_GetSellerOrderList_Full_dDispathTime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @catalogStatusXml,
   @paidInFull, @keyword, @rowFrom, @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
End

if  @timeType = 4
Begin
  Exec sp_trd_GetSellerOrderList_Full_dApplyPostPayTime @sellerId, @orderType, @sortType, @timeType, @timeoutType, @beginTime, @endTime, @timeoutBegin, @timeoutEnd, @shangou, @orderStatusXml, @catalogStatusXml,
   @paidInFull, @keyword, @rowFrom, @rowTo, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
End
