
CREATE PROCEDURE [dbo].[spConfigMilkFundCouponBatch]
	@configDate date,
	@batchCode varchar(15)
AS
BEGIN
	SET NOCOUNT ON;
	SET XACT_ABORT ON
	
	declare @batchId int
	declare @startTime datetime
	declare @endTime datetime
	declare @settingId int
	
	declare @minBornDate date
	declare @maxBornDate date
	
	declare @couponUseCount int
	
	set @minBornDate = DATEADD(MONTH, 1, DATEADD(YEAR, -2, @configDate))
	set @maxBornDate = DATEADD(MONTH, 6, @configDate)
	
	select @batchId = ibatchId, @startTime = cs.dValidStart, @endTime = cs.dValidEnd, @couponUseCount = cs.iMaxUseTimePerUser, @settingId = cb.iCouponSettingId
	 from Ymt_CouponBatch cb, Ymt_CouponSetting cs where cb.sBatchCode = @batchCode and cs.iCouponSettingId = cb.iCouponSettingId
	
	print dbo.GenerateMilkFundCouponCode(23425, @batchId)

	BEGIN TRAN
	
	--新建优惠券号临时表
	delete from Temp_Code
	
	insert Temp_Code (UserId, Code) 
	select iUserId, dbo.GenerateMilkFundCouponCode(ma.iUserId, @batchId)
		from Ymt_MilkFundApply ma where ma.iAction = 1 and ma.dBornDate >= @minBornDate and ma.dBornDate < @maxBornDate and not exists(select * from Ymt_CouponPrivateUserBound where iUserId = ma.iUserId and iBatchId = @batchId)
	
	
	--添加奶粉基金配置
	insert Ymt_MilkFundCoupnConfig (dConfigMonth, sBatchCode, iBatchId, dAddTime, iAction) values
	(@configDate, @batchCode, @batchId, GETDATE(), 0)
	
	--生成优惠券
	insert Ymt_Coupon (sCouponId, sCouponCode, iCouponType, dValidStart, dValidEnd, iCouponSetting, iBatchId, iUsage)
	select NEWID(), Temp_Code.Code, 2, @startTime, @endTime, @settingId, @batchId, 1
		from Ymt_MilkFundApply ma inner join Temp_Code on Temp_Code.UserId = ma.iUserId
	
	--绑定优惠券
	insert Ymt_CouponPrivateUserBound (sBoundId, sCouponCode, iUserId, dAddTime, iCouponUsedCount, sCouponId, iBatchId)
	select NEWID(), Temp_Code.Code, ma.iUserId, GETDATE(), @couponUseCount, c.sCouponId, @batchId
		from Ymt_MilkFundApply ma inner join Temp_Code on Temp_Code.UserId = ma.iUserId inner join Ymt_Coupon c on c.iBatchId = @batchId and Temp_Code.Code = c.sCouponCode
	
	COMMIT

END

