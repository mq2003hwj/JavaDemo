

-- =============================================            
-- Author:  CL        
-- ALTER date: 2015-12-1
-- Description: 交易服务SP
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderListCount_Full_NoTime]

@sellerId int,
@orderType int,
@timeType int,
@beginTime  datetime,
@endTime datetime,
@timeoutType bit,
@timeoutType1 tinyint,
@timeoutType2 tinyint,
@timeoutType3 tinyint,
@timeoutBegin1 datetime,
@timeoutEnd1 datetime,
@timeoutBegin2 datetime,
@timeoutEnd2 datetime,
@timeoutBegin3 datetime,
@timeoutEnd3 datetime,
@shangou bit,
@orderStatusXml xml,
@catalogStatusXml xml,
@keyword varchar(200),
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@salesRefundOrderOnly bit = 0,
@domesticDelivered bit = null

AS

---------------variables-------------
--declare @orderStatus table(value int primary key);
--declare @catalogStatus table(value int primary key);

----------------process--------------
--set nocount on;

--if @orderStatusXml is not null
--begin
--    insert into @orderStatus 
--    select tbl.col.value('@s','int')
--    from @orderStatusXml.nodes('/root/x') tbl(col)
--end

--if @catalogStatusXml is not null
--begin
--    insert into @catalogStatus 
--    select tbl.col.value('@s','int')
--    from @catalogStatusXml.nodes('/root/x') tbl(col)
--end

--set statistics time on;set statistics io on;
if @considerRiskVerfiedStatus = 0 begin

;with t as(
select o.iOrderId, o.iTradingStatus, o.bPaidInFull,
ROW_NUMBER() over(partition by o.iOrderId order by o.iOrderId) as n
from Ymt_Orders o with (nolock,index = IX_Ymt_Orders) 
inner loop join Ymt_OrderInfo(nolock) i on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId
--and (
--@timeType = 0
--or @timeType = 1 and o.dAddTime between @beginTime and @endTime
--or @timeType = 2 and o.dPaidTime between @beginTime and @endTime
--or @timeType = 3 and o.dDispathTime between @beginTime and @endTime
--or @timeType = 4 and o.dApplyPostPayTime between @beginTime and @endTime
--)
and 
(
@orderType = 0
or @orderType = 1 and o.bShangouOrder = @shangou
or @orderType = 2 and o.bShangouOrder = 0
or @orderType = 3 and o.bShangouOrder = 1
or @orderType = 4 and i.sCatalogId is not null
or @orderType = 5 and (o.bShangouOrder = 1 or (o.bShangouOrder = 0 and i.sCatalogId is null))
or @orderType = 6 and (o.bShangouOrder = 0 and i.sCatalogId is not null)
or @orderType = 7 and (o.bShangouOrder = 0 and i.sCatalogId is null)
)
--and (@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))
and (@orderStatusXml is null or cast(@orderStatusXml as varchar(1000)) like '%"' + cast(o.iTradingStatus as varchar)+ '"%')
and (
@timeoutType = 0 or(
    @timeoutType1 = 0 or (@timeoutType1 = 1 and (o.dPaidTime > @timeoutBegin1 and o.dPaidTime <= @timeoutEnd1 and o.iTradingStatus = 2) or @timeoutType1 = 2 and (o.dPaidTime <= @timeoutEnd1 and o.iTradingStatus = 2))
  and @timeoutType2 = 0 or (@timeoutType2 = 1 and (o.dAcceptTime > @timeoutBegin2 and o.dPaidTime <= @timeoutEnd2 and o.iTradingStatus = 17 and o.bPaidInFull = 0) 
  or @timeoutType2 = 2 and (o.dAcceptTime <= @timeoutEnd2 and o.iTradingStatus = 17 and o.bPaidInFull = 0))
  and @timeoutType3 = 0 or (@timeoutType3 = 1 and (isnull(o.dPostPaidTime,o.dPaidTime) > @timeoutBegin3 and isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd3 and o.iTradingStatus = 17 and o.bPaidInFull = 1) 
  or @timeoutType3 = 2 and (isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd3 and o.iTradingStatus = 17 and o.bPaidInFull = 1))
        )
)
--and(@catalogStatusXml is null or i.iCatalogStatus in (select value from @catalogStatus))
and (@catalogStatusXml is null or cast(@catalogStatusXml as varchar(2000)) like '%"' + cast(i.iCatalogStatus as varchar) + '"%')
and (@domesticDelivered is null or isnull(o.bDomesticDelivered, 0) = @domesticDelivered)
and (@keyword is null or (o.iOrderId like @keyword or o.sBuyerLoginId like @keyword or i.sTitle like @keyword))
and (@salesRefundOrderOnly = 0 or o.iSalesRefundStatus is not null)
) select iTradingStatus, bPaidInFull, count(iOrderId) as num from t where n = 1 group by iTradingStatus, bPaidInFull;

end else begin

;with t as(
select o.iOrderId, o.iTradingStatus, o.bPaidInFull, o.iRiskVerifiedStatus,
ROW_NUMBER() over(partition by o.iOrderId order by o.iOrderId) as n
from Ymt_Orders o with (nolock,index = IX_Ymt_Orders) 
inner loop join Ymt_OrderInfo(nolock) i on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId
--and (
--@timeType = 0
--or @timeType = 1 and o.dAddTime between @beginTime and @endTime
--or @timeType = 2 and o.dPaidTime between @beginTime and @endTime
--or @timeType = 3 and o.dDispathTime between @beginTime and @endTime
--or @timeType = 4 and o.dApplyPostPayTime between @beginTime and @endTime
--)
and 
(
@orderType = 0
or @orderType = 1 and o.bShangouOrder = @shangou
or @orderType = 2 and o.bShangouOrder = 0
or @orderType = 3 and o.bShangouOrder = 1
or @orderType = 4 and i.sCatalogId is not null
or @orderType = 5 and (o.bShangouOrder = 1 or (o.bShangouOrder = 0 and i.sCatalogId is null))
or @orderType = 6 and (o.bShangouOrder = 0 and i.sCatalogId is not null)
or @orderType = 7 and (o.bShangouOrder = 0 and i.sCatalogId is null)
)
and --(@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))
(
  @considerOrderStatus = 0 or
  (
    (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
    or
    (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
    or
    --(@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
  (@considerRestOrderStatus = 1 and cast(@orderStatusXml as varchar(1000)) like '%"' + cast(o.iTradingStatus as varchar)+ '"%')
  )
)
and (
@timeoutType = 0 or(
    @timeoutType1 = 0 or (@timeoutType1 = 1 and (o.dPaidTime > @timeoutBegin1 and o.dPaidTime <= @timeoutEnd1 and o.iTradingStatus = 2) or @timeoutType1 = 2 and (o.dPaidTime <= @timeoutEnd1 and o.iTradingStatus = 2))
  and @timeoutType2 = 0 or (@timeoutType2 = 1 and (o.dAcceptTime > @timeoutBegin2 and o.dPaidTime <= @timeoutEnd2 and o.iTradingStatus = 17 and o.bPaidInFull = 0) 
  or @timeoutType2 = 2 and (o.dAcceptTime <= @timeoutEnd2 and o.iTradingStatus = 17 and o.bPaidInFull = 0))
  and @timeoutType3 = 0 or (@timeoutType3 = 1 and (isnull(o.dPostPaidTime,o.dPaidTime) > @timeoutBegin3 and isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd3 and o.iTradingStatus = 17 and o.bPaidInFull = 1) 
  or @timeoutType3 = 2 and (isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd3 and o.iTradingStatus = 17 and o.bPaidInFull = 1))
        )
)
--and(@catalogStatusXml is null or i.iCatalogStatus in (select value from @catalogStatus))
and (@catalogStatusXml is null or cast(@catalogStatusXml as varchar(2000)) like '%"' + cast(i.iCatalogStatus as varchar) + '"%')
and (@domesticDelivered is null or isnull(o.bDomesticDelivered, 0) = @domesticDelivered)
and (@keyword is null or (o.iOrderId like @keyword or o.sBuyerLoginId like @keyword or i.sTitle like @keyword))
and (@salesRefundOrderOnly = 0 or o.iSalesRefundStatus is not null)
) select case 
when (iTradingStatus = 1 or iTradingStatus = 2 and iRiskVerifiedStatus = 1) then 1
when (iTradingStatus = 2 and (iRiskVerifiedStatus is null or iRiskVerifiedStatus = 2)) then 2
else iTradingStatus end as iTradingStatus
, bPaidInFull, count(iOrderId) as num from t where n = 1 group by case 
when (iTradingStatus = 1 or iTradingStatus = 2 and iRiskVerifiedStatus = 1) then 1
when (iTradingStatus = 2 and (iRiskVerifiedStatus is null or iRiskVerifiedStatus = 2)) then 2
else iTradingStatus end, 
bPaidInFull;
end
