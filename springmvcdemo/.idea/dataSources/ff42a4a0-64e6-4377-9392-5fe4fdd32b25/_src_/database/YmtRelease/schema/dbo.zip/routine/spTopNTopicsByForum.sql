-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spTopNTopicsByForum]
	-- Add the parameters for the stored procedure here
	@Count int,
	@ForumId varchar(36)
AS
BEGIN

	-- declare var
	DECLARE @sCount VARCHAR(10)
	DECLARE @sSQL VARCHAR(1000)

	-- set var
	SET @sCount = Convert(VARCHAR(10), @Count)


	SET @sSQL = 'select top ' + @sCount + ' * from Ymt_Topics p left join Ymt_TopicType t on p.sTopicTypeId=t.sTopicTypeId '
	SET @sSQL = @sSQL + 'left join ('
	SET @sSQL = @sSQL + 'select iTopicId,SUM(iAddScore) addScore from Ymt_TopicAddScoreRecord group by iTopicId) s '
	SET @sSQL = @sSQL + 'on p.iTopicId=s.iTopicId '
	SET @sSQL = @sSQL + 'where p.iDisplayStatus=0 and p.iAction>=0 '
	SET @sSQL = @sSQL + 'and p.sForumId=''' + @ForumId + ''' '
	SET @sSQL = @sSQL + 'order by iTopStatu desc, dLastPost desc'

	EXEC(@sSQL)

END