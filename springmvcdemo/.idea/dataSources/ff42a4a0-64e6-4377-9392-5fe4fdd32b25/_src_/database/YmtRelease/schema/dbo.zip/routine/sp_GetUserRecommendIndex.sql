
-- =============================================
-- Author:		adu
-- Create date: 2015-06-08
-- Description:	获取老推新首页所需的信息，包括推荐人的名字，logo，最近10个被推荐人的名字
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetUserRecommendIndex] 
	@UserId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT u.iUserId AS RecommenderId,u.sLoginId AS RecommenderUserName,[t0].sLogoUrl AS RecommenderLogo,dbo.GetLastRecommendedUserNameSplitBy(@UserId,',') AS LastRecommendedUserName FROM Ymt_Users u 
	Outer Apply
	(
	SELECT TOP 1 sLogoUrl FROM Ymt_UserLogo WHERE iUserId=u.iUserId AND iAction=0
	) AS [t0]

	WHERE u.iUserId=@UserId
END

