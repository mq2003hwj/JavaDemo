-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-12-21
-- Description: 交易服务SP       
-- 20160801：添加减促销满减金额
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerSalesInfo_v2]

@sellerId int,
@date datetime = NULL

AS

if @date is null set @date = getdate();

SET DATEFIRST 1
declare @today datetime = DATEADD(day, DATEDIFF(day,0,@date),0)
declare @yesterday datetime = DATEADD(day, DATEDIFF(day,0,@today-1), 0)
declare @tomorrow datetime = DATEADD(day,1,@today)
declare @week datetime = DATEADD(day, DATEDIFF(day,0,@today-(DATEPART(weekday, @today)-1)),0)
declare @month datetime = DATEADD(month, DATEDIFF(month,0,@today),0)

--set statistics io on;set statistics time on;
-------------------------------------------------------销售额
--昨天
select 'yesterday' as TimeSpan,
sum(IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0) , 0)) Spot,
sum(IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Shangou,
sum(isnull(i.fSellerCouponAmount,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
join ymt_orderinfo i with(nolock) on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.dAddTime >= @yesterday and o.dAddTime < @today and o.iTradingStatus in (1,2,3,4,16,17)
union all--今天
select  'today' as TimeSpan,
sum(IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Spot,
sum(IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Shangou,
sum(isnull(i.fSellerCouponAmount,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
join ymt_orderinfo i with(nolock) on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.dAddTime >= @today and o.dAddTime < @tomorrow and o.iTradingStatus in (1,2,3,4,16,17)
union all--本周
select 'week' as TimeSpan,
sum(IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Spot,
sum(IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Shangou,
sum(isnull(i.fSellerCouponAmount,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
join ymt_orderinfo i with(nolock) on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.dAddTime >= @week and o.dAddTime < @tomorrow and o.iTradingStatus in (1,2,3,4,16,17)
union all--本月
select 'month' as TimeSpan, 
sum(IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Spot,
sum(IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Shangou,
sum(isnull(i.fSellerCouponAmount,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
join ymt_orderinfo i with(nolock) on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.dAddTime >= @month and o.dAddTime < @tomorrow and o.iTradingStatus in (1,2,3,4,16,17)

-------------------------------------------------------成交额

select 'yesterday' as TimeSpan,
sum(IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount + isnull(i.fDiscount, 0) + isnull(i.fFreight, 0) - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Spot,
sum(IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount + isnull(i.fDiscount, 0) + isnull(i.fFreight, 0) - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Shangou,
sum(isnull(i.fSellerCouponAmount,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dConfirmedTime)
join ymt_orderinfo i with(nolock) on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.iTradingStatus = 4 and o.dConfirmedTime >= @yesterday and o.dConfirmedTime < @today

union all
select 'today' as TimeSpan,
sum(IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount + isnull(i.fDiscount, 0) + isnull(i.fFreight, 0) - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Spot,
sum(IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount + isnull(i.fDiscount, 0) + isnull(i.fFreight, 0) - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Shangou,
sum(isnull(i.fSellerCouponAmount,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dConfirmedTime)
join ymt_orderinfo i with(nolock) on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.iTradingStatus = 4 and o.dConfirmedTime >= @today and o.dConfirmedTime < @tomorrow

union all
select 'week' as TimeSpan,
sum(IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount + isnull(i.fDiscount, 0) + isnull(i.fFreight, 0) - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Spot,
sum(IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount + isnull(i.fDiscount, 0) + isnull(i.fFreight, 0) - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Shangou,
sum(isnull(i.fSellerCouponAmount,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dConfirmedTime)
join ymt_orderinfo i with(nolock) on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.iTradingStatus = 4 and o.dConfirmedTime >= @week and o.dConfirmedTime < @tomorrow

union all
select 'month' as timespan,
sum(IIF(i.iSalesType = 1, i.fProductPrice * i.iAmount + isnull(i.fDiscount, 0) + isnull(i.fFreight, 0) - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Spot,
sum(IIF(i.iSalesType = 2 or i.iSalesType is null, i.fProductPrice * i.iAmount + isnull(i.fDiscount, 0) + isnull(i.fFreight, 0) - isnull(i.fSellerCouponAmount,0) - isnull(i.fSellerPromotionAmount,0), 0)) Shangou,
sum(isnull(i.fSellerCouponAmount,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dConfirmedTime)
join ymt_orderinfo i with(nolock) on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId and o.iTradingStatus = 4 and o.dConfirmedTime >= @month and o.dConfirmedTime < @tomorrow

--set statistics io off;set statistics time off;