


-- =============================================
-- Author:		zhujinfeng
-- Create date: 2015-02-25
-- Description:	取有效的优惠券列表（使用场景：订单生成页面）
-- =============================================
CREATE PROCEDURE [dbo].[SP_CouponValidList]
	@BuyerUserId INT
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT a.sCouponCode, b.sBatchCode, a.iCouponType, dbo.FUNC_MargeCouponValue(a.iCouponSetting) AS CouponValue, c.iCouponUseType, c.iMaxUseTime, a.dValidStart, a.dValidEnd, f.iCouponUsedCount, e.iUserType, 
			e.sSellerIds, e.sLogisticsTypes, e.sStockStatus, e.sProductCategories, e.sSpecificProducts, e.sProductBrands, e.sActivityIds, e.sUserLevels, e.sUsePlatforms,C.bIsMobileVerify,b.iBatchCreateType
		FROM Ymt_Coupon a WITH(NOLOCK)
			LEFT JOIN Ymt_CouponBatch b WITH(NOLOCK) ON a.iBatchId = b.iBatchId
			LEFT JOIN Ymt_CouponSetting c WITH(NOLOCK) ON a.iCouponSetting = c.iCouponSettingId
			LEFT JOIN Ymt_CouponScenario e WITH(NOLOCK) ON c.iScenarioId = e.iCouponScenarioId
			LEFT JOIN Ymt_CouponPrivateUserBound f WITH(NOLOCK) ON a.sCouponCode = f.sCouponCode
		WHERE f.iUserId = @BuyerUserId AND (GETDATE() BETWEEN a.dValidStart AND a.dValidEnd) AND f.iCouponUsedCount > 0 AND c.iMaxUseTime > 0
END



