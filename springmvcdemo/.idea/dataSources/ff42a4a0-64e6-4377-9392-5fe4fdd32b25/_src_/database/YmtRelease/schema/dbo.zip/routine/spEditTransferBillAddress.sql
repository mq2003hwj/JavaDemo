CREATE PROCEDURE [dbo].[spEditTransferBillAddress]
    @sCode nvarchar(50) out          -- 面单的面单号
    ,@sRecAds nvarchar(200)           -- 收件人地址，传入参数，必填
    ,@sReceiverCity nvarchar(64)      -- 收件人所在市，传入参数，必填
    ,@sReceiverProvince nvarchar(64)  -- 收件人所在省，传入参数，必填
    ,@sReceiverRegion nvarchar(64)    -- 收件人所在区，传入参数
    ,@sRecName nvarchar(50)        -- 收件人名字，传入参数，必填
    ,@sRecPhone nvarchar(50)       -- 收件人电话，传入参数，必填
    ,@sRecPostcode nvarchar(64)    -- 收件人邮编，传入参数，必填
    ,@result int=0 out             -- 返回值,0表示成功,非表示失败
    ,@message varchar(max) out     -- 错误消息
   
AS
BEGIN
DECLARE	@return_value int

EXEC	@return_value = [XloboRelease].[dbo].[spEditTransferBillAddress]
		@sCode = @sCode,
		@sRecAds = @sRecAds,
		@sReceiverCity = @sReceiverCity,
		@sReceiverProvince =@sReceiverProvince,
		@sReceiverRegion = @sReceiverRegion ,
		@sRecName =@sRecName,
		
		
		@sRecPhone = @sRecPhone,
		@sRecPostcode = @sRecPostcode,
		
		
		@result = @result OUTPUT,
		@message = @message OUTPUT
		
		
		
		
end
