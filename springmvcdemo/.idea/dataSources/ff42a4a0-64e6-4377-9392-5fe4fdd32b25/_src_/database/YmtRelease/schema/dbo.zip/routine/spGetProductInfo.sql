-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE spGetProductInfo
AS
BEGIN
	Select p.sproductid,icategoryid,ibrandid,sproduct,validstart,validend,iismerchant,p.icatalogtype,ithirdcategoryid,isellnum,irecentsellnum,min(fQuotePrice) as fquoteprice,sort,pid
	From Ymt_Products p with(nolock) inner join Ymt_Catalogs c with(nolock) on p.sProductId = c.sProductId
	Where p.iAction = 0 And c.iAction = 0 And bShangouProduct = 0 And bYmtProduct = 1 And bHidden = 0
	Group By p.sproductid,icategoryid,ibrandid,sproduct,validstart,validend,iismerchant,p.icatalogtype,ithirdcategoryid,isellnum,irecentsellnum, sort, pid
END
