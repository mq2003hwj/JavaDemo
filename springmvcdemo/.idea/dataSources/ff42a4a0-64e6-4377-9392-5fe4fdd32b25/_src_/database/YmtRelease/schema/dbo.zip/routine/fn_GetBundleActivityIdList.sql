-- =============================================
-- Author:		zhujinfeng
-- Create date: 2015-12-25
-- Description:	取进行中的套餐所关联的活动编号
-- =============================================
CREATE FUNCTION fn_GetBundleActivityIdList
(
	-- 套餐编号
	@BundleId varchar(20)
)
RETURNS VARCHAR(400)
AS
BEGIN
	
	DECLARE @ActivityIds varchar(400);
	SET @ActivityIds = '';

	SELECT @ActivityIds = @ActivityIds+',' +  CONVERT(varchar, ActivityId) FROM Ymt_ProductBundleInActivity WITH(NOLOCK) WHERE BundleId = @BundleId AND [Status] > -1 AND GETDATE() BETWEEN BeginTime AND EndTime;
	
	SET @ActivityIds=STUFF(@ActivityIds, 1, 1, '') 

	RETURN @ActivityIds;

END
