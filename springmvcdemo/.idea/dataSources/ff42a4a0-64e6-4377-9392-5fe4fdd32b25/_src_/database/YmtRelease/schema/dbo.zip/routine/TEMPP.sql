-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[TEMPP] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    --CREATE TABLE #TempAllCats(rowid int,id int,level int,masterId int,mid varchar(20))
    --INSERT INTO #TempAllCats SELECT ROW_NUMBER() OVER(ORDER BY iLevel,iCategoryId) AS RowNumber,iCategoryId,iLevel,iMasterCategory,CAST(iMasterCategory as varchar) FROM Ymt_ProductCategory WHERE iAction=0 ORDER BY iLevel,iCategoryId
    
    --新建表变量 @TempAllCats 
    DECLARE @TempAllCats TABLE(rowid int,id int,level int,masterId int,mid varchar(20))
    --初始化表变量 填入有效类别 增加索引RowId
    INSERT INTO @TempAllCats SELECT ROW_NUMBER() OVER(ORDER BY iLevel,iCategoryId) AS RowNumber,iCategoryId,iLevel,iMasterCategory,CAST(iMasterCategory as varchar) FROM Ymt_ProductCategory WHERE iAction=0 ORDER BY iLevel,iCategoryId
    
	--临时RowId RowNumber
	DECLARE @tempRowId int
	--获取最小RowId
	SELECT @tempRowId=MIN(rowid) FROM @TempAllCats
	
	--声明表变量 @CategoryIndex 结果表 
	--DECLARE @CategoryIndex TABLE(id int,subs varchar(500),cwithsubs varchar(500))
	
	--临时表变量 获取单ID及子ID		
	DECLARE @T table(id int,clevel int)
	DECLARE @TEMPROWCOUNT int =0
	
	WHILE @tempRowId IS NOT NULL
	BEGIN
		DECLARE @tempCatId int = 0
		SELECT @tempCatId=MIN(id) FROM @TempAllCats WHERE rowid=@tempRowId
		
		DECLARE @clevel int
		SELECT @clevel=MIN(level) FROM @TempAllCats WHERE rowid=@tempRowId
		INSERT INTO @T SELECT @tempCatId,@clevel
		
		SET @clevel=@clevel+1
		INSERT INTO @T SELECT id,@clevel FROM @TempAllCats WHERE masterId=@tempCatId
		
		WHILE @@ROWCOUNT<>0
		BEGIN
			SET @clevel = @clevel +1
			INSERT INTO @T SELECT a.id,@clevel FROM @TempAllCats a,@T b where a.masterId=b.id and b.clevel=@clevel-1
		END
		
		DECLARE @tempppp varchar(4000) = ''

		SELECT @tempppp=@tempppp+','+CAST(id as varchar) FROM @T
		--SELECT @tempppp
		
		SET @TEMPROWCOUNT=0
		SELECT @TEMPROWCOUNT=COUNT(*) FROM Trig_CategorysIndex WHERE iCategoryId=@tempCatId
		IF @TEMPROWCOUNT<>0
			BEGIN
				SELECT @TEMPROWCOUNT=COUNT(*) FROM Trig_CategorysIndex WHERE iCategoryId=@tempCatId AND sCategoryWithSub=STUFF(@tempppp,1,1,'')
				IF @TEMPROWCOUNT =0
				BEGIN
					--INSERT INTO Trig_CategorysIndex VALUES(@tempCatId,STUFF(@tempppp,1,Len(@tempCatId)+2,''),STUFF(@tempppp,1,1,''))
					UPDATE Trig_CategorysIndex SET sSubCategorys=STUFF(@tempppp,1,Len(@tempCatId)+2,''),sCategoryWithSub=STUFF(@tempppp,1,1,'') WHERE iCategoryId=@tempCatId
					--print '--update--' + cast(@tempCatId as varchar)
				END
			END
		ELSE
			BEGIN
				INSERT INTO Trig_CategorysIndex VALUES(@tempCatId,STUFF(@tempppp,1,Len(@tempCatId)+2,''),STUFF(@tempppp,1,1,''))
				--print '--insert--' + cast(@tempCatId as varchar)
			END
		SELECT @tempRowId=MIN(rowid) FROM @TempAllCats WHERE rowid>@tempRowId
		--INSERT INTO @CategoryIndex(id,subs,cwithsubs) values(@tempCatId,STUFF(@tempppp,1,Len(@tempCatId)+2,''),STUFF(@tempppp,1,1,''))		
		--print (@tempRowId)
		DELETE FROM @T WHERE id>0
	END
	--select * from @CategoryIndex
    --DROP TABLE #TempAllCats	
END
