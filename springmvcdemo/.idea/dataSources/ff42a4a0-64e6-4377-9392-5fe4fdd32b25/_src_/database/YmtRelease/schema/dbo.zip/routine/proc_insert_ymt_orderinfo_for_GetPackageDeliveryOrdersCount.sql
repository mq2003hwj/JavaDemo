create proc proc_insert_ymt_orderinfo_for_GetPackageDeliveryOrdersCount(@orderInfoId int, @orderId int)
as    

     insert [YmtRelease].[dbo].[Ymt_OrderInfo] ([sOrderInfoId], [iOrderId], [iType], [sCatalogId], [sPropertyInfo], [sTitle], 
  [sDescription], [sPictureUrl], [sReferenceUrl], [fOriginalPrice], [fDiscount], [iAmount], [fTotalPrice], [iSailProtected], 
  [sSKU], [bForVip], [iCatalogType], [iCatalogStatus], [iProductType], [sProductId], [iProductMainCategoryId], 
  [iProductSubCategoryId], [iProductThirdCategoryId], [iProductBrandId], [iBondedArea], [sProductCode], [iTariffType], [fFlight], 
  [iPriceType], [sPackageNo], [iProductRefundChannel], [iProductRefundStatus], [fProductPrice]) 
  values (cast(@orderInfoId as varchar(36)),cast(@orderId as int),cast(0 as int),
  cast('ef6f28e2-fc8c-4da5-84e2-21dc34bbd9fa' as varchar(36)),cast('' as varchar(max)),
  cast('【洋码头免国际运费周】限时专场：美国GNC男性综合维生素矿物质植物精华缓释片180片' as nvarchar(1000)),NULL,
  cast('http://p3.img.ymatou.com/upload/product/original/53ecffa77e0341e18d9199636249ecdc_o.jpg' as nvarchar(2048)),NULL,
  cast(130.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),cast(1 as int),cast(130.00 as decimal(18, 2)),cast(1 as int),
  cast('4961989107400 :1' as varchar(300)),cast(0 as bit),cast(0 as int),cast(7 as int),cast(0 as int),
  cast('98401d9c-3561-4c36-95b0-a2ae4ec08c10' as varchar(100)),cast(1232 as int),cast(1252 as int),cast(1253 as int),
  cast(10132 as int),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
     
