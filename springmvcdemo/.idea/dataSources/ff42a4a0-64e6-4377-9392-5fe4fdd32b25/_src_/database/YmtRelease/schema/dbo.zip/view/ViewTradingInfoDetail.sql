CREATE VIEW dbo.ViewTradingInfoDetail
AS
SELECT      b.iTradingId, b.dAddTime, ts.iTradingStatus, a.iOrderId, a.iBuyerId, a.iUserId, a.fFreight, a.fDiscount AS orderdiscount, oi.sOrderInfoId, 
                        oi.iAmount AS [OrderInfo.iAmount], oi.sPropertyInfo AS [OrderInfo.sPropertyInfo], oi.fOriginalPrice AS [OrderInfo.fOriginalPrice], 
                        oi.fDiscount AS [OrderInfo.fDiscount], oi.fTotalPrice AS [OrderInfo.fTotalPrice], oi.iOrderId AS [OrderInfo.iOrderId], 
                        dbo.Ymt_Users.sNickName AS sBuyer, oi.sCatalogId, dbo.Ymt_Catalogs.sPicUrl, dbo.Ymt_Catalogs.sProductName
FROM          dbo.Ymt_Orders AS a LEFT OUTER JOIN
                        dbo.Ymt_TradingInfo AS b ON a.iTradingId = b.iTradingId LEFT OUTER JOIN
                        dbo.Ymt_OrderInfo AS oi ON a.iOrderId = oi.iOrderId INNER JOIN
                        dbo.Ymt_TradingStatus AS ts ON a.iOrderId = ts.iTraddingId INNER JOIN
                        dbo.Ymt_Users ON a.iBuyerId = dbo.Ymt_Users.iUserId INNER JOIN
                        dbo.Ymt_Catalogs ON oi.sCatalogId = dbo.Ymt_Catalogs.sCatalogId
