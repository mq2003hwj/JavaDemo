CREATE FUNCTION [dbo].[CheckOrderPaymentStatus]
(	
	@sDate	varchar(20),
	@mode	int
)
RETURNS int
AS

BEGIN
	declare @count int
		
	if @mode = 1 begin
		select @count = COUNT(*) from (select t.iTraddingId from ymt_tradingstatus t inner join ymt_orders o on o.iOrderId = t.iTraddingId
		where t.iTradingStatus = 2 and DATEDIFF(d, @sdate, dupdatetime) = 0 and o.iTradingStatus <> 12 and o.iTradingStatus <> 13 and o.bPaidInFull = 0
		group by t.iTraddingId) as tb
		
		return ISNULL(@count, 0)
	end
	
	if @mode = 2 begin
		select @count = COUNT(*) from (select t.iTraddingId from ymt_tradingstatus t inner join ymt_orders o on o.iOrderId = t.iTraddingId
		where t.iTradingStatus = 2 and DATEDIFF(d, @sdate, dupdatetime) = 0 and o.iTradingStatus <> 12 and o.iTradingStatus <> 13 and o.bPaidInFull = 1
		group by t.iTraddingId) as tb
		
		return ISNULL(@count, 0)
	end
	
	if @mode = 3 begin
		select @count = COUNT(*) from (select t.iTraddingId from ymt_tradingstatus t inner join ymt_orders o on o.iOrderId = t.iTraddingId
		where t.iTradingStatus = 17 and mMemo = '补款成功' and DATEDIFF(d, @sdate, dupdatetime) = 0 and o.iTradingStatus <> 12 and o.iTradingStatus <> 13
		group by t.iTraddingId) as tb
		
		return ISNULL(@count, 0)
	end
	
	return 0
END	

