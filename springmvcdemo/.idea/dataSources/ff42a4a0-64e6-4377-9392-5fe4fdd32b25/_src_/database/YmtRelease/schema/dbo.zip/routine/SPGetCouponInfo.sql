-- =============================================          
-- Author:  cpx      
-- Create date: 2014-8-8       
-- Description: 获取优惠券详情          
-- =============================================    
CREATE PROCEDURE [dbo].[SPGetCouponInfo]  
	@CouponCode VARCHAR(50),
	@Amount DECIMAL(18,2)
AS  
BEGIN
    SET NOCOUNT ON
    SET LOCK_TIMEOUT 1000
	
	SELECT Coupon.sCouponCode,CSetting.iCouponUseType,Coupon.iCouponType,Coupon.dValidStart,Coupon.dValidEnd
	,CValue.fMinOrderValue,CValue.fCouponValue,CSetting.iMaxUseTimePerUser,Coupon.iCouponSetting
	,ISNULL(ISNULL(CPrivateCBound.iCouponUsedCount,CPublicBound.iCouponUsedCount),0) AS iCouponUsedCount
	INTO #CouponList
	FROM Ymt_Coupon Coupon WITH(NOLOCK)		
		JOIN Ymt_CouponSetting CSetting WITH(NOLOCK) ON Coupon.iCouponSetting = CSetting.iCouponSettingId
		JOIN Ymt_CouponValue CValue WITH(NOLOCK) ON Coupon.iCouponSetting = CValue.iCouponSettingId
		LEFT JOIN Ymt_CouponPrivateUserBound CPrivateCBound WITH(NOLOCK) ON Coupon.sCouponCode = CPrivateCBound.sCouponCode
		LEFT JOIN Ymt_CouponPublicUsed CPublicBound WITH(NOLOCK) ON Coupon.sCouponCode = CPublicBound.sCouponCode
	WHERE Coupon.sCouponCode=@CouponCode
		  AND CValue.fMinOrderValue <= @Amount
		  		 	
    SELECT * FROM #CouponList cl WHERE EXISTS(
    SELECT 1 FROM (SELECT sCouponCode,MAX(fCouponValue) AS fCouponValue FROM #CouponList GROUP BY sCouponCode) coupon 
     WHERE coupon.sCouponCode=cl.sCouponCode AND coupon.fCouponValue=cl.fCouponValue)
     
    DROP TABLE #CouponList
    SET NOCOUNT OFF
END