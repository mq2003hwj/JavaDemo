-- ============================================= 
-- Author: zhangzhiqiang 
-- Create date: 2015-04-20 
-- Description: 同步商品关税和运费到订单中 
-- ============================================= 
CREATE PROCEDURE [dbo].[sp_SyncOrderInfo] 
AS 
BEGIN 
SET NOCOUNT ON 
SET LOCK_TIMEOUT 8000 

UPDATE oi SET oi.iTariffType=p.iTariffType,oi.fFlight=p.fFlight FROM Ymt_OrderInfo oi INNER JOIN Ymt_Products p on oi.sProductId=p.sProductId 
WHERE oi.iTariffType IS NULL AND EXISTS(SELECT 1 FROM Ymt_Orders o where o.iOrderId=oi.iOrderId AND o.bShangouOrder = 0) 

SET NOCOUNT OFF 
END
