CREATE VIEW dbo.View_ProductsCatalogs
AS
SELECT     dbo.Ymt_Catalogs.*, dbo.Ymt_Products.iCategoryId AS Expr2, dbo.Ymt_Products.iBrandId AS Expr3, dbo.Ymt_Products.sProduct AS Expr4, 
                      dbo.Ymt_Products.iAttention, dbo.Ymt_Products.dLastUpdate, dbo.Ymt_Products.iSellNum, dbo.Ymt_Products.sRefUrl, dbo.Ymt_Products.dAddTime AS Expr1, 
                      dbo.Ymt_Products.mDescriptEn, dbo.Ymt_Products.mDescript, dbo.Ymt_Products.sPrice, dbo.Ymt_Products.sProductEn
FROM         dbo.Ymt_Catalogs INNER JOIN
                      dbo.Ymt_Products ON dbo.Ymt_Catalogs.sProductId = dbo.Ymt_Products.sProductId
