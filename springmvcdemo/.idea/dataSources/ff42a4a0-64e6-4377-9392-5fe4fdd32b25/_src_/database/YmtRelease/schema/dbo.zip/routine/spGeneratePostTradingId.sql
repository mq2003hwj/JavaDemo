

-- =============================================            
-- Author:  zhangzhiqiang 
-- Create date: 2015-05-14
-- Description: 创建一个补款交易号      
-- =============================================     
CREATE PROCEDURE [dbo].[spGeneratePostTradingId]
	 
AS
BEGIN
	INSERT INTO Ymt_AutoPostTradingIds DEFAULT VALUES
	
	IF @@ERROR > 0
		Return -1
		
	RETURN SCOPE_IDENTITY()+300000000
END
