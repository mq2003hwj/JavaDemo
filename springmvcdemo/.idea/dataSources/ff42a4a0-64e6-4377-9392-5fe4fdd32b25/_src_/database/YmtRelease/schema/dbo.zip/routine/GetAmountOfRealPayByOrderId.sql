

CREATE FUNCTION [dbo].[GetAmountOfRealPayByOrderId]
(	
	@orderId int
)
RETURNS float
AS

BEGIN
	--DECLARE @orderId int
	--SET @orderId = 100005813
	DECLARE @PostPay float, 
			@Refund float,
			@OrderTotal float,
			@result float,
			@PostPayCount int,
			@RefundCount int
	SET @PostPay = 0;
	SET @Refund = 0;
	SET @OrderTotal = 0;
	SET @result = 0;
	
	SET @OrderTotal =   (
							SELECT (fFreight + fOrderPrice + fDiscount + fOrderDiscount) AS Total 
							FROM dbo.Ymt_Orders where iOrderId=@orderId
						)

    SET @PostPayCount =    (
								SELECT count(*) FROM dbo.Ymt_OrderPostPay 
								where iOrderId=@orderId
							)
	--Select @PostPayCount as postPayCount
	--SELECT * FROM dbo.Ymt_OrderPostPay 
	--where iOrderId=@orderId and iAction=1
	
	IF @PostPayCount > 0 
		SET @PostPay =  (
							SELECT SUM(fAmount) AS PostPay 
							FROM dbo.Ymt_OrderPostPay 
							where iOrderId=@orderId and iAction=1
						)

    SET @RefundCount =    (
								SELECT count(*) FROM dbo.Ymt_RefundRecord 
								where iOrderId=@orderId
							)
	IF @RefundCount > 0 
		SET @Refund =  (
							SELECT SUM(fAmount) AS Refund 
							FROM dbo.Ymt_RefundRecord
							where iOrderId=@orderId
						)
	SET @result = @OrderTotal + @PostPay - @Refund
	--SELECT @OrderTotal as OrderTotal
	--SELECT @PostPay as PostPay
	--SELECT @Refund as refund
	--SELECT @result as result
	return @result;
END	




