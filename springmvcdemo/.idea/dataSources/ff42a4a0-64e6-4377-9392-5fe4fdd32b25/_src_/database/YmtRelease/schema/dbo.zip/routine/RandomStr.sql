CREATE proc dbo.RandomStr

 @RandomStr varchar(8) output

as

BEGIN

 declare @s varchar(60)  

 declare @r VARCHAR(8)  

 declare @pos int

 declare @len int

 set @s = 'ABCDEFGHJKMNPQRSTUVWXY123456789'  

 set @len = len(@s);

 set @r = ''  

   

 while len(@r) < 8  

 begin  

  set @pos = cast(rand()*100 as int);

  while @pos > @len or @pos <1

  begin

   if(@pos < 1)

    set @pos = cast(rand()*100 as int);

   else

    set @pos = cast(@pos /2 as int);

  end

  set @r = @r + substring(@s, @pos, 1)

 end  

set @RandomStr = @r

END