CREATE PROCEDURE [dbo].[spMsProductPrivilege]
	@userid int,
	@productid varchar(36)
AS
BEGIN
	if (exists(select 1 from ( 
			select 'ffed46f3-df87-4a31-8b88-6d2fee64cb5a' as msProductId
			union select '874a596d-d4bd-43b2-8842-e9f3d4ab70af' as msProductId
			union select 'b1e76775-896b-43c6-a119-8283979ca53d' as msProductId
			union select '5eeb6eaf-f2ad-46b0-b7fb-7520c6c39c40' as msProductId
			union select 'b60d643d-f459-45b0-9d28-6af5d4c7a3a6' as msProductId
			union select '7447d01c-0291-4bfb-b78c-a129f2393aa4' as msProductId
			union select '59cc0fbf-12ef-4b84-8c82-a1d79c41e22d' as msProductId
			union select '8328021d-e888-4184-a0d1-7e645a2746b6' as msProductId
			union select '5675af93-f761-46be-b121-0860d9811f47' as msProductId
			union select '22909a9b-baff-4e25-977c-3848273bfb70' as msProductId
			union select '53109f3f-af4f-49b0-9e18-8da53dfc2ac9' as msProductId
			union select 'a9fb50d4-3dbf-4fcb-8a10-61a9be80b861' as msProductId
			union select '45a35627-f0a4-4a03-bf14-aa4dd16a6820' as msProductId
			union select '6ef7c058-99b5-41ee-8e99-8a6fffa4db45' as msProductId
			union select 'd91e3899-b4d3-4afd-8fef-53b64d1889df' as msProductId
			union select 'bfe68627-4069-4c5e-8597-5577271ec0e4' as msProductId
			union select 'b2d793fe-4ddf-4f4a-a75c-a774b6d58a45' as msProductId
			union select 'fa94a72b-72f7-4193-ba22-457f6bc65e0c' as msProductId
			) as msTable 
			where msProductId = @productid) 
		and
		-- 不存在特权表中
	 (not exists(select 1 from Ymt_ProductPrivilege(nolock) where sProductId=@productid and iUserId=@userid)))
	begin	
	
		INSERT INTO Ymt_ProductPrivilege (iUserId ,sProductId,sUserLoginId) VALUES (@UserId,@ProductId,'MSProductPrivilege')	
	end
END