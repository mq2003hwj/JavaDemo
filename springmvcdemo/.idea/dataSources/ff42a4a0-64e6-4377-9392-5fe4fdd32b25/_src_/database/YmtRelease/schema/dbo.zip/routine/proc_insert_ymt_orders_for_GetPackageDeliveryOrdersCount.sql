create proc proc_insert_ymt_orders_for_GetPackageDeliveryOrdersCount(@orderId int, @buyerId int, @bDomesticDelivered int)
as
    if(@bDomesticDelivered=0)
    begin

     insert [YmtRelease].[dbo].[Ymt_Orders] ([iOrderId], [iUserId], [iBuyerId], [sMarkId], [dAddTime], [fOrderPrice], 
[fOrderDiscount], [fFreight], [fDiscount], [iTradingId], [iTradingStatus], [iOperate], [dOperateExpireTime], [sAddress],
 [sPostCode], [sReceivePerson], [sPhone], [sTelephone], [sQQ], [sEmail], [sLeaveWord], [iUnfreezeStatus], [dDispathTime], 
 [iTopicId], [sTitle], [iReplyTopicWhenOrderPaid], [bPaidInFull], [fUseGiftAmount], [sCouponCode], [CouponValue], [iCouponType], 
 [dPaidTime], [dApplyPostPayTime], [dPostPaidTime], [dConfirmedTime], [dChangeAddressTime], [iDistributor], [sThirdOrderId], 
 [iType], [fOldFreight], [dDiscountTime], [fOldDiscount], [fAutoCancelOrderHours], [dCancelTime], [bShangouOrder], 
 [sBuyerLoginId], [sBuyerLoginEmail], [sSellerLoginId], [sSellerLoginEmail], [iIsMerchant], [sBuyerNickName], [fTotalPrice], 
 [fUseFreeCardAmount], [sHostRef], [bIncludeActivityProducts], [bShippedByXlobo], [dAcceptTime], [sCurType], [bCanLocalReturn], 
 [bApplyLocalReturn], [dApplyLocalReturnTime], [iRiskVerifiedStatus], [dLastUpdateTime], [iThirdPartyRefundStatus],
  [iCouponChannel], [iSalesRefundStatus], [bPackageDelivery_DomesticDelivered], [bDomesticDelivered]) 
  values (cast(@orderId as int),cast(786476 as int),cast(@buyerId as int),cast('' as varchar(36)),cast('2014-11-29 09:51:32.907' as datetime),
  cast(110.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),NULL,
  cast(3 as int),NULL,NULL,cast('上海市,上海市,徐汇区,测试地址' as varchar(Max)),cast('200093' as varchar(10)),cast('张*****' as varchar(50)),
  cast('13800000000' as varchar(20)),cast('' as varchar(20)),cast('' as varchar(20)),cast('automation@ymatou.com' as varchar(500)),
  cast('要红色' as nvarchar(Max)),cast(0 as int),cast('2014-12-02 11:20:33.530' as datetime),1,NULL,NULL,cast(1 as bit),
  cast(20.00 as decimal(18, 2)),NULL,NULL,NULL,cast('2014-11-29 09:51:48.490' as datetime),cast('2014-12-01 14:32:59.397' as datetime),
  cast('2014-12-01 17:57:06.477' as datetime),cast('2014-12-13 19:47:09.997' as datetime),NULL,cast(1 as int),NULL,cast(0 as int),
  NULL,NULL,NULL,cast(0.16 as decimal(18, 2)),NULL,cast(1 as bit),cast('786475.weibo' as nvarchar(400)),
  cast('automation@ymatou.com' as nvarchar(400)),cast('shanexili' as nvarchar(400)),cast('automation@ymatou.com' as nvarchar(400)),
  cast(0 as int),cast('786475.weibo' as nvarchar(400)),cast(368.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),
  cast('APIORDER129' as varchar(100)),cast(1 as bit),cast(1 as bit),cast('2014-12-01 08:54:15.610' as datetime),
  cast('CNY' as varchar(50)),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
  end
  else
	begin
	
     insert [YmtRelease].[dbo].[Ymt_Orders] ([iOrderId], [iUserId], [iBuyerId], [sMarkId], [dAddTime], [fOrderPrice], 
[fOrderDiscount], [fFreight], [fDiscount], [iTradingId], [iTradingStatus], [iOperate], [dOperateExpireTime], [sAddress],
 [sPostCode], [sReceivePerson], [sPhone], [sTelephone], [sQQ], [sEmail], [sLeaveWord], [iUnfreezeStatus], [dDispathTime], 
 [iTopicId], [sTitle], [iReplyTopicWhenOrderPaid], [bPaidInFull], [fUseGiftAmount], [sCouponCode], [CouponValue], [iCouponType], 
 [dPaidTime], [dApplyPostPayTime], [dPostPaidTime], [dConfirmedTime], [dChangeAddressTime], [iDistributor], [sThirdOrderId], 
 [iType], [fOldFreight], [dDiscountTime], [fOldDiscount], [fAutoCancelOrderHours], [dCancelTime], [bShangouOrder], 
 [sBuyerLoginId], [sBuyerLoginEmail], [sSellerLoginId], [sSellerLoginEmail], [iIsMerchant], [sBuyerNickName], [fTotalPrice], 
 [fUseFreeCardAmount], [sHostRef], [bIncludeActivityProducts], [bShippedByXlobo], [dAcceptTime], [sCurType], [bCanLocalReturn], 
 [bApplyLocalReturn], [dApplyLocalReturnTime], [iRiskVerifiedStatus], [dLastUpdateTime], [iThirdPartyRefundStatus],
  [iCouponChannel], [iSalesRefundStatus], [bPackageDelivery_DomesticDelivered], [bDomesticDelivered]) 
  values (cast(@orderId as int),cast(786476 as int),cast(@buyerId as int),cast('' as varchar(36)),cast('2014-11-29 09:51:32.907' as datetime),
  cast(110.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),NULL,
  cast(3 as int),NULL,NULL,cast('上海市,上海市,徐汇区,测试地址' as varchar(Max)),cast('200093' as varchar(10)),cast('张*****' as varchar(50)),
  cast('13800000000' as varchar(20)),cast('' as varchar(20)),cast('' as varchar(20)),cast('automation@ymatou.com' as varchar(500)),
  cast('要红色' as nvarchar(Max)),cast(0 as int),cast('2014-12-02 11:20:33.530' as datetime),1,NULL,NULL,cast(1 as bit),
  cast(20.00 as decimal(18, 2)),NULL,NULL,NULL,cast('2014-11-29 09:51:48.490' as datetime),cast('2014-12-01 14:32:59.397' as datetime),
  cast('2014-12-01 17:57:06.477' as datetime),cast('2014-12-13 19:47:09.997' as datetime),NULL,cast(1 as int),NULL,cast(0 as int),
  NULL,NULL,NULL,cast(0.16 as decimal(18, 2)),NULL,cast(1 as bit),cast('786475.weibo' as nvarchar(400)),
  cast('automation@ymatou.com' as nvarchar(400)),cast('shanexili' as nvarchar(400)),cast('automation@ymatou.com' as nvarchar(400)),
  cast(0 as int),cast('786475.weibo' as nvarchar(400)),cast(368.00 as decimal(18, 2)),cast(0.00 as decimal(18, 2)),
  cast('APIORDER129' as varchar(100)),cast(1 as bit),cast(1 as bit),cast('2014-12-01 08:54:15.610' as datetime),
  cast('CNY' as varchar(50)),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,@bDomesticDelivered)
	end
