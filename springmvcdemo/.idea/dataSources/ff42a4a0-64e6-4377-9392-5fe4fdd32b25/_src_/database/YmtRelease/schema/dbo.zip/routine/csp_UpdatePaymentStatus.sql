
create proc csp_UpdatePaymentStatus

(

	@PaymentId	 varchar(64),

	@PaymentStatus int,

	@SettlementCurrency varchar(16),

	@SettlementAmount decimal,

	@SettlementRate	float,

	@Fee decimal,

	@Memo	varchar(2048),
	@ReturnValue int output

)

as

begin

	if @PaymentId is null

		raiserror('error payment id',11,1)
	declare @CurrentStatus int
	select @CurrentStatus=PaymentStatus from dbo.PaymentOrder(updlock)
		where PaymentId=@PaymentId
	
	if @CurrentStatus=1
		set @ReturnValue=-1

	update dbo.PaymentOrder set PaymentStatus=@PaymentStatus,

	UpdateTime=GETDATE(),PaymentTime=getdate(),SettlementCurrency=@SettlementCurrency,SettlementAmount=@SettlementAmount,SettlementRate=@SettlementRate,

	Memo=@Memo,Fee=@Fee

	 where PaymentId=@PaymentId and PaymentStatus!=1

	set @ReturnValue=@@ROWCOUNT

end
