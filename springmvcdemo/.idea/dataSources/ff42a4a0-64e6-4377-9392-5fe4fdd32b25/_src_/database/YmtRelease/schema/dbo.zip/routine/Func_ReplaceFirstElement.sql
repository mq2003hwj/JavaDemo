CREATE function Func_ReplaceFirstElement
(
    @result varchar(500), --被替换第一个元素的字符串
	@elment varchar(20) --替换字符串
)
returns varchar(500)
as
begin
   declare @newresult varchar(500)
   declare @lastcharindex int
   set @newresult=LTRIM(rtrim(@result))
   set @lastcharindex=LEN(@newresult)-CHARINDEX(',',Reverse(@newresult))+1
   set @newresult= @elment+','+SUBSTRING(@newresult,0,@lastcharindex)
   return @newresult
end