
-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-1
-- Description: 交易服务SP       
-- 20160819：取消根据风控状态做的特殊查询逻辑   
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrdersListV2]

@sellerId int,
@orderSellerAcceptedStatus int,
@orderStatusXml xml,
@lastOrderId int,
@paidInFull bit,
@timeFrom datetime,
@timeTo datetime,
@top int,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit

AS

-------------variables-------------
declare @orderStatus table([value] int primary key)
declare @orderIds table(id int primary key)
declare @rowCount int = 0

--------------process--------------
if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

--set statistics time on;set statistics io on;

set nocount off;
insert into @orderIds
select top(@top) iOrderId from Ymt_Orders(nolock) o where iBuyerId = @sellerId and bShangouOrder = 1
and (
	(@paidInFull is not null and (o.iTradingStatus = @orderSellerAcceptedStatus and o.bPaidInFull = @paidInFull))
	or (@orderStatusXml is not null and o.iTradingStatus in (select [value] from @orderStatus))
)
/*
and (
  @paidInFull is null and @considerOrderStatus = 0
  or
  @paidInFull is not null and (o.iTradingStatus = @orderSellerAcceptedStatus and o.bPaidInFull = @paidInFull)
  or 
  (
    @considerOrderStatus = 0 and 1 < 0
    or @considerOrderStatus = 1 and
    (
      (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
        or
      (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
        or
      (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
    )
  )
)*/
and (@timeFrom is null or dAddTime >= @timeFrom and dAddTime < @timeTo)
and (@lastOrderId = 0 or iOrderId < @lastOrderId)
order by iOrderId desc
set @rowCount = @@ROWCOUNT;

set nocount on;

select iOrderId,iUserId,iTradingStatus,dAddTime,sBuyerLoginId,sLeaveWord,fTotalPrice,bPaidInFull,iRiskVerifiedStatus from Ymt_Orders(nolock) where @rowCount > 0 and iOrderId in (select id from @orderIds) order by iOrderId desc

select iOrderId,sPictureUrl,sPropertyInfo,sProductId,fOriginalPrice,sTitle,iAmount,iPriceType from Ymt_OrderInfo(nolock) where @rowCount > 0 and iOrderId in (select id from @orderIds) order by iOrderId desc

set nocount off;

--set statistics time off;set statistics io off;

