
-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-1
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderCount]

@sellerId int,
@isShangouOrder bit,
@beginTime datetime,
@endTime datetime,
@orderStatusXml xml,
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit

AS

-------------variables-------------
declare @orderStatus table([value] int);

if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end;

/*if @considerRiskVerfiedStatus = 0 begin*/
  select iTradingStatus, bPaidInFull, COUNT(iOrderId) as orderCount
  from Ymt_Orders(nolock) o
  where iBuyerId = @sellerId
  and (@beginTime is null or dAddTime >= @beginTime)
  and (@endTime is null or dAddTime <= @endTime)
  and (@isShangouOrder is null or bShangouOrder = @isShangouOrder)
  and (@orderStatusXml is null or iTradingStatus in (select value from @orderStatus))
  group by iTradingStatus, bPaidInFull
/*end else begin
  select case 
  when (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1) then 1
  when (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)) then 2
  else o.iTradingStatus end as iTradingStatus
  ,bPaidInFull, COUNT(iOrderId) as orderCount
  from Ymt_Orders(nolock) o
  where iBuyerId = @sellerId
  and (@beginTime is null or dAddTime >= @beginTime)
  and (@endTime is null or dAddTime <= @endTime)
  and (@isShangouOrder is null or bShangouOrder = @isShangouOrder)
  and (@considerOrderStatus = 0 or --iTradingStatus in (select value from @orderStatus)
    (
      (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
      or
      (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
      or
      (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
    )
  )
  group by case 
  when (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1) then 1
  when (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)) then 2
  else o.iTradingStatus end
  , bPaidInFull
end
*/

