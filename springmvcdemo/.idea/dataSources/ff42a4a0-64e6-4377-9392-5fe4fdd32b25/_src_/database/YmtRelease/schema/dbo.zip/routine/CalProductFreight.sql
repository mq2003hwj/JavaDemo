-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION CalProductFreight
(
	@Weight DECIMAL,
	@TemplateCategory INT,
	@StartStandard DECIMAL,
	@StartFee DECIMAL,
	@AddStandard DECIMAL,
	@AddFee DECIMAL
)
RETURNS Decimal
AS
BEGIN
	
	DECLARE @Freight DECIMAL;

	IF(@TemplateCategory = 1) 
		BEGIN
			-- 按件
			SET @Freight = @StartFee;
		END
	ELSE
		BEGIN
			-- 按重
			DECLARE @leftWeight DECIMAL;
			SET @leftWeight = @Weight - @StartStandard;
			IF @leftWeight < 0
			BEGIN
			   SET @leftWeight = 0;
			END          

			SET @Freight = @StartFee + CEILING(@leftWeight/@AddStandard) * @AddFee;
		END
  RETURN  @Freight;
END
