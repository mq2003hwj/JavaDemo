

CREATE PROCEDURE [dbo].[SP_CreateCouponBatch]

@UserId INT,
@UserType INT,
@SellerIds NVARCHAR(2000) ,
@LogisticsTypes NVARCHAR(255),
@StockStatus NVARCHAR(255),
@ProductCategories NVARCHAR(255),
@SpecificProducts NVARCHAR(2000),
@ProductBrands NVARCHAR(255),
@ActivityIds VARCHAR(500),
@UserLevels VARCHAR(100),
@UsePlatforms VARCHAR(100),
@CouponUseType INT,
@MaxUseTime INT,
@MaxUseTimePerUser INT,
@ValidStart DATETIME,
@ValidEnd DATETIME,
@ApplyUser NVARCHAR(50),
@ApplyMemo NVARCHAR(200),
@IsMobileVerify BIT,
@CouponUseCount INT,
@ReceiveCount  INT,
@EffectiveType INT,
@EffectiveValidType INT,
@EffectiveDays INT,
@ScenarioType INT = 1,
@couponValues VARCHAR(1000),
@SendType INT,
@BatchCreateType INT,
@CouponName NVARCHAR(50),
@BatchPrefix VARCHAR(50),
@OutputBatchCode VARCHAR(36) output,
@OutputCode INT output,
@OutputMsg NVARCHAR(500) output
AS
BEGIN

BEGIN TRY

IF NOT EXISTS(SELECT 1 FROM dbo.Ymt_Users WITH(NOLOCK) WHERE iUserId=@UserId AND iType=1)
BEGIN
	SELECT @OutputCode=-9,@OutputMsg=N'卖家ID不存在'
	RETURN;
END

SELECT @OutputBatchCode=''
DECLARE @dSysDate DATETIME = GETDATE(),@iCouponScenarioId INT = 0,@iCouponSettingId INT = 0,@iBatchId INT = 0

--开启事务
BEGIN TRAN

--创建使用场景
INSERT INTO dbo.Ymt_CouponScenario (iUserType,sSellerIds,sLogisticsTypes,sStockStatus,sProductCategories,
                                     sSpecificProducts,sProductBrands,sActivityIds,sUserLevels,sUsePlatforms)
SELECT @UserType,@SellerIds,@LogisticsTypes,@StockStatus,@ProductCategories,@SpecificProducts,@ProductBrands,@ActivityIds,@UserLevels,@UsePlatforms
--获取使用场景ID
SELECT @iCouponScenarioId=SCOPE_IDENTITY()

--创建优惠券设置
INSERT INTO dbo.Ymt_CouponSetting (iScenarioId,iCouponUseType,iMaxUseTime,iMaxUseTimePerUser,dValidStart,dValidEnd,sApplyUser,sApplyMemo,bIsMobileVerify,
                                    iUseTotalCount,iCouponUseCount,iReceiveCount,iEffectiveType,iEffectiveValidType,iEffectiveDays,iScenarioType)
SELECT @iCouponScenarioId,@CouponUseType,@MaxUseTime,@MaxUseTimePerUser,@ValidStart,@ValidEnd,@ApplyUser,@ApplyMemo,@IsMobileVerify
      ,@MaxUseTime,@CouponUseCount,0,@EffectiveType,@EffectiveValidType,@EffectiveDays,@ScenarioType
--获取优惠券设置ID
SELECT @iCouponSettingId=SCOPE_IDENTITY()

--创建优惠券面值信息
INSERT INTO dbo.Ymt_CouponValue (fMinOrderValue,fCouponValue,iCouponSettingId)
SELECT LEFT(col,CHARINDEX('|',col)-1) fMinOrderValue,SUBSTRING(col,CHARINDEX('|',col)+1,LEN(col)) fCouponValue,@iCouponSettingId FROM dbo.Split(@couponValues,',')


--创建优惠券批次信息
INSERT INTO dbo.Ymt_CouponBatch (sBatchCode,iCouponTotalNum,iCouponNumPerUser,iOperatorId,iCouponSettingId,dExpiredDate,iSendType,dAddTime,iUsage,iBatchCreateType,sCouponName,sBatchPrefix)
SELECT '',@MaxUseTime,@MaxUseTimePerUser,@UserId,@iCouponSettingId,@dSysDate,@SendType,@dSysDate,1,@BatchCreateType,@CouponName,@BatchPrefix

SELECT @iBatchId=SCOPE_IDENTITY()

--更新优惠券批次号
SELECT @OutputBatchCode=RIGHT(CONVERT(VARCHAR(8),@dSysDate,112),6)+RIGHT(CAST(@iBatchId AS VARCHAR(36)),4)

--SELECT @OutputBatchCode=RIGHT(CONVERT(VARCHAR(8),@dSysDate,112),6)+CAST(@iBatchId AS VARCHAR(36))

UPDATE Ymt_CouponBatch SET sBatchCode=@OutputBatchCode WHERE iBatchId=@iBatchId
--提交事务
COMMIT
SELECT @OutputCode=0 
END TRY	
BEGIN CATCH
	ROLLBACK
	SELECT @OutputBatchCode='',@OutputCode=ERROR_NUMBER(),@OutputMsg=ERROR_MESSAGE()
END CATCH
END


