Create function fn_getminFQuotePrice_from_App_Catalog
(
@productid varchar(50)
)
returns decimal(18,2)
as
begin

declare @fQuotePrice decimal(18,2)

select @fQuotePrice = min(fQuotePrice) from ymt_Catalogs with (Nolock) where sProductId = @productid

return @fQuotePrice

end