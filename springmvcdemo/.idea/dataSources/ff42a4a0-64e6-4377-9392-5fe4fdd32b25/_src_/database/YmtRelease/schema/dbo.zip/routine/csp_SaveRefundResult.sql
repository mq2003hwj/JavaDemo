
create proc csp_SaveRefundResult
(
	@RefundProcessId uniqueidentifier,
	@TradeNo varchar(64),
	@ProcessStatus int
)
as
begin
	if (@RefundProcessId is null) and (@TradeNo is null)
		raiserror('处理号和交易号不能同时为空',11,1)
	if @RefundProcessId is not null
		update dbo.RefundProcessInfo
		set RetryCount=RetryCount+1,
			ProcessMachineName=null,
			ProcessStatus=@ProcessStatus,
			LastProcessedTime=getdate()
				where RefundProcessId=@RefundProcessId
	else
		update dbo.RefundProcessInfo
		set ProcessMachineName=null,
			ProcessStatus=@ProcessStatus,
			LastProcessedTime=getdate()
				where TradeNo=@TradeNo
				and ProcessStatus not in (-2,3)
end

