create function fn_Split

(

  @Input varchar(max), 

  @Separator varchar(10)  

)

RETURNS TABLE

    AS

RETURN

    ( SELECT    B.id

      FROM      ( SELECT    [value] = CONVERT(XML , '<v>' + REPLACE(@Input , @Separator , '</v><v>')

                            + '</v>')

                ) A

      OUTER APPLY ( SELECT  id = N.v.value('.' , 'varchar(64)')

                    FROM    A.[value].nodes('/v') N ( v )

                  ) B

    )

