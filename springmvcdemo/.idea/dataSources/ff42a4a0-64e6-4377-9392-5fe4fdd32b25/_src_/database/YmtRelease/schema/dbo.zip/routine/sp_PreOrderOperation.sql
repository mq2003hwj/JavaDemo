-- =============================================
-- Author:		许秀雷
-- Create date: 2016-05-08
-- Description:	预下单日志操作
-- =============================================
CREATE PROCEDURE [dbo].[sp_PreOrderOperation] 
	@PreOrderId INT,
	@OrderId INT,
	@PreOrderStatus INT,
	@RepeatCount INT,
	@ReturnCatalogData VARCHAR(2000)
AS
BEGIN
	IF @PreOrderId>0
	BEGIN	
		UPDATE Ymt_MulteCatalogPreOrderLog SET OrderId=@OrderId,PreOrderStatus=@PreOrderStatus,RepeatCount=@RepeatCount,UpdateTime=GETDATE(),[ReturnCatalogData]=@ReturnCatalogData WHERE PreOrderId=@PreOrderId
		SELECT @PreOrderId
	END
	ELSE
	BEGIN
		INSERT INTO Ymt_MulteCatalogPreOrderLog ([OrderId],[PreOrderStatus],[RepeatCount],[CreateTime],[UpdateTime],[ReturnCatalogData]) 
		VALUES (@OrderId,@PreOrderStatus,0,GETDATE(),GETDATE(),@ReturnCatalogData)
		SELECT @@IDENTITY
	END
END
