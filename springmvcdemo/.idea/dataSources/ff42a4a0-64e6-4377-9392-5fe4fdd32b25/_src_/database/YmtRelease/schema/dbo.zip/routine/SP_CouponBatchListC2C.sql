
-- =============================================
-- Author:		zhangzhiqiang
-- Create date: 2015-11-29
-- Description:	查询优惠券批次列表C2C
-- =============================================
CREATE PROCEDURE [dbo].[SP_CouponBatchListC2C]
	@BatchCreateType INT,
	@BatchStatus INT,
	@SellerId INT,
	@PageSize INT,
	@CurPage INT
AS
BEGIN
	
	DECLARE @SQL NVARCHAR(MAX)=''
			,@StartRow INT
			,@EndRow INT
			,@param_def NVARCHAR(MAX)=N'@BatchCreateType INT,@SellerId INT'

	SET @SQL='SELECT ROW_NUMBER() OVER(ORDER BY A.dAddTime DESC) RowNum
		  ,A.sBatchCode BatchCode
		  ,A.sCouponName CouponName
		  ,A.iCouponTotalNum MaxSendNum
		  ,A.iCouponNumPerUser UserMaxReceiveNum
		  ,A.dInvalidTime InvalidTime
		  ,B.iReceiveCount HaveSendNum
		  ,(B.iUseTotalCount-B.iMaxUseTime) HaveUsedNum
		  ,B.dValidStart ValidStart
		  ,B.dValidEnd ValidEnd
	  FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) INNER JOIN dbo.Ymt_CouponSetting B WITH(NOLOCK) ON A.iCouponSettingId = B.iCouponSettingId
	  WHERE 1=1'

	IF @BatchCreateType <> 0
		SET @SQL += ' AND A.iBatchCreateType = @BatchCreateType'

	IF @SellerId <> 0
		SET @SQL += ' AND A.iOperatorId = @SellerId'

	IF @BatchStatus = 1  --1-有效优惠券
		SET @SQL += ' AND B.dValidEnd >= GetDATE()'
	ELSE IF @BatchStatus = 2  --2-失效优惠券
		SET @SQL += ' AND B.dValidEnd < GetDATE()'


	--获取分页记录
	SET @StartRow = (@CurPage - 1) * @PageSize + 1
	SET @EndRow = @CurPage * @PageSize
	IF @PageSize > 0 AND @CurPage > 0
	BEGIN
		SELECT @SQL = N'SELECT * FROM (' + @SQL + ') TEMP WHERE RowNum BETWEEN @StartRow AND @EndRow'
		SELECT @param_def += N',@StartRow INT,@EndRow INT'
		EXEC sp_executesql @SQL, @param_def, @BatchCreateType, @SellerId, @StartRow, @EndRow
	END
	ELSE
	BEGIN
		EXEC sp_executesql @SQL, @param_def, @BatchCreateType, @SellerId
	END
END

