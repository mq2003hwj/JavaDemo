


-- =============================================
-- Author:		郑世领
-- Create date: 2015-8-7
-- Description:	查询投诉列表
-- =============================================
CREATE PROCEDURE [dbo].[SP_ComplaintList]
	@Status int,--表示忽略：-1
	@OrderId int,--表示忽略：-1
	@SellerType int,--表示忽略：-1
	@SellerCountry int,--表示忽略：-1
	@UpdateUserType int,--表示忽略：-1
	@AddTimeStart nvarchar(20),
	@AddTimeEnd nvarchar(20),
	@UpdateTimeStart nvarchar(20),
	@UpdateTimeEnd nvarchar(20),
	@NextFollowTimeStart nvarchar(20),
	@NextFollowTimeEnd nvarchar(20),
	@AcceptUserLoginId nvarchar(200),
	@BuyerUserLoginId nvarchar(200),
	@SellerUserLoginId nvarchar(200),
	@pageIndex int,
	@pageSize int,
	@RecordCount int output
AS
BEGIN
	SET NOCOUNT ON;
	declare @sql nvarchar(max),@sqlCount nvarchar(max),@where nvarchar(4000)=' 1=1 '
	declare @pageStartRow int,@pageEndRow int
	set @pageStartRow=(@pageIndex-1)*@pageSize+1
	set @pageEndRow=@pageStartRow+@pageSize-1
	
	if (@Status!=-1)
    begin
        set @where += ' and t0.Status=@Status'
    end
    if (@OrderId!=-1)
    begin
		set @where += ' and t0.OrderId=@OrderId'
    end
    if (len(@AcceptUserLoginId)>0)
    begin
        set @where += ' and t0.iAcceptUserLoginId=@AcceptUserLoginId'
    end
    if (len(@BuyerUserLoginId)>0)
    begin
		set @where += ' and t0.iBuyerUserLoginId like ''%'+@BuyerUserLoginId+'%'''
    end
    if (len(@SellerUserLoginId)>0)
    begin
		set @where += ' and t0.iSellerUserLoginId like ''%'+@SellerUserLoginId+'%'''
    end
    if (@SellerType != -1)
    begin
		set @where += ' and tSeller.mshop=@SellerType'
    end
    if (@SellerCountry != -1)
    begin
		set @where += ' and tSeller.iLiveCountry=@SellerCountry'
    end
    if (@UpdateUserType != -1)
    begin
		set @where += ' and t0.UpdateUserType=@UpdateUserType'
    end
    if (len(@AddTimeStart)>0)
    begin
		set @where += ' and t0.AddTime>=@AddTimeStart'
    end
	if (len(@AddTimeEnd)>0)
    begin
		set @where += ' and t0.AddTime<=@AddTimeEnd'
    end
	if (len(@UpdateTimeStart)>0)
    begin
		set @where += ' and t0.UpdateTime>=@UpdateTimeStart'
    end
	if (len(@UpdateTimeEnd)>0)
    begin
		set @where += ' and t0.UpdateTime<=@UpdateTimeEnd'
    end
	if (len(@NextFollowTimeStart)>0)
    begin
		set @where += ' and (SELECT TOP (1) [tMeg].[NextFollowTime] FROM [dbo].[CS_ComplaintMessage] AS [tMeg] WITH (NOLOCK)  WHERE ([tMeg].[iType] = 2) AND ([tMeg].[ComplaintId] = [t0].[ComplaintId]) ORDER BY [tMeg].[AddTime] DESC) >=@NextFollowTimeStart'
    end
	if (len(@NextFollowTimeEnd)>0)
    begin
		set @where += ' and (SELECT TOP (1) [tMeg].[NextFollowTime] FROM [dbo].[CS_ComplaintMessage] AS [tMeg] WITH (NOLOCK)  WHERE ([tMeg].[iType] = 2) AND ([tMeg].[ComplaintId] = [t0].[ComplaintId]) ORDER BY [tMeg].[AddTime] DESC) <=@NextFollowTimeEnd'
    end

	set @sql = N'SELECT [t2].[ComplaintId], [t2].[ComplaintTypeId], [t2].[AddTime], [t2].[iBuyerUserId], [t2].[OrderId], [t2].[Status], [t2].[Request], [t2].[Reason], [t2].[ContactPhone], [t2].[iSellerUserId], [t2].[iAcceptUserId], [t2].[AcceptTime], [t2].[Note], [t2].[ResultDescription], [t2].[ComplaintSubTypeId], [t2].[UpdateTime], [t2].[UpdateUserType], [t2].[UpdateStatusTime], [t2].[AddUserId], [t2].[iBuyerUserLoginId], [t2].[iSellerUserLoginId], [t2].[iAcceptUserLoginId]
				FROM (
					SELECT ROW_NUMBER() OVER (ORDER BY [t0].[UpdateTime] DESC) AS [ROW_NUMBER], [t0].[ComplaintId]
					FROM [dbo].[CS_Complaint] AS [t0]
					INNER JOIN [dbo].[Ymt_SellerInfo] AS [tSeller] WITH (NOLOCK) ON [tSeller].[iUserId] = [t0].[iSellerUserId]
					Where '+@where+'
					) AS [t1]
				INNER JOIN [dbo].[CS_Complaint] AS [t2] ON [t2].[ComplaintId] = [t1].[ComplaintId]
				WHERE [t1].[ROW_NUMBER] BETWEEN @pageStartRow AND @pageEndRow
				ORDER BY [t1].[ROW_NUMBER]'

	set @sqlCount = N'SELECT @RecordCount=count(t0.[ComplaintId])
				FROM [dbo].[CS_Complaint] AS [t0]
				INNER JOIN [dbo].[Ymt_SellerInfo] AS [tSeller] WITH (NOLOCK) ON [tSeller].[iUserId] = [t0].[iSellerUserId]
				Where '+@where+' '

    --print 'sql:'+@sql
	exec sp_executesql @sql,
	N'@where nvarchar(4000),@Status int,@OrderId int,@SellerType int,@SellerCountry int,@UpdateUserType int,@AddTimeStart nvarchar(20),@AddTimeEnd nvarchar(20),@UpdateTimeStart nvarchar(20),@UpdateTimeEnd nvarchar(20),@NextFollowTimeStart nvarchar(20),@NextFollowTimeEnd nvarchar(20),@AcceptUserLoginId nvarchar(200),@BuyerUserLoginId nvarchar(200),@SellerUserLoginId nvarchar(200),@pageStartRow int ,@pageEndRow int',
	@where,@Status,@OrderId,@SellerType,@SellerCountry,@UpdateUserType,@AddTimeStart,@AddTimeEnd,@UpdateTimeStart,@UpdateTimeEnd,@NextFollowTimeStart,@NextFollowTimeEnd,@AcceptUserLoginId,@BuyerUserLoginId,@SellerUserLoginId,@pageStartRow,@pageEndRow

	exec sp_executesql @sqlCount,
	N'@where nvarchar(4000),@RecordCount int output,@Status int,@OrderId int,@SellerType int,@SellerCountry int,@UpdateUserType int,@AddTimeStart nvarchar(20),@AddTimeEnd nvarchar(20),@UpdateTimeStart nvarchar(20),@UpdateTimeEnd nvarchar(20),@NextFollowTimeStart nvarchar(20),@NextFollowTimeEnd nvarchar(20),@AcceptUserLoginId nvarchar(200),@BuyerUserLoginId nvarchar(200),@SellerUserLoginId nvarchar(200),@pageStartRow int ,@pageEndRow int',
	@where,@RecordCount output,@Status,@OrderId,@SellerType,@SellerCountry,@UpdateUserType,@AddTimeStart,@AddTimeEnd,@UpdateTimeStart,@UpdateTimeEnd,@NextFollowTimeStart,@NextFollowTimeEnd,@AcceptUserLoginId,@BuyerUserLoginId,@SellerUserLoginId,@pageStartRow,@pageEndRow

END

