-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateBrandDescript] 
	-- Add the parameters for the stored procedure here
	@sourceId int,
	@updateId int
AS
BEGIN
	if(@sourceid<>@Updateid)
	begin
	update ymt_productbrand set mbranddescript=(select mbranddescript from ymt_productbrand where ibrandid=@sourceid) 
	where ibrandid=@updateId
	insert into ymt_pictures(itype,stitle,skey,surl,soriname,sfilename,mdescript,daddtime,iaction)
	select itype,stitle,@updateid,surl,soriname,sfilename,mdescript,getdate(),iaction from ymt_pictures where skey=@sourceid and itype=1
	end
END
