


-- =============================================
-- Author:		zhujinfeng
-- Create date: 2015-02-26
-- Description:	取用户所有优惠券列表
-- =============================================
CREATE PROCEDURE [dbo].[SP_CouponListByUser] 
	@BuyerUserId INT,
	@CouponState INT
AS
BEGIN
	
	SET NOCOUNT ON;

	SELECT a.sCouponCode, a.iCouponType, dbo.FUNC_MargeCouponValue(a.iCouponSetting) AS CouponValue, c.iCouponUseType, 
		a.dValidStart, a.dValidEnd, f.iCouponUsedCount, e.sUsePlatforms, f.dAddTime,e.iUserType,e.sActivityIds,e.sLogisticsTypes,e.sProductBrands,e.sProductCategories,
		e.sSellerIds,e.sSpecificProducts,e.sUserLevels,b.sCouponName,B.iBatchCreateType,
		case when iCouponUsedCount>0 AND a.dValidStart<=GETDATE() AND a.dValidEnd>=GETDATE() then 1 
			when iCouponUsedCount>0 AND a.dValidStart>GETDATE() then 2
			when iCouponUsedCount=0 then 3
			when iCouponUsedCount>0 AND a.dValidStart<=a.dValidEnd AND a.dValidEnd<GETDATE() then 4 else 5 END AS iUseState
    INTO #temp
	FROM Ymt_Coupon a 
		LEFT JOIN Ymt_CouponBatch b ON a.iBatchId = b.iBatchId
		LEFT JOIN Ymt_CouponSetting c ON a.iCouponSetting = c.iCouponSettingId
		LEFT JOIN Ymt_CouponScenario e ON c.iScenarioId = e.iCouponScenarioId
		inner JOIN Ymt_CouponPrivateUserBound f ON a.sCouponCode = f.sCouponCode
	WHERE f.iUserId = @BuyerUserId

	IF @CouponState=1		--可使用
		SELECT *,row_number() over(partition by iUseState order by iBatchCreateType,dAddTime desc) as rounum FROM #temp WHERE iUseState=1 
	ELSE IF @CouponState=2	--未生效
		SELECT *,row_number() over(partition by iUseState order by iBatchCreateType,dAddTime desc) as rounum FROM #temp WHERE iUseState=2 
	ELSE IF @CouponState=3	--已使用
		SELECT *,row_number() over(partition by iUseState order by iBatchCreateType,dAddTime desc) as rounum FROM #temp WHERE iUseState=3 
	ELSE IF @CouponState=4	--已过期
		SELECT *,row_number() over(partition by iUseState order by iBatchCreateType,dAddTime desc) as rounum FROM #temp WHERE iUseState=4 
	---ELSE IF @CouponState=5	--已作废
		---SELECT * FROM #temp WHERE dValidEnd<dValidStart ORDER BY dAddTime DESC
	ELSE
		SELECT *,row_number() over(partition by iUseState order by iBatchCreateType,dAddTime desc) as rounum FROM #temp WHERE iUseState!=5
END





