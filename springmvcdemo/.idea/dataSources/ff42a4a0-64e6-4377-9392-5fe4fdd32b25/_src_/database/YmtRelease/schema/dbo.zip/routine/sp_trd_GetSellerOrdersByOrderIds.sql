

-- =============================================            

-- Author:  fanwei        

-- ALTER date: 2016-2-17

-- Description: 通过订单ID获取卖家订单信息       

-- =============================================



CREATE PROCEDURE sp_trd_GetSellerOrdersByOrderIds

@orderIds Int32Array READONLY,

@sellerId int = null

AS BEGIN



--------------process--------------



--set statistics time on;set statistics io on;



set nocount on;



select o.*,

(select top 1 RefundAmount from ymt_refundbill with(nolock,ForceSeek) where orderid=o.iorderid) as TotalSalesRefundAmount 

from Ymt_Orders o with(nolock,ForceSeek)

where o.iOrderId in (select [Value] from @orderIds) 



if @@ROWCOUNT < 1 return 0;



--获取评价列表  

select * from Ymt_CreditDetail(nolock) where stargetid in (select cast([Value] as varchar(36)) from @orderIds) 



--获取备注列表

if @sellerId is null begin

  select iOrderId,sContent from Ymt_O_OrderNote(nolock) where iorderid in (select [Value] from @orderIds)

end

else begin

  select iOrderId,sContent from Ymt_O_OrderNote(nolock) where iorderid in (select [Value] from @orderIds) and iuserid = @sellerId

end



--获取订单金额详情列表

select * from Ymt_OrderState(nolock) where iorderid in (select [Value] from @orderIds)



--获取订单补款列表  

select * from Ymt_OrderPostPay(nolock) where iorderid in (select [Value] from @orderIds)



--获取订单商品详情列表

select

i.iOrderId,i.sOrderInfoId,i.fOriginalPrice,i.iPriceType,i.iAmount,i.iBondedArea,i.iCatalogStatus,i.iCatalogType,

i.iProductSubCategoryId,i.iSailProtected,i.iType,i.sCatalogId,i.sDescription,i.sPictureUrl,i.sProductId,i.sPropertyInfo,i.sReferenceUrl,i.sSKU,i.sTitle 

,e.sOrderInfoId as sOrderInfoExtId,e.bGiftAvail4Reward,e.iActivityId,e.iActivityTemplateId

from Ymt_OrderInfo i with(nolock,ForceSeek)

--join @orderIds o on i.iOrderId = o.[Value]

left join Ymt_OrderInfoExt e with(nolock,ForceSeek)

on i.sOrderInfoId = e.sOrderInfoId

where i.iOrderId in (select [Value] from @orderIds)



--获取订单物流信息  

select iOrderId, iBillType, sSummary from Ymt_OrderSummary(nolock) where iorderid in (select [Value] from @orderIds)



--获取订单冻结信息  

select * from Ymt_Order_Frozen(nolock) where iorderid in (select [Value] from @orderIds)  



declare @orderToBills table(iOrderId int not null, sBillId varchar(36) not null)

declare @orderTradingIds table(orderId int not null, tradingId int not null, virtualTime datetime not null)



 --获取订单账单信息
 
 insert into @orderToBills select iOrderid, sBillId from Ymt_OrderToBill(nolock) where iorderid in (select [Value] from @orderIds) and iaction >= 0
 
 select iOrderid, sBillId from @orderToBills
 
 
 
 --print 'ymt_bill'
 
 --获取订单账单信息  
 
 select * from Ymt_Bill(nolock) where sbillid in (select sBillId from @orderToBills) and iaction >= 0



--print 'orderTradingId'

--订单有效的交易ID

insert into @orderTradingIds select iOrderId, iTradingId, dUpdateTime from Ymt_TradingItem(nolock) where iOrderId in (select [Value] from @orderIds)



update @orderTradingIds set virtualTime = '9999-1-1' where tradingId in (

  select ti.iTradingId from Ymt_TradingInfo ti with(nolock,ForceSeek)

  --where ti.iTradingId in (select tradingId from @orderTradingIds) and ti.iTradingStatus = 2

  inner loop join @orderTradingIds tid on ti.iTradingId = tid.tradingId and ti.iTradingStatus = 2

)



;with t as(

select ROW_NUMBER() over(partition by orderId order by virtualTime desc) as n, orderId, tradingId from @orderTradingIds

) 

select orderId as iOrderId, tradingId as iTradingId from t where n = 1 order by orderId;



select iOrderId,bIsNeedUploadIdCard,bHaveUploadedIdCard from ymt_orderext(nolock) where iorderid in (select [Value] from @orderIds)



set nocount off;



return 1;

--set statistics time off;set statistics io off;--set statistics profile off;



END;

