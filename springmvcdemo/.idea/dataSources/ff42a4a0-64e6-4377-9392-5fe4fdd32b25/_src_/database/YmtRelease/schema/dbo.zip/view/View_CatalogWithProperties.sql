CREATE VIEW dbo.View_CatalogWithProperties
AS
SELECT     dbo.Ymt_CatalogProperty.sCatalogPropertyId, dbo.Ymt_CatalogProperty.iPropertyType, dbo.Ymt_CatalogProperty.sAttributes, 
                      dbo.Ymt_CatalogProperty.sProductProperty, dbo.Ymt_CatalogSetAttributes.sCatalogAttributeId, dbo.Ymt_CatalogSetAttributes.sCategoryAttribute, 
                      dbo.Ymt_CatalogSetAttributes.iAttributeType, dbo.Ymt_Catalogs.sCatalogId, dbo.Ymt_Catalogs.iUserId, dbo.Ymt_Catalogs.sProductId, dbo.Ymt_Catalogs.fQuotePrice, 
                      dbo.Ymt_Catalogs.fFlight, dbo.Ymt_Catalogs.sDescript, dbo.Ymt_Catalogs.iAcceptReturn, dbo.Ymt_Catalogs.iCatalogStatus, 
                      dbo.Ymt_CatalogProperty.iPropertyAutoId, dbo.Ymt_Catalogs.iAction, dbo.Ymt_Catalogs.sProductName, dbo.Ymt_Catalogs.sPicUrl, dbo.Ymt_Catalogs.iExpire, 
                      dbo.Ymt_Catalogs.dAddTime, dbo.Ymt_Catalogs.sLocation, dbo.Ymt_CatalogProperty.sProductPropertyId
FROM         dbo.Ymt_CatalogProperty LEFT OUTER JOIN
                      dbo.Ymt_CatalogSetAttributes ON dbo.Ymt_CatalogProperty.sCatalogPropertyId = dbo.Ymt_CatalogSetAttributes.sCatalogPropertyId RIGHT OUTER JOIN
                      dbo.Ymt_Catalogs ON dbo.Ymt_CatalogProperty.sCatalogId = dbo.Ymt_Catalogs.sCatalogId
