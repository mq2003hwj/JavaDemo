
CREATE PROCEDURE [dbo].[spDeleteBill] 
	@billCode nvarchar(50),
	@userName nvarchar(50),           -- 传入ymt虚拟用户的名字，
	@result int=0 out,                -- 返回值
	@message varchar(max) out         -- 错误消息
AS

BEGIN


DECLARE	@return_value int


EXEC	@return_value = [XloboRelease].[dbo].[spDeleteBill]
		@billCode = @billCode,
		@userName = @userName,
		@result = @result OUTPUT,
		@message = @message OUTPUT

END
