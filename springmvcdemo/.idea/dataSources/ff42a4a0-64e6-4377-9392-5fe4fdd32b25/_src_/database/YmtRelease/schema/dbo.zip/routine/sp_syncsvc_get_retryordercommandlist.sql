
-- =============================================
-- Author:		<dengpeng@ymatou.com>
-- Create date: <2016-08-10>
-- Description:	<同步服务补偿线程：获取需要补偿的列表数据>
-- =============================================
create PROCEDURE [dbo].[sp_syncsvc_get_retryordercommandlist] 
	@batchSize int = 10,
	@second int =30
AS
BEGIN
	declare @latestTime datetime = dateadd(ss,-@second,getdate());

	;with result1 as (
		select top (@batchSize) [Type], [Command], [OrderID], [Content] 
		from [dbo].[Ymt_Order_CommandStatus] with(nolock,forceseek) 
		where CreateTime <= @latestTime and SyncStatus is null order by [CreateTime] asc
	)
	,result2 as (
		select top (@batchSize) [Type], [Command], [OrderID], [Content] 
		from [dbo].[Ymt_Order_CommandStatus] with(nolock,forceseek) 
		where CreateTime <= @latestTime and SyncStatus='fail' order by [CreateTime] asc
	)
	select * from result1
	union all
	select * from result2
END
