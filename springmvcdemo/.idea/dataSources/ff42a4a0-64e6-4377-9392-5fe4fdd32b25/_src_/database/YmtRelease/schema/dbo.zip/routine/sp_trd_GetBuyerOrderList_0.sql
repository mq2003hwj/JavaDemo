-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-13
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetBuyerOrderList_0]

@buyerId int,
@orderStatusXml xml,
@rowFrom int,
@rowTo int,
@complaintedOnly bit,
@tradingId int,
@uncommented bit,
@top int,
@lastOrderId int,
@noCreditDetail bit,
@receiver varchar(50),
@phone varchar(20)

AS

-------------variables-------------
declare @orderIds table(id int not null primary key clustered)
declare @orderStatus table(value int not null primary key clustered)
declare @orderToBills table(iOrderId int not null, sBillId varchar(36) not null)
declare @orderTradingIds table(orderId int not null, tradingId int not null, virtualTime datetime not null)
declare @orderStatusExists bit = 0
declare @totalCount int = 0
declare @rowsCount int = 0

--------------process--------------
if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
  select top 1 @orderStatusExists = 1 from @orderStatus
end;

--print 'insert';
--查出符合条件的订单ID及符合条件的订单总数
SET NOCOUNT OFF;

if @top = 0 begin

  if @uncommented = 0 begin

    with t(id, rowIndex) as (
    select iOrderId, row_number() over(order by dAddTime desc)
    from ymt_orders(nolock) o where iUserId = @buyerId
    and (@orderStatusExists = 0 or iTradingStatus in (select value from @orderStatus))
    and (@receiver is null or sReceivePerson = @receiver)
    and (@phone is null or sPhone = @phone)
    and (@complaintedOnly = 0 or exists(select 1 from Ymt_OrderComplaint(nolock) c where o.iOrderId = c.iOrderId))
    and (@tradingId = 0 or iOrderId in (select iOrderId from Ymt_TradingItem(nolock) where iTradingId = @tradingId))
    ),
    t2 as (select isnull(max(rowIndex), 0) as total from t)
    insert into @orderIds 
    select id from t where rowIndex between @rowFrom and @rowTo
    union all
    select -total from t2 where total > 0; --订单总量以负数表示,与订单ID区分开
    set @rowsCount = @@ROWCOUNT;
    if @rowsCount > 0 begin
      set @rowsCount = @rowsCount - 1; --减去多余的用来记录订单总量的行
      select @totalCount = -min(id) from @orderIds; --获取总数
      delete from @orderIds where @rowsCount > 0 and id = -@totalCount; --删除@orderIds中的总数
    end

  end 
  else begin

    with t(id, rowIndex) as (
    select iOrderId, row_number() over(order by dAddTime asc)
    from ymt_orders(nolock) o where iUserId = @buyerId 
    and (@orderStatusExists = 0 or iTradingStatus in (select value from @orderStatus))
    and (@receiver is null or sReceivePerson = @receiver)
    and (@phone is null or sPhone = @phone)
    and (@complaintedOnly = 0 or exists(select 1 from Ymt_OrderComplaint(nolock) c where o.iOrderId = c.iOrderId))
    and (@tradingId = 0 or iOrderId in (select iOrderId from Ymt_TradingItem(nolock) where iTradingId = @tradingId))
    and not exists(select 1 from Ymt_CreditDetail(nolock) c where c.iUserId = @buyerId and c.iAction > -1 and cast(o.iOrderId as varchar(36)) = c.sTargetId)
    ),
    t2 as (select isnull(max(rowIndex), 0) as total from t)
    insert into @orderIds 
    select id from t where rowIndex between @rowFrom and @rowTo
    union all
    select -total from t2 where total > 0; --订单总量以负数表示,与订单ID区分开
    set @rowsCount = @@ROWCOUNT;
    if @rowsCount > 0 begin
      set @rowsCount = @rowsCount - 1; --减去多余的用来记录订单总量的行
      select @totalCount = -min(id) from @orderIds; --获取总数
      delete from @orderIds where @rowsCount > 0 and id = -@totalCount; --删除@orderIds中的总数
    end

  end

end 
else begin
  
  insert into @orderIds
  select top (@top) iOrderId from Ymt_Orders(nolock) where iUserId = @buyerId 
  and ((@lastOrderId = 0 and iOrderId > 0) or (@lastOrderId <> 0 and iOrderId < @lastOrderId))
  and (@orderStatusExists = 0 or iTradingStatus in (select value from @orderStatus))
  order by iOrderId desc

  set @rowsCount = @@ROWCOUNT;
  set @totalCount = @rowsCount;

end

SET NOCOUNT ON;

--print '@totalCount'
--获取订单总数量  
select @totalCount as TotalCount;

--print 'ymt_orders';
select * from ymt_orders(nolock) where @rowsCount > 0 and iOrderId in (select id from @orderids) order by iOrderId asc

--print 'ymt_orderext';
select iOrderId,iOrderType,sOrderSource from Ymt_OrderExt(nolock) where @rowsCount > 0 and iOrderId in (select id from @orderids) 

--print 'ymt_creditdetail'   
--获取评价列表  
select * from Ymt_CreditDetail(nolock) where @noCreditDetail = 0 and @rowsCount > 0 and stargetid in (select cast(id as varchar(36)) from @orderids)  

--print 'ymt_o_ordernote'
--获取备注列表  
select iOrderId,sContent from Ymt_O_OrderNote(nolock) where @rowsCount > 0 and iuserid = @buyerid and iorderid in (select id from @orderids)  

--print 'ymt_orderstate'
--获取订单金额详情列表  ymt_orderinfo
select * from Ymt_OrderState(nolock) where @rowsCount > 0 and iorderid in (select id from @orderids)  

--print 'ymt_orderpostpay'
--获取订单补款列表  
select iOrderId,fAmount,fUseGiftAmount from Ymt_OrderPostPay(nolock) where @rowsCount > 0  and iorderid in (select id from @orderids)

--获取订单商品详情列表
--print 'ymt_orderinfo'
select
i.iOrderId,i.sOrderInfoId,i.fOriginalPrice,i.iAmount,i.iBondedArea,i.iCatalogStatus,i.iCatalogType,i.iProductSubCategoryId,i.iSailProtected,i.iType,i.sCatalogId,i.sDescription,i.sPictureUrl,i.sProductId,i.sPropertyInfo,i.sReferenceUrl,i.sSKU,i.sTitle,i.iPriceType
,e.sOrderInfoId as sOrderInfoExtId,e.bGiftAvail4Reward,e.iActivityId,e.iActivityTemplateId
from Ymt_OrderInfo i(nolock) 
left join Ymt_OrderInfoExt(nolock) e
on i.sOrderInfoId = e.sOrderInfoId
where @rowsCount > 0 and i.iOrderId in (select id from @orderIds)

--print 'ymt_ordersummary'
--获取订单物流信息  
select iOrderId, iBillType, sSummary from Ymt_OrderSummary(nolock) where @rowsCount > 0 and iorderid in (select id from @orderids)  

--print 'ymt_order_frozen'
--获取订单冻结信息  
select * from Ymt_Order_Frozen(nolock) where @rowsCount > 0 and iorderid in (select id from @orderids)  

--print 'ymt_ordertobill'
--获取订单账单信息
insert into @orderToBills select iOrderid, sBillId from Ymt_OrderToBill(nolock) where @rowsCount > 0 and iorderid in (select id from @orderids) and iaction >= 0
select iOrderid, sBillId from @orderToBills where @rowsCount > 0;

--print 'ymt_bill'
--获取订单账单信息  
select * from Ymt_Bill(nolock) where @rowsCount > 0 and sbillid in (select sBillId from @orderToBills) and iaction >= 0

--print 'orderTradingId'
--订单有效的交易ID  
if @rowsCount > 0 begin
  insert into @orderTradingIds select iOrderId, iTradingId, dUpdateTime from Ymt_TradingItem(nolock) where iOrderId in (select id from @orderIds)
  update @orderTradingIds set virtualTime = '9999-1-1' where tradingId in (select iTradingId from Ymt_TradingInfo(nolock) where iTradingId in (select tradingId from @orderTradingIds) and iTradingStatus = 2)
  ;with t as(
    select ROW_NUMBER() over(partition by orderId order by virtualTime desc) as n, orderId, tradingId from @orderTradingIds
  ) 
  select orderId as iOrderId, tradingId as iTradingId from t where n = 1 order by orderId;
end

--print 'finished'
SET NOCOUNT OFF; 
--set statistics time off
--print datediff(ms,@t1,getdate())