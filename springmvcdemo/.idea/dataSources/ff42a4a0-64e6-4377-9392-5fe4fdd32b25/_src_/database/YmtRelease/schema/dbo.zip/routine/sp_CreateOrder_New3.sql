-- =============================================            

-- Author:  zhangzhiqiang        

-- Create date: 2015-11-23

-- Description: 创建订单（M2C）       

-- =============================================     

CREATE PROC [dbo].[sp_CreateOrder_New3]

	@UserId INT,

	@OrderType INT,

	@OrderSource VARCHAR(128),

	@OrderSourceIp VARCHAR(128),

	@TerminalSource VARCHAR(128),

	@AppTerminalSource VARCHAR(128),

	@DeviceId VARCHAR(200) = null,

	@IsNeedUploadIdCard BIT,

	@SellerId INT,

	@Address VARCHAR(1000),

	@PostCode VARCHAR(10),

	@Phone VARCHAR(20),

	@ReceivePerson VARCHAR(50),

	@Telephone VARCHAR(20),

	@Freight DECIMAL(18,2),

	@LeaveWord NVARCHAR(2000),

	@AutoCancelOrderHours DECIMAL(18,2),

	@IncludeActivity BIT,

	@CanLocalReturn BIT,

	@CurType VARCHAR(50),

	@OrderPrice  DECIMAL(18,2),

	@UseGiftAmount DECIMAL(18,2),

	@UseFreeCardAmount DECIMAL(18,2),

	@CouponCode VARCHAR(36) = null,

	@CouponType INT = null,

	@CouponValue DECIMAL(18,2) = null,

	@CouponChannel INT = null,

	@CommissionFee DECIMAL(18,2),

	@IsFirstOrder BIT  = null,

	@OrderInfos TempOrderInfos3 READONLY

AS



declare @OrderId int

		,@IsMerchant int = 0  --0：非商家

		,@SellerCouponCode varchar(36) = null

		,@SellerCouponAmount decimal(18,2) = 0

		,@YmtCouponCode varchar(36) = null

		,@YmtCouponAmount decimal(18,2) = 0

		,@PayableAmount decimal(18,2) = 0



		,@OrderInfoId varchar(36)

		,@ProductNum int

		,@PropetyInfo varchar(2000)

		,@ProductPrice decimal(18,2)

		,@PictureUrl varchar(1000)

		,@ProductName varchar(500)

		,@SailProtected int

		,@CatalogId varchar(36)

		,@CatalogStatus int

		,@CatalogType int

		,@SKU varchar(300)

		,@ProductId varchar(36)

		,@MainCategoryId int

		,@SubCategoryId int

		,@ThirdCategoryId int

		,@ProductBrandId int

		,@BondedArea int

		,@ProductCode varchar(50)

		,@Flight decimal(18,2)

		,@TariffType int

		,@PackageNo varchar(50)

		,@ProductRefundChannel int

		,@CouponAvail4OrderDeduct bit

		,@GiftAvail4Reward bit

		,@ActivityId int

		,@ActivityTemplateId int

		,@PromotionType int

		,@Promotion decimal(18,2)

		,@CommissionRate decimal(18,2)

		,@Premium decimal(18,2)

		,@IsCost bit

		,@GiftAvail4OrderDeduct bit

		,@FeeFree bit

		,@Only4Vip bit

		,@TotalPrice decimal(18,2)

		,@Id int

		,@PriceType int = 0  --0-商品原价

		,@Now datetime = getdate()


	--生成新订单号
	EXEC @OrderId = spGenerateOrderId

	IF @CouponValue IS NULL

	BEGIN

		SET @CouponValue = 0

	END

	IF @CouponChannel = 1   --码头自有优惠券=1

	BEGIN

		SET @YmtCouponCode = @CouponCode

		SET @YmtCouponAmount = @CouponValue

	END

	IF @CouponChannel = 2   --商家优惠券=2

	BEGIN

		SET @SellerCouponCode = @CouponCode

		SET @SellerCouponAmount = @CouponValue

	END



	SET @PayableAmount =@OrderPrice+@Freight-@CouponValue

	--插入订单数据Ymt_Orders

	INSERT INTO [Ymt_Orders]

           ([iOrderId],[iUserId],[iBuyerId],[sMarkId],[dAddTime],[fOrderPrice],[fOrderDiscount] ,[fFreight],[fDiscount],[iTradingStatus] ,[sAddress],[sPostCode]

           ,[sReceivePerson],[sPhone],[sTelephone],[sLeaveWord],[iUnfreezeStatus],[bPaidInFull],[fUseGiftAmount],[sCouponCode],[CouponValue]

           ,[iCouponType],[iCouponChannel],[iDistributor],[fAutoCancelOrderHours],[bShangouOrder]

           ,[iIsMerchant],[fTotalPrice],[fUseFreeCardAmount],[bIncludeActivityProducts],[sCurType],[bCanLocalReturn]

		   ,[sSellerCouponCode],[fSellerCouponAmount],[sYmtCouponCode],[fYmtCouponAmount],[fPayableAmount],[fSellerPromotionAmount])

     VALUES

           (@OrderId,@UserId,@SellerId,'',@Now,@OrderPrice,0,@Freight,0,1,@Address,@PostCode,@ReceivePerson,@Phone,@Telephone,@LeaveWord,0,1

           ,@UseGiftAmount,@CouponCode,@CouponValue,@CouponType,@CouponChannel,1,@AutoCancelOrderHours,0

           ,@IsMerchant,@OrderPrice,@UseFreeCardAmount,@IncludeActivity,@CurType,@CanLocalReturn

		   ,@SellerCouponCode,@SellerCouponAmount,@YmtCouponCode,@YmtCouponAmount,@PayableAmount,0)

	

	--插入订单资金数据Ymt_OrderState

	INSERT INTO [Ymt_OrderState]

           ([iOrderId],[fRefundedAmountOfCash],[fRefundedAmountOfGift],[fPaidAmountOfCash],[fPaidAmountOfGift],[fPostPaidAmountOfCash],[fPostPaidAmountOfGift]

           ,[fPaidAmountOfCoupon],[fRefundedAmountOfCoupon],[fPostPadiAmountOfCoupon],[fQuickTurnoverAmount],[fCommissionFee],[fNeedCommissionFee]

           ,[fPaidAmountOfFreeCard],[fBalanceAmount],[fPaidAmountOfSellerCoupon],[fPaidAmountOfYmtCoupon],[dAddTime],[dUpdateTime])

     VALUES

           (@OrderId,0,0,0,@UseGiftAmount,0,0,@CouponValue,0,0,0,0, @CommissionFee,@UseFreeCardAmount,0,@SellerCouponAmount,@YmtCouponAmount,@Now,@Now)

	

	--插入订单扩展信息Ymt_OrderExt

	INSERT INTO [Ymt_OrderExt]

           ([iOrderId],[sOrderSource],[sOrderSourceIP],[iOrderType],[sTerminalSource],[bIsNeedUploadIdCard],[sAppTerminalSource],[sDeviceId],[bIsFirstOrder],[dAddTime],[sInterfaceVersion])

    VALUES

           (@OrderId,@OrderSource,@OrderSourceIP,@OrderType,@TerminalSource,@IsNeedUploadIdCard,@AppTerminalSource,@DeviceId,@IsFirstOrder,@Now,'CreateOrder')



	--插入Ymt_TradingOrder

	INSERT INTO Ymt_TradingOrder

           ([iOrderId],[iBuyerUserId],[iSellerUserId],[dAddTime],[dUpdateTime],[iAction])

     VALUES

           (@OrderId,@UserId,@SellerId,@Now,@Now,0)



	SET @Id = 1

	WHILE EXISTS(SELECT 1 FROM @OrderInfos WHERE RowId=@Id)

	BEGIN

		SET @OrderInfoId = newid()



		SELECT @CatalogId=CatalogId,@PropetyInfo=PropetyInfo,@ProductName=ProductName,@PictureUrl=PictureUrl

			,@ProductPrice=ProductPrice,@ProductNum=ProductNum,@SailProtected=SailProtected,@SKU=SKU,@PackageNo=PackageNo

			,@CatalogType=CatalogType,@CatalogStatus=CatalogStatus,@ProductId=ProductId,@MainCategoryId=MainCategoryId

			,@SubCategoryId=SubCategoryId,@ThirdCategoryId=ThirdCategoryId,@ProductBrandId=ProductBrandId,@BondedArea=BondedArea

			,@ProductCode=ProductCode,@TariffType=TariffType,@Flight=Flight,@ActivityId=ActivityId

			,@ActivityTemplateId=ActivityTemplateId,@PromotionType=PromotionType,@Promotion=Promotion,@GiftAvail4Reward=GiftAvail4Reward

			,@GiftAvail4OrderDeduct=GiftAvail4OrderDeduct,@CouponAvail4OrderDeduct=CouponAvail4OrderDeduct,@Only4VIP=Only4VIP

			,@FeeFree=FeeFree,@CommissionRate=CommissionRate,@Premium=Premium,@IsCost=IsCost

			,@ProductRefundChannel=ProductRefundChannel

		FROM @OrderInfos WHERE RowId=@Id



		--插入订单商品信息Ymt_OrderInfo

		IF @ActivityId > 0

			SET @PriceType = 3  -- 3-活动价

		SET @TotalPrice = @ProductPrice * @ProductNum

		INSERT INTO [Ymt_OrderInfo]

			   ([sOrderInfoId],[iOrderId],[iType],[sCatalogId],[sPropertyInfo],[sTitle],[sPictureUrl],[fOriginalPrice],[fDiscount],[iAmount]

			   ,[fTotalPrice],[iSailProtected],[sSKU],[iCatalogType],[iCatalogStatus],[sProductId],[iProductMainCategoryId],[iProductSubCategoryId]

			   ,[iProductThirdCategoryId],[iProductBrandId],[iBondedArea],[sProductCode],[iTariffType],[fFlight],[iPriceType],[sPackageNo]

			   ,[iProductRefundChannel],[fProductPrice],[fSubsidyAmount],[dAddTime],[dUpdateTime],[iSalesType],[fSellerPromotionAmount])

		 VALUES

			   (@OrderInfoId,@OrderId,0,@CatalogId,@PropetyInfo,@ProductName,@PictureUrl,@ProductPrice,0,@ProductNum,@TotalPrice

			   ,@SailProtected,@SKU,@CatalogType,@CatalogStatus,@ProductId,@MainCategoryId,@SubCategoryId,@ThirdCategoryId,@ProductBrandId

			   ,@BondedArea,@ProductCode,@TariffType,@Flight,@PriceType,@PackageNo,@ProductRefundChannel,@ProductPrice,0,@Now,@Now,1,0)



		IF @ActivityId > 0  --插入订单商品活动信息Ymt_OrderInfoExt

		BEGIN

			INSERT INTO [Ymt_OrderInfoExt]

				([sOrderInfoId],[iActivityId],[iActivityTemplateId],[iPromotionType],[fPromotion],[bGiftAvail4OrderDeduct]

				,[bGiftAvail4Reward],[bCouponAvail4OrderDeduct],[bOnly4VIP],[bFeeFree],[fCommissionRate],[fPremium],[bIsCost])

			VALUES

				(@OrderInfoId,@ActivityId,@ActivityTemplateId,@PromotionType,@Promotion,@GiftAvail4OrderDeduct,@GiftAvail4Reward

				,@CouponAvail4OrderDeduct,@Only4VIP,@FeeFree,@CommissionRate,@Premium,@IsCost)

		END

		SET @Id = @Id + 1

	END



SELECT @OrderId AS iOrderId,@SellerId AS iBuyerId,@CouponCode AS sCouponCode,@CouponType AS iCouponType,@CouponChannel AS iCouponChannel

	,@UseGiftAmount AS fUseGiftAmount,@UseFreeCardAmount AS fUseFreeCardAmount,@AutoCancelOrderHours AS fAutoCancelOrderHours

	,@OrderPrice AS fOrderPrice,@CouponValue AS CouponValue
