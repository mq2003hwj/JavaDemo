CREATE PROCEDURE UpdateProductOnShevelOff
AS
BEGIN
	DECLARE @productTable table
	(
		productid varchar(64)
	)
	INSERT INTO @productTable
	(
		productid
	)
	SELECT DISTINCT P.sProductId FROM Ymt_Catalogs AS C  with (Nolock)
	INNER JOIN Ymt_Products AS P with (Nolock)
		ON C.sProductId = P.sProductId
	WHERE C.fQuotePrice <= 80
		AND C.iAction = 0
		AND GETDATE() BETWEEN P.validStart AND P.validEnd
		AND P.iAction = 0;

	UPDATE P
		SET P.bAutoRefresh = 0,
		 P.validEnd = DATEADD(SECOND,-1,GETDATE())
	FROM Ymt_Products AS P
	INNER JOIN @productTable AS PT
		ON P.sProductId = PT.productid;
END