

-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-11-26
-- Update date: 2016-03-15
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetBuyerOrderInfos_v4]

@orderId int,
@userId int,
@orderNum int,
@lastOrderId int,
@orderStatusUsingMethod int,
@orderStatusXml xml,
@refundedOrderOnly int = 0,
@evaluatedDays int = null
AS

-------------variables-------------
declare @tTradingStatus table([value] int)
declare @orderIds table(id int, refund int)

declare @exsitsShippedStatus bit = 0
declare @exsitsReceivedStatus bit = 0

declare @considerShippedStatus bit = 0
declare @considerReceivedStatus bit = 0
declare @considerRestStatus bit = 1
--------------process--------------
if @orderStatusUsingMethod > 0
begin
    insert into @tTradingStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

--set statistics io on;set statistics time on;

if @orderId > 0 begin

	select top 1 o.iOrderId,o.iTradingId,o.iUserId,o.sBuyerLoginId,o.dAddTime,o.fOrderPrice,o.fOrderDiscount,o.fAutoCancelOrderHours,bEvaluated
		,case when r.iProcessStatus is null then o.iTradingStatus when r.iProcessStatus = 0 then 3 else o.iTradingStatus end as iTradingStatus
		,o.fUseGiftAmount,o.sLeaveWord,o.iBuyerId,o.dDispathTime,o.bPaidInFull,o.fFreight,o.dConfirmedTime
		,o.sReceivePerson,o.sAddress,o.sPostCode,o.sPhone,o.sTelephone
		,o.bCanLocalReturn,o.dApplyLocalReturnTime, o.fTotalPrice,e.bIsNeedUploadIdCard,e.sOrderSource,e.iOrderType
		,o.bShangouOrder
		,frozen.dFrozenTime,frozen.iUserId as iFrozenUserId,frozen.bFrozen,frozen.bFrozenAutoReceive,frozen.bPause
		,p.fAmount as postpayAmount,p.fUseGiftAmount as postpayUseGiftAmount
		,o.iThirdPartyRefundStatus
		,o.sSellerLoginId
		,o.CouponValue,o.iCouponChannel,o.sCouponCode
		,e.bHaveUploadedIdCard
		,n.sContent as sellerNote
		,(select top 1 sReason from Ymt_OrderReason(nolock) where iOrderId = @orderId) as sReason
		,s.*
		,o.iSalesRefundStatus,o.dPaidTime,o.dAcceptTime,o.dPostPaidTime
		,(select top 1 [sId] from Ymt_IdPic(nolock) c where o.iUserId = c.iUserId and o.sReceivePerson = c.sName and e.bIsNeedUploadIdCard = 1) as IdCardUploadedKey
		,(select top 1 concat(fAmount,'|',sPayChannel) from ymt_tradinginfo(nolock) where s.fPaidAmountOfCash > 0 and iTradingId = o.iTradingId and iTradingStatus = 2) as ThirdPartyPaidInfo
		,(select top 1 concat(Amount,'|',p.sPayChannel) from Ymt_PostPayTradingInfo(nolock) where s.fPostPaidAmountOfCash > 0 and p.iAction = 1 and PostPayTradingId = p.sPostPayTradingId and OrderId = o.iorderId and iAction = 1) as ThirdPartyPostpaidInfo
	from Ymt_Orders(nolock) o
	left join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId
	left join Ymt_Order_Frozen(nolock) frozen on frozen.iOrderId = o.iOrderId
	left join Ymt_OrderPostPay(nolock) p on o.iOrderId = p.iOrderId and (p.iAction = 0 or p.iAction = 1)
	left join Ymt_O_OrderNote(nolock) n on o.iOrderId = n.iOrderId and o.iBuyerId = n.iUserId
	left join Ymt_OrderState(nolock) s on o.iOrderId = s.iOrderId
	left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId
	where o.iOrderId = @orderId and (o.iUserId = @userId or o.iBuyerId = @userId)
	order by p.iAction desc

	if @@ROWCOUNT > 0 begin
		select oi.iOrderId,oi.iAmount,oi.sProductId,oi.sPropertyInfo,oi.iCatalogStatus,oi.sCatalogId,oi.iPriceType,oi.sTitle,oi.sPictureUrl,oi.fOriginalPrice,oi.iBondedArea,oi.iTariffType
		,oi.iProductRefundChannel,oi.iProductRefundStatus,oi.sProductInfo
		,ie.iActivityId
		from Ymt_OrderInfo(nolock) oi
		left join Ymt_OrderInfoExt(nolock) ie on oi.sOrderInfoId = ie.sOrderInfoId
		where oi.iOrderId = @orderId

		select * from Ymt_RefundBill(nolock) where OrderId = (select iOrderId from Ymt_Orders(nolock) where iOrderId = @orderId and iSalesRefundStatus is not null)
	end

end else begin
	if exists(select top 1 1 from @tTradingStatus where [value] = 3) begin
		set  @exsitsShippedStatus = 1
	end

	if exists(select top 1 1 from @tTradingStatus where [value] = 4) begin
		set  @exsitsReceivedStatus = 1
	end

	if not (@exsitsShippedStatus = 1 and @exsitsReceivedStatus = 1) begin
		if @exsitsShippedStatus = 1 begin
			delete @tTradingStatus where [value] = 3
			set @considerShippedStatus = 1
			select @considerRestStatus = case when count(*)>0 then 1 else 0 end from @tTradingStatus
		end

		if @exsitsReceivedStatus = 1 begin
			delete @tTradingStatus where [value] = 4
			set @considerReceivedStatus = 1
			select @considerRestStatus = case when count(*)>0 then 1 else 0 end from @tTradingStatus
		end
	end

	declare @evaluatedDateBase datetime = null
	if @evaluatedDays is not null begin
		set @evaluatedDateBase = getdate() - @evaluatedDays
	end

	insert into @orderIds
	select top (@orderNum) o.iOrderId, o.iSalesRefundStatus from Ymt_Orders(nolock) o 
	join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId
	left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId
	where 
	o.iUserId = @userId
	and (o.bShangouOrder = 1 or e.sOrderSource in ('C2CAPP','C2CWAP','C2CWechat'))
	and(
	  @orderStatusUsingMethod =0 or 
	  (
		   (@orderStatusUsingMethod=1 and (o.iTradingStatus=17 and o.bPaidInFull=1))
		or (@orderStatusUsingMethod=2 and (o.iTradingStatus=17 and o.bPaidInFull=0))
		or (
			(@considerShippedStatus = 1 and (o.iTradingStatus = 3 or o.iTradingStatus = 4 and r.iProcessStatus = 0))
			or
			(@considerReceivedStatus = 1 and (o.iTradingStatus = 4 and (r.iProcessStatus is null or r.iProcessStatus > 0)))
			or
			(@considerRestStatus = 1 and o.iTradingStatus in (select [value] from @tTradingStatus))
		)
	  )
	)
	and (@lastOrderId=0 or o.iOrderId < @lastOrderId)
	and (@refundedOrderOnly = 0 or (@refundedOrderOnly = 1 and o.dApplyLocalReturnTime is not null) or (@refundedOrderOnly = 2 and o.iSalesRefundStatus is not null))
	and (@evaluatedDateBase is null or (o.iTradingStatus = 4 and isnull(o.bEvaluated, 0) = 0 and @evaluatedDateBase < o.dConfirmedTime))
	order by o.iOrderId desc

	select top (@orderNum) r.iProcessStatus,o.iOrderId,o.iTradingId,o.iUserId,o.sBuyerLoginId,o.dAddTime,o.fOrderPrice,o.fOrderDiscount,o.fAutoCancelOrderHours,bEvaluated
		,case when r.iProcessStatus is null then o.iTradingStatus when r.iProcessStatus = 0 then 3 else o.iTradingStatus end as iTradingStatus
		,o.fUseGiftAmount,o.sLeaveWord,o.iBuyerId,o.dDispathTime,o.bPaidInFull,o.fFreight,o.dConfirmedTime
		,o.sReceivePerson,o.sAddress,o.sPostCode,o.sPhone,o.sTelephone
		,o.bCanLocalReturn,o.dApplyLocalReturnTime, o.fTotalPrice,e.bIsNeedUploadIdCard,e.sOrderSource,e.iOrderType
		,o.bShangouOrder
		,o.iThirdPartyRefundStatus
		,o.sSellerLoginId
		,o.CouponValue,o.iCouponChannel,o.sCouponCode
		,e.bHaveUploadedIdCard
		,frozen.dFrozenTime,frozen.iUserId as iFrozenUserId,frozen.bFrozen,frozen.bFrozenAutoReceive,frozen.bPause
		,(select top 1 concat(p.fAmount,'|',p.fUseGiftAmount) from Ymt_OrderPostPay(nolock) p where p.iOrderId = o.iOrderId and (p.iAction = 0 or p.iAction = 1) order by p.iAction desc) postpayAccountAndGiftInfo
        ,s.*
		,o.iSalesRefundStatus,o.dPaidTime,o.dAcceptTime,o.dPostPaidTime
		,(select top 1 [sId] from Ymt_IdPic(nolock) c where o.iUserId = c.iUserId and o.sReceivePerson = c.sName and e.bIsNeedUploadIdCard = 1) as IdCardUploadedKey
	from Ymt_Orders(nolock) o 
	left join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId
	left join Ymt_Order_Frozen(nolock) frozen on frozen.iOrderId = o.iOrderId
	left join Ymt_OrderState(nolock) s on o.iOrderId = s.iOrderId
	left join Temp_ReceivedOrders20151109(nolock) r on o.iOrderId = r.iOrderId
	where o.iOrderId in (select id from @orderIds)
	order by o.iOrderId desc

	if @@ROWCOUNT > 0 begin
		select oi.iOrderId,oi.iAmount,oi.sProductId,oi.sPropertyInfo,oi.sCatalogId,oi.iCatalogStatus,oi.iPriceType,oi.sTitle,oi.sPictureUrl,oi.fOriginalPrice,oi.iBondedArea,oi.iTariffType
		,oi.iProductRefundChannel,oi.iProductRefundStatus,oi.sPackageNo,oi.sProductInfo
		,ie.iActivityId
		from Ymt_OrderInfo(nolock) oi
		left join Ymt_OrderInfoExt(nolock) ie on oi.sOrderInfoId = ie.sOrderInfoId
		where oi.iOrderId in (select id from @orderIds)

		select * from Ymt_RefundBill(nolock) where OrderId in (select id from @orderIds where refund is not null)
	end
end

--set statistics io off;set statistics time off;
