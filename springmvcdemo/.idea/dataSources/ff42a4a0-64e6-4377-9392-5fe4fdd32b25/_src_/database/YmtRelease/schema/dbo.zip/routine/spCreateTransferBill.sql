
create PROCEDURE [dbo].[spCreateTransferBill]
    @fInsure money=0                  -- 丢单保险, 传入参数，必填
    ,@sUsExpressCode nvarchar(512)    -- 美国境内物流单号，传入参数，必填
    ,@fPrice money=0                  -- 海关申报价值，传入参数，必填
    ,@iWeight float=0                 -- 申报重量, 传入参数，必填
    ,@iYmatouOrderId int              -- 洋码头订单号，传入参数
    ,@sBackAds nvarchar(200)=null     -- 退件地址，传入参数，非必填
    ,@sComment nvarchar(max)=null     -- 备注，传入参数
    ,@sCreaterName nvarchar(50)       -- 创建人名字，传入参数，必填
    ,@sItem nvarchar(500)             -- 包裹显示内容，传入参数，必填
    ,@sNoticeEmail nvarchar(64)       -- 通知email，传入参数
    ,@sNoticePhone nvarchar(64)       -- 通知电话，传入参数
    ,@sPoAds nvarchar(200)            -- 发件人地址，传入参数，必填
    ,@sPoName nvarchar(50)            -- 发件人姓名，传入参数，必填
    ,@sPoPhone nvarchar(50)           -- 发件人电话，传入参数，必填
    ,@sRecAds nvarchar(200)           -- 收件人地址，传入参数，必填
    ,@sReceiverCity nvarchar(64)      -- 收件人所在市，传入参数，必填
    ,@sReceiverProvince nvarchar(64)  -- 收件人所在省，传入参数，必填
    ,@sReceiverRegion nvarchar(64)    -- 收件人所在区，传入参数
    ,@sRecEmail nvarchar(64)       -- 收件人email，传入参数
    ,@sRecName nvarchar(50)        -- 收件人名字，传入参数，必填
    ,@sRecPhone nvarchar(50)       -- 收件人电话，传入参数，必填
    ,@sRecPostcode nvarchar(64)    -- 收件人邮编，传入参数，必填
    ,@sSmallTicket nvarchar(1024)=null -- 货物小票，传入参数，非必填
    ,@result int=0 out             -- 返回值,0表示成功,非表示失败
    ,@message varchar(max) out     -- 错误消息
    ,@sCode nvarchar(50) out       -- 返回值, 创建面单的面单号
AS
BEGIN


DECLARE	@return_value int
EXEC	@return_value = [XloboRelease].[dbo].[spCreateTransferBill]
		@sUsExpressCode = @sUsExpressCode,
		@fInsure = @fInsure,
		@fPrice = @fPrice,
		@iWeight =@iWeight,
		@iYmatouOrderId = @iYmatouOrderId ,
		@sBackAds =@sBackAds,
		@sComment = @sComment,
		@sCreaterName = @sCreaterName,
		@sItem = @sItem,
		@sNoticeEmail=@sNoticeEmail,
		@sNoticePhone=@sNoticePhone,
		
		@sPoAds = @sPoAds ,
		@sPoName = @sPoName,
		@sPoPhone = @sPoPhone,
		@sRecAds = @sRecAds,
		@sReceiverCity =@sReceiverCity ,
		@sReceiverProvince = @sReceiverProvince ,
		@sReceiverRegion =@sReceiverRegion ,
		
		@sRecEmail = @sRecEmail,
		@sRecName = @sRecName,
		@sRecPhone = @sRecPhone ,
		@sRecPostcode = @sRecPostcode ,
		@sSmallTicket=@sSmallTicket,
		
		@result = @result OUTPUT,
		@message = @message OUTPUT,
		
		@sCode = @sCode OUTPUT
		

END
