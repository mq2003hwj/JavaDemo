



CREATE PROCEDURE [dbo].[SP_CouponPackageInfo]
		@PackageId INT,
		@UserId INT,
		@DeviceCode VARCHAR(500),
		@DeviceReceiveCouponMaxCount INT,
		@UserReceiveCouponMaxCount INT,
		@RetCode INT OUTPUT
AS
BEGIN
	
	SELECT @RetCode = 0
	--判断礼包是否存在
	IF NOT EXISTS(SELECT 1 FROM dbo.Ymt_CouponPackage with(nolock) where iPackageId=@PackageId)
	BEGIN
		SELECT @RetCode = -1
		RETURN
	END

	--判断同一设备礼包领取次数
	DECLARE @DeviceReceiveCount AS INT=0
	SELECT @DeviceReceiveCount=COUNT(0) FROM dbo.Ymt_CouponReceiveByDevice WITH(NOLOCK) WHERE iPackageId = @PackageId AND sDeviceCode = @DeviceCode
	IF @DeviceReceiveCount>=@DeviceReceiveCouponMaxCount
	BEGIN
		SELECT @RetCode = -3
		RETURN
	END

	--判断同一用户礼包领取次数
	DECLARE @UserReceiveCount AS INT=0
	SELECT @UserReceiveCount=COUNT(0) FROM dbo.Ymt_CouponReceiveByDevice WITH(NOLOCK) WHERE iPackageId = @PackageId AND iUserId = @UserId
	IF @UserReceiveCount>=@UserReceiveCouponMaxCount
	BEGIN
		SELECT @RetCode=-4
		RETURN
	END
	
	BEGIN TRY
	--添加用户领取礼包记录
	IF NOT EXISTS(SELECT 1 FROM dbo.Ymt_CouponReceiveByDevice WITH(NOLOCK) WHERE iPackageId = @PackageId AND iUserId = @UserId)
	BEGIN
		INSERT INTO dbo.Ymt_CouponReceiveByDevice(iPackageId,iUserId,sDeviceCode,dReceiveDate) VALUES(@PackageId,@UserId,@DeviceCode,GETDATE())
		--根据礼包ID获取优惠券批次信息
		SELECT sBatchCode FROM dbo.Ymt_CouponPackage WITH(NOLOCK) WHERE iPackageId=@PackageId
	END
	END TRY
	BEGIN CATCH
		SELECT @RetCode=-4
		RETURN  
	END CATCH  
END


