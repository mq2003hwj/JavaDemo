-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-11-26
-- Description: 交易服务SP       
-- 20160819：取消根据风控状态做的特殊查询逻辑   
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrdersListV2_3]

@sellerId int,
@orderSellerAcceptedStatus int,
@orderStatusXml xml,
@lastOrderId int,
@paidInFull bit,
@timeFrom datetime,
@timeTo datetime,
@top int,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@filter int = 0,
@filterValue varchar(100) = NULL

AS

-------------variables-------------
declare @orderStatus table([value] int)
declare @orderIds table(id int)
declare @rowCount int = 0

--------------process--------------
if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

--set statistics time on;set statistics io on;

set nocount off;
insert into @orderIds
select top(@top) iOrderId from Ymt_Orders(nolock) o where iBuyerId = @sellerId and bShangouOrder = 1
and (
	(@paidInFull is not null and (o.iTradingStatus = @orderSellerAcceptedStatus and o.bPaidInFull = @paidInFull))
	or (@orderStatusXml is not null and o.iTradingStatus in (select [value] from @orderStatus))
)
/*
and (
  @paidInFull is null and @considerOrderStatus = 0
  or
  @paidInFull is not null and (o.iTradingStatus = @orderSellerAcceptedStatus and o.bPaidInFull = @paidInFull)
  or 
  (
    @considerOrderStatus = 0 and 1 < 0
    or @considerOrderStatus = 1 and
    (
      (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
        or
      (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
        or
      (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
    )
  )
)
*/
and (@timeFrom is null or dAddTime >= @timeFrom and dAddTime < @timeTo)
and (@lastOrderId = 0 or iOrderId < @lastOrderId)
and (
@filter = 0 or 
(@filter = 1 and o.iOrderId like @filterValue) or 
(@filter = 2 and o.sBuyerNickName like @filterValue) or 
(@filter = 3 and o.sReceivePerson like @filterValue) or 
(@filter = 4 and exists(select top 1 1 from Ymt_OrderSummary(nolock) where iOrderId = o.iOrderId and sSummary like @filterValue))
)
order by iOrderId desc
set @rowCount = @@ROWCOUNT;

set nocount on;

select o.iOrderId,o.iUserId,o.iTradingStatus,o.dAddTime,o.sBuyerLoginId,o.sLeaveWord,o.fOrderPrice,o.fTotalPrice,o.bPaidInFull,o.iRiskVerifiedStatus,n.sContent as sellerNote,CouponValue,iCouponChannel
,o.bShangouOrder
,p.fAmount as postpayAmount,p.fUseGiftAmount as postpayUseGiftAmount
,case when bl.iSellerId is null then 0 else 1 end as buyerInBlacklist
,o.dApplyPostPayTime
from Ymt_Orders(nolock) o
left join Ymt_O_OrderNote(nolock) n on o.iOrderId = n.iOrderId and o.iBuyerId = n.iUserId
left join Ymt_OrderPostPay(nolock) p on o.iOrderId = p.iOrderId and (p.iAction = 0 or p.iAction = 1)
left join Ymt_BlackListForSeller(nolock) bl on o.iBuyerId = bl.iSellerId and o.iUserId = bl.iBuyerId and bl.iAction = 0
where @rowCount > 0 and o.iOrderId in (select id from @orderIds) order by o.iOrderId desc

select iOrderId,sPictureUrl,sPropertyInfo,sProductId,fOriginalPrice,sTitle,iAmount,iPriceType,iCatalogStatus,iProductRefundChannel,iProductRefundStatus from Ymt_OrderInfo(nolock) where @rowCount > 0 and iOrderId in (select id from @orderIds) order by iOrderId desc

set nocount off;

--set statistics time off;set statistics io off;