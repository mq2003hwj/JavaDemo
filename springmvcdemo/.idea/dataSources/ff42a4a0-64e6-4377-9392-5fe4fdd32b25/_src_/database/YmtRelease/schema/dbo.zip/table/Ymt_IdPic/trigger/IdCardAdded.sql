CREATE TRIGGER [dbo].[IdCardAdded]
ON [dbo].[Ymt_IdPic]
AFTER INSERT
AS
	Declare @iUserId int
	Declare @sName varchar(200)
	Select @sName = sName, @iUserId = iUserId From inserted

    exec [dbo].[sp_SyncIdCardStateByName] @iUserId,@sName
		


