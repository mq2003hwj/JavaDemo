
CREATE PROCEDURE [dbo].[spRefreshProductsOnShelve] 
	@sellerId int
AS
BEGIN

	UPDATE Ymt_Products 
	SET 
		validStart = GETDATE(), 
		validEnd = DATEADD(day, 7, GETDATE())
	WHERE 
		iUserId = @sellerId AND 
		bAutoRefresh = 1 AND
		validStart<=CONVERT(date, getdate()) AND
		validEnd<DATEADD(d,10,GETDATE()) AND
		sProductId in (SELECT sProductId FROM Ymt_Catalogs WHERE iAction = 0 AND iNum > 0)

END
