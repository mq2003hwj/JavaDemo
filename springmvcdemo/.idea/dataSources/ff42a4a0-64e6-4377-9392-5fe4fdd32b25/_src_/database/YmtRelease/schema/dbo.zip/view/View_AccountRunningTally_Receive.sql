CREATE VIEW dbo.View_AccountRunningTally_Receive
AS
SELECT     dbo.Ymt_AccountRunningTally.sRunningTallyId, dbo.Ymt_AccountRunningTally.fOccurredAmount, dbo.Ymt_AccountRunningTally.iType, 
                      dbo.Ymt_AccountRunningTally.iUserId, dbo.Ymt_AccountRunningTally.fBalance, dbo.Ymt_AccountRunningTally.fFreezeAmount, 
                      dbo.Ymt_AccountRunningTally.fAvailAmount, dbo.Ymt_AccountRunningTally.dAddTime, dbo.Ymt_AccountRunningTally.sOperator, 
                      dbo.Ymt_AccountRunningTally.sUseage, dbo.Ymt_AccountRunningTally.sMemo, dbo.Ymt_Users.sLoginId
FROM         dbo.Ymt_AccountRunningTally INNER JOIN
                      dbo.Ymt_Users ON dbo.Ymt_AccountRunningTally.iUserId = dbo.Ymt_Users.iUserId
WHERE     (dbo.Ymt_AccountRunningTally.dAddTime > '2011-1-1') AND (dbo.Ymt_AccountRunningTally.sOperator = 'Receive')
