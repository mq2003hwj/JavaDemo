CREATE TRIGGER [dbo].[TopicAdded]
ON [dbo].[Ymt_Topics]
AFTER INSERT
AS
	Declare @iUserId int
	Declare @iTopicId int
	Declare @sTopic varchar(200)
	Declare @sForumId varchar(200)
	Select @sTopic = sTitle, @iTopicId = iTopicId, @sForumId = sForumId, @iUserId = iPosterId From inserted

	If Exists (Select iPosterId From Ymt_Topics Where iPosterId = @iUserId And iAction = -1 Group By iPosterId Having Count(*) > 100) BEGIN
		update Ymt_Topics set iAction = -1 where iTopicId = @iTopicId
	End
	
	If Exists (Select iPosterId, count(*) From Ymt_Topics Where DateDiff(hour, DateAdd(hour, -1, getdate()), dposttime) >= 0 and DateDiff(hour, DateAdd(hour, -1, getdate()), dposttime) <= 1 And iPosterId = @iUserId Group By iPosterId Having Count(*) > 20) BEGIN
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End

	If CHARINDEX('短信群发', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	
	If @sForumId = 'F121393F-D2A2-4513-83E0-0DDFA1FE1720' And Exists (Select iUserId From Ymt_Users Where iType = 0 And iUserId = @iUserId) BEGIN
		update Ymt_Topics set iAction = -1 where iTopicId = @iTopicId
	End
	If CHARINDEX('答案', @sTopic) > 0 and (CHARINDEX('考试', @sTopic) > 0 or CHARINDEX('考試', @sTopic) > 0 or CHARINDEX('攷试', @sTopic) > 0 or CHARINDEX('考前', @sTopic) > 0 or CHARINDEX('攷前', @sTopic) > 0 or CHARINDEX('英语', @sTopic) > 0 or CHARINDEX('四级', @sTopic) > 0 or CHARINDEX('四級', @sTopic) > 0 or CHARINDEX('六级', @sTopic) > 0 or CHARINDEX('六級', @sTopic) > 0 or CHARINDEX('QQ', @sTopic) > 0) BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('办', @sTopic) > 0 and (CHARINDEX('文凭', @sTopic) > 0 or CHARINDEX('文 凭', @sTopic) > 0 or CHARINDEX('文憑', @sTopic) > 0 or CHARINDEX('文 憑', @sTopic) > 0 or CHARINDEX('证', @sTopic) > 0 or CHARINDEX('卡', @sTopic) > 0 or CHARINDEX('証', @sTopic) > 0 or CHARINDEX('證', @sTopic) > 0) BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('需要', @sTopic) > 0 and (CHARINDEX('文凭', @sTopic) > 0 or CHARINDEX('文 凭', @sTopic) > 0 or CHARINDEX('文憑', @sTopic) > 0 or CHARINDEX('文 憑', @sTopic) > 0 or CHARINDEX('证', @sTopic) > 0 or CHARINDEX('卡', @sTopic) > 0 or CHARINDEX('証', @sTopic) > 0 or CHARINDEX('證', @sTopic) > 0) BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('辦', @sTopic) > 0 and (CHARINDEX('文凭', @sTopic) > 0 or CHARINDEX('文 凭', @sTopic) > 0 or CHARINDEX('文憑', @sTopic) > 0 or CHARINDEX('文 憑', @sTopic) > 0 or CHARINDEX('证', @sTopic) > 0 or CHARINDEX('卡', @sTopic) > 0 or CHARINDEX('証', @sTopic) > 0 or CHARINDEX('證', @sTopic) > 0) BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('身', @sTopic) > 0 and CHARINDEX('份', @sTopic) > 0 and CHARINDEX('证', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('银', @sTopic) > 0 and CHARINDEX('行', @sTopic) > 0 and CHARINDEX('卡', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('银', @sTopic) > 0 and CHARINDEX('行', @sTopic) > 0 and CHARINDEX('卡', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('小姐', @sTopic) > 0 or CHARINDEX('学生妹', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('打架', @sTopic) > 0 or CHARINDEX('报仇', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('手枪', @sTopic) > 0 or CHARINDEX('手槍', @sTopic) > 0 or CHARINDEX('氣槍', @sTopic) > 0 or CHARINDEX('氣鎗', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('毒药', @sTopic) > 0 or CHARINDEX('迷药', @sTopic) > 0 or CHARINDEX('安乐死', @sTopic) > 0 or CHARINDEX('赌博', @sTopic) > 0 or CHARINDEX('毒药', @sTopic) > 0 or CHARINDEX('迷葯', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('安', @sTopic) > 0 and CHARINDEX('乐', @sTopic) > 0 and CHARINDEX('死', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('迷', @sTopic) > 0 and CHARINDEX('药', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('枪', @sTopic) > 0 and (CHARINDEX('买', @sTopic) > 0 or CHARINDEX('卖', @sTopic) > 0 or CHARINDEX('出售', @sTopic) > 0) BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('藥', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('充气娃娃', @sTopic) > 0 or CHARINDEX('情趣娃娃', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('麻将', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('拍肩粉', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('答案★', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('短信群發平台', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End
	If CHARINDEX('短信群發平台', @sTopic) > 0 BEGIN
		update ymt_users set sPassword = 'forbidden', sToken = '' where iUserId = @iUserId
		update Ymt_Topics set iAction = -1 where iPosterId = @iUserId
	End

