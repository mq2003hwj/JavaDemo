-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[DiffTimeIsBefore]
(	
	-- Add the parameters for the function here
	@startTime datetime, 
	@endTime datetime
)
RETURNS int
AS

BEGIN
-- Add the SELECT statement with parameter references here
	declare @totalTimeDiff int
	declare @result int
	Set @result = 0;
	IF @endTime is null
	begin
	 set @result=0;
	end
	else
	begin
	SET @totalTimeDiff = DATEDIFF(second,@startTime,@endTime);
	IF(@totalTimeDiff>0)
	Begin
		Set @result = 1;
	End
	end
	return @result;
END	

