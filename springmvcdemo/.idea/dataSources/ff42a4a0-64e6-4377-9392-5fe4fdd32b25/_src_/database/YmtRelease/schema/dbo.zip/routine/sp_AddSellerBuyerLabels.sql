
-- ===========================================================================================================
-- Author:		
-- Create date: 2016-5-20
-- Description:	买手为买家添加标签
-- ===========================================================================================================
CREATE PROC sp_AddSellerBuyerLabels(
	@SellerId INT,--买手ID
	@CopyBatchId VARCHAR(50),--批次ID
	@MaxLabelCount INT = 5--最大标签数
)
AS
BEGIN
	--删除废弃标签
	DELETE Ymt_MktSeller_BuyerLabel
	--SELECT A.*
	FROM dbo.Ymt_MktSeller_BuyerLabel A WITH(NOLOCK)
	INNER JOIN dbo.Ymt_MktSeller_Label B WITH(NOLOCK) ON A.LabelId = B.LabelId AND B.SellerId = A.SellerId AND B.IsDeleted<>0
	WHERE A.SellerId=@SellerId

	--删除买家已有的标签数据
	DELETE Ymt_MktSeller_BuyerLabel_Copy
	--SELECT C.* 
	FROM Ymt_MktSeller_BuyerLabel_Copy C WITH(NOLOCK)
	WHERE C.CopyBatchId=@CopyBatchId AND C.SellerId=@SellerId AND EXISTS 
	(
	SELECT 1 FROM (SELECT A.BuyerId,A.LabelId,A.SellerId FROM dbo.Ymt_MktSeller_BuyerLabel A WITH(NOLOCK)
	INNER JOIN dbo.Ymt_MktSeller_Label B WITH(NOLOCK) ON A.LabelId = B.LabelId AND A.SellerId = B.SellerId AND B.IsDeleted=0
	WHERE A.SellerId=@SellerId) D WHERE C.BuyerId=D.BuyerId AND C.LabelId=D.LabelId AND C.SellerId=D.SellerId
	)

	--获取买手关联的买家剩余标签数量
	DECLARE @TB_ResidualQty TABLE (BuyerId INT,ResidualQty INT)
	INSERT INTO @TB_ResidualQty(BuyerId,ResidualQty)
	SELECT DISTINCT A.BuyerId,ResidualQty=@MaxLabelCount - COUNT(0) FROM dbo.Ymt_MktSeller_BuyerLabel A WITH(NOLOCK)
	INNER JOIN Ymt_MktSeller_BuyerLabel_Copy C WITH(NOLOCK) ON C.BuyerId = A.BuyerId AND C.LabelId = A.LabelId AND C.SellerId = A.SellerId
	INNER JOIN dbo.Ymt_MktSeller_Label B WITH(NOLOCK) ON A.LabelId = B.LabelId AND A.SellerId = B.SellerId AND B.IsDeleted=0
	WHERE A.SellerId=@SellerId
	GROUP BY A.BuyerId

	--获取没有添加过标签的用户
	INSERT INTO @TB_ResidualQty(BuyerId,ResidualQty)
	SELECT DISTINCT D1.BuyerId,ResidualQty=@MaxLabelCount FROM Ymt_MktSeller_BuyerLabel_Copy D1 WITH(NOLOCK)
	WHERE D1.SellerId=@SellerId AND D1.CopyBatchId=@CopyBatchId
	AND NOT EXISTS(
		SELECT 1 FROM (SELECT BuyerId,SellerId FROM dbo.Ymt_MktSeller_BuyerLabel WITH(NOLOCK)
		WHERE SellerId=@SellerId) D2 WHERE D2.BuyerId=D1.BuyerId AND D1.SellerId=d2.SellerId
	)

	--从copy表中删除标签已满的买家信息
	DELETE Ymt_MktSeller_BuyerLabel_Copy
	--SELECT A.* 
	FROM Ymt_MktSeller_BuyerLabel_Copy A WITH(NOLOCK) INNER JOIN @TB_ResidualQty B ON A.BuyerId = B.BuyerId AND B.ResidualQty <= 0
	WHERE A.SellerId=@SellerId AND CopyBatchId=@CopyBatchId

	--批量设置买家标签
	INSERT INTO dbo.Ymt_MktSeller_BuyerLabel (BuyerId,LabelId,SellerId,AddTime,Memo)
	SELECT A.BuyerId,A.LabelId,SellerId=@SellerId,AddTime=GETDATE(),Memo='' FROM (
	SELECT BuyerId,LabelId,RowNum=ROW_NUMBER() OVER(PARTITION BY BuyerId ORDER BY LabelId) FROM Ymt_MktSeller_BuyerLabel_Copy WITH(NOLOCK) 
	WHERE SellerId=@SellerId AND CopyBatchId=@CopyBatchId) A INNER JOIN @TB_ResidualQty B ON A.BuyerId = B.BuyerId AND A.RowNum<=B.ResidualQty

	--清空本批次复制数据
	DELETE Ymt_MktSeller_BuyerLabel_Copy WHERE CopyBatchId=@CopyBatchId
END
