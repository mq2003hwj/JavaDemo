-- ============================================= 

-- Author: ccw

-- Create date: 2015-05-28 

-- Description: paymentoder分页查询

-- =============================================
CREATE proc csp_SearchPaymentOrder 
( 
@BizNo varchar(64), 
@PageIndex int, 
@PageSize int, 
@PayType int, 
@PaymentPlatform int, 
@PaymentMethod int, 
@PaymentStatus int, 
@TotalCount int output 
) 
as 
begin 
declare @intDefaultValue int 
set @intDefaultValue=-999999 

if(@BizNo!='') 
begin 
select @TotalCount=count(1) from dbo.PaymentOrder(nolock) 
where BizNo=@BizNo 
and (@PayType=@intDefaultValue or PayType=@PayType) 
and (@PaymentPlatform=@intDefaultValue or PaymentPlatform=@PaymentPlatform) 
and (@PaymentMethod=@intDefaultValue or PaymentMethod=@PaymentMethod) 
and (@PaymentStatus=-999999 or PaymentStatus=@PaymentStatus) 
select * from ( 
select *,ROW_NUMBER() over(order by AddTime desc) as rowCounts from dbo.PaymentOrder(nolock) 
where BizNo=@BizNo 
and (@PayType=@intDefaultValue or PayType=@PayType) 
and (@PaymentPlatform=@intDefaultValue or PaymentPlatform=@PaymentPlatform) 
and (@PaymentMethod=@intDefaultValue or PaymentMethod=@PaymentMethod) 
and (@PaymentStatus=-999999 or PaymentStatus=@PaymentStatus) 
) tb where rowCounts >= (@PageIndex-1)*@PageSize and rowCounts<@PageIndex*@PageSize 
end 
else 
begin 
select @TotalCount=count(1) from dbo.PaymentOrder(nolock) 
where (@PayType=@intDefaultValue or PayType=@PayType) 
and (@PaymentPlatform=@intDefaultValue or PaymentPlatform=@PaymentPlatform) 
and (@PaymentMethod=@intDefaultValue or PaymentMethod=@PaymentMethod) 
and (@PaymentStatus=-999999 or PaymentStatus=@PaymentStatus) 

select * from ( 
select *,ROW_NUMBER() over(order by AddTime desc) as rowCounts from dbo.PaymentOrder(nolock) 
where (@PayType=@intDefaultValue or PayType=@PayType) 
and (@PaymentPlatform=@intDefaultValue or PaymentPlatform=@PaymentPlatform) 
and (@PaymentMethod=@intDefaultValue or PaymentMethod=@PaymentMethod) 
and (@PaymentStatus=-999999 or PaymentStatus=@PaymentStatus) 
) tb where rowCounts >= (@PageIndex-1)*@PageSize and rowCounts<@PageIndex*@PageSize 
end 

end 

