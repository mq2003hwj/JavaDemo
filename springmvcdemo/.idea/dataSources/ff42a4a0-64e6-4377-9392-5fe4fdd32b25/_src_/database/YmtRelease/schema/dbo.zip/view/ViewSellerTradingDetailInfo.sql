CREATE VIEW dbo.ViewSellerTradingDetailInfo
AS
SELECT     dbo.Ymt_Orders.iOrderId AS SellerOrderId, dbo.Ymt_Orders.iUserId AS UserId, dbo.Ymt_Orders.iBuyerId AS SellerId, 
                      dbo.Ymt_OrderInfo.sCatalogId AS OrderCatalogId, dbo.Ymt_OrderInfo.iAmount, dbo.Ymt_OrderInfo.sPropertyInfo, dbo.Ymt_OrderInfo.fOriginalPrice AS CatalogPrice, 
                      dbo.Ymt_OrderInfo.fDiscount AS CatalogDiscount, dbo.Ymt_OrderInfo.fTotalPrice AS CatalogTotalPrice, dbo.Ymt_TradingInfo.sReceiveAddress, 
                      dbo.Ymt_TradingInfo.sPostCode, dbo.Ymt_TradingInfo.sTelphone, dbo.Ymt_TradingInfo.sCellPhone, dbo.Ymt_Catalogs.sProductId AS CatalogProductId, 
                      dbo.Ymt_Catalogs.sPicUrl, dbo.Ymt_Products.sProduct
FROM         dbo.Ymt_Catalogs LEFT OUTER JOIN
                      dbo.Ymt_Products ON dbo.Ymt_Catalogs.sProductId = dbo.Ymt_Products.sProductId RIGHT OUTER JOIN
                      dbo.Ymt_OrderInfo ON dbo.Ymt_Catalogs.sCatalogId = dbo.Ymt_OrderInfo.sCatalogId RIGHT OUTER JOIN
                      dbo.Ymt_Orders LEFT OUTER JOIN
                      dbo.Ymt_TradingInfo ON dbo.Ymt_Orders.iTradingId = dbo.Ymt_TradingInfo.iTradingId ON dbo.Ymt_OrderInfo.iOrderId = dbo.Ymt_Orders.iOrderId
