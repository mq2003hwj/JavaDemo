CREATE VIEW dbo.View_OrderSummaryForXlobo
AS
SELECT     iOrderId
FROM         dbo.Ymt_OrderSummary
WHERE     (sSummary LIKE '%bh%')
