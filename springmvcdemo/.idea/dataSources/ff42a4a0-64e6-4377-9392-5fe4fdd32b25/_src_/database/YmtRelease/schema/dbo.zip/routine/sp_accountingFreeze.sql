


-- ===========================================================================================================
-- Author:		Tony
-- Create date: 2016-1-19
-- Description:	账户资金冻结解冻
-- Change log:
-- ===========================================================================================================
create PROCEDURE [dbo].[sp_accountingFreeze]
	@accountId		varchar(36),			--账户编号
	@amount			decimal(10, 2),			--发生金额
	@operator		varchar(50),			--操作员
	@memo			varchar(1000),			--备注
	@originalNo		varchar(100),			--原始单号
	@bizSerialNo	varchar(100),			--业务流水号
	@appId			varchar(50),			--应用编号
	@bizCode		int,					--业务操作代码
	@serverIP		varchar(50),			--服务器IP
	@clientIP		varchar(50),			--调用者IP
	@accountingDate datetime2,				--操作日期
	@requestId		varchar(50),			--唯一的请求编号
	@freezeAmount	decimal(10, 2) output,	--操作后的冻结金额
	@availAmount	decimal(10, 2) output	--操作后的可用金额
AS

	DECLARE @entryType int
	DECLARE @userId int
	DECLARE @rowCount int
	DECLARE @beforeUpdateTime datetime
	DECLARE @ErrorMessage NVARCHAR(4000)
	DECLARE @ErrorSeverity INT
	DECLARE @ErrorState INT
	DECLARE @ErrorNumber INT

	SET @entryType = 4 --代表冻结解冻操作
BEGIN
	BEGIN TRY
		UPDATE Ymt_AccountInfo SET [fAvailAmount] = [fAvailAmount] - @amount
			, [fFreezeAmount] = [fFreezeAmount] + @amount
			, @availAmount = [fAvailAmount] - @amount
			, @freezeAmount = [fFreezeAmount] + @amount
			, @userId = iUserId
			, @beforeUpdateTime = [dUpdateTime]
			, [dUpdateTime] = GETDATE() 
		WHERE [sAccountInfoId] = @accountId 
		SET @rowCount = @@ROWCOUNT
	END TRY
	BEGIN CATCH
		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE(),
			@ErrorNumber = ERROR_NUMBER();

		IF CHARINDEX('fAvailAmount', @ErrorMessage) > 0 BEGIN
			RETURN 9002	--可用余额不足
		END

		IF CHARINDEX('fFreezeAmount', @ErrorMessage) > 0 BEGIN
			RETURN 9003	--冻结余额不足
		END

		IF @rowCount = 0 BEGIN
			RETURN 9001	--资金账户不存在
		END

		--未知异常直接抛出
		RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState)
	END CATCH

	--资金账户不存在
	IF @rowCount = 0 BEGIN
		RETURN 9001
	END

	--可用余额不足
	IF @availAmount < 0 BEGIN
		RETURN 9002
	END

	--冻结余额不足
	IF @freezeAmount < 0 BEGIN
		RETURN 9003
	END

	--记录资金操作流水
	BEGIN TRY
		INSERT INTO [dbo].[Ymt_AccountEntry]
			   ([AccountId],[Amount],[FreezeAmount],[AvailAmount],[EntryType],[UserId],[BizCode],[BizNo],[OriginalNo],[AccountingDate],[UpdateTime]
			   ,[Operator],[Memo],[AppId],[ServerIp],[ClientIp],[RequestId])
		VALUES
			   (@accountId, @amount, @freezeAmount, @availAmount, @entryType, @userId, @bizCode, @bizSerialNo, @originalNo, @accountingDate, getdate()
			   ,@operator, @memo, @appId, @serverIP, @clientIP, @requestId )
	END TRY
	BEGIN CATCH
		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE(),
			@ErrorNumber = ERROR_NUMBER();

		IF @ErrorNumber = 2601 BEGIN
			return 9000	--违反唯一约束，返回幂等状态码
		END
		
		--未知异常直接抛出
		RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState)
	END CATCH

	--返回成功
	RETURN 0
END

