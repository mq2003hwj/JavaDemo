



-- =============================================            
-- Author:  fanwei        
-- Create date: 2016-4-13
-- Description: 更新卖家订单商品信息      
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_UpdateSellerOrderProductNames]
@seller int,
@time datetime,
@products StringKeyValues readonly
AS

merge into Trd_SellerProductNames as s
using @products as p on s.SellerId = @seller and s.MD5 = p.[Key]
when matched and s.LastUsedTime < @time
then update set s.LastUsedTime = @time, s.UsedTimes = s.UsedTimes + 1
when not matched
then insert ([SellerId],[MD5],[ProductName],[LastUsedTime]) values(@seller,p.[Key],p.[Value],@time)
;
