-- 修改红包有效期存储过程
CREATE PROCEDURE [dbo].[p红包过期] AS 
BEGIN

	BEGIN TRANSACTION
	
	-- 当天有资金变化(获取)的，且在用户红包中没有记录或者用户红包未超过30天的，将有效期变更为最后获取红包时间+30天
	UPDATE Ymt_GiftAccountInfo set ExpiredDate = DATEADD(DAY,30,temp.LastDate)
	FROM (
		SELECT iUserId,Max(dAddTime) AS LastDate
		FROM Ymt_GiftAccountRunningTally with (Nolock)
		WHERE fOccurredAmount>0 and dAddTime >= CONVERT(varchar(10),getdate() - 1,120) and dAddTime < CONVERT(varchar(10),getdate() + 1,120)
		GROUP BY iUserId
	) AS temp
	--WHERE ExpiredDate IS NULL OR DATEDIFF(DAY,GETDATE(),ExpiredDate) < 30 
	WHERE (ExpiredDate IS NULL OR DATEDIFF(DAY,GETDATE(),ExpiredDate) < 29 )
	and Ymt_GiftAccountInfo.iUserId = temp.iUserId

	--红包过期用户
	DECLARE @T TABLE([ID] [int] NOT NULL)


	INSERT INTO @T
	SELECT iUserId
	FROM Ymt_GiftAccountInfo with (Nolock)
	--WHERE DATEDIFF(DAY,GETDATE(),ExpiredDate) < 0 and iUserId > 0
	WHERE DATEDIFF(DAY,GETDATE(),ExpiredDate) < 0 and [fAvailAmount] > 0

	--插入流水
	INSERT INTO  [Ymt_GiftAccountRunningTally]
	 ([sRunningTallyId]
	 ,[fOccurredAmount]
	 ,[iType]
	 ,[iUserId]
	 ,[fBalance]
	 ,[fFreezeAmount]
	 ,[fAvailAmount]
	 ,[dAddTime]
	 ,[sOperator]
	 ,[sUseage])
	 SELECT NEWID(),-a.fAvailAmount,2, u.iUserId,0,0,0,GETDATE(),N'红包过期清零',N'红包过期清零' 
	 FROM @T t  
	 INNER JOIN Ymt_Users u with (Nolock) ON t.ID = u.iUserId
	 INNER JOIN Ymt_GiftAccountInfo a with (Nolock) ON t.ID = a.iUserId

	--更新用户帐户 
	UPDATE [Ymt_GiftAccountInfo] SET [fAvailAmount]=0 WHERE iUserId in (SELECT ID FROM @T)

	COMMIT TRANSACTION 
END




