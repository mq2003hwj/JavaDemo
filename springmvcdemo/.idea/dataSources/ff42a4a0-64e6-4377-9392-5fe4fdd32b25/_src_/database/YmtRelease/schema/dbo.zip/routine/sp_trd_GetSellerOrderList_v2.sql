
-- =============================================            
-- Author:  Deng Peng     
-- Create Time:2016-05-20
-- Description: PC Seller 订单列表 MONGODB版
-- 20160527：添加实际退平台优惠券金额的统计
-- 20160613：添加对订单卖家备注查询的支持
-- 20160615：变新Ext左联接查询规则：先关联查询再对结果做过滤
--		Ymt_Orders与Ymt_OrderExt记录不对等情况，查询情况分为：1.指定旗子，2.Ext没有或为NULL的
-- 20160621：添加促销活动相关数据信息
-- 20160623：添加对支付时间的查询判断（取最终支付时间），即存在尾款支付以尾款时间作为支付时间，反之支付时间
-- 20160818：取消根据风控状态转变交易状态的逻辑
-- =============================================

CREATE procedure [dbo].[sp_trd_GetSellerOrderList_v2]
	@sellerId int,
	@orderType int,
	@shangou bit,
	@orderStatusXml xml,
	@catalogStatusXml xml,
	@addBeginTime datetime,
	@addEndTime datetime,
	@paidBeginTime datetime,
	@paidEndTime datetime,
	@paidInFull bit,
	@rowFrom int,
	@rowTo int,
	@buyerNickName nvarchar(20),
	@productName nvarchar(500),
	@considerOrderStatus bit,
	@considerRCOrderEstablish bit,
	@considerRCAccountPaid bit,
	@considerRestOrderStatus bit,
	@salesRefundOrderOnly bit = 0,
	@domesticDelivered bit = null,
	@mainOrderId int = null,
	@OrderId int = null,
	@RemarkLevel int = null
as 

-------------variables-------------
set nocount on;

set @ProductName = isnull(@ProductName,'');

create table #mainOrderIdFull ([iMainOrderId] int not null, [iOrderId] int not null);

declare @sqlCmd nvarchar(max) ;

-- 固定两表关联脚本开始
set @sqlCmd = '
	select '+ (case when @productName<>'' or @catalogStatusXml is not null then 'distinct' else '' end)+' [order].[iMainOrderId], [order].[iOrderId] from [dbo].[Ymt_Orders] as [order] with(nolock'+ case 
		when @addBeginTime is not null or  @addEndTime is not null then ',index = idx_Ymt_Orders_iBuyerId_dAddTime'
		when @paidBeginTime is not null or @paidEndTime is not null then ',index = idx_Ymt_Orders_iBuyerId_dPaidTime'
		else '' end + ')';

--看是否进行了关联查询
if @catalogStatusXml is not null or @ProductName <> '' begin
	set @sqlCmd = @sqlCmd + '
	inner loop join [dbo].[Ymt_OrderInfo] as [orderInfo] with(nolock) on [orderInfo].[iOrderId] = [order].[iOrderId]';

	--存在商品名称关键字查询
	if isnull(@ProductName,'') <> '' begin
		set @sqlCmd = @sqlCmd + ' and [orderInfo].[sTitle] like ''%'' + @ProductName + ''%''' ;
	end

	--存在物流方式查询
	if @catalogStatusXml is not null begin
		set @sqlCmd = @sqlCmd +'
		and [orderInfo].[iCatalogStatus] in (select tbl.col.value(''@s'',''int'') from @catalogStatusXml.nodes(''/root/x'') tbl(col))';
	end

end

--看是否进行了订单卖家备注关联查询
if @RemarkLevel is not null begin
	set @sqlCmd = @sqlCmd + '
	left join [dbo].[Ymt_O_OrderNote] as [orderNote] with(nolock) on [orderNote].[iOrderId] = [order].[iOrderId] and [orderNote].[iUserId] = [order].[iBuyerId]'
end

--固定参数
set @sqlCmd = @sqlCmd + '
	where [order].[iBuyerId] = @sellerId'

--指定了订单卖家血备注查询条件:Ext记录不对等情况只能先关联结果再过滤
if @RemarkLevel is not null begin
	set @sqlCmd = @sqlCmd + '
	  and [orderNote].[iRemarkLevel]' + case 
														when @RemarkLevel = 0 then ' is null ' 
														else ' = ' + cast(@RemarkLevel as varchar(8)) end;
end

--存在指定订单号查询
if @OrderId is not null begin
	set @sqlCmd = @sqlCmd + ' 
	and [order].[iOrderId] = ' + cast(@OrderId as varchar(36)) ;
end

--存在指定主订单号查询
if @MainOrderId is not null begin
	set @sqlCmd = @sqlCmd + ' 
	and [order].[iMainOrderId] = ' + cast(@MainOrderId as varchar(36)) ;
end

--下单开始时间
if( @addBeginTime is not null) begin
	set @sqlCmd = @sqlCmd + ' 
	and [order].[dAddTime] >= convert(varchar(10), @addBeginTime, 120)';
end

--下单结束时间
if( @addEndTime is not null) begin
	set @sqlCmd = @sqlCmd + ' 
	and [order].[dAddTime] < convert(varchar(10), dateadd(day,1,@addEndTime) , 120)';
end

--支付开始时间
if( @paidBeginTime is not null) begin
	set @sqlCmd = @sqlCmd + ' 
	and ( ([order].[dPostPaidTime] is null and [order].[dPaidTime] >= convert(varchar(10), @paidBeginTime, 120)) or [order].[dPostPaidTime] >= convert(varchar(10), @paidBeginTime, 120) )';
end

--支付结束时间
if( @paidEndTime is not null) begin
	set @sqlCmd = @sqlCmd + ' 
	and ( ([order].[dPostPaidTime] is null and [order].[dPaidTime] < convert(varchar(10), dateadd(day,1,@paidEndTime), 120)) or [order].[dPostPaidTime] < convert(varchar(10), dateadd(day,1,@paidEndTime), 120) )';
end

--买家名称
if( @BuyerNickName is not null) begin
	set @sqlCmd = @sqlCmd + ' 
	and [order].[sBuyerNickName] = @BuyerNickName';
end

if @orderStatusXml is not null begin
	set @sqlCmd = @sqlCmd +'
	 and [order].[iTradingStatus] in (select tbl.col.value(''@s'',''int'') from @orderStatusXml.nodes(''/root/x'') tbl(col))';
end

--存在交易状态
/*
set @sqlCmd = @sqlCmd +(case 
when @considerOrderStatus = 0 then ''
when @considerRCOrderEstablish = 1 then ' and ([order].[iTradingStatus] = 1 or [order].[iTradingStatus] = 2 and [order].[iRiskVerifiedStatus] = 1)'
when @considerRCAccountPaid = 1 then ' and ([order].[iTradingStatus] = 2 and ([order].[iRiskVerifiedStatus] is null or [order].[iRiskVerifiedStatus] = 2))'
when @considerRestOrderStatus = 1 then ' and [order].[iTradingStatus] in (select tbl.col.value(''@s'',''int'') from @orderStatusXml.nodes(''/root/x'') tbl(col))' 
else '' end);
*/

--存在指定全款
if @paidInFull is not null begin
	set @sqlCmd = @sqlCmd + ' 
	and [order].[bPaidInFull] = ' + cast(@paidInFull as char(1));
end

if @domesticDelivered is not null begin
	set @sqlCmd = @sqlCmd +'
	and isnull([order].[bDomesticDelivered], 0) = '+ cast(@domesticDelivered as char(1));
end

if @salesRefundOrderOnly <> 0 begin
	set @sqlCmd = @sqlCmd +'
	and [order].[iSalesRefundStatus] is not null ';
end

set @sqlCmd = '
;with datatable as (
' + @sqlCmd + '
)
insert into #mainOrderIdFull([iMainOrderId], [iOrderId]) select [iMainOrderId], [iOrderId] from datatable ;'
--执行脚本
exec sp_executesql @sqlCmd
	, N'@sellerId int,@orderStatusXml xml,@catalogStatusXml xml,@buyerNickName nvarchar(20),@productName nvarchar(500),@addBeginTime datetime,@addEndTime datetime,@paidBeginTime datetime,@paidEndTime datetime'
	, @SellerId,@orderStatusXml,@catalogStatusXml,@buyerNickName,@productName,@addBeginTime,@addEndTime,@paidBeginTime,@paidEndTime

print @sqlCmd

--分页数据:	获取当前页的所有订单ID
declare @PaginationOrderId table([iMainOrderId] int not null, [iOrderId] int not null);
------------------------------------------------------------------
insert into @PaginationOrderId( [iMainOrderId], [iOrderId] )
select [iMainOrderId],[iOrderId] from #mainOrderIdFull order by [iMainOrderId] desc
	offset @rowFrom - 1 rows fetch next @rowTo - @rowFrom + 1 rows only

--最大最小主订单特殊处理
------------------------------------------------------------------
declare @maxMainOrderId int
declare @minMainOrderId int

select @maxMainOrderId = max([iMainOrderId]) from @PaginationOrderId
select @minMainOrderId = min([iMainOrderId]) from @PaginationOrderId

--最大：当前页与统计来的数据不一致且主订单数大于1个，剔除 (排除第一页，即其实为1的情况)
if  ( select count(1) from #mainOrderIdFull where [iMainOrderId] = @maxMainOrderId ) <> ( select count(1) from @PaginationOrderId where [iMainOrderId] = @maxMainOrderId )
	and (select count(distinct [iMainOrderId]) from @PaginationOrderId ) > 1 and @rowFrom > 1
begin
	delete @PaginationOrderId where [iMainOrderId] = @maxMainOrderId
end

--最小：当前页与统计来的数据不一致，剔除，再追加所有
if ( select count(1) from #mainOrderIdFull where [iMainOrderId] = @minMainOrderId ) <> ( select count(1) from @PaginationOrderId where [iMainOrderId] = @minMainOrderId )
begin
	delete @PaginationOrderId where [iMainOrderId] = @minMainOrderId
	insert into @PaginationOrderId( [iMainOrderId], [iOrderId] )
	select [iMainOrderId], [iOrderId] from #mainOrderIdFull where [iMainOrderId] = @minMainOrderId
end

--获取当前分页的OrderId
declare @orderIds Int32Array
insert into @orderIds ([Value])
select [iOrderId] from @PaginationOrderId

--统计订单总量
declare @totalCount int
select @totalCount = count(1) from #mainOrderIdFull;

drop table #mainOrderIdFull ;

--当页订单的详细信息
exec [dbo].[sp_trd_GetSellerOrdersByOrderIds_v1] @orderIds, @sellerId, @totalCount

set nocount off;
