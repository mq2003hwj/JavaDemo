-- =============================================
-- Author:		zhujinfeng
-- Create date: 2016-06-08
-- Description:	限购服务操作sql
-- =============================================
CREATE PROCEDURE [dbo].[SP_Product_AddLimitData]
	@BuyerId INT,
	@ProductId VARCHAR(36),
	@ActivityId INT,
	@ProductLimitNumber INT,
	@ProductLimitStartTime DATETIME,
	@ActivityLimitNumber INT,
	@BuyCount INT
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @Id INT;
	DECLARE @ProductResult INT;   -- 0 为商品限购，超出限购， 1- 不限购或没有超出限购
	DECLARE @ActivityResult INT;  -- 0 为活动限购，超出限购， 1- 不限购或没有超出限购

	-- 检查商品限购
	IF(@ProductLimitNumber > 0)
	BEGIN
	
		SET @Id = (SELECT TOP 1 ISNULL(Id,0) FROM Ymt_ProductLimitStats WHERE BuyerId = @BuyerId AND ProductId = @ProductId AND [ProductLimitTime] = @ProductLimitStartTime);
		PRINT @Id;
		IF @Id > 0
		BEGIN
			UPDATE Ymt_ProductLimitStats SET ProductLimit= @ProductLimitNumber, BoughtNumber = BoughtNumber + @BuyCount WHERE Id = @Id AND BoughtNumber + @BuyCount <= @ProductLimitNumber
			IF(@@RowCount = 1)
				SET @ProductResult = 1;
			ELSE
				SET @ProductResult = 0
		END
		ELSE
		BEGIN
			IF(@BuyCount <= @ProductLimitNumber)
			BEGIN  
				INSERT Ymt_ProductLimitStats ([BuyerId],[ProductId],[ActivityId],[BoughtNumber],[ProductLimit],[ProductLimitTime],[ActivityLimit],[AddTime])
				VALUES (@BuyerId,@ProductId,0,@BuyCount,@ProductLimitNumber,@ProductLimitStartTime,0,GETDATE());
			
				SET @ProductResult = 1;
			END
			ELSE
				 SET @ProductResult = 0;     
		END
	END
	ELSE
		SET @ProductResult = 1;

	-- 检查活动限购
	IF(@ActivityId > 0 AND @ActivityLimitNumber > 0)
	BEGIN

		SET @Id = (SELECT TOP 1 ISNULL(Id,0) FROM Ymt_ProductLimitStats WHERE BuyerId = @BuyerId AND ActivityId = @ActivityId);
		PRINT @Id;
		IF @Id > 0
		BEGIN
			UPDATE Ymt_ProductLimitStats SET ActivityLimit=@ActivityLimitNumber, BoughtNumber = BoughtNumber + @BuyCount WHERE Id = @Id AND BoughtNumber + @BuyCount <= @ActivityLimitNumber
			IF(@@RowCount = 1)
				SET @ActivityResult = 1;
			ELSE
				SET @ActivityResult = 0
		END
		ELSE
		BEGIN
			IF(@BuyCount <= @ActivityLimitNumber)
			BEGIN  
				INSERT Ymt_ProductLimitStats ([BuyerId],[ProductId],[ActivityId],[BoughtNumber],[ProductLimit],[ProductLimitTime],[ActivityLimit],[AddTime])
				VALUES (@BuyerId,@ProductId,@ActivityId,@BuyCount,0,@ProductLimitStartTime,@ActivityLimitNumber,GETDATE());
			
				SET @ActivityResult = 1;
				PRINT @ActivityResult;
			END
			ELSE
				 SET @ActivityResult = 0;     
		END
	END
	ELSE
		SET @ActivityResult = 1;

	SELECT @ProductResult AS ProductResult, @ActivityResult AS ActivityResult;
END
