-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[FDiff]
(
	-- Add the parameters for the function here
	@p1 datetime,@p2 datetime
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	
	RETURN 0

END
