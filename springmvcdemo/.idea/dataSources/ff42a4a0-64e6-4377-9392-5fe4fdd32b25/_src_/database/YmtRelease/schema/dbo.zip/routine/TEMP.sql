-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[TEMP] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @tempAllCategorys TABLE (rowid int,id int,level int,masterId int)
	INSERT INTO @tempAllCategorys SELECT ROW_NUMBER() OVER(ORDER BY iLevel,iCategoryId) AS RowNumber,iCategoryId,iLevel,iMasterCategory FROM Ymt_ProductCategory WHERE iAction=0 ORDER BY iLevel,iCategoryId

	DECLARE @tttt TABLE (rowid int,id int,level int,masterId int,mid varchar(20))
	INSERT INTO @tttt SELECT ROW_NUMBER() OVER(ORDER BY iLevel,iCategoryId) AS RowNumber,iCategoryId,iLevel,iMasterCategory,CAST(iMasterCategory as varchar) FROM Ymt_ProductCategory WHERE iAction=0 ORDER BY iLevel,iCategoryId

    CREATE TABLE #TableT(rowid int,id int,level int,masterId int,mid varchar(20))
    INSERT INTO #TableT SELECT ROW_NUMBER() OVER(ORDER BY iLevel,iCategoryId) AS RowNumber,iCategoryId,iLevel,iMasterCategory,CAST(iMasterCategory as varchar) FROM Ymt_ProductCategory WHERE iAction=0 ORDER BY iLevel,iCategoryId

	SELECT * FROM @tempAllCategorys
	
	DECLARE @IndexCategory TABLE (id int,subcategoryIds int,catwithsub varchar(500))
	
	DECLARE @tempRowId int
	
	--SET @tempCategoryId = (SELECT TOP 1 iCategoryId FROM @IndexCategory)
	SELECT @tempRowId=MIN(rowid) FROM @tempAllCategorys
	
	DECLARE @tempCategoryId int
	--SELECT  @tempCategoryId=ABS(iCategoryId) FROM @tempAllCategorys
	----WHILE @tempRowId IS NOT NULL
	----BEGIN
	----	--SELECT @ TOP 1 
	----	--SELECT * FROM @tempAllCategorys WHERE masterId = 
	----	SELECT @tempRowId=MIN(rowid) FROM @tempAllCategorys WHERE rowid>@tempRowId
	----	--DECLARE @temdCT TABLE 
		
	----	SELECT * FROM @IndexCategory
	----END
	
	declare @var1 int=1
	declare @var2 varchar(500)
	SET @var2 = '1,2';
	
	declare @var3 varchar(500)
	SET @var3 =''
	declare @var4 int =1
	declare @var5 int =0
	----print @var2
	WHILE @var4>@var5
	BEGIN
	SET @var3=@var2
	print '---@var2-----'
	print (@var2)
    print '---@var3-----'
	print (@var3)
	print '-------------'

	----if(@var4<5)
	--begin
	--SET @var2+='q'
	--end
	--SET @var3+='w'
	--print 'fff'
	----SET @var5 +=1

	----SET @var3=@var2
	----Print @var3
	declare @tmp nvarchar(500)='1'
	print '---@tmp-----------'
	print @tmp
	print 'test1'
	declare @sqltmp nvarchar(4000) = '';
	declare @tmp1 varchar(400)
	SET @tmp1 = ''
	SELECT @tmp1=@tmp1+','+cast(id as varchar)  from  @tttt where mid in (select @var2)
	---SET @sqltmp = 'SELECT @tmp1=@tmp1+'+''','''+'+'+'cast(id as varchar)  from  @tttt where  where id in ('+@var2+')'
	
	DECLARE @ttfff nvarchar(4000)	
	create table #ttttf(id int)
	SET @ttfff = 'insert into #ttttf select id from #TableT where mid in (' +@var2+')'
	execute sp_ExecuteSQL @ttfff
	SELECT @tmp1=@tmp1+','+cast(id as varchar) from #ttttf 
	print @ttfff
	select  * from  #ttttf
	 
	drop table #ttttf
	
	
	---print @sqltmp
	---execute sp_executeSql  @sqltmp,@tmp1=@tmp
	print 'test2'
	print '--tmp after--------------'
	print @tmp1
	print '--tmp after end----------'
	SET @var2=stuff(@tmp1,1,1,'')
	print '---var2-------'
	print @var2
	print '---var2 end-----------'
		SET @var4 = LEN(@var2)
	SET @var5 = LEN(@var3)
	print '---var4--------'
   print @var4
   print '----var5---------'
   print @var5
   print '------vaddd----'
   print '=======pause====='
	--SET @var2 = stuff(@tmp,1,1,'')   
	END
	
--declare @str varchar(8000)   
--set @str=''   
--select @str=@str+','+cast(iCategoryId as varchar)  from  dbo.Ymt_ProductCategory where iMasterCategory in (1)
--select stuff(@str,1,1,'')   
--DECLARE @ffff varchar(40)
--SET @ffff=stuff(@str,1,1,'')  
--print @ffff 
--print Cast(@ffff as int)
--select @str=@str+','+cast(iCategoryId as varchar)  from  dbo.Ymt_ProductCategory where iMasterCategory in (Cast(@ffff as int))
--select stuff(@str,1,1,'')   
	
	
	
	--create table #tempc(id int,scat varchar(50))
	--select * from Ymt_ProductCategory;
	--select iCategoryId,sCategory into #tempc
	--drop table #tempc
	

    -- Insert statements for procedure here
    DROP TABLE #TableT
	
END
