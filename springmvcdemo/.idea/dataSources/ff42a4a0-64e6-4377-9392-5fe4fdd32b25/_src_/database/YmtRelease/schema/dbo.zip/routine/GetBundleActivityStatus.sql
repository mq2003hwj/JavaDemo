
-- =============================================
-- Author:		zhujinfeng
-- Create date: 2015-10-24
-- Description:	取套餐在活动中的状态
-- =============================================
CREATE FUNCTION [dbo].[GetBundleActivityStatus]
(
	-- 套餐编号， 
	@BundleId VARCHAR(20)
)
-- 返回套餐参加活动的状态， 0-待关联， 1-待开始，2-进行中，3-已结束
RETURNS INT 
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Status INT;

	-- 不存在，为待关联
	IF NOT EXISTS(SELECT 1 FROM dbo.Ymt_ProductBundleInActivity WHERE BundleId = @BundleId AND [Status] > -1 AND EndTime > BeginTime)
    BEGIN
		SET @Status = 0;
	END  
	-- 开始时间小于当前时间， 结束时间大于当前时间，为进行中
	ELSE IF EXISTS (SELECT 1 FROM dbo.Ymt_ProductBundleInActivity WHERE BundleId = @BundleId AND  GETDATE() BETWEEN BeginTime AND EndTime and Status > -1) 
    BEGIN
		SET @Status = 2;
	END  
	-- 开始时间大于当前时间，为待开始
	ELSE IF EXISTS(SELECT 1 FROM dbo.Ymt_ProductBundleInActivity WHERE BundleId = @BundleId AND Status > -1 AND BeginTime > GETDATE())
	BEGIN
		SET @Status = 1;
	END  
	-- 结束时间小于当前时间，为已结束
	ELSE IF EXISTS(SELECT 1 FROM dbo.Ymt_ProductBundleInActivity WHERE BundleId = @BundleId  AND  Status > -1 AND EndTime < GETDATE() )
	BEGIN
		SET @Status = 3;
	END  

	-- Return the result of the function
	RETURN @Status;

END



