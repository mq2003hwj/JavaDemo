



-- =============================================
-- Author:		张建涛
-- Create date: 2015-6-14
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Ymt_App_TuanMember_Insert]
	@GroupCode varchar(5),
	@TopicId int,
	@UserId int,
	@PicUrl varchar(500)
AS
BEGIN
	declare @member int =(select count(1) from Ymt_App_TuanMember where iTopicId=@TopicId and sGroupCode=@GroupCode and iUserId=@UserId)
	declare @topicNumber int =(select iMemberNumber from Ymt_App_TuanTopic where iTopicId=@TopicId)
	declare @memberCount int =(select count(1) from Ymt_App_TuanMember where iTopicId=@TopicId and sGroupCode=@GroupCode)

	if (@member=0 and (@memberCount<=@topicNumber))
	begin
	   INSERT INTO Ymt_APP_TuanMember
       ([sGroupCode],[iUserId] ,[iTopicId],[sStatus],[dCreatedDate],[sPicUrl]) 
	   VALUES
       (@GroupCode,@UserId ,@TopicId,1,GETDATE(),@PicUrl)
	end
END


