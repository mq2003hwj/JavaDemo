



-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-5-23
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_ExistsExportOrderInfo]

@sellerId int,
@orderType int,
@timeType int,
@beginTime  datetime,
@endTime datetime,
@paidInFull bit,
@orderStatusXml xml,
@keyword varchar(200),
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@logisticsTypesXml xml = null
AS

-------------variables-------------
declare @orderStatus table(value int primary key);
declare @logisticsTypes table(value int primary key);

declare @rowCount int = 0;

--------------process--------------
if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

if @logisticsTypesXml is not null
begin
    insert into @logisticsTypes 
    select tbl.col.value('@s','int')
    from @logisticsTypesXml.nodes('/root/x') tbl(col)
end


select top 1 1
from ymt_orders(nolock) o 
join ymt_orderinfo(nolock) i on o.iorderid = i.iorderid
where iBuyerId = @sellerId
and (@timeType = 0
or @timeType = 1 and o.dAddTime between @beginTime and @endTime
or @timeType = 2 and o.dPaidTime between @beginTime and @endTime
or @timeType = 3 and o.dDispathTime between @beginTime and @endTime
or @timeType = 4 and o.dApplyPostPayTime between @beginTime and @endTime
)
and (
  @paidInFull is null and @considerOrderStatus = 0
  or
  @paidInFull is not null and (o.iTradingStatus = 17 and o.bPaidInFull = @paidInFull)
  or 
  (
    @considerOrderStatus = 0 and 1 < 0
    or @considerOrderStatus = 1 and
    (
      (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
        or
      (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
        or
      (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
    )
  )
)
and (@orderType = 0
or @orderType = 1 and (o.bShangouOrder = 1 or i.sCatalogId is not null)
or @orderType = 2 and o.bShangouOrder = 0
or @orderType = 3 and (o.bShangouOrder = 1 or i.sCatalogId is null)
or @orderType = 4 and (o.bShangouOrder = 0 and i.sCatalogId is not null)
or @orderType = 5 and o.bShangouOrder = 1
or @orderType = 6 and i.sCatalogId is null
)
and (@logisticsTypesXml is null
or i.iCatalogStatus in (select value from @logisticsTypes)
)
and (@keyword is null
or (o.iOrderId like @keyword or i.sSKU like @keyword or i.sTitle like @keyword)
)
