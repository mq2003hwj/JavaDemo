-- =============================================          
-- Author:  zhangzhiqiang          
-- Create date: 2014-8-8       
-- Description: 获取优惠券列表          
-- =============================================    
CREATE PROCEDURE [dbo].[SPGetCouponInfoList]  
	@SellerId VARCHAR(50), 
	@BuyerId INT,
	@Amount DECIMAL(18,2),
	@UsePlatform VARCHAR(100) = NULL
AS  
BEGIN
    SET NOCOUNT ON
    SET LOCK_TIMEOUT 3000
    DECLARE @CurrentDate VARCHAR(10)
    SET @CurrentDate = CONVERT(VARCHAR(10),GETDATE(),120)
    SET @SellerId = ',' + @SellerId + ','
    SET @UsePlatform = ',' + ISNULL(@UsePlatform,'') + ','
	
	SELECT Coupon.sCouponCode,CSetting.iCouponUseType,Coupon.dValidStart,Coupon.dValidEnd,CValue.fMinOrderValue,CValue.fCouponValue,CBound.iCouponUsedCount,CSetting.iMaxUseTimePerUser,Coupon.iCouponSetting	
	INTO #CouponList
	FROM Ymt_Coupon Coupon WITH(NOLOCK)
		JOIN Ymt_CouponPrivateUserBound CBound WITH(NOLOCK) ON Coupon.sCouponCode = CBound.sCouponCode
		JOIN Ymt_CouponSetting CSetting WITH(NOLOCK) ON Coupon.iCouponSetting = CSetting.iCouponSettingId
		JOIN Ymt_CouponValue CValue WITH(NOLOCK) ON Coupon.iCouponSetting = CValue.iCouponSettingId
	WHERE CBound.iUserId=@BuyerId
		AND CBound.iCouponUsedCount > 0
		AND CValue.fMinOrderValue <= @Amount
		AND Coupon.dValidStart <= @CurrentDate AND Coupon.dValidEnd >= @CurrentDate
		AND EXISTS(SELECT 1 FROM Ymt_CouponScenario Scenario WITH(NOLOCK) WHERE CSetting.iScenarioId = Scenario.iCouponScenarioId
			AND (ISNULL(Scenario.sSellerIds,'')='' OR CHARINDEX(@SellerId,','+ISNULL(Scenario.sSellerIds,'')+',')>0)
			AND (ISNULL(Scenario.sUsePlatforms,'')='' OR CHARINDEX(@UsePlatform,','+Scenario.sUsePlatforms+',')>0)
			AND ISNULL(Scenario.sLogisticsTypes,'')=''
			AND ISNULL(Scenario.sProductCategories,'')='' AND ISNULL(Scenario.sSpecificProducts,'')='')

    SELECT * FROM #CouponList cl WHERE EXISTS(
    SELECT 1 FROM (SELECT sCouponCode,MAX(fMinOrderValue) AS fMinOrderValue FROM #CouponList GROUP BY sCouponCode) coupon 
     WHERE coupon.sCouponCode=cl.sCouponCode AND coupon.fMinOrderValue=cl.fMinOrderValue)
     
    DROP TABLE #CouponList
    SET NOCOUNT OFF
END

