CREATE FUNCTION [dbo].[GetProductUrlByOrderInfoId]
(	
	@orderInfoId nvarchar(1024)
)
RETURNS nvarchar(1024)
AS

BEGIN
	--DECLARE @orderInfoId varchar(36)
	--SET @orderInfoId = '47769189-0953-4d3f-bf13-17db49b6833c'
	DECLARE @result nvarchar(1024), @nullCatalogCount int
	SET @nullCatalogCount = 0
		
	SET @nullCatalogCount = (
								SELECT count(*) FROM Ymt_OrderInfo
								WHERE isnull(sCatalogId, '') > '' and sOrderInfoId=@orderInfoId
							)
	--SELECT @nullCatalogCount as NullCatalogCount

	If @nullCatalogCount > 0         -- 是现货 
		SET @result = (
						Select P.sPicUrl from Ymt_Products P 
						Inner join Ymt_Catalogs C on P.sProductId = C.sProductId
						inner join Ymt_OrderInfo I on C.sCatalogId = I.sCatalogId
						where I.sOrderInfoId=@orderInfoId
					   ) 
	If @nullCatalogCount = 0         -- 是代购
		SET @result = (
						Select sPictureUrl from Ymt_OrderInfo
						where sOrderInfoId=@orderInfoId
					   )
	--Select @result as result
	
	return @result;
END	





