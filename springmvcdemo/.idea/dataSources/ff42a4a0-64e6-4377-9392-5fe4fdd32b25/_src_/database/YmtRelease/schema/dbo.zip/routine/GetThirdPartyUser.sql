/*
-- Author:          ghu
-- Create date: 2015-09-08
-- Description:   目前需要获取第三方(微信，微博),需要重置交易密码的用户信息
*/

CREATE PROCEDURE GetThirdPartyUser
(
	@UserId INT
)
AS
BEGIN
	IF (@UserId <> -10000)
	BEGIN
			;WITH U AS
			(
				SELECT 
					iuserid,
					sloginid
				FROM dbo.ymt_users 
				WHERE spassword = '8ymatou.com'
					AND stradingpassword IS NULL  --登陆密码是默认的，同时交易密码是空
					AND ichannelsource IN (3,5,6) --微博，支付宝、微信三种第三方渠道
					AND daddtime>DATEADD(DAY,-365,GETDATE()) -- 一年内登录有效的
					AND iUserId = @UserId
			)
			SELECT 
				U.iuserid,
				U.sloginid,
				P.saccountname
			FROM U
			INNER JOIN dbo.Ymt_MobilePhoneAccount AS P
				ON U.iuserid = P.iuserid  --绑定了手机
			INNER JOIN dbo.ymt_accountinfo AS A 
			 ON A.iuserid = U.iuserid 
			  AND A.fAvailAmount > 0 --账户有余额
			
	END
	ELSE
	BEGIN
			;WITH U AS
			(
				SELECT 
					iuserid,
					sloginid
				FROM dbo.ymt_users 
				WHERE spassword = '8ymatou.com'
					AND stradingpassword IS NULL  --登陆密码是默认的，同时交易密码是空
					AND ichannelsource IN (3,5,6) --微博，支付宝、微信三种第三方渠道
					AND daddtime>DATEADD(DAY,-365,GETDATE()) -- 一年内登录有效的
			)
			SELECT 
				U.iuserid,
				U.sloginid,
				P.saccountname
			FROM U
			INNER JOIN dbo.Ymt_MobilePhoneAccount AS P
				ON U.iuserid = P.iuserid  --绑定了手机
			INNER JOIN dbo.ymt_accountinfo AS A 
			 ON A.iuserid = U.iuserid 
			  AND A.fAvailAmount > 0 --账户有余额
	END
END