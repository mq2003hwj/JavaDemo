


-- =============================================            
-- Author:  fanwei        
-- ALTER date: 2015-9-1
-- Description: 交易服务SP       
--update by cl 2015-12-01
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderListCount_Full]

@sellerId int,
@orderType int,
@timeType int,
@beginTime  datetime,
@endTime datetime,
@timeoutType bit,
@timeoutType1 tinyint,
@timeoutType2 tinyint,
@timeoutType3 tinyint,
@timeoutBegin1 datetime,
@timeoutEnd1 datetime,
@timeoutBegin2 datetime,
@timeoutEnd2 datetime,
@timeoutBegin3 datetime,
@timeoutEnd3 datetime,
@shangou bit,
@orderStatusXml xml,
@catalogStatusXml xml,
@keyword varchar(200),
@considerRiskVerfiedStatus bit,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@salesRefundOrderOnly bit = 0,
@domesticDelivered bit = null

AS

if @timeType = 0
begin
  --select @beginTime = getdate() - 90,@endTime = getdate()
  Exec sp_trd_GetSellerOrderListCount_Full_NoTime @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered
end

--or @timeType = 1 and o.dAddTime between @beginTime and @endTime
--or @timeType = 2 and o.dPaidTime between @beginTime and @endTime
--or @timeType = 3 and o.dDispathTime between @beginTime and @endTime
--or @timeType = 4 and o.dApplyPostPayTime between @beginTime and @endTime

if @timeType = 1
begin
  exec sp_trd_GetSellerOrderListCount_Full_dAddTime @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3,@shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
end

if @timeType = 2
begin
  exec sp_trd_GetSellerOrderListCount_Full_dPaidTime @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
end

if @timeType = 3
begin
  exec sp_trd_GetSellerOrderListCount_Full_dDispathTime @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
end

if @timeType = 4
begin
  exec sp_trd_GetSellerOrderListCount_Full_dApplyPostPayTime @sellerId, @orderType, @timeType, @beginTime, @endTime, @timeoutType, @timeoutType1, @timeoutType2, @timeoutType3, @timeoutBegin1, @timeoutEnd1, @timeoutBegin2,
   @timeoutEnd2, @timeoutBegin3, @timeoutEnd3, @shangou, @orderStatusXml, @catalogStatusXml, @keyword, @considerRiskVerfiedStatus, @considerOrderStatus, @considerRCOrderEstablish, @considerRCAccountPaid, @considerRestOrderStatus,@salesRefundOrderOnly,@domesticDelivered

  return
end
