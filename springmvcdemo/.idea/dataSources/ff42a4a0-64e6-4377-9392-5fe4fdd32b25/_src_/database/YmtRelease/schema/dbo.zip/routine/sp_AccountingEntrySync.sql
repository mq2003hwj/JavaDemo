
-- =============================================
-- Author:		Tony
-- Create date: 2016-02-25
-- Description:	创建流水同步记录
-- =============================================
CREATE PROCEDURE sp_AccountingEntrySync
AS
BEGIN
	DECLARE @CurrentMaxId BIGINT	--当前最大资金流水号
	DECLARE @LastSyncId BIGINT		--上次同步的资金流水号
	DECLARE @SyncNum INT			--本次需要同步的资金流水数量
	DECLARE @StartTime DATETIME		--执行开始时间
	
	SET @StartTime = GETDATE()

	SELECT @CurrentMaxId = MAX(EntryId)  FROM Ymt_AccountEntry
	SELECT @LastSyncId = MAX(LastSyncId)  FROM Ymt_AccountEntrySync
	
	--PRINT @CurrentMaxId
	--PRINT @LastSyncId

	--如果当前的最大流水大于上次同步流水则表示有新的流水产生，需要同步到旧的流水表
	IF @CurrentMaxId > @LastSyncId BEGIN
		--STEP.1.计算需要同步的资金流水数量
		--SELECT @SyncNum = COUNT(*)  FROM Ymt_AccountEntry WHERE EntryId > @LastSyncId AND EntryId <= @CurrentMaxId

		--STEP.2.将资金流水同步到旧流水表中
		INSERT Ymt_AccountRunningTally([sRunningTallyId],[fOccurredAmount],[iType],[iUserId]
			,[fBalance],[fFreezeAmount],[fAvailAmount], [dAddTime], [sOperator], [sUseage], [sMemo], [iCurrencyType],[fClearAmount])
		SELECT EntryId, Amount, EntryType, UserId,   
			0, 0, 0, CreateTime, LEFT(Memo, 400), LEFT(OriginalNo, 400), Memo, 1, 0
		FROM Ymt_AccountEntry WHERE EntryId > @LastSyncId AND EntryId <= @CurrentMaxId

		set @SyncNum=@@Rowcount

		--STEP.3.记录同步信息
		INSERT [Ymt_AccountEntrySync] VALUES(@CurrentMaxId, @SyncNum, @StartTime, GETDATE())
	END
END
