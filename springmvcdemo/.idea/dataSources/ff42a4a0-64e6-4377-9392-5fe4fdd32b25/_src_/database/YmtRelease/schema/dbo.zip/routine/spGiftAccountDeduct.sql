-- =============================================
-- Author:		Jmtek
-- Create date: 2014-5-27
-- Description:	资金操作SP化，事务死锁的快速解决方案
-- =============================================
CREATE PROCEDURE [dbo].[spGiftAccountDeduct]
	@userId		int			--资金账号
AS
BEGIN
	declare @amount decimal(18,2)

	select @amount = fAvailAmount from Ymt_GiftAccountInfo Where iUserId = @userId

	--更新账户余额
	Update Ymt_GiftAccountInfo Set fAvailAmount = fAvailAmount - @amount Where iUserId = @userId

	--收入账户资金流水
	Insert Into Ymt_GiftAccountRunningTally 
	([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
	Select NewId(), -@amount, 2, iUserId, fBalance, fFreezeAmount, @amount, getdate(), '取消红包', '异常注册收回红包', '异常注册收回红包' 
	From Ymt_GiftAccountInfo with(rowlock)
	Where iUserId = @userId
END
