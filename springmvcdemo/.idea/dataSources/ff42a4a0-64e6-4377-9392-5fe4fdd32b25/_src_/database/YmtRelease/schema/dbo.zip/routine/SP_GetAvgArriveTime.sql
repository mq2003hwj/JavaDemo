CREATE proc [dbo].[SP_GetAvgArriveTime](@BillOrderDetails xml)
as
begin
   --select * from @BillOrderDetails
   if OBJECT_ID(N'tempdb..#temp',N'U') is not null
	begin   
	   drop table #temp
	end
   Create table #temp(
      sBillCode nvarchar(50) null,
	  ArriveDate date null,
	  ArriveDateTime datetime null,
	  SellerID int null 
   )
   insert into #temp(sBillCode,ArriveDate,ArriveDateTime,SellerID) SELECT  
       Tbl.Col.value('sBillCode[1]', 'nvarchar(50)') as sBillCode,  
       Tbl.Col.value('ArriveDate[1]', 'date') as ArriveDate,  
       Tbl.Col.value('ArriveDateTime[1]', 'datetime') as ArriveDateTime,
       Tbl.Col.value('SellerID[1]', 'int') as SellerID
FROM   @BillOrderDetails.nodes('/ArrayOfBillDetails/BillDetails') Tbl(Col)
	if OBJECT_ID(N'tempdb..#BillOrderTempResult',N'U') is not null
	begin   
	   drop table #BillOrderTempResult
	end
	create table #BillOrderTempResult
	(
		  sBillCode nvarchar(50) null,
		  ArriveDate date null,
		  ArriveDateTime datetime null,
		  SellerID int null,
		  dDispatchTime datetime null,
		  dAddTime datetime null,
		  OrderStatus int null
	)

	insert into #BillOrderTempResult 
	select * from
	--根据order查询
	(select Ymt_OrderSummary.sSummary as BillCode, #temp.ArriveDate, #temp.ArriveDateTime,Ymt_Orders.iBuyerId as sellerID,Ymt_Orders.dDispathTime,Ymt_Orders.dAddTime,
		 --代购
	case when (not exists(select 1 from Ymt_OrderInfo
			  where Ymt_OrderInfo.iOrderId=Ymt_Orders.iOrderId and Ymt_OrderInfo.sCatalogId is not null and Ymt_OrderInfo.sCatalogId!='' and Ymt_OrderInfo.iCatalogType!=1)) then 2
		 when (not exists(select 1 from Ymt_OrderInfo
		 --现货
			  where Ymt_OrderInfo.iOrderId=Ymt_Orders.iOrderId and (Ymt_OrderInfo.sCatalogId is null or Ymt_OrderInfo.sCatalogId='') or (Ymt_OrderInfo.sCatalogId is not null and Ymt_OrderInfo.sCatalogId='' and Ymt_OrderInfo.iCatalogType=1))) then 1
		 else 3 
	end as OrderStatus
	 from Ymt_OrderSummary inner join #temp on Ymt_OrderSummary.sSummary= #temp.sBillCode inner join Ymt_Orders on Ymt_OrderSummary.iOrderId=Ymt_Orders.iOrderId  
	 --where sSummary=@BillCode
	 union
	 --根据Bill单查询
	 select Ymt_Bill.sBillCode as BillCode,  #temp.ArriveDate, #temp.ArriveDateTime,Ymt_Bill.iFromUserId as sellerID,Ymt_Orders.dDispathTime,Ymt_Orders.dAddTime,
		 --代购
	case when (not exists(select 1 from Ymt_OrderInfo
			  where Ymt_OrderInfo.iOrderId=Ymt_Orders.iOrderId and Ymt_OrderInfo.sCatalogId is not null and Ymt_OrderInfo.sCatalogId!='' and Ymt_OrderInfo.iCatalogType!=1)) then 2
		 when (not exists(select 1 from Ymt_OrderInfo 
		 --现货
			  where Ymt_OrderInfo.iOrderId=Ymt_Orders.iOrderId and (Ymt_OrderInfo.sCatalogId is null or Ymt_OrderInfo.sCatalogId='') or (Ymt_OrderInfo.sCatalogId is not null and Ymt_OrderInfo.sCatalogId='' and Ymt_OrderInfo.iCatalogType=1))) then 1
		 else 3
		 end as OrderStatus 
		 from Ymt_Bill inner join #temp on Ymt_Bill.sBillCode= #temp.sBillCode inner join Ymt_OrderToBill on Ymt_Bill.sBillId=Ymt_OrderToBill.sBillId
			  inner join Ymt_Orders on Ymt_OrderToBill.iOrderId=Ymt_Orders.iOrderId) as a order by  a.ArriveDate desc

	

	if OBJECT_ID(N'tempdb..#SellerIDArriveTime',N'U') is not null
	begin   
	   drop table #SellerIDArriveTime
	end
	create table #SellerIDArriveTime
	(
		  SellerID int null,
		  ArriveDate date null,
		  GoodsSumdays int null,
		  GoodsNumbers int null,
		  ShoppingSumdays int null,
		  ShoppingNumbers int null
	)
	 --所有订单情况
	 insert into #SellerIDArriveTime
	 select isNull(b.SellerID,c.SellerID) as SellerID,isNull(b.ArriveDate,c.ArriveDate) as ArriveDate, isNull(b.Sumdays,0) as GoodsSumdays,isNull(b.numbers,0) as GoodsNumbers,isNull(c.Sumdays,0) as ShoppingSumdays,isNull(c.numbers,0) as ShoppingNumbers from (
	(select SellerID,ArriveDate,sum(round(DATEDIFF(HOUR,dDispatchTime,ArriveDateTime),2)) as Sumdays,count(1) as numbers from #BillOrderTempResult where OrderStatus =1 or OrderStatus=3 
	group by SellerID,ArriveDate) as b full outer join (select SellerID,ArriveDate,sum(round(DATEDIFF(HOUR,dDispatchTime,ArriveDateTime),2)) as Sumdays,count(1) as numbers from #BillOrderTempResult where OrderStatus =2 or OrderStatus=3 
	group by SellerID,ArriveDate) as c on b.SellerID=c.SellerID and b.ArriveDate=c.ArriveDate) order by isNull(b.ArriveDate,c.ArriveDate) desc


	--更新现货平均发货时间
	MERGE into Ymt_AveArriveTime as p 
	using
	 --进行字符串拼接
	(select SellerID,Count(1) as totalNumbers, STUFF((SELECT ',' + CAST(GoodsSumdays as varchar(20)) AS [text()]
		FROM #SellerIDArriveTime AS G2
		WHERE G2.SellerID = G1.SellerID
		ORDER BY G2.ArriveDate desc
		FOR XML PATH('')), 1, 1, '') AS GoodsSumdays,
		STUFF((SELECT ',' + CAST(GoodsNumbers as varchar(20)) AS [text()]
		FROM #SellerIDArriveTime AS G2
		WHERE G2.SellerID = G1.SellerID
		ORDER BY G2.ArriveDate desc
		FOR XML PATH('')), 1, 1, '') AS GoodsNumbers,
		STUFF((SELECT ',' + CAST(ShoppingSumdays as varchar(20)) AS [text()]
		FROM #SellerIDArriveTime AS G2
		WHERE G2.SellerID = G1.SellerID
		ORDER BY G2.ArriveDate desc
		FOR XML PATH('')), 1, 1, '') AS ShoppingSumdays,
		STUFF((SELECT ',' + CAST(ShoppingNumbers as varchar(20)) AS [text()]
		FROM #SellerIDArriveTime AS G2
		WHERE G2.SellerID = G1.SellerID
		ORDER BY G2.ArriveDate desc
		FOR XML PATH('')), 1, 1, '') AS ShoppingNumbers
	from #SellerIDArriveTime as G1 group by SellerID) as a 
	on p.sellerID=a.SellerID
	When Matched  Then 
	Update set p.GoodsAveArriveTimeForSeller=dbo.Func_ReplaceNElement(p.GoodsAveArriveTimeForSeller,a.GoodsSumdays,a.totalNumbers),p.GoodsBillCount=dbo.Func_ReplaceNElement(p.GoodsBillCount,a.GoodsNumbers,a.totalNumbers),p.ShoppingAveArriveTimeForSeller=dbo.Func_ReplaceNElement(p.ShoppingAveArriveTimeForSeller,a.ShoppingSumdays,a.totalNumbers),p.ShoppingBillCount=dbo.Func_ReplaceNElement(p.ShoppingBillCount,a.ShoppingNumbers,a.totalNumbers)
	When Not Matched By Target Then 
	Insert (SellerID,GoodsAveArriveTimeForSeller,ShoppingAveArriveTimeForSeller,GoodsBillCount,ShoppingBillCount) values (a.SellerID,dbo.Func_GetDefaultYmtArriveTime(a.GoodsSumdays,a.totalNumbers),dbo.Func_GetDefaultYmtArriveTime(a.ShoppingSumdays,a.totalNumbers),dbo.Func_GetDefaultYmtArriveTime(a.GoodsNumbers,a.totalNumbers),dbo.Func_GetDefaultYmtArriveTime(a.ShoppingNumbers,a.totalNumbers));

	select * from Ymt_AveArriveTime inner join (Select distinct SellerID from #BillOrderTempResult) as a on Ymt_AveArriveTime.SellerId=a.SellerID

	if OBJECT_ID(N'tempdb..#SellerIDArriveTime',N'U') is not null
	begin   
	   drop table #SellerIDArriveTime
	end

	if OBJECT_ID(N'tempdb..#BillOrderTempResult',N'U') is not null
	begin   
	   drop table #BillOrderTempResult
	end

	if OBJECT_ID(N'tempdb..#temp',N'U') is not null
	begin   
	   drop table #temp
	end
	
end

