
create proc csp_QueryRefunds
(
	@TradeNo varchar(64),
	@OrderId varchar(64),
	@ApproveStatus bit,
	@PageSize int,
	@PageIndex int,
	@TotalCount int output
)
as
begin
	if @PageIndex<=0
		set @PageIndex=1

	if(@OrderId is not null)
	begin
		select @TotalCount=count(1) from dbo.RefundRequest(nolock) a	
		where a.OrderId=@OrderId
			and (a.TradeNo=@TradeNo or @TradeNo is null)
			and (a.ApproveStatus=@ApproveStatus or @ApproveStatus is null)
			and a.SoftDeleteFlag=0

		select * from (
			select a.*,b.BatchNo,b.RetryCount,b.ProcessStatus,b.LastProcessedTime,b.ProcessMachineName,ROW_NUMBER() over(order by a.CreatedTime desc) as rowindex
				from dbo.RefundRequest(nolock) a 
					left join dbo.RefundProcessInfo(nolock) b
					on a.RefundRequestId=b.RefundRequestId
					where a.OrderId=@OrderId
						and (a.TradeNo=@TradeNo or @TradeNo is null)
						and (a.ApproveStatus=@ApproveStatus or @ApproveStatus is null)
						and a.SoftDeleteFlag=0 ) t
			where rowindex>=(@PageIndex-1)*@PageSize and rowindex<=@PageIndex*@PageSize
	end
	else if(@TradeNo is not null)
	begin
		select @TotalCount=count(1) from dbo.RefundRequest(nolock) a 		
		where a.TradeNo=@TradeNo
			and (a.OrderId=@OrderId or @OrderId is null)
			and (a.ApproveStatus=@ApproveStatus or @ApproveStatus is null)
			and a.SoftDeleteFlag=0
		
		select * from (
			select a.*,b.BatchNo,b.RetryCount,b.ProcessStatus,b.LastProcessedTime,b.ProcessMachineName,ROW_NUMBER() over(order by a.CreatedTime desc) as rowindex
				from dbo.RefundRequest(nolock) a 
					left join dbo.RefundProcessInfo(nolock) b
					on a.RefundRequestId=b.RefundRequestId
					where a.OrderId=@OrderId
						and (a.TradeNo=@TradeNo or @TradeNo is null)
						and (a.ApproveStatus=@ApproveStatus or @ApproveStatus is null)
						and a.SoftDeleteFlag=0) t
			where rowindex>=(@PageIndex-1)*@PageSize and rowindex<=@PageIndex*@PageSize
	end
	else
	begin
		select @TotalCount=count(1) from dbo.RefundRequest(nolock) a 		
		where  (a.ApproveStatus=@ApproveStatus or @ApproveStatus is null)
			and a.SoftDeleteFlag=0

		select * from (
				select a.*,b.BatchNo,b.RetryCount,b.ProcessStatus,b.LastProcessedTime,b.ProcessMachineName,ROW_NUMBER() over(order by a.CreatedTime desc) as rowindex
					from dbo.RefundRequest(nolock) a 
						left join dbo.RefundProcessInfo(nolock) b
						on a.RefundRequestId=b.RefundRequestId
						where (a.ApproveStatus=@ApproveStatus or @ApproveStatus is null)
							and a.SoftDeleteFlag=0) t
				where rowindex>=(@PageIndex-1)*@PageSize and rowindex<=@PageIndex*@PageSize
	end
end

