

CREATE FUNCTION [dbo].[GenerateMilkFundCouponCode]
(
	@userId int,
	@batchId int
)
RETURNS varchar(20)
AS
BEGIN
	
	return 'B' + right('00000000'+cast(convert(varchar(8), @userId) + convert(varchar(4),@batchId) as varchar),10) 

END


