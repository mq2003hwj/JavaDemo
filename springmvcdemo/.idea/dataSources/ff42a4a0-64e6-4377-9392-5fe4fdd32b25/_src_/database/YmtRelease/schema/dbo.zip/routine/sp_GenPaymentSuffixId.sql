
-- =============================================
-- Author:		Tony
-- Create date: 2016-05-28
-- Description:	创建支付单后缀
-- =============================================
CREATE PROCEDURE [dbo].[sp_GenPaymentSuffixId]
	 
AS
BEGIN
	INSERT INTO [PaymentSuffixId] DEFAULT VALUES
	
	IF @@ERROR > 0
		SELECT -1
		
	SELECT SCOPE_IDENTITY()
END