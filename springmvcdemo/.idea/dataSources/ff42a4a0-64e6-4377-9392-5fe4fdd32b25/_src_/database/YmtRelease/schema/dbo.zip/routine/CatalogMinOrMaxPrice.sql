-- =============================================
-- Author:		zhuinfeng
-- Create date: <Create Date, ,>
-- Description:	取商品的最高最低价格
-- =============================================
CREATE FUNCTION CatalogMinOrMaxPrice 
(
	@ProductId VARCHAR(36),
	@Types VARCHAR(20)
)
RETURNS DECIMAL
AS
BEGIN
	DECLARE @Price DECIMAL;
    
	IF @Types = 'max'
	BEGIN
		SET @Price = (select MAX(fQuotePrice) from Ymt_Catalogs with(nolock) where sProductId = @ProductId)
	END  
	ELSE
	BEGIN
		SET @Price = (select MIN(fQuotePrice) from Ymt_Catalogs with(nolock) where sProductId = @ProductId)
	END  
    
	RETURN @Price;

END
