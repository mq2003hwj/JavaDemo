
-- =============================================
-- Author:		zhujinfeng
-- Create date: 2015-02-27
-- Description:	创建私有优惠券，并发送给买家用户
-- =============================================
CREATE PROCEDURE [dbo].[SP_CouponPrivateBind]
	@BatchCode VARCHAR(36),
	@CouponCode VARCHAR(36),
	@BuyerUserId INT,
	@ValidStart VARCHAR(20),
	@ValidEnd VARCHAR(20)
AS
BEGIN
	
	SET NOCOUNT ON;
	DECLARE @RetStatus			 INT		 --执行状态
		   ,@UserReceiveCount	 INT		 --当前优惠券批次已经领用个数
		   ,@iCouponTotalNum	 INT		 --总的优惠券个数
		   ,@iBatchId			 INT		 --批次ID
		   ,@iUseTotalCount		 INT		 --本批次最大使用次数
		   ,@iMaxUseTimePerUser  INT		 --单用户最大使用数
		   ,@iCouponUseCount	 INT		 --单券码限用次数
		   ,@iCouponSettingId	 INT	
		   ,@defValidStart		 DATETIME --默认优惠券有效期起始时间
		   ,@defValidEnd		 DATETIME --默认优惠券有效期截止时间
		   ,@iEffectiveType		 INT	  --有效期类型，0：绝对有效期 1：相对有效期
		   ,@iEffectiveValidType INT	  --相对有效期场景下生效方式，0：领取后立即生效 1：领取后隔天生效
  		   ,@iEffectiveDays		 INT	  --相对有效期天数   
		   ,@bInvalidStatus		 INT = 0	  --批次状态  
    
	SELECT @iBatchId=A.iBatchId
	      ,@iCouponTotalNum=A.iCouponTotalNum
	      ,@UserReceiveCount=ISNULL(C.iReceiveCount,0)
		  ,@iUseTotalCount=C.iUseTotalCount
		  ,@iMaxUseTimePerUser=C.iMaxUseTimePerUser
		  ,@iCouponUseCount=C.iCouponUseCount
		  ,@defValidStart=C.dValidStart
		  ,@defValidEnd=C.dValidEnd
		  ,@iCouponSettingId=C.iCouponSettingId
		  ,@iEffectiveType=C.iEffectiveType
		  ,@iEffectiveValidType=C.iEffectiveValidType
		  ,@iEffectiveDays=C.iEffectiveDays
		  ,@bInvalidStatus = A.bInvalidStatus
	  FROM dbo.Ymt_CouponBatch A WITH(NOLOCK) 
	  INNER JOIN dbo.Ymt_CouponSetting C WITH(NOLOCK) ON A.iCouponSettingId=C.iCouponSettingId
	 WHERE A.sBatchCode=@BatchCode 

	 IF @iBatchId IS NULL OR @iBatchId=0 OR @bInvalidStatus=1
	 BEGIN
		SELECT @RetStatus = 202
		GOTO Error_Handler;
	 END   

	 --判断券码是否领取完
	 IF @UserReceiveCount>=@iCouponTotalNum
	 BEGIN
	   SELECT @RetStatus = 203
	   GOTO Error_Handler;
	 END

	 IF NOT EXISTS(SELECT 1 FROM dbo.Ymt_Users WITH(NOLOCK) WHERE iUserId=@BuyerUserId)
	BEGIN
		SELECT @RetStatus = 201
		GOTO Error_Handler;
	END
  
	 --判断当前用户领取次数
	 SELECT @UserReceiveCount=COUNT(0) FROM Ymt_CouponPrivateUserBound WITH(NOLOCK) WHERE iBatchId=@iBatchId AND iUserId=@BuyerUserId
	 IF @UserReceiveCount>=@iMaxUseTimePerUser
	 BEGIN
	   SELECT @RetStatus = 204
	   GOTO Error_Handler;
	 END

	-- 判断优惠券有效期类型
	IF @iEffectiveType = 1
	BEGIN
		--相对有效期  
        SELECT  @ValidStart = CASE WHEN @iEffectiveValidType = 0
                                   THEN CONVERT(VARCHAR(10),GETDATE(),120)
                                   ELSE CONVERT(VARCHAR(10),DATEADD(DAY,1,GETDATE()),120)
                              END + ' 00:00:00',
                @ValidEnd = CONVERT(VARCHAR(10),DATEADD(DAY,
                                                        @iEffectiveDays - 1,
                                                        CASE WHEN @iEffectiveValidType = 0 THEN GETDATE() ELSE DATEADD(DAY,1,GETDATE()) END),120) + ' 23:59:59'
														
	END
	ELSE
	BEGIN
		IF GETDATE() > @defValidEnd
		BEGIN
			SELECT @RetStatus = 205
			GOTO Error_Handler;
		END
		--绝对有效期  
		SELECT @ValidStart = @defValidStart,@ValidEnd = @defValidEnd
	END  
  		
	BEGIN TRY
	BEGIN TRAN
		      
	-- 写入优惠券数据
	DECLARE @CouponId VARCHAR(36) = NEWID();
	INSERT INTO dbo.Ymt_Coupon(sCouponId,sCouponCode,iCouponType,dValidStart,dValidEnd,iCouponSetting,iBatchId,iUsage,sInvalidMemo)
	SELECT @CouponId,@CouponCode,2,@ValidStart,@ValidEnd,@iCouponSettingId,@iBatchId,1,''
		
	-- 用户领用该批次的优惠券
	INSERT INTO dbo.Ymt_CouponPrivateUserBound(sBoundId,sCouponCode,iUserId,dAddTime,iCouponUsedCount,sCouponId,iBatchId)
	SELECT NEWID(), @CouponCode, @BuyerUserId, GETDATE(), @iCouponUseCount, @CouponId, @iBatchId

	-- 累加领取次数
	UPDATE Ymt_CouponSetting SET iReceiveCount+=1 where iCouponSettingId=@iCouponSettingId
		
	SELECT @RetStatus = 200;
	SELECT @RetStatus AS [Status];
	COMMIT TRAN
	END TRY
 	BEGIN CATCH
		ROLLBACK TRAN
		SET @RetStatus = 500;   
		GOTO Error_Handler
	END CATCH

Error_Handler:
	SELECT @RetStatus AS [Status];
	    
END









