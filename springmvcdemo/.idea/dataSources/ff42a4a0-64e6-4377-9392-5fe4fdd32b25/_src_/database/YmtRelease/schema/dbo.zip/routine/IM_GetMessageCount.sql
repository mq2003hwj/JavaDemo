CREATE procedure [dbo].[IM_GetMessageCount] @UserID int,@OtherUserID int=0,@ReadStatus int=-1
as
begin
SET NOCOUNT ON;
declare @messagecount int
declare @sSessionId varchar(100)
set @messagecount=0
if @ReadStatus=0
begin
   if @OtherUserID=0
     select @messagecount=count(1) from Ymt_Message(nolock) where iMsgToId=@UserID and iIsRead=0 and RSee=0
   else
     select @messagecount=count(1) from Ymt_Message(nolock) where iMsgToId=@UserID and iMsgFromId=@OtherUserID and iIsRead=0 and RSee=0
end
else
begin
  if @OtherUserID<>0
     begin
	  if @UserID<@OtherUserID
	  begin
	     set @sSessionId= convert(varchar(30),@UserID)+'_'+convert(varchar(30),@OtherUserID)
		 select @messagecount=count(1) from Ymt_Message(nolock) where sSessionId= @sSessionId and iSSee=0
	  end
	  else
	  begin
	   set @sSessionId= convert(varchar(30),@OtherUserID)+'_'+convert(varchar(30),@UserID)
	   select @messagecount=count(1) from Ymt_Message(nolock) where sSessionId= @sSessionId and iBSee=0
	  end
	 end
   else
     begin
       select @messagecount=count(1) from Ymt_Message(nolock) where (iMsgFromId=@UserID and SSee=0) or (iMsgToId=@UserID and RSee=0)
     end
end

select @messagecount
end