-- =============================================
-- Author:		adu
-- Create date: 2015-04-28
-- Description:	按分页获取异步回调日志,'1753/1/1 0:00:00'为时间空值
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetNotifyLogByPage] 
	@PageSize int,--每页显示的记录条数
	@PageIndex INT, --当前页码
	@BeginTime DATETIME,--搜索条件中时间段的开始时间,'1753/1/1 0:00:00'为时间空值
	@EndTime DATETIME=NULL, --搜索条件中时间段的结束时间,'1753/1/1 0:00:00'为时间空值
	@BizNo VARCHAR(50) =NULL, --业务编号，可能是交易号，补款ID，冲值ID
	@TotalCount INT OUTPUT --总页数
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @SQL nvarchar(3250)	
	DECLARE @SQL1 nvarchar(3250)
	DECLARE @SQL2 nvarchar(3250)
	declare @iBeginRow int, @iEndRow INT
  
    --调试用的，创建存储过程时这块注释 start   
    --declare @TotalCount int,@TotalPage int
	--declare @PageSize int,	@PageIndex INT,@BeginTime DATETIME,@EndTime DATETIME,@BizNo VARCHAR(50) --创建存储过程时这行注释
	--select @PageSize=20,@PageIndex=2--创建存储过程时这行注释	
	--select @BeginTime='04/24/2015',@EndTime='04/25/2015 15:58:07'--创建存储过程时这行注释
	--SET @BizNo=NULL
	--调试用的，创建存储过程时这块注释 end

	
	SET @SQL1=N'SELECT @num=COUNT(iId) FROM dbo.Ymt_AlipayNotifyLog where 1=1';
	SET @SQL2=N'SELECT *,ROW_NUMBER() over(order by iId desc) as rows FROM dbo.Ymt_AlipayNotifyLog where 1=1';
	select @iBeginRow = (@PageIndex-1)*@PageSize, @iEndRow = @PageIndex*@PageSize;
	--PRINT @iBeginRow
	--PRINT @iEndRow
	

	IF(@BeginTime IS NOT NULL AND @BeginTime <> '1753/1/1 0:00:00')
	BEGIN
		SET @SQL1 = @SQL1 + ' and dAddTime > ''' +CONVERT(VARCHAR, @BeginTime,120)  + ''''
		SET @SQL2 = @SQL2 + ' and dAddTime > ''' +CONVERT(VARCHAR, @BeginTime,120)  + ''''
	END

	IF(@EndTime IS NOT NULL AND @EndTime <> '1753/1/1 0:00:00')
	BEGIN
		
		SET @SQL1 = @SQL1 + 'and dAddTime < ''' +CONVERT(VARCHAR, @EndTime,120)  + ''''
		SET @SQL2 = @SQL2 + ' and dAddTime < ''' +CONVERT(VARCHAR, @EndTime,120)  + ''''
	END
  
    IF(@BizNo IS NOT NULL)
	BEGIN
		SET @SQL1 = @SQL1 + ' and BizNo = ''' + @BizNo + ''''
		SET @SQL2 = @SQL2 + ' and BizNo = ''' + @BizNo + ''''
	END
	  
    SET @SQL=N'SELECT AA.* FROM 
	(
		'+ @SQL2 + ' 
	) AA
	where AA.rows >= ' + CAST(@iBeginRow AS VARCHAR(10)) + ' and AA.rows<'+ CAST(@iEndRow AS VARCHAR(10)) +'';

	--PRINT @SQL;
	--PRINT @SQL1;
	--PRINT @SQL2;

	EXEC sp_executesql @SQL1,N'@num int output',@TotalCount OUTPUT

    --PRINT @TotalCount  
	EXEC (@SQL) 
END
