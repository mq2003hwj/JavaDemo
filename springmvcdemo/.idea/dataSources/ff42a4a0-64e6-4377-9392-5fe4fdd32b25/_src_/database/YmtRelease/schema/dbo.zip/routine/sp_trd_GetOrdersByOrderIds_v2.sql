-- =============================================            

-- Author:  fanwei        

-- CREATE date: 2016-4-8

-- Description: 通过订单ID获取订单信息      

-- 20160714：商品详情上获取退货退款信息 by dp 

-- 20160719：商品详情上iProductBrandId by dp

-- 20160919: 商品上增加 fDiscount fSellerCouponAmount fSellerPromotionAmount by zhangyf

-- =============================================



CREATE PROCEDURE [dbo].[sp_trd_GetOrdersByOrderIds_v2]

@orders Int32Array READONLY,

@seller int = null

AS BEGIN



--------------process--------------



--set statistics time on;set statistics io on;



set nocount on;





select 

--Basic

 o.iOrderId as Basic_ID

,o.dAddTime as Basic_CreatedTime

,o.dCancelTime as Basic_CancelledTime

,o.dAcceptTime as Basic_AcceptedTime

,o.iTradingStatus as Basic_Status

,o.iRiskVerifiedStatus as Basic_RiskStatus

,o.bShangouOrder as Basic_Type

,e.sOrderSource as Basic_Source

,IIF(o.bShangouOrder=1,o.fTotalPrice,o.fOrderPrice) as Basic_TotalPrice

,o.fOrderDiscount as Basic_Discount
,o.bPreSale as Basic_PreSale

--Buyer

,o.iUserId as Buyer_ID

,o.sBuyerLoginId as Buyer_LoginId

,o.sBuyerLoginEmail as Buyer_Email

,o.sBuyerNickName as Buyer_NickName

,o.sLeaveWord as Buyer_Message

--Seller

,o.iBuyerId as Seller_ID

,o.sSellerLoginId as Seller_LoginId

,o.sSellerLoginEmail as Seller_Email

,(select top 1 n.sContent from Ymt_O_OrderNote(nolock) n where n.iOrderId = o.iOrderId and n.iUserId = o.iBuyerId) as Seller_Comment

--Consignee

,o.sAddress as Consignee_Address

,o.sReceivePerson as Consignee_Name

,o.sPhone as Consignee_Phone

,o.sTelephone as Consignee_Tel

,o.sPostCode as Consignee_Postcode

--Payment

,(

	s.fPaidAmountOfCash + s.fPostPaidAmountOfCash - o.fFreight

) as Payment_ActualPaid

,o.dPaidTime as Payment_1_PaidTime

,o.iTradingId as Payment_1_InternalTradingNo

,(select top 1 sTradeNo from Ymt_TradingInfo(nolock) t where s.fPaidAmountOfCash > 0 and t.iTradingId = o.iTradingId and t.iTradingStatus = 2) as Payment_1_ExternalTradingNo

,o.dPostPaidTime as Payment_2_PaidTime

--Transfer

,o.dDispathTime as Transfer_DeliveredTime

,o.dConfirmedTime as Transfer_ReceiptConfirmedTime

from Ymt_Orders(nolock) o

left join Ymt_OrderExt(nolock) e on o.iOrderId = e.iOrderId

left join Ymt_OrderState(nolock) s on o.iOrderId = s.iOrderId

where o.iOrderId in (select [Value] from @orders) and (@seller is null or o.iBuyerId = @seller)





--获取订单商品详情列表

select 

 i.iOrderId as OrderId

,i.sTitle as [Name]

,i.sCatalogId as CatalogId

,i.sProductId as ProductId

,i.fProductPrice as Price

,i.fProductOriginalPrice as OriginalPrice

,i.iAmount as [Count]

,i.fOriginalPrice * i.iAmount as TotalPrice

,i.iCatalogType as CatalogType

,i.sSKU as SKU

,i.sPropertyInfo as PropertyInfo

,e.iActivityId as ActivityId

,i.sPackageNo as PackageNo

,i.iBondedArea as BondedArea

,i.iCatalogStatus as Logistics

,i.iProductMainCategoryId as Category1

,i.iProductSubCategoryId as Category2

,i.iProductThirdCategoryId as Category3

,i.fFreight as PartialFreight

,i.fYmtCouponAmount as PartialYmtCoupon

,refund.*

,i.iProductBrandId as BrandId

,i.fDiscount AS PartialDiscount

,i.fSellerCouponAmount AS PartialSellerCoupon

,i.fSellerPromotionAmount AS PartialSellerPromotion

,i.bPreSale AS PreSale

,i.fThirdPartyDiscount as ThirdPartyDiscount

from Ymt_OrderInfo i with(nolock,ForceSeek)

left join Ymt_OrderInfoExt e with(nolock,ForceSeek)

on i.sOrderInfoId = e.sOrderInfoId

outer apply (

	select top 1

		[t1].[RefundAmount], [t1].[RefundedAmountOfCash], [t1].[RefundedAmountOfGift], [t1].[RefundStatus], 

		[t1].[SettlementAmountOfCoupon], [t1].[SalesRefundStatus], [t2].[RefundProductNum],[t1].RefundedDiscountOfThirdParty

	from [dbo].[Ymt_RefundBill] as t1 with(nolock)

	inner join [dbo].[Ymt_RefundProduct] as t2 with(nolock)

	on t1.[RefundBillNo] = t2.[RefundBillNo] and [t2].[OrderId] = [t1].[OrderId] and [t1].[OrderId] = i.[iOrderId] and [t2].[OrderInfoId] = i.[sOrderInfoId] and [t1].[SalesRefundStatus] = 10

) as refund

where i.iOrderId in (select [Value] from @orders)





select o.iOrderId as OrderId

,s.fPaidAmountOfCash as PaidCash

,s.fPaidAmountOfGift as PaidGift

,s.fPaidAmountOfFreeCard as PaidFreeCard

,s.fPaidAmountOfYmtCoupon as PaidYmtCoupon

,s.fPaidAmountOfSellerCoupon as PaidSellerCoupon

,s.fPostPaidAmountOfCash as PostPaidCash

,s.fPostPaidAmountOfGift as PostPaidGift

,s.fDiscountOfThirdParty as thirdPartyDiscount

,o.fTotalPrice as TotalProductPrice

,o.fOrderPrice as FirstPayProductPrice

,o.fFreight as Freight

,o.fOrderDiscount as OrderDiscount

,o.fDiscount as PostPayDiscount

,o.fSellerPromotionAmount as TotalActivityPrice

,r.*

from Ymt_OrderState(nolock) s join Ymt_Orders(nolock) o

on s.iorderid = o.iorderid

outer apply (

	select sum(RefundedAmountOfCash) as TotalRefundedCash, sum(RefundedAmountOfGift) as TotalRefundedGift
  , sum(SettlementAmountOfCoupon) as TotalRefundedYmtCoupon,SUM(isnull(RefundedDiscountOfThirdParty,0)) as TotalRefundedThirdPartyDiscount

	from Ymt_RefundBill(nolock) where OrderId = o.iOrderId and SalesRefundStatus = 10 and RefundStatus = 1

) r

where s.iorderid in (select [Value] from @orders)



set nocount off;



return 1;

--set statistics time off;set statistics io off;--set statistics profile off;



END;