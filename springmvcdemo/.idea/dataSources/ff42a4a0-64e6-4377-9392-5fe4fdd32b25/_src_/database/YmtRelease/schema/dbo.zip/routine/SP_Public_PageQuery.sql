
-- =============================================
-- Author:		<sp_Public_PageQuery>
-- Create date: <2006>
-- Description:	<通用分页>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Public_PageQuery]
	@iPageSize INT,
	@iCurPage INT,
	@sField VARCHAR(2000),
	@sFrom VARCHAR(2000),
	@sPKField VARCHAR(1000),
	@iPKFieldType INT,
	@sOrder VARCHAR(1000),
	@sWhere VARCHAR(4000),
	@sGroupBy VARCHAR(1000),
	@iPageCount INT OUTPUT,
	@iRecordCount INT OUTPUT
AS
/*取得某个表的某页的记录集，并返回页数和记录数
	@iPageSize INT,					每页记录数
	@iCurPage INT,					当前页
	@sField VARCHAR(100),			需查询的字段
	@sFrom VARCHAR(2000),			需查询的表
	@sPKField VARCHAR(1000),		字段名(用于分页)
	@iPKFieldType INT,				字段类型,0=数值；1=字符串
	@sOrder VARCHAR(100),			排序字段名(比如：CreateTime DESC,Name ASC)
	@sWhere VARCHAR(1000),			查询条件
	@sGroupBy VARCHAR(1000),		分组
	@iPageCount INT OUTPUT,			返回的总页数
	@iRecordCount BIGINT OUTPUT		返回的总记录数
调用例程：
--多字段组合唯一的分页
select * from a inner join b on b.f = a.f
where a.c in (select e.c from e)
DECLARE @iPageCount INT
DECLARE @iRecordCount BIGINT
DECLARE @sWhere VARCHAR(2000)
DECLARE @sPKField VARCHAR(8000)
DECLARE @sFrom VARCHAR(8000)
DECLARE @sField VARCHAR(8000)
DECLARE @sGroupBy VARCHAR(8000)
SET @sFrom = 'Group'
SET @sGroupBy = ''
SET @sField = '*'
SET @sPKField = 'GroupID'
SET @sWhere =  ''
EXEC sp_Public_PageQuery 10,2,@sField,@sFrom,@sPKField,0,'',@sWhere,@sGroupBy,@iPageCount OUTPUT,@iRecordCount OUTPUT
--普通分页
DECLARE @iPageCount INT
DECLARE @iRecordCount BIGINT
EXEC sp_Public_PageQuery 0,1,'*','View_Entity','Guid',1,'','(Depth <= 4 AND Depth >= 3) AND CHARINDEX(''C33B1CF9-99DC-4BF7-94B8-CAB8918296CC'',GuidPath)>0 AND ObjTypeID IN (4) AND  Entity.CreateTime >''2004-1-1'' AND  Entity.DomainName LIKE ''%abc%'' AND  Entity.OpAd <=1','',@iPageCount OUTPUT,@iRecordCount OUTPUT
PRINT @iRecordCount
*/
DECLARE @sIDList VARCHAR(8000)
DECLARE	@iCurRecord INT
DECLARE @sID VARCHAR(100)
DECLARE @i INT
DECLARE @iCurRealRecord INT
DECLARE @sSQL VARCHAR(8000)
DECLARE @sFix VARCHAR(1)
SET NOCOUNT ON
--返回所有记录
IF @iPageSize=0
BEGIN
	SET @sSQL = 'SELECT ' + @sField + ' FROM ' + @sFrom
	
	SET @sSQL = @sSQL + ' WHERE ' + @sPKField + ' IS NOT NULL'
	
	IF @sWhere<>''
	BEGIN
		SET @sSQL = @sSQL + ' AND ' + @sWhere
	END
	
	IF @sGroupBy<>''
	BEGIN
		SET @sSQL = @sSQL + ' GROUP BY ' + @sGroupBy
	END
	
	IF @sOrder<>''
	BEGIN
		SET @sSQL = @sSQL + ' ORDER BY ' + @sOrder
	END
	EXEC(@sSQL)
	SET @iRecordCount = @@ROWCOUNT
	SET @iPageCount=1
	RETURN
END

SET @sFix = ''
IF @iPKFieldType = 1 SET @sFix = ''''
SET @iCurRecord = @iPageSize * @iCurPage
SET @sIDList=''
SET @sID=''
SET @sSQL = 'SELECT  ' + @sPKField + ' FROM ' + @sFrom
SET @sSQL = @sSQL + ' WHERE ' + @sPKField + ' IS NOT NULL'

IF @sWhere<>''
BEGIN
	SET @sSQL = @sSQL + ' AND ' + @sWhere
END
IF @sGroupBy<>''
BEGIN
	SET @sSQL = @sSQL + ' GROUP BY ' + @sGroupBy
END

IF @sOrder<>''
BEGIN
	SET @sSQL = @sSQL + ' ORDER BY ' + @sOrder
END

--SET @sSQL = REPLACE(@sSQL,'SELECT','SELECT TOP '+CAST(@iPageSize*@iCurPage AS VARCHAR(10)))
SET @sSQL = 'DECLARE IDList_Cursor CURSOR SCROLL FOR ' + @sSQL
--PRINT @sSQL
--return

EXEC (@sSQL)
OPEN IDList_Cursor
--下面的这句FETCH NEXT 会产生一条记录
--FETCH NEXT FROM IDList_Cursor
SET @iRecordCount = @@CURSOR_ROWS
SET @iPageCount = @iRecordCount / @iPageSize
IF @iRecordCount % @iPageSize >0 SET @iPageCount = @iPageCount + 1
--边界检查
IF (@iPageSize * @iCurPage) <= 0
BEGIN
	SET @sIDList = ''
	CLOSE IDList_Cursor
	DEALLOCATE IDList_Cursor
	SET @sSQL = 'SELECT ' + @sField +' FROM ' + @sFrom + ' WHERE 1=0'
	IF @sGroupBy<>''
	BEGIN
		SET @sSQL = @sSQL + ' GROUP BY ' + @sGroupBy
	END
--PRINT @sSQL
	EXEC (@sSQL)
	RETURN
END
IF @iCurRecord<=@iRecordCount
--可以返回所有行
BEGIN
	
	SET @iCurRealRecord=@iCurRecord-@iPageSize+1
	--PRINT @iCurRealRecord
	SET @i = 1
	FETCH ABSOLUTE @iCurRealRecord FROM IDList_Cursor INTO @sID
	SET @sIDList = @sFix + @sID + @sFix
	WHILE (@i < @iPageSize)
	BEGIN
		FETCH NEXT FROM IDList_Cursor INTO @sID
		SET @sIDList = @sIDList + ',' + @sFix + @sID + @sFix
		SET @i=@i+1
	END
END
IF (@iCurRecord>@iRecordCount AND (@iCurRecord-@iPageSize)<@iRecordCount) OR ((@iCurRecord-@iPageSize)>@iRecordCount AND @iRecordCount>0)
--返回最后一页
BEGIN
	SET @iCurPage = @iPageCount
	SET @iCurRecord = @iPageCount * @iPageSize
	SET @iCurRealRecord=@iCurRecord-@iPageSize+1
	IF @iCurRealRecord<0
	BEGIN
		SET @iCurRealRecord = 0
	END
	SET @i=0
	FETCH ABSOLUTE @iCurRealRecord FROM IDList_Cursor INTO @sID
	SET @sIDList = @sFix + @sID + @sFix
	WHILE @i<(@iRecordCount-@iCurRealRecord)
	BEGIN
		FETCH NEXT FROM IDList_Cursor INTO @sID
		SET @sIDList = @sIDList + ',' + @sFix + @sID + @sFix
		SET @i=@i+1
	END
END
IF (@iCurRecord-@iPageSize)>@iRecordCount
--超出，返回错误
BEGIN
	SET @sIDList = ''
	CLOSE IDList_Cursor
	DEALLOCATE IDList_Cursor
	SET @sSQL = 'SELECT ' + @sField + ' FROM ' + @sFrom + ' WHERE 1=0'
	IF @sGroupBy<>''
	BEGIN
		SET @sSQL = @sSQL + ' GROUP BY ' + @sGroupBy
	END
	EXEC (@sSQL)
	RETURN
END
CLOSE IDList_Cursor
DEALLOCATE IDList_Cursor
IF LEN(@sIDList)>0
BEGIN
	SET @sSQL = 'SELECT ' + @sField + ' FROM ' + @sFrom + ' WHERE ' + @sPKField + ' IN (' + @sIDList + ')'
END
ELSE
BEGIN
	SET @sSQL = 'SELECT ' + @sField + ' FROM ' + @sFrom + ' WHERE 1=0'
END
IF @sGroupBy<>''
BEGIN
	SET @sSQL = @sSQL + ' GROUP BY ' + @sGroupBy
END
IF @sOrder<>''
BEGIN
	SET @sSQL = @sSQL + ' ORDER BY ' + @sOrder
END
SET NOCOUNT OFF
EXEC (@sSQL)

