
-- =============================================          
-- Author:  张建涛      
-- Create date: 2015-4-20       
-- Description: 根据主题Id生成口令          
-- =============================================    
CREATE PROCEDURE [dbo].[SPTuanCodeGenerateCode]  
	@TopicId int,
	@UserId int
AS  
BEGIN
    SET NOCOUNT ON

		DECLARE @NUM INT;		
		Declare @Draft char(1)		='D' --未生成口令
		Declare @Completed char(1)	='C' --口令生成完成
		Declare @Processing char(1)	='P' --正在生成口令
		Declare @Fail char(1)		='F' --口令生成失败

        SET @NUM = 0;
		begin try
			--口令完成或正在生成口令的就不能再生成了
			if (Exists( select sGenerateCode 
						from [Ymt_App_TuanTopic] 
						where itopicId=@TopicId and (sGenerateCode=@Completed or sGenerateCode=@Processing) ) )
			begin			
				return
			end

			--删除失败的口令生成记录
			if (Exists(select sGenerateCode from [Ymt_App_TuanTopic] where itopicId=@TopicId and sGenerateCode=@Fail ) )
			begin			
				delete [Ymt_App_TuanCode] 
				where iTopicId=@TopicId
			end
				
		
			--进行中，标记生成状态		
			update [dbo].[Ymt_App_TuanTopic] 
			set 
				sGenerateCode = @Processing,
				iModifyByUserId = @UserId ,
				dModifyDate = GetDate()
			where iTopicId=@TopicId
						

			WHILE @NUM<100000
			BEGIN
			
				INSERT INTO [dbo].[Ymt_App_TuanCode]
					 ( 
							[iCodeId],
							[iTopicId]
					  ) VALUES (
							@NUM,
							@TopicId
					  );
				SET @NUM = @NUM + 1;
			END
			
			--已完成，标记生成状态		
			update [dbo].[Ymt_App_TuanTopic] 
			set 
				sGenerateCode =@Completed,
				iModifyByUserId = @UserId ,
				dModifyDate = GetDate()
			where iTopicId=@TopicId

		end try
		begin catch 
			--执行失败，标记生成状态
			update [dbo].[Ymt_App_TuanTopic] 
			set 
				sGenerateCode = @Fail,
				iModifyByUserId = @UserId ,
				dModifyDate = GetDate()
			where iTopicId=@TopicId

			--删除失败的口令生成记录			
			delete [Ymt_App_TuanCode] 
			where iTopicId=@TopicId  
		end catch


    SET NOCOUNT OFF
END
