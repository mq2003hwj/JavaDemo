CREATE VIEW dbo.View_CountProductGroupByCategory
AS
SELECT      COUNT(*) AS iProductCount, dbo.Ymt_ProductCategory.iCategoryId
FROM          dbo.Ymt_ProductCategory INNER JOIN
                        dbo.Ymt_Products ON dbo.Ymt_ProductCategory.iCategoryId = dbo.Ymt_Products.iCategoryId
GROUP BY dbo.Ymt_ProductCategory.iCategoryId
