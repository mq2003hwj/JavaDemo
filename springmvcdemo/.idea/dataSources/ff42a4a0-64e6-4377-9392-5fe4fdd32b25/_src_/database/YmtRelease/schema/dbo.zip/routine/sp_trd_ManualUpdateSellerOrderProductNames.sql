


-- =============================================            
-- Author:  fanwei        
-- Create date: 2016-4-13
-- Description: 更新卖家订单商品信息      
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_ManualUpdateSellerOrderProductNames]
@seller int,
@products StringKeyTextDateTimes readonly
AS

merge into Trd_SellerProductNames as s
using @products as p on s.SellerId = @seller and s.MD5 = p.[Key]
when matched and s.LastUsedTime < p.[Time]
then update set s.LastUsedTime = p.[Time], s.UsedTimes = s.UsedTimes + 1
when not matched
then insert ([SellerId],[MD5],[ProductName],[LastUsedTime]) values(@seller,p.[Key],p.[Text],p.[Time])
;
