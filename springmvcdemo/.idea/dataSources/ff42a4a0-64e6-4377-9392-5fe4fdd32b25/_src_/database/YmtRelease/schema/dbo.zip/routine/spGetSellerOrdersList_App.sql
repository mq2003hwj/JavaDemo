-- =============================================
-- Author:		CPX
-- Create date: 2014年8月15日
-- Description:	app端的获取卖家订单列表
-- =============================================
CREATE PROCEDURE [dbo].[spGetSellerOrdersList_App]
	@OrderNum INT,--要获取的订单数量
	@SellerId INT, --卖家ID
	@ActivedId INT --商品活动ID
AS
BEGIN
	SET NOCOUNT ON
    SET LOCK_TIMEOUT 1000
  
	--ProductId VARCHAR(150) NOT NULL,--商品Id
	--LastOrderTime DATETIME NOT NULL,--最后下单时间
	--PaidNum INT NOT NULL, --已支付商品销售数量
	--NotPaidNum INT NOT NULL --未支付商品销售数量 
        
    SELECT TOP (@OrderNum) info.sProductId AS ProductId, --将具体卖家中的某个活动中的商品进行分组，并根据分组后的商品对应的最近的下单时间
    MAX(O.dAddTime) AS LastOrderTime
    INTO #TempOrderTable
    FROM Ymt_OrderS AS o WITH(NOLOCK) 
    JOIN  Ymt_orderInfo AS info ON o.iOrderId = info.iOrderId 
    WHERE o.bShangouOrder = 1 
    AND ISNULL(info.sProductId,'') <> ''
	AND o.iBuyerId = @SellerId
	--AND CHARINDEX(',' + CONVERT(VARCHAR(10),O.iTradingStatus) + ',',@OrderStatusListStr) > 0
	AND o.iTradingStatus IN (1,2,3,4,16,17)
	AND EXISTS(SELECT 1 FROM Ymt_OrderInfo AS TempInfo WITH(NOLOCK) 
	JOIN Ymt_OrderInfoExt AS oext ON oext.sOrderInfoId = TempInfo.sOrderInfoId 
	WHERE oext.iActivityId = @ActivedId 
	AND TempInfo.iOrderId = O.iOrderId)
	GROUP BY info.sProductId
	
	SELECT ISNULL(SUM(PaidInfo.iAmount),0)AS PaidNum,TEMPTABLE.ProductId 
	INTO #TempPaidNumTable 
	FROM Ymt_OrderInfo AS PaidInfo	--根据某个具体的商品获取已经支付的商品数量
	JOIN Ymt_Orders AS PaidO ON PaidO.iOrderId = PaidInfo.iOrderId
	JOIN #TempOrderTable TempTable ON TempTable.ProductId = PaidInfo.sProductId
	WHERE 
	PAIDO.iTradingStatus <> 1 
	AND PaidInfo.sProductId	= TempTable.ProductId
	AND PaidO.iBuyerId = @SellerId
	AND PaidO.iTradingStatus IN (1,2,3,4,16,17)
	GROUP BY TempTable.ProductId
	
	SELECT ISNULL(SUM(NotPaidInfo.iAmount),0)AS NotPaidNum,NotPaidTempTable.ProductId 
	INTO #TempNotPaidNumTable 
	FROM Ymt_OrderInfo NotPaidInfo	--根据某个具体的商品获取未支付的商品数量
	JOIN Ymt_Orders NotPaidO ON NotPaidO.iOrderId = NotPaidInfo.iOrderId
	JOIN #TempOrderTable NotPaidTempTable ON NotPaidTempTable.ProductId = NotPaidInfo.sProductId
	WHERE 
	NotPaidO.iTradingStatus = 1 
	AND NotPaidInfo.sProductId	= NotPaidTempTable.ProductId
	AND NotPaidO.iBuyerId = @SellerId
	AND NotPaidO.iTradingStatus IN (1,2,3,4,16,17)
	GROUP BY NotPaidTempTable.ProductId
	
	SELECT t.ProductId AS ProductId,t.LastOrderTime AS LastOrderTime,
	ISNULL(PaidNumTable.PaidNum,0) AS PaidNum,ISNULL(NotPaidNumTable.NotPaidNum,0) AS NotPaidNum
	INTO #TempResultTable
	FROM #TempOrderTable AS t 
	LEFT JOIN #TempPaidNumTable PaidNumTable ON t.ProductId = PaidNumTable.ProductId
	LEFT JOIN #TempNotPaidNumTable NotPaidNumTable ON NotPaidNumTable.ProductId = T.ProductId
	ORDER BY t.LastOrderTime desc
	
	
    SELECT * FROM #TempResultTable
    
	DROP TABLE #TempOrderTable
	DROP TABLE #TempPaidNumTable
	DROP TABLE #TempNotPaidNumTable
	DROP TABLE #TempResultTable
	SET NOCOUNT OFF
END
