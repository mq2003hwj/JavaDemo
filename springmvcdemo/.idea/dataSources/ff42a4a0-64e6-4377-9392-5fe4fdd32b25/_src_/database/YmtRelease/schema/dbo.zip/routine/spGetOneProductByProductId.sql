-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE spGetOneProductByProductId
	-- Add the parameters for the stored procedure here
	@ProductId varchar(36)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select p.*,b.sBrand,c.* from Ymt_Products p
	left join
	Ymt_ProductBrand b on p.iBrandId=b.iBrandId
	left join
	Ymt_Comments c on c.iType=2 and c.sKeyId=p.sProductId and c.iAction>-1
	where p.sProductId=@ProductId and b.iAction>-1

END
