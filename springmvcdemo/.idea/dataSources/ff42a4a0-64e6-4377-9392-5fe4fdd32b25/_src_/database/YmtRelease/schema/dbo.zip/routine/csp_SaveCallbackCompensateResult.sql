
create proc csp_SaveCallbackCompensateResult
(
	@CompensateId uniqueidentifier,
	@ProcessStatus int
)
as
begin
	update dbo.CallbackCompensateProcessInfo
	set  RetryCount=RetryCount+1,
		ProcessMachineName=null,
		ProcessStatus=@ProcessStatus,
		LastProcessedTime=getdate()
			where CompensateId=@CompensateId
end

