
CREATE PROCEDURE [dbo].[SP_CouponPrivateBindBatch]
	@BatchCodes VARCHAR(500),
	@CouponCodes VARCHAR(2000),
	@BuyerUserId INT,
	@ValidStart VARCHAR(20),
	@ValidEnd VARCHAR(20),
	@RetCode INT OUTPUT
AS
BEGIN
	
	SELECT @RetCode = 200
	IF NOT EXISTS(SELECT 1 FROM dbo.Ymt_Users WITH(NOLOCK) WHERE iUserId=@BuyerUserId)
	BEGIN
		SELECT @RetCode = 201
		RETURN;
	END
	
	DECLARE @tableCouponBatch TABLE (CouponId UNIQUEIDENTIFIER,
									 BatchCode VARCHAR(36),
									 CouponCode VARCHAR(36),
									 BatchId INT,CouponTotalNum INT, 
									 CouponSettingId INT,
									 CouponUseCount INT,
									 ValidStart DATETIME,
									 ValidEnd DATETIME,
									 BatchReceiveCount INT,
									 UserReceiveCount INT,
									 MaxUseTimePerUser INT,
									 [Status] INT,
									 CouponUseType INT)

	INSERT INTO @tableCouponBatch
	SELECT CouponId,
		   sBatchCode,
		   sCouponCode,
		   iBatchId,
		   iCouponTotalNum,
		   iCouponSettingId,
		   iCouponUseCount,
		   dValidStart,
		   dValidEnd,
		   iBatchReceiveCount,
		   UserReceiveCount,
		   iMaxUseTimePerUser,
		   CASE WHEN iBatchReceiveCount>=iCouponTotalNum THEN 203
		        WHEN UserReceiveCount>=iMaxUseTimePerUser THEN 204
				WHEN bInvalidStatus = 1 THEN 202
				WHEN dValidEnd = NULL THEN 205
				ELSE 200 END [Status],
		   iCouponUseType FROM (
	SELECT NEWID() CouponId,
		   A.sBatchCode,
		   B.sCouponCode,
		   C.iBatchId,
		   C.iCouponTotalNum,
		   D.iCouponSettingId,
		   D.iCouponUseCount,
		   CASE WHEN D.iEffectiveType = 0 THEN D.dValidStart ELSE 
				CASE WHEN D.iEffectiveValidType = 0 THEN CONVERT(VARCHAR(10),GETDATE(),120) ELSE CONVERT(VARCHAR(10),DATEADD(DAY,1,GETDATE()),120) END + ' 00:00:00'
		   END dValidStart,
		   CASE WHEN D.iEffectiveType = 0 THEN
			CASE WHEN GETDATE() > D.dValidEnd THEN NULL
			ELSE D.dValidEnd END
		   ELSE 
				CONVERT(VARCHAR(10),DATEADD(DAY,D.iEffectiveDays - 1,CASE WHEN D.iEffectiveType = 0 THEN GETDATE() ELSE DATEADD(DAY,1,GETDATE()) END),120) + ' 23:59:59'
		   END dValidEnd,
		   ISNULL(D.iReceiveCount,0) AS iBatchReceiveCount,
		   (SELECT COUNT(1) from Ymt_CouponPrivateUserBound E with (Nolock) where E.iBatchId = C.iBatchId AND iUserId=@BuyerUserId) UserReceiveCount,
		   D.iMaxUseTimePerUser,
		   D.iCouponUseType,
		   C.bInvalidStatus
	FROM
	  ( SELECT col AS sBatchCode
	   FROM dbo.Split(@BatchCodes,',')) A
	INNER JOIN
	  ( SELECT col AS sCouponCode
	   FROM dbo.Split(@CouponCodes,',')) B ON B.sCouponCode LIKE A.sBatchCode+'%'
	INNER LOOP JOIN dbo.Ymt_CouponBatch C WITH(NOLOCK) ON A.sBatchCode = C.sBatchCode
	INNER LOOP JOIN dbo.Ymt_CouponSetting D WITH(NOLOCK) ON C.iCouponSettingId = D.iCouponSettingId) temp

	IF EXISTS(SELECT 1 FROM @tableCouponBatch WHERE [Status]=200)
	BEGIN
    BEGIN TRY
   
		BEGIN TRAN
		-- 写入优惠券数据
		INSERT INTO dbo.Ymt_Coupon(sCouponId,sCouponCode,iCouponType,dValidStart,dValidEnd,iCouponSetting,iBatchId,iUsage,sInvalidMemo)
		SELECT CouponId,CouponCode,2,ValidStart,ValidEnd,CouponSettingId,BatchId,1,''
			FROM @tableCouponBatch WHERE [Status]=200
		
		-- 用户领用该批次的优惠券
		INSERT INTO dbo.Ymt_CouponPrivateUserBound(sBoundId,sCouponCode,iUserId,dAddTime,iCouponUsedCount,sCouponId,iBatchId)
		SELECT NEWID(), CouponCode, @BuyerUserId, GETDATE(), CouponUseCount, CouponId, BatchId
			FROM @tableCouponBatch WHERE [Status]=200

		-- 累加领取次数
		UPDATE Ymt_CouponSetting SET iReceiveCount+=1 FROM Ymt_CouponSetting A with (Nolock) INNER JOIN @tableCouponBatch B ON A.iCouponSettingId=B.CouponSettingId AND B.[Status]=200
		COMMIT TRAN

		SELECT @RetCode=200
	END TRY
  	BEGIN CATCH
		ROLLBACK TRAN
		SELECT @RetCode=500
	END CATCH
	END
	ELSE
	BEGIN
		SELECT @RetCode=300
	END
  
	SELECT A.CouponCode sCouponCode,
				   CASE WHEN @ValidStart='' THEN A.ValidStart ELSE @ValidStart END dValidStart,
				   CASE WHEN @ValidEnd='' THEN A.ValidEnd ELSE @ValidEnd END dValidEnd,
				   A.CouponUseType iCouponUseType,
				   MAX(C.fMinOrderValue) AS fMinOrderValue,
				   MAX(C.fCouponValue*A.CouponUseCount) fCouponValue,
				   A.[Status]
			  FROM @tableCouponBatch A INNER LOOP JOIN dbo.Ymt_CouponValue C WITH(NOLOCK) ON  A.CouponSettingId=C.iCouponSettingId
			  GROUP BY A.CouponCode,
					   CASE WHEN @ValidStart='' THEN A.ValidStart ELSE @ValidStart END,
					   CASE WHEN @ValidEnd='' THEN A.ValidEnd ELSE @ValidEnd END,
					   A.CouponUseType,
					   A.[Status]


END





