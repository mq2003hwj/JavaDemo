-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION ProductStockNumberCount 
(
	@ProductId varchar(36)
)
RETURNS int

AS
BEGIN
	
	DECLARE @stockNum int;

	SET @stockNum = (select SUM(iNum)as StockNum from  Ymt_Catalogs(NOLOCK) WHERE iAction >-1 and  sProductId = @ProductId);

	RETURN @stockNum;

END
