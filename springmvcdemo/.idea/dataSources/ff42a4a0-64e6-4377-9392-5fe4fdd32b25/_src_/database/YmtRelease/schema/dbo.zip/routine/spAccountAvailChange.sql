
-- =============================================
-- Author:		Jmtek
-- Create date: 2014-5-9
-- Description:	资金操作SP化，事务死锁的快速解决方案
-- Change log:
-- 2015-10-16 移除截面账减少锁定时长 By Jmtek
-- =============================================
CREATE PROCEDURE [dbo].[spAccountAvailChange]
	@userId		int,			--资金账号
	@amount		decimal(10, 2),	--资金金额
	@operator	varchar(50),	--资金科目
	@useage		varchar(50),	--付款凭据
	@memo		varchar(200)	--备注
AS
Declare
	@RewardCharge	decimal(10, 2),
	@DefaultCurrency		int
BEGIN
	If @userId < 0
	Begin
		Return 0
	End

	SET @DefaultCurrency = 1		--默认币种 RMB

	If @amount > 0
	Begin
		--更新账户余额
		Update Ymt_AccountInfo Set fAvailAmount = fAvailAmount + @amount Where iUserId = @userId AND iCurrencyType = @DefaultCurrency

		--收入账户资金流水
		Insert Into Ymt_AccountRunningTally 
		([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
		Values
		(NewId(), @amount, 2, @userId, 0, 0, 0, GetDate(), @operator, @useage, @memo)
		--Select NewId(), @amount, 2, iUserId, fBalance, fFreezeAmount, fAvailAmount - @amount, getdate(), @operator, @useage, @memo 
		--From Ymt_AccountInfo with(rowlock)
		--Where iUserId = @userId AND iCurrencyType = @DefaultCurrency
	End
	Else
	Begin
		If Not Exists (Select 1 From Ymt_AccountInfo with(rowlock) Where iUserId = @userId AND iCurrencyType = @DefaultCurrency And fAvailAmount + @amount >= 0) Begin
			RAISERROR('账户余额不足',16,1,'-99') 
		End

		Set @amount = ABS(@amount)

		Select @RewardCharge = (Case When fRewardAmount > @amount Then @amount Else fRewardAmount End) From Ymt_AccountInfo with(rowlock) Where iUserId = @userId AND iCurrencyType = @DefaultCurrency

		--更新账户余额
		Update Ymt_AccountInfo Set fAvailAmount = fAvailAmount - @amount, fRewardAmount = fRewardAmount - @RewardCharge 
		Where iUserId = @userId AND iCurrencyType = @DefaultCurrency
		
		If @RewardCharge > 0 Begin
			--扣款（补贴账户）资金流水
			Insert Into Ymt_AccountRunningTally 
			([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
			Values
			(NewId(),  -@RewardCharge, 3, @userId, 0, 0, 0, GetDate(), @operator, @useage, @memo)
			--Select NewId(), -@RewardCharge, 3, @userId, fBalance, fFreezeAmount, fAvailAmount + @amount, getdate(), @operator, @useage, @memo 
			--From Ymt_AccountInfo with(rowlock)
			--Where iUserId = @userId AND iCurrencyType = @DefaultCurrency
		End

		If @amount - @RewardCharge > 0 Begin
			--扣款资金流水
			Insert Into Ymt_AccountRunningTally 
			([sRunningTallyId],[fOccurredAmount],[iType],[iUserId],[fBalance],[fFreezeAmount],[fAvailAmount],[dAddTime],[sOperator],[sUseage],[sMemo])
			Values
			(NewId(),  -(@amount - @RewardCharge), 2, @userId, 0, 0, 0, GetDate(), @operator, @useage, @memo)
			--Select NewId(), -(@amount - @RewardCharge), 2, @userId, fBalance, fFreezeAmount, fAvailAmount + @amount - @RewardCharge, getdate(), @operator, @useage, @memo 
			--From Ymt_AccountInfo with(rowlock)
			--Where iUserId = @userId AND iCurrencyType = @DefaultCurrency
		End
	End
END


