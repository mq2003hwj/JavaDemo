-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-11-26
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerConsumers]

@sellerId int,-- = 3383
@shangou bit,-- = 1
@turnover bit,-- = 1
@countOnly bit,-- = 0
@excludeBlacklistConsumers bit,-- = 1
@beginTime datetime,-- = '2015-1-1'
@endTime datetime-- = '2015-9-1'

AS

--set statistics io on;

if @countOnly = 1 begin
	select NULL as iUserId where 1 = 0
	
	if @excludeBlacklistConsumers = 1 begin
		select count(distinct iUserId) as Totoal from Ymt_Orders(nolock) o 
		left join Ymt_BlackListForSeller(nolock) bl on o.iBuyerId = bl.iSellerId and o.iUserId = bl.iBuyerId and bl.iAction = 0
		where o.iBuyerId = @sellerId
		and (@shangou is null or o.bShangouOrder = @shangou)
		and (@turnover = 0 or o.iTradingStatus = 4)
		and (@beginTime is null or o.dAddTime >= @beginTime)
		and (@endTime is null or o.dAddTime < @endTime)
		and bl.iSellerId is null
		
	end else begin
		select count(distinct iUserId) as Totoal from Ymt_Orders(nolock) o where iBuyerId = @sellerId
		and (@shangou is null or bShangouOrder = @shangou)
		and (@turnover = 0 or iTradingStatus = 4)
		and (@beginTime is null or dAddTime >= @beginTime)
		and (@endTime is null or dAddTime < @endTime)
		
	end
end else begin
	if @excludeBlacklistConsumers = 1 begin
		select distinct iUserId from Ymt_Orders(nolock) o 
		left join Ymt_BlackListForSeller(nolock) bl on o.iBuyerId = bl.iSellerId and o.iUserId = bl.iBuyerId and bl.iAction = 0
		where o.iBuyerId = @sellerId
		and (@shangou is null or o.bShangouOrder = @shangou)
		and (@turnover = 0 or o.iTradingStatus = 4)
		and (@beginTime is null or o.dAddTime >= @beginTime)
		and (@endTime is null or o.dAddTime < @endTime)
		and bl.iSellerId is null
		
		select @@ROWCOUNT as Totoal
		
	end else begin
		select distinct iUserId from Ymt_Orders(nolock) o where iBuyerId = @sellerId
		and (@shangou is null or bShangouOrder = @shangou)
		and (@turnover = 0 or iTradingStatus = 4)
		and (@beginTime is null or dAddTime >= @beginTime)
		and (@endTime is null or dAddTime < @endTime)
		
		select @@ROWCOUNT as Totoal
		
	end
end

--set statistics io off;