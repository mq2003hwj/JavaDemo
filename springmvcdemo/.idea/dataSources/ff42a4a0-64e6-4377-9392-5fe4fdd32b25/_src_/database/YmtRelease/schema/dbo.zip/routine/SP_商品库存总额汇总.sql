-- =============================================
-- Author:		zhujinfeng
-- Create date: 2015-11-4
-- Description: 商品库存总额汇总
-- =============================================
CREATE PROCEDURE [dbo].[SP_商品库存总额汇总]
AS
BEGIN
	
	-- 取5分钟内创建的订单编号
	SELECT iOrderId INTO #tmpOrderId FROM dbo.Ymt_Orders with (Nolock) WHERE dAddTime > DATEADD(minute, -10, GETDATE())

	-- 根据订单编号找到相应的商品编号
	SELECT DISTINCT sProductId INTO #tmpProductId FROM dbo.Ymt_OrderInfo with (Nolock) WHERE iOrderId IN (SELECT * FROM #tmpOrderId)
	
	--插入新的产品ID
	insert into #tmpProductId
	select sProductId from Ymt_Products with (Nolock) where dAddTime > DATEADD(Minute, -10, GETDATE()) and sProductId not in (select sProductId from #tmpProductId) and iaction > - 1

	--插入iTotalStock 为 0，但有规格库存的商品ID
	INSERT INTO #tmpProductId
	SELECT DISTINCT a.sProductId FROM dbo.Ymt_Products(NOLOCK) a INNER JOIN dbo.Ymt_Catalogs b with (NOLOCK,index = IX_Ymt_CatalogsProductid) ON a.sProductId = b.sProductId 
	WHERE a.iTotalStock = 0 AND a.iAction > -1 AND b.iAction > -1 AND b.iNum > 0

	--插入iTotalStock 为 0, 但有活动库存的商品ID
	INSERT INTO #tmpProductId
	SELECT DISTINCT a.sProductId FROM dbo.Ymt_Products(NOLOCK) a INNER JOIN dbo.Ymt_ProductActivityStock(NOLOCK) b ON a.sProductId = b.sProductId 
	WHERE a.iTotalStock = 0 AND a.iAction > -1 AND b.iAction > -1 AND b.iStockNum > 0

	-- 计算共享库存
	SELECT SUM(iNum) AS CatalogStock , sProductId AS ProductId INTO #tmpCatalogStock FROM dbo.Ymt_Catalogs with (Nolock)
	WHERE sProductId IN (SELECT sProductId	FROM #tmpProductId) AND iAction > -1 GROUP BY sProductId

	-- 计算活动库存
	SELECT SUM(iStockNum) AS ActivityStock, sProductId AS ProductId INTO #tmpActivityStock FROM dbo.Ymt_ProductActivityStock with (Nolock)
	WHERE sProductId IN (SELECT * FROM #tmpProductId) AND iAction > -1 GROUP BY sProductId

	SELECT ISNULL(a.CatalogStock,0) + ISNULL(b.ActivityStock,0) AS TotalStock, t.sProductId INTO #tmpTotalStock 
	FROM #tmpProductId t LEFT JOIN #tmpCatalogStock a ON t.sProductId = a.ProductId LEFT JOIN #tmpActivityStock b ON t.sProductId = b.ProductId

	-- 更新涉及到的商品库存总额
	UPDATE a SET a.iTotalStock = p.TotalStock FROM #tmpTotalStock p LEFT JOIN dbo.Ymt_Products a with (Nolock) ON a.sProductId = p.sProductId

	-- 清空临时表
	DROP TABLE #tmpOrderId;
	DROP TABLE #tmpProductId;
	DROP TABLE #tmpCatalogStock;
	DROP TABLE #tmpActivityStock;
	--DROP TABLE #tmpBundleStock;
	DROP TABLE #tmpTotalStock;

END

