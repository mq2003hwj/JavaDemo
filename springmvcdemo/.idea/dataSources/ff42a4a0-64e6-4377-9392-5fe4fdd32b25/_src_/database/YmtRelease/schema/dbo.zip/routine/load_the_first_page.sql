CREATE procedure [dbo].[load_the_first_page]
as
begin
	set nocount on
	set fmtonly off
	
	if object_id('tempdb..#t') is not null
		drop table #t

	create table #t
	(
		ID int,
		描述 nvarchar(64),	
		商品ID varchar(36), 	
		商品单价 float,	
		销售件数 int,	
		销售金额 float,	
		订单量 int
	)

	create index ss on #t(商品ID)

	insert into #t(id, 描述, 商品ID)
	values
	(1,N'品牌推荐位','c77d3d230da3410a8c9941bd0e03f6fa'),
	(2,N'品牌推荐位','6ae2fedc0786464db8e9b97d3a200c7f'),
	(3,N'品牌推荐位','e0bff71eabe54c5fa79bb1193f389df9'),
	(4,N'品牌推荐位','139decf6fde5467db4149c95f88f91ea'),
	(5,N'品牌推荐位','aae0b3c359014595a8dbfa6cd61e464d'),
	(6,N'明星商家','a49e9f79f048433e9e72b0b4b9a465f8'),
	(7,N'明星商家','6e5cec10689146ed8cbbd13b32833087'),
	(8,N'明星商家','3386765da928491d8cf81492ee2ee557'),
	(9,N'明星商家','a314d77e886f418fa7a17ab406be4e4b'),
	(10,N'明星商家','127eabc8f52b4a93ae270c1d90616209'),
	(11,N'明星商家','1468ce3811ba45f0855a710b7555f502'),
	(12,N'明星商家','38b404538ba849d2b36c3ca60338487e'),
	(13,N'明星商家','1873a535f4b7467b834137add722f68a'),
	(14,N'明星商家','6dd2972808784003b6f6678daae2cf9b'),
	(15,N'推荐商家','cbbb74eb21534282b5d50a85e3e73d7f'),
	(16,N'推荐商家','73bb7fe2bfaa4d84a506cf292acf42a7'),
	(17,N'推荐商家','b44424712afe4b71af46ae8fc32a77e7'),
	(18,N'推荐商家','74174d1d91894e6e8b7ac21e617f042a'),
	(19,N'推荐商家','60804d076ede4efc876950a38f2a6be6'),
	(20,N'推荐商家','8a7034ae8c884a23911c7c5856ef7545'),
	(21,N'推荐商家','509183a4077948e49c5264e531b9150d'),
	(22,N'推荐商家','d428cf07ec80425180010c39864d9f17'),
	(23,N'推荐商家','968115e36f8746988a3c35ce08d7c22c'),
	(24,N'最新商家','7c6dcd42d2ae49638b5c848cb2fd6c5f'),
	(25,N'最新商家','2b35622a3a344d76ab6540c628dd9291'),
	(26,N'最新商家','4527ab107aa9405e9a902f58d54ab412'),
	(27,N'最新商家','790b98467ec24dd88f1dee0ee3ab1165'),
	(28,N'最新商家','fffd9eb2a4fd4e01a21148348e986a95'),
	(29,N'最新商家','8d00212d35b6444597326140fb642ba9'),
	(30,N'最新商家','11a317db216f4c9cb1a67948108e0e35'),
	(31,N'最新商家','baf95a2e89d04b1db6ba267818e3b6d3'),
	(32,N'最新商家','29ae108b55d8418ca2399b24b1576abf'),
	(33,N'8张彩图','d01e3498f78d499da5e1844fbf6dcd2a'),
	(34,N'8张彩图','5ce75aafc82344a29b025b82c8d343bb'),
	(35,N'8张彩图','e2bb42eb70634c8d9580e1fb782d5f23'),
	(36,N'8张彩图','a295efaa65d74a9dab2b71687aa8b8ba'),
	(37,N'8张彩图','28c81ec3adb3484891c8e87fa04b34c9'),
	(38,N'8张彩图','f6b98e3423144b95907750b5b534be55'),
	(39,N'8张彩图','f3c1cabe9236456ca320d3e9aaae55e2'),
	(40,N'8张彩图','21c0db57c4d94c5d8f3f1b8667bc339b'),
	(41,N'热卖商品','4265eb63ae6e4ee8a2d47b4c2fd95d33'),
	(42,N'热卖商品','91ebd8fac4a14be9b941ac79958f9487'),
	(43,N'热卖商品','243eecb6ce5f4dc1914fd28d9a58ee66'),
	(44,N'热卖商品','f484f946b0124c84933d41b659f541d2'),
	(45,N'热卖商品','7BA9CF45D0AE40D5875151F045881C44'),
	(46,N'热卖商品','0b3fe03042b849b09746cd00138397b8'),
	(47,N'热卖商品','87d69f07e93e4ce5a7414f2f28e91dda'),
	(48,N'母婴用品','61165f1f2a0847998830e1f07e03cfce'),
	(49,N'母婴用品','65efb9b01e6b4fdd922f981b87d38e1c'),
	(50,N'母婴用品','6737a78275ae465182705adf4813e51e'),
	(51,N'母婴用品','e055d1da6fc943d6bf51b47b697b2179'),
	(52,N'母婴用品','2ecea73ba4174aab96bbe88ad762c386'),
	(53,N'母婴用品','9ebe967feee6441b8c53a70fe8e146a5'),
	(54,N'母婴用品','b1cce0a1a2b944659f638da175a11186'),
	(55,N'母婴用品','c19f12e3d4c548aa9d149e92b20c4ea3'),
	(56,N'营养健康','e99f9db8eb68484c80f4c89842072194'),
	(57,N'营养健康','27b00941978b4262a2fdcd8eab2175b2'),
	(58,N'营养健康','cec50beb051e4fae8356ea12209248cc'),
	(59,N'营养健康','f10357fbbef4405c802eb29b3265cf04'),
	(60,N'营养健康','fd95ce7947674983bfc1245407f11be6'),
	(61,N'营养健康','3ca72cf18651404894b99d613419ede1'),
	(62,N'营养健康','a9c4246164f648e386d7fe12c732d61d'),
	(63,N'营养健康','e5682b61a2ce436bbb37f9c15b42b0b3'),
	(64,N'营养健康','e6b7d651cfbd412cabd00458441e23c0'),
	(65,N'美容护肤','54B448980226421087AF9B1D2D35D4C6'),
	(66,N'美容护肤','0167a4264b714e4eb8bffc6d947731c4'),
	(67,N'美容护肤','f4185df845a54c70950da5d72154aef8'),
	(68,N'美容护肤','56ca0948b2cd4b52970b3d9ccab31a75'),
	(69,N'美容护肤','c366963002b64ea4aefb3a818aa7aaed'),
	(70,N'美容护肤','51c8ae24354647889980afa6c9a79545'),
	(71,N'美容护肤','a6da9ca84fc54a0bbe5fb5be497abeed'),
	(72,N'美容护肤','cb7f04fd679b40e8b737641b38849ab9'),
	(73,N'美容护肤','323640d0e4c7401aa7b811e308b4d58d'),
	(74,N'鞋帽服饰','86451745f11d4bb1abb9bc5dd78c305e'),
	(75,N'鞋帽服饰','0d3b8a27851e4484be4b41c84959b4ba'),
	(76,N'鞋帽服饰','72a4b31c1c1243d29c84dd5e57d0be9a'),
	(77,N'鞋帽服饰','29f6d7bb9d624953b26caa703c5dc82b'),
	(78,N'鞋帽服饰','707c0b3ccb47432e86d187575304845e'),
	(79,N'鞋帽服饰','daffbd21da934bd8b23c8287873989b4'),
	(80,N'鞋帽服饰','0a0c037fe78b4e73960f9dda6ba0b5c8'),
	(81,N'鞋帽服饰','2239fd2406ba49b8987d45d3a9c96f9e'),
	(82,N'鞋帽服饰','0488b39452d74ca99765b33acce4dc14'),
	(83,N'箱包手袋','b563617873e14a52bed8a890ea767860'),
	(84,N'箱包手袋','25cf5c73277c4b03bedeefff5bdfdd22'),
	(85,N'箱包手袋','093570d495244a5081c74ce949914740'),
	(86,N'箱包手袋','de0ea7b184b44634b9a2b1b33d74feef'),
	(87,N'箱包手袋','b4a5d7e8c0d842e5912f4a7d1b58aa3b'),
	(88,N'箱包手袋','5d5287d605cc4a008a31dd175943e3f3'),
	(89,N'箱包手袋','2c7c457c51114aec8138691d22efd280'),
	(90,N'箱包手袋','e9aebb863fbb4004ada0cf1afa44b663'),
	(91,N'箱包手袋','ecbf1ee7c2494391a186738411cee8f9')



	UPDATE	#t
	SET 商品ID = SUBSTRING(商品ID, 1,8)+'-' + SUBSTRING(商品ID, 9, 4) + '-' 
			+ SUBSTRING(商品ID, 13,4) + '-' 
			+ SUBSTRING(商品ID, 17,4) + '-' + SUBSTRING(商品ID, 21, 12)

	declare @beginDate date, @endDate date
	select	@beginDate = getdate()-1, @endDate = getdate()


	update	#t
	set		销售件数 = AA.销售件数, 销售金额=AA.销售金额, 订单量=AA.订单量 
	from	#t
	inner join
	(
		select	商品ID, sum(YOI.iAmount) 销售件数, sum(YOI.fTotalPrice * iAmount) 销售金额, count(distinct YO.iOrderId) 订单量
		from	Ymt_Orders YO
		inner join Ymt_OrderInfo YOI
		on		YO.iOrderId = YOI.iOrderId 
		inner join #t 
		on		YOI.sProductId = #t.商品ID collate SQL_Latin1_General_CP1_CI_AS
		where	YO.dAddTime >= @beginDate
		and		YO.dAddTime < @endDate 
		group by 商品ID
	) AA
	on	#t.商品ID = AA.商品ID 

	update #t
	set 商品单价 = 销售金额/销售件数

	select * from #t

	drop table #t
end
