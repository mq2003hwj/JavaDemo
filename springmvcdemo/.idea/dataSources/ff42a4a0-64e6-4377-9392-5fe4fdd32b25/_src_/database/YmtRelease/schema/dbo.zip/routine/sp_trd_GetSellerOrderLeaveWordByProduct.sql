-- =============================================            

-- Author:  fanwei        

-- Create date: 2015-9-1

-- Description: 交易服务SP     

-- 20160819：取消根据风控状态做的特殊查询逻辑   

-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetSellerOrderLeaveWordByProduct]

@sellerId int,

@lastOrderId int,

@productId varchar(36),

@orderStatusXml xml,

@top int,

@considerOrderStatus bit,

@considerRCOrderEstablish bit,

@considerRCAccountPaid bit,

@considerRestOrderStatus bit



AS



---------------variables-------------

declare @orderIds table(id int not null, bid int)

declare @orderStatus table([value] int primary key)

declare @rowCount int = 0



--------------process--------------

if @orderStatusXml is not null

begin

    insert into @orderStatus 

    select tbl.col.value('@s','int')

    from @orderStatusXml.nodes('/root/x') tbl(col)

end



--set statistics time on;set statistics io on;


set nocount off;

if @productId is null begin

  insert into @orderIds

  select top (@top) o.iOrderId, o.iUserId

  from Ymt_Orders(nolock) o 

  where o.iBuyerId = @sellerId and

  (@lastOrderId is null or o.iOrderId < @lastOrderId) and

  (@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))

  order by o.dAddTime desc

end else begin

  insert into @orderIds

  select top (@top) o.iOrderId, o.iUserId

  from Ymt_Orders(nolock) o 

  join Ymt_OrderInfo(nolock) i on o.iOrderId = i.iOrderId and i.sProductId = @productId

  where o.iBuyerId = @sellerId and

  (@lastOrderId = 0 or o.iOrderId < @lastOrderId) and

  (@orderStatusXml is null or o.iTradingStatus in (select value from @orderStatus))

  order by o.dAddTime desc

end

set @rowCount = @@ROWCOUNT


set nocount on;

select iOrderId,iUserId,sLeaveWord,dAddTime,sBuyerLoginId from Ymt_Orders(nolock) where @rowCount > 0 and iOrderId in (select id from @orderIds) order by dAddTime desc

select iOrderId as [id], sPropertyInfo as [text], iPriceType from Ymt_OrderInfo(nolock) where @rowCount > 0 and iOrderId in (select id from @orderIds)

select 0 as [id], '' as [text]


--set statistics time off;set statistics io off;


