
-- =============================================            
-- Author:  zhangzhiqiang        
-- Create date: 2015-9-9
-- Description: 创建订单（C2C）       
-- =============================================     

CREATE PROC [dbo].[sp_CreateOrderC2C_New]
	@UserId int
	,@SellerId int
	,@OrderType int
	,@OrderSource varchar(128)
	,@OrderSourceIp varchar(128)
	,@TerminalSource varchar(128)
	,@AppTerminalSource varchar(128)
	,@DeviceId varchar(200) = null
	,@ShangouOrder bit
	,@Address varchar(1000) = ''
	,@PostCode varchar(10)
	,@Phone varchar(20)
	,@ReceivePerson varchar(50)
	,@Telephone varchar(20)
	,@LeaveWord varchar(2000)
	,@AutoCancelOrderHours decimal(18,2)
	,@UseGiftAmount decimal(18,2)
	,@CouponCode varchar(36) = null
	,@CouponValue decimal(18,2)
	,@CouponUseType int
	,@CouponChannel int = null
	,@PriceType int
	,@ProductNum int
	,@PropetyInfo varchar(2000)
	,@ProductPrice decimal(18,2)
	,@EarnestPrice decimal(18,2)
	,@PictureUrl varchar(1000)
	,@ProductName varchar(500)
	,@CatalogId varchar(36)
	,@CatalogStatus int
	,@ProductId varchar(36)
	,@ActivityId int
	,@CouponAvail4OrderDeduct bit
	,@GiftAvail4OrderDeduct bit
	,@FeeFree bit
	,@GiftAvail4Reward bit
	,@ActivityTemplateId int
	,@PromotionType int
	,@Promotion decimal(18,2)
	,@CommissionRate decimal(18,2)
AS

declare @OrderId int = 0
		,@QQ varchar(20)
		,@Email varchar(500)
		,@BuyerLoginId nvarchar(200)
		,@BuyerLoginEmail nvarchar(200)
		,@SellerLoginId nvarchar(200)
		,@SellerLoginEmail nvarchar(200)
		,@SellerType int
		,@IsMerchant int = 0  --0：非商家
		,@BuyerNickName nvarchar(200)
		,@IncludeActivity bit = 0
		,@Now datetime = getdate()
		,@OrderPrice decimal(18,2)
		,@TotalPrice decimal(18,2)
		,@OrderInfoId varchar(36)
		,@IsNeedUploadIdCard bit = 0
		,@SailProtected int = 0

--生成新订单号
	EXEC @OrderId = spGenerateOrderId 

	SELECT @QQ=sQQ,@Email=sLoginEmail,@BuyerLoginId=sLoginId,@BuyerLoginEmail=sLoginEmail,@BuyerNickName=sNickName
	FROM Ymt_Users WITH(NOLOCK) WHERE iUserId = @UserId

	SELECT @SellerLoginId=sLoginId,@SellerLoginEmail=sLoginEmail,@SellerType=iType
	FROM Ymt_Users WITH(NOLOCK) WHERE iUserId = @SellerId

	--验证此卖家是否是商家
	IF @SellerType=1 AND EXISTS(SELECT 1 FROM Ymt_SellerInfo WITH(NOLOCK) WHERE iUserId=@SellerId AND mshop = 1)
	BEGIN
		SET @IsMerchant = 1
	END

	SET @OrderPrice = @EarnestPrice * @ProductNum
	SET @TotalPrice = @ProductPrice * @ProductNum
	IF @ActivityId > 0
		SET @IncludeActivity = 1

	--插入订单数据Ymt_Orders
	INSERT INTO [Ymt_Orders]
           ([iOrderId],[iUserId],[iBuyerId],[sMarkId],[dAddTime],[fOrderPrice],[fOrderDiscount] ,[fFreight],[fDiscount],[iTradingStatus] ,[sAddress],[sPostCode]
           ,[sReceivePerson],[sPhone],[sTelephone],[sQQ],[sEmail] ,[sLeaveWord],[bPaidInFull],[fUseGiftAmount],[sCouponCode],[CouponValue]
           ,[iCouponType],[iCouponChannel],[fAutoCancelOrderHours],[bShangouOrder],[sBuyerLoginId],[sBuyerLoginEmail],[sSellerLoginId]
           ,[sSellerLoginEmail],[iIsMerchant],[sBuyerNickName],[fTotalPrice],[bIncludeActivityProducts],[sCurType])
     VALUES
           (@OrderId,@UserId,@SellerId,'',@Now,@OrderPrice,0,0,0,1,@Address,@PostCode,@ReceivePerson,@Phone,@Telephone,@QQ,@Email,@LeaveWord,0
           ,@UseGiftAmount,@CouponCode,@CouponValue,@CouponUseType,@CouponChannel,@AutoCancelOrderHours,@ShangouOrder,@BuyerLoginId,@BuyerLoginEmail
           ,@SellerLoginId,@SellerLoginEmail,@IsMerchant,@BuyerNickName,@TotalPrice,@IncludeActivity,'CNY')
	
	--插入订单资金数据Ymt_OrderState
	IF @CouponValue IS NULL OR (@CouponUseType IS NOT NULL AND @CouponUseType <> 1)
	BEGIN
		SET @CouponValue = 0
	END
	INSERT INTO [Ymt_OrderState]
           ([iOrderId],[fRefundedAmountOfCash],[fRefundedAmountOfGift],[fPaidAmountOfCash],[fPaidAmountOfGift],[fPostPaidAmountOfCash],[fPostPaidAmountOfGift]
           ,[fPaidAmountOfCoupon])
     VALUES
           (@OrderId, 0, 0, 0, @UseGiftAmount, 0, 0, @CouponValue)
	
	
	IF @CatalogStatus = 3  --护航只有需要上传身份证
		SET @IsNeedUploadIdCard = 1
	--插入订单扩展信息Ymt_OrderExt
	INSERT INTO [Ymt_OrderExt]
           ([iOrderId],[sOrderSource],[sOrderSourceIP],[iOrderType],[sTerminalSource],[sAppTerminalSource],[sDeviceId],[bIsNeedUploadIdCard])
    VALUES
           (@OrderId,@OrderSource,@OrderSourceIp,@OrderType,@TerminalSource,@AppTerminalSource,@DeviceId,@IsNeedUploadIdCard)


	SET @OrderInfoId = NEWID()
	IF @CatalogStatus = 3  --3-代表护航直邮
		SET	@SailProtected = 1
	--插入订单商品信息Ymt_OrderInfo
	INSERT INTO [Ymt_OrderInfo]
			([sOrderInfoId],[iOrderId],[sCatalogId],[sPropertyInfo],[sTitle],[sPictureUrl],[fOriginalPrice],[iAmount]
			,[fTotalPrice],[iSailProtected],[sSKU],[iCatalogType],[iCatalogStatus],[sProductId]
			,[iBondedArea],[iTariffType],[fFlight],[iPriceType])
		VALUES
			(@OrderInfoId,@OrderId,@CatalogId,@PropetyInfo,@ProductName,@PictureUrl,@EarnestPrice,@ProductNum
			,@OrderPrice,@SailProtected,'',1,@CatalogStatus,@ProductId,0,0,0,@PriceType)

	IF @IncludeActivity = 1  --插入订单商品活动信息Ymt_OrderInfoExt
	BEGIN
		INSERT INTO [Ymt_OrderInfoExt]
			([sOrderInfoId],[iActivityId],[iActivityTemplateId],[iPromotionType],[fPromotion],[bGiftAvail4OrderDeduct]
			,[bGiftAvail4Reward],[bCouponAvail4OrderDeduct],[bOnly4VIP],[bFeeFree],[fCommissionRate])
		VALUES
			(@OrderInfoId,@ActivityId,@ActivityTemplateId,@PromotionType,@Promotion,@GiftAvail4OrderDeduct,@GiftAvail4Reward
			,@CouponAvail4OrderDeduct,0,@FeeFree,@CommissionRate)
	END

SELECT @OrderId AS OrderId

