-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spGenerateOrderId]
	 
AS
BEGIN
	INSERT INTO Ymt_AutoOrderIds DEFAULT VALUES
	
	IF @@ERROR > 0
		Return -1
		
	RETURN SCOPE_IDENTITY()+100000000
END
