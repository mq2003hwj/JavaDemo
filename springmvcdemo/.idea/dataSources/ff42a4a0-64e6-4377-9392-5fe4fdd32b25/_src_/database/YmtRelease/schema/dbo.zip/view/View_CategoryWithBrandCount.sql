CREATE VIEW dbo.View_BrandCategory
AS
SELECT     dbo.Ymt_ProductCategory.iLevel, dbo.Ymt_ProductCategory.sCategory, dbo.Ymt_ProductCategory.iMasterCategory, dbo.Ymt_ProductCategory.iCategoryId, 
                      dbo.View_CountBrandGroupCategory.iBrandCount
FROM         dbo.Ymt_ProductCategory INNER JOIN
                      dbo.Ymt_CategoryForBrand ON dbo.Ymt_ProductCategory.iCategoryId = dbo.Ymt_CategoryForBrand.iCategoryId INNER JOIN
                      dbo.View_CountBrandGroupCategory ON dbo.Ymt_ProductCategory.iCategoryId = dbo.View_CountBrandGroupCategory.iCategoryId
