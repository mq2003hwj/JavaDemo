CREATE TRIGGER [dbo].[ComplaintMessageAdded]
ON [dbo].[CS_ComplaintMessage]
AFTER INSERT
AS
	Declare @sComplaintMessageId varchar(36)
	Select @sComplaintMessageId = ComplaintMessageId From inserted
	
	update cs_complaintmessage set content = replace(content, '<body', '<span') where ComplaintMessageId = @sComplaintMessageId
	update cs_complaintmessage set content = replace(content, '</body', '</span') where ComplaintMessageId = @sComplaintMessageId