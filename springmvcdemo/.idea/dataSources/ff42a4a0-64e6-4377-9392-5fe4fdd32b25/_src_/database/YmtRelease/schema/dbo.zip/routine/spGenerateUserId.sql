-- =============================================
-- Author:		Jmtek
-- Create date: 2011-12-12 11:30:00
-- Description:	take out the userid generation
-- =============================================
CREATE PROCEDURE [dbo].[spGenerateUserId] 
AS
BEGIN
	INSERT INTO Ymt_UserIds DEFAULT VALUES
	
	IF @@ERROR > 0
		Return -1
		
	RETURN SCOPE_IDENTITY()
END
