/**********************************************
**** Author:		Rain.Xiao              ****
**** Create date:   2015-10-15             ****
**** Description:	幸运转盘抽奖存储过程   ****
**********************************************/
CREATE PROC [dbo].[SP_InsertLotteryRecord]
 @iUserId INT,
 @sDeviceId VARCHAR(200),
 @dLotteryDate DATETIME2,
 @sIp NVARCHAR(15)
AS
BEGIN
 INSERT INTO Ymt_Lottery(iUserId,sDeviceId,dLotteryDate,sIp) VALUES(@iUserId,@sDeviceId,@dLotteryDate,@sIp)
 SELECT @@IDENTITY AS LotteryId
END
