
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	复制活动模板佣金设置到指定活动
-- =============================================
CREATE PROCEDURE [dbo].[spCopyActivityCommission]
	@iActivityTemplateId int,
	@iActivityId int,
	@result int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	set @result = 2
	if(exists(select * from Ymt_ActivityCommission where iActivityId = @iActivityId))
	begin
		set @result = 1
	end
	else
	begin
		insert into Ymt_ActivityCommission (iActivityId, iCategoryId, fFeeRate)	
		select @iActivityId, iCategoryId, fFeeRate from Ymt_ActivityTemplateCommission where iActivityTemplateId = @iActivityTemplateId
		
		set @result = 0
	end
	

END

