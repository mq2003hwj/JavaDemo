-- =============================================
-- Author:		Lasko
-- Create date: 2010-05-28
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[spGetQuotePriceInfoByProductIds]
	-- Add the parameters for the stored procedure here
	@productIds nvarchar(max)='ffffffff-ffff-ffff-ffff-ffffffffffff,ffffffff-ffff-ffff-ffff-ffffffffffff' 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @strSQL nvarchar(4000);

    -- Insert statements for procedure here
	SET @strSQL = 'SELECT a.sProductId,a.sProduct,b.fQuotePrice,c.priceCount FROM Ymt_Products a ';
	SET @strSQL += ' left join (Select sProductId,Min(fQuotePrice) as fQuotePrice from Ymt_Catalogs WHERE DATEDIFF(DAY,dAddTime,GETDATE())<iExpire Group by sProductId) b ';
	SET @strSQL += ' on a.sProductId = b.sProductId';
	--SET @strSQL += ' left join (Select sProductId,COUNT(fQuotePrice) AS priceCount  from Ymt_Catalogs WHERE DATEDIFF(DAY,dAddTime,GETDATE())<iExpire group by sProductId) c ';
	--注释总报价数 改为有效报价用户数 经测试 这样做是可以滴 2010-05-29 15:26 附测试语句
	--select sProductId, COUNT(distinct iUserId) as co from Ymt_Catalogs group by sProductId
	--select * from Ymt_Catalogs where sProductId = '42686D0F-406D-4AA3-9E43-EC10DF8E3AA6'
	SET @strSQL += ' left join (Select sProductId,COUNT(distinct iUserId) AS priceCount  from Ymt_Catalogs WHERE DATEDIFF(DAY,dAddTime,GETDATE())<iExpire group by sProductId) c ';
	SET @strSQL += ' on a.sProductId = c.sProductId';
	SET @strSQL += ' where 1=1 '
	SET @strSQL += ' and  a.sProductId in (  select * from Split('''+@productIds + ''', '',''))';
	SET @strSQL += ' and  c.priceCount is not null and c.priceCount>0';
	
	print @strsql;
	
	Exec (@strSQL );
END
