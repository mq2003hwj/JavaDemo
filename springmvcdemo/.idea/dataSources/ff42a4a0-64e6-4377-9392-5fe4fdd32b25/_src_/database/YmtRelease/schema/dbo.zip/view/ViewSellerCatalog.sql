CREATE VIEW dbo.ViewSellerCatalog
AS
SELECT     dbo.Ymt_Catalogs.sCatalogId, dbo.Ymt_Catalogs.sProductId, dbo.Ymt_Catalogs.fQuotePrice, dbo.Ymt_Catalogs.fFlight, dbo.Ymt_Catalogs.sLocation, 
                      dbo.Ymt_Catalogs.dAddTime, dbo.Ymt_Catalogs.sDescript, dbo.Ymt_Catalogs.iAcceptReturn, dbo.Ymt_Catalogs.iCatalogStatus, dbo.Ymt_Users.sNickName AS sUser, 
                      dbo.Ymt_Users.iUserId, dbo.Ymt_Users.sBaseAddress, dbo.Ymt_Products.sPicUrl, dbo.Ymt_Products.sProduct
FROM         dbo.Ymt_Users INNER JOIN
                      dbo.Ymt_Catalogs ON dbo.Ymt_Users.iUserId = dbo.Ymt_Catalogs.iUserId INNER JOIN
                      dbo.Ymt_Products ON dbo.Ymt_Catalogs.sProductId = dbo.Ymt_Products.sProductId
WHERE     (dbo.Ymt_Users.sNickName <> '') AND (dbo.Ymt_Users.iAction > - 1) AND (dbo.Ymt_Catalogs.iAction > - 1)
