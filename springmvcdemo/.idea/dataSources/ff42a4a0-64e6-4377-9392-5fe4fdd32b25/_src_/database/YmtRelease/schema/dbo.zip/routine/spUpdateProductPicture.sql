-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE spUpdateProductPicture 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	--Declare @pictureUrl varchar(4000);


    Declare @tProducts table(id varchar(500));
	declare @productId varchar(500);
	declare @picurl varchar(1000);
	declare @lastCatalogDate datetime;
	
	insert into @tProducts select sProductId from Ymt_Products ;
	

	
	--select * from @tProducts
	
	select top 1 @productId=(id) from @tProducts;
	print '4444444444444444' + @productId;
	while(@productId is not null)
	begin
		print 'deledt' + @productId;
		delete from @tProducts where id=@productId;
		Set @picurl = '';
		select top 1 @picurl=(sFileName) from Ymt_ProductPicture where sProductId = @productId;
		print 'dddd' + @picurl;
		--Set @lastCatalogDate = GETDATE();
		--select top 1 @lastCatalogDate=(DateAdd("D",iExpire,dAddTime)) from Ymt_Catalogs where sProductId =@productId order by DateAdd("D",iExpire,dAddTime) desc;
		if(@picurl is not null and @picurl <>'')
		begin
			SET @picurl = 'http://p3.img.ymatou.com/webpic/list/'+replace(@picurl,'_o','_l');
			update Ymt_Products set sPicUrl = @picurl where sProductId = @productId
		end
		Set @productId = null;
		
		select top 1 @productId=(id) from @tProducts;
	end
	
	update Ymt_Products set sPicUrl = 'http://img.ymatou.com/portal/images/null.gif' where sPicUrl is null
 --   -- Insert statements for procedure here
	----SELECT <@Param1, sysname, @p1>, <@Param2, sysname, @p2>
	--declare @tProductid varchar(36)
	--declare @picurl varchar(500);
	--declare table_cur cursor for
	--Select sProductId from Ymt_Products
	--open table_cur
	--fetch next from table_cur into @tProductid
	--while @@FETCH_STATUS = 0
	--begin
	----declare @picurl varchar(500)
	----select top 1 @picurl=(sUrl) from Ymt_Pictures where sKey =@tProductid
	----select top 1 
	----update Ymt_Products set sPicUrl=@picurl where sProductId=
	--Print @tproductid
	--end
	--Deallocate table_cur



	
END
