CREATE PROCEDURE [dbo].[spUpdateShopToMShop] 
	@userId int
AS
BEGIN
	SET NOCOUNT ON;

    update Ymt_Shop set iShopType = 1 where iUserId = @userId
    
    --更新风格为纯现货，打开演示
    update Ymt_ShopSetting set iShopSettingType = 1 ,  iShopSettingStatus =3  where iUserId = @userId 

	--更新用户商品
	update Ymt_Products set iIsMerchant = 1 where iUserId = @userId
END