-- =============================================
-- Author:		lzh
-- Create date: 2015-11-18
-- Description:	CreateTradingWithOrders
-- =============================================

CREATE PROCEDURE  sp_CreateTradingWithOrders
	@userId int,
	@orderIdXml xml,
	@tradingStatus int,
	@sumPrePayAmount  decimal(18,2),
	@now datetime
AS

BEGIN
	declare @orderIds table(id int not null primary key clustered)
	declare @tradingId int
	--------------process--------------

	if @orderIdXml is not null
	begin
		insert into @orderIds 
		select tbl.col.value('@s','int')
		from @orderIdXml.nodes('/root/x') tbl(col)
	end;

	if @@ROWCOUNT <= 0 
	begin
		select @tradingId
		return;
	end

	exec @tradingId = [dbo].[spGenerateTradingId]
	if @tradingId = -1 
	begin
		select @tradingId
		return;
	end

	begin try
		begin transaction 
			insert into Ymt_TradingInfo
			(iTradingId,dAddTime,iTradingStatus,fAmount,iUserId,dUpdateTime,fPayableAmount)
			values (@tradingId,@now,@tradingStatus,@sumPrePayAmount,@userId,@now,@sumPrePayAmount)

			insert into Ymt_TradingItem([sId],iOrderId,dAddTime,iTradingId,dUpdateTime,iTradingResult,iTradingType)
			select NEWID(),id,@now,@tradingId,@now,0,0 from @orderIds
		commit
	end try 

	begin catch 
		rollback;
		throw;
	end catch

	select @tradingId

END