





-- =============================================



-- Author:		gejianhua



-- Create date: 2016-8-11



-- Description:	优惠券资金统计



-- =============================================



CREATE PROCEDURE dbo.sp_couponfundstat


AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from



	-- interfering with SELECT statements.



	SET NOCOUNT ON;


    -- Insert statements for procedure here

	--统计平台批次资金状况
	--目前仅统计绝对有效期并且过期的批次


	--定义表变量，存储需要统计的批次信息

	declare @batchtable table
	(



		autoid smallint identity,



		batchid int,				--批次id



		batchcode varchar(36),		--批次编号



		sendtype tinyint,			--发放方式  1:短码  2:链接



		batchname varchar(50),		--优惠券名称



		byjcode varchar(50),		--备用金单号



		usetimesperuser int,		--短码：单用户最大使用次数，链接：单用户最大领取次数



		usetimespercoupon int,		--单券码最大可使用次数



		usetimestotal int,			--批次可使用总次数



		validitytype tinyint,		--有效期类型 0：绝对有效期 1：相对有效期



		validstarttime datetime,	--有效开始时间



		validendtime datetime,		--有效结束时间



		facevalue decimal(18,2),	--面额



		createtime datetime			--优惠券创建时间



	)







	--查找平台、绝对有效期、过期的批次信息，插入表变量



	insert into @batchtable



		(batchid, 



		batchcode, 



		sendtype, 



		batchname, 



		byjcode, 



		usetimesperuser, 



		usetimespercoupon, 



		usetimestotal, 



		validitytype, 



		validstarttime, 



		validendtime, 



		facevalue, 



		createtime)



	select



		b.iBatchId,



		b.sBatchCode,



		b.iSendType,



		b.sCouponName,



		b.ImpresetInvoiceId,



		s.iMaxUseTimePerUser,



		s.iCouponUseCount,



		s.iUseTotalCount,



		s.iEffectiveType,



		s.dValidStart,



		s.dValidEnd,



		v.fCouponValue,



		b.dAddTime



	from Ymt_CouponBatch b with(nolock)



		inner join Ymt_CouponSetting s with(nolock) on b.iCouponSettingId = s.iCouponSettingId



		inner join Ymt_CouponValue v with(nolock) on v.iCouponSettingId = s.iCouponSettingId



		left join ymt_couponfundstat f with(nolock) on f.batchcode = b.sBatchCode



	where b.iBatchCreateType = 1 and s.iEffectiveType = 0 and s.dValidEnd < getdate() and isnull(b.ImpresetInvoiceId,'') <> '' and f.batchcode is null







	



	declare @count int	--定义需要统计的批次总数



	select @count = count(1) from @batchtable



	declare @counter int = 1	--定义计数器







	--定义变量



	declare @batchid int					--批次ID



	declare	@batchcode varchar(36)			--批次编号



	declare	@sendtype tinyint				--发放方式  1:短码  2:链接



	declare	@batchname varchar(50)			--优惠券名称



	declare	@byjcode varchar(50)			--备用金单号



	declare	@usetimesperuser int			--短码：单用户最大使用次数，链接：单用户最大领取次数



	declare	@usetimespercoupon int			--单券码最大可使用次数



	declare	@usetimestotal int				--批次可使用总次数



	declare	@validitytype tinyint			--有效期类型 0：绝对有效期 1：相对有效期



	declare	@validstarttime datetime		--有效开始时间



	declare	@validendtime datetime			--有效结束时间



	declare	@facevalue decimal(18,2)		--面额



	declare	@createtime datetime			--优惠券创建时间



	declare @UsedTimes int					--已使用次数



	declare @RecyclableTimes int			--可回收次数







	--开始循环统计



	while(@counter <= @count)



	begin



		begin try



		select @batchid = batchid,



			@batchcode = batchcode, 



			@sendtype = sendtype,



			@batchname = isnull(batchname, ''),



			@byjcode = byjcode,



			@usetimesperuser = usetimesperuser,



			@usetimespercoupon = usetimespercoupon,



			@usetimestotal = usetimestotal,



			@validitytype = validitytype,



			@validstarttime = isnull(validstarttime, '1900-1-1'),



			@validendtime = isnull(validendtime, '1900-1-1'),



			@facevalue = facevalue,



			@createtime = createtime



		from @batchtable where autoid = @counter



		set @counter += 1



		--短码



		if(@sendtype = 1)



		begin



			select @UsedTimes = isnull(sum(@usetimesperuser - iCouponUsedCount),0) from Ymt_CouponPublicUsed with(nolock) where iBatchId = @batchid



		end



		else if(@sendtype = 2)--链接



		begin



			select @UsedTimes = isnull(sum(@usetimespercoupon - iCouponUsedCount),0) from Ymt_CouponPrivateUserBound with(nolock) where iBatchId = @batchid



		end



		else



		begin



			print('batchid:' + convert(varchar, @batchid) + ' sendtype:' + convert(varchar, @sendtype))



			continue;



		end







		set @RecyclableTimes = @usetimestotal - @UsedTimes







		insert into ymt_couponfundstat 



			(ByjCode, BatchCode, BatchCreateTime, BatchName, ValidityType, ValidStartTime, ValidEndTime, FaceValue, UseableTotalTimes, UsedTimes, RecyclableTimes)



		values



			(@byjcode, @batchcode, @createtime, @batchname, @validitytype, @validstarttime, @validendtime, @facevalue, @usetimestotal, @UsedTimes, @RecyclableTimes)



		end try



		begin catch



			print('batchid:' + convert(varchar, @batchid) + ' 错误信息：' + ERROR_MESSAGE())



		end catch



	end



	



END
