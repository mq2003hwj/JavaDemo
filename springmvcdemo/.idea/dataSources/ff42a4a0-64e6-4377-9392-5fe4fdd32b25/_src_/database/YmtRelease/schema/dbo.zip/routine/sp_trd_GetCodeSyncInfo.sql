-- =============================================            
-- Author:  fanwei        
-- ALTER date: 2016-4-6
-- Description: 获取编码更新信息       
-- =============================================

CREATE PROCEDURE sp_trd_GetCodeSyncInfo
@name varchar(100),
@version bigint
AS BEGIN

--------------process--------------
declare @enabled bit = 0;

--set statistics time on;set statistics io on;
if exists (select top 1 1 from ymt_thirdpartyrefundconfigs(nolock) where [key]='CodeContentSync' and [Available]=1) begin
	set @enabled = 1
end

select @enabled as [enabled];


if @enabled = 1 begin
	
	select top 1 [Name],[Version],[Content] from Trd_CodeContainer where [Name] = @name and [Version] > @version and [Available] = 1 order by [Version] desc

end
--set statistics time off;set statistics io off;--set statistics profile off;

END;
