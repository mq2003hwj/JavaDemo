

create proc [dbo].[csp_GetRefundJobs]
(
	@MachineName varchar(64),
	@MaxRetryCount int=3,
	@MaxJobsPerDuration int=100,
	@MaxDayRange int=30
)
as
begin
	set rowcount @MaxJobsPerDuration
	update dbo.RefundProcessInfo
		set ProcessMachineName=@MachineName
				where CreatedTime>DATEADD(day,-@MaxDayRange,getdate())
					and RetryCount<@MaxRetryCount
					and (ProcessMachineName is null or ProcessMachineName=@MachineName)
					and ProcessStatus in (-1,0,2)					

	select a.*,b.PayType,b.RefundAmount,b.CurrencyType,b.OrderId from dbo.RefundProcessInfo a inner join dbo.RefundRequest b on a.RefundRequestId=b.RefundRequestId
		where a.CreatedTime>DATEADD(day,-@MaxDayRange,getdate())
			and a.RetryCount<@MaxRetryCount
			and  a.ProcessMachineName=@MachineName
			and a.ProcessStatus in (-1,0,2)
			and b.SoftDeleteFlag=0
end

