-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[TEMP_PRODUCTUPDATE]
ON [dbo].[Ymt_Products]
AFTER INSERT, UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @PID VARCHAR(50)
    -- Insert statements for trigger here
	select @PID = p.sproductid from inserted p inner join Ymt_Catalogs c with(nolock) on p.sproductid = c.sProductId
	where p.iaction = 0 and c.iaction = 0 and c.inum > 0 and c.fQuotePrice < 80 and getdate() between validStart and validEnd
	group by p.sProductId

	if @PID is not null begin
		update ymt_products set validEnd = getdate() where sProductId = @PID
	end
END
