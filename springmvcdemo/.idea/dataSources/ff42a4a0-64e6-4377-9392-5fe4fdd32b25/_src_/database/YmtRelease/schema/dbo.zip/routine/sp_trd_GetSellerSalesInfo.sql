-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-12-21
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSellerSalesInfo]

@sellerId int,
@date datetime = NULL

AS

if @date is null set @date = getdate();

SET DATEFIRST 1
declare @today datetime = DATEADD(day, DATEDIFF(day,0,@date),0)
declare @yesterday datetime = DATEADD(day, DATEDIFF(day,0,@today-1), 0)
declare @tomorrow datetime = DATEADD(day,1,@today)
declare @week datetime = DATEADD(day, DATEDIFF(day,0,@today-(DATEPART(weekday, @today)-1)),0)
declare @month datetime = DATEADD(month, DATEDIFF(month,0,@today),0)

--set statistics io on;set statistics time on;
-------------------------------------------------------销售额
--昨天
select 'yesterday' as TimeSpan,
sum(IIF(o.bShangouOrder = 0,IIF(o.iCouponChannel=2,o.fOrderPrice-CouponValue,o.fOrderPrice),0)) Spot,
sum(IIF(o.bShangouOrder = 1,IIF(o.iCouponChannel=2,o.fTotalPrice-CouponValue,o.fTotalPrice),0)) Shangou,
sum(IIF(o.iCouponChannel = 2,CouponValue,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
where o.iBuyerId = @sellerId and o.dAddTime >= @yesterday and o.dAddTime < @today and o.iTradingStatus not in (12,13,18)
union all--今天
select  'today' as TimeSpan,
sum(IIF(o.bShangouOrder = 0,IIF(o.iCouponChannel=2,o.fOrderPrice-CouponValue,o.fOrderPrice),0)) Spot,
sum(IIF(o.bShangouOrder = 1,IIF(o.iCouponChannel=2,o.fTotalPrice-CouponValue,o.fTotalPrice),0)) Shangou,
sum(IIF(o.iCouponChannel = 2,CouponValue,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
where o.iBuyerId = @sellerId and o.dAddTime >= @today and o.dAddTime < @tomorrow and o.iTradingStatus not in (12,13,18)
union all--本周
select 'week' as TimeSpan,
sum(IIF(o.bShangouOrder = 0,IIF(o.iCouponChannel=2,o.fOrderPrice-CouponValue,o.fOrderPrice),0)) Spot,
sum(IIF(o.bShangouOrder = 1,IIF(o.iCouponChannel=2,o.fTotalPrice-CouponValue,o.fTotalPrice),0)) Shangou,
sum(IIF(o.iCouponChannel = 2,CouponValue,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
where o.iBuyerId = @sellerId and o.dAddTime >= @week and o.dAddTime < @tomorrow and o.iTradingStatus not in (12,13,18)
union all--本月
select 'month' as TimeSpan, 
sum(IIF(o.bShangouOrder = 0,IIF(o.iCouponChannel=2,o.fOrderPrice-CouponValue,o.fOrderPrice),0)) Spot,
sum(IIF(o.bShangouOrder = 1,IIF(o.iCouponChannel=2,o.fTotalPrice-CouponValue,o.fTotalPrice),0)) Shangou,
sum(IIF(o.iCouponChannel = 2,CouponValue,0)) SellerCoupon
from ymt_orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
where o.iBuyerId = @sellerId and o.dAddTime >= @month and o.dAddTime < @tomorrow and o.iTradingStatus not in (12,13,18)

-------------------------------------------------------成交额

select 'yesterday' as TimeSpan,
sum(IIF(o.bShangouOrder = 0,s.fPaidAmountOfCash + s.fPaidAmountOfGift + s.fPaidAmountOfFreeCard+IIF(o.iCouponChannel=2,0,s.fPaidAmountOfCoupon)-(s.fRefundedAmountOfCash + s.fRefundedAmountOfGift + s.fRefundedAmountOfCoupon),0)) Spot,
sum(IIF(o.bShangouOrder = 1,s.fPaidAmountOfCash + s.fPaidAmountOfGift + s.fPaidAmountOfFreeCard+IIF(o.iCouponChannel=2,0,s.fPaidAmountOfCoupon)+ s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift -(s.fRefundedAmountOfCash + s.fRefundedAmountOfGift + s.fRefundedAmountOfCoupon),0)) Shangou,
sum(IIF(o.iCouponChannel = 2,o.CouponValue,0)) SellerCoupon
from Ymt_Orders o with(nolock, index=idx_Ymt_Orders_iBuyerId_dConfirmedTime)
join Ymt_OrderState s on o.iOrderId = s.iOrderId
where o.iBuyerId = @sellerId and o.iTradingStatus = 4 and o.dConfirmedTime >= @yesterday and o.dConfirmedTime < @today

union all
select 'today' as TimeSpan,
sum(IIF(o.bShangouOrder = 0,s.fPaidAmountOfCash + s.fPaidAmountOfGift + s.fPaidAmountOfFreeCard+IIF(o.iCouponChannel=2,0,s.fPaidAmountOfCoupon)-(s.fRefundedAmountOfCash + s.fRefundedAmountOfGift + s.fRefundedAmountOfCoupon),0)) Spot,
sum(IIF(o.bShangouOrder = 1,s.fPaidAmountOfCash + s.fPaidAmountOfGift + s.fPaidAmountOfFreeCard+IIF(o.iCouponChannel=2,0,s.fPaidAmountOfCoupon)+ s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift -(s.fRefundedAmountOfCash + s.fRefundedAmountOfGift + s.fRefundedAmountOfCoupon),0)) Shangou,
sum(IIF(o.iCouponChannel = 2,o.CouponValue,0)) SellerCoupon
from Ymt_Orders o with(nolock, index=idx_Ymt_Orders_iBuyerId_dConfirmedTime)
join Ymt_OrderState s on o.iOrderId = s.iOrderId
where o.iBuyerId = @sellerId and o.iTradingStatus = 4 and o.dConfirmedTime >= @today and o.dConfirmedTime < @tomorrow

union all
select 'week' as TimeSpan,
sum(IIF(o.bShangouOrder = 0,s.fPaidAmountOfCash + s.fPaidAmountOfGift + s.fPaidAmountOfFreeCard+IIF(o.iCouponChannel=2,0,s.fPaidAmountOfCoupon)-(s.fRefundedAmountOfCash + s.fRefundedAmountOfGift + s.fRefundedAmountOfCoupon),0)) Spot,
sum(IIF(o.bShangouOrder = 1,s.fPaidAmountOfCash + s.fPaidAmountOfGift + s.fPaidAmountOfFreeCard+IIF(o.iCouponChannel=2,0,s.fPaidAmountOfCoupon)+ s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift -(s.fRefundedAmountOfCash + s.fRefundedAmountOfGift + s.fRefundedAmountOfCoupon),0)) Shangou,
sum(IIF(o.iCouponChannel = 2,o.CouponValue,0)) SellerCoupon
from Ymt_Orders o with(nolock, index=idx_Ymt_Orders_iBuyerId_dConfirmedTime)
join Ymt_OrderState s on o.iOrderId = s.iOrderId
where o.iBuyerId = @sellerId and o.iTradingStatus = 4 and o.dConfirmedTime >= @week and o.dConfirmedTime < @tomorrow

union all
select 'month' as timespan,
sum(IIF(o.bShangouOrder = 0,s.fPaidAmountOfCash + s.fPaidAmountOfGift + s.fPaidAmountOfFreeCard+IIF(o.iCouponChannel=2,0,s.fPaidAmountOfCoupon)-(s.fRefundedAmountOfCash + s.fRefundedAmountOfGift + s.fRefundedAmountOfCoupon),0)) Spot,
sum(IIF(o.bShangouOrder = 1,s.fPaidAmountOfCash + s.fPaidAmountOfGift + s.fPaidAmountOfFreeCard+IIF(o.iCouponChannel=2,0,s.fPaidAmountOfCoupon)+ s.fPostPaidAmountOfCash + s.fPostPaidAmountOfGift -(s.fRefundedAmountOfCash + s.fRefundedAmountOfGift + s.fRefundedAmountOfCoupon),0)) Shangou,
sum(IIF(o.iCouponChannel = 2,o.CouponValue,0)) SellerCoupon
from Ymt_Orders o with(nolock, index=idx_Ymt_Orders_iBuyerId_dConfirmedTime)
join Ymt_OrderState s on o.iOrderId = s.iOrderId
where o.iBuyerId = @sellerId and o.iTradingStatus = 4 and o.dConfirmedTime >= @month and o.dConfirmedTime < @tomorrow

--set statistics io off;set statistics time off;