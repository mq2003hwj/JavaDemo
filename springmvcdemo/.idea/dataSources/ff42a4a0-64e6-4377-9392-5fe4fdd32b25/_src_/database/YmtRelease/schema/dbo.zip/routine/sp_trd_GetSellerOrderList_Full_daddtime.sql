


-- =============================================            
-- Author:  CL        
-- ALTER date: 2015-12-03
-- Description: 交易服务SP       
-- =============================================

CREATE PROCEDURE sp_trd_GetSellerOrderList_Full_daddtime

@sellerId int,
@orderType int,
@sortType int,
@timeType int,
@timeoutType int,
@beginTime  datetime,
@endTime datetime,
@timeoutBegin datetime,
@timeoutEnd datetime,
@shangou bit,
@orderStatusXml xml,
@catalogStatusXml xml,
@paidInFull bit,
@keyword varchar(200),
@rowFrom int,
@rowTo int,
@considerOrderStatus bit,
@considerRCOrderEstablish bit,
@considerRCAccountPaid bit,
@considerRestOrderStatus bit,
@salesRefundOrderOnly bit = 0,
@domesticDelivered bit = null

AS BEGIN

-------------variables-------------
declare @orderIds1 table(id int not null, num int not null)
declare @orderIds table(id int not null, num int not null)
declare @orderStatus table(value int primary key);
declare @catalogStatus table(value int primary key);
declare @orderToBills table(iOrderId int not null, sBillId varchar(36) not null)
declare @orderTradingIds table(orderId int not null, tradingId int not null, virtualTime datetime not null)

declare @totalCount int = 0
declare @rowsCount int = 0

--------------process--------------
if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

if @catalogStatusXml is not null
begin
    insert into @catalogStatus 
    select tbl.col.value('@s','int')
    from @catalogStatusXml.nodes('/root/x') tbl(col)
end

--set statistics time on;set statistics io on;

set nocount off;
;with t as (
select distinct o.iOrderId as id,
case @sortType 
when 0 then o.dAddTime
when 1 then isnull(o.dConfirmedTime,o.dAddTime)
when 2 then isnull(o.dPostPaidTime,o.dAcceptTime)
when 3 then isnull(o.dAcceptTime,o.dAddTime)
when 4 then isnull(o.dDispathTime,o.dAddTime)
when 5 then isnull(o.dApplyPostPayTime,o.dAddTime)
when 6 then isnull(o.dConfirmedTime,o.dAddTime)
when 7 then isnull(o.dPaidTime,o.dAddTime)
else o.dAddTime end as [time]
from Ymt_Orders o with (nolock,index = idx_Ymt_Orders_iBuyerId_dAddTime)
inner loop join Ymt_OrderInfo(nolock) i on o.iOrderId = i.iOrderId
where o.iBuyerId = @sellerId
and o.dAddTime between @beginTime and @endTime
--and (
--@timeType = 0
--or @timeType = 1 and o.dAddTime between @beginTime and @endTime
--or @timeType = 2 and o.dPaidTime between @beginTime and @endTime
--or @timeType = 3 and o.dDispathTime between @beginTime and @endTime
--or @timeType = 4 and o.dApplyPostPayTime between @beginTime and @endTime
--)
and 
(
@orderType = 0
or @orderType = 1 and o.bShangouOrder = @shangou
or @orderType = 2 and o.bShangouOrder = 0
or @orderType = 3 and o.bShangouOrder = 1
or @orderType = 4 and i.sCatalogId is not null
or @orderType = 5 and (o.bShangouOrder = 1 or (o.bShangouOrder = 0 and i.sCatalogId is null))
or @orderType = 6 and (o.bShangouOrder = 0 and i.sCatalogId is not null)
or @orderType = 7 and (o.bShangouOrder = 0 and i.sCatalogId is null)
)
and
(
  @considerOrderStatus = 0 or
  (
    (@considerRCOrderEstablish = 1 and (o.iTradingStatus = 1 or o.iTradingStatus = 2 and o.iRiskVerifiedStatus = 1))
    or
    (@considerRCAccountPaid = 1 and (o.iTradingStatus = 2 and (o.iRiskVerifiedStatus is null or o.iRiskVerifiedStatus = 2)))
    or
    (@considerRestOrderStatus = 1 and o.iTradingStatus in (select [value] from @orderStatus))
  )
)
and (@paidInFull is null or o.bPaidInFull = @paidInFull)
and (
@timeoutType = 0
or @timeoutType = 1 and (o.dPaidTime > @timeoutBegin and o.dPaidTime <= @timeoutEnd and o.iTradingStatus = 2)
or @timeoutType = 2 and (o.dPaidTime <= @timeoutEnd and o.iTradingStatus = 2)
or @timeoutType = 3 and (o.dAcceptTime > @timeoutBegin and o.dPaidTime <= @timeoutEnd and o.iTradingStatus = 17 and o.bPaidInFull = 0)
or @timeoutType = 4 and (o.dAcceptTime <= @timeoutEnd and o.iTradingStatus = 17 and o.bPaidInFull = 0 )
or @timeoutType = 5 and (isnull(o.dPostPaidTime,o.dPaidTime) > @timeoutBegin and isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd and o.iTradingStatus = 17 and o.bPaidInFull = 1)
or @timeoutType = 6 and (isnull(o.dPostPaidTime,o.dPaidTime) <= @timeoutEnd and o.iTradingStatus = 17 and o.bPaidInFull = 1)
)
and(@catalogStatusXml is null or i.iCatalogStatus in (select value from @catalogStatus))
and (@domesticDelivered is null or isnull(o.bDomesticDelivered, 0) = @domesticDelivered)
and (@keyword is null or (o.iOrderId like @keyword or o.sBuyerLoginId like @keyword or i.sTitle like @keyword))
and (@salesRefundOrderOnly = 0 or o.iSalesRefundStatus is not null)
)
insert into @orderIds1 select id, row_number() over(order by [time] desc) as rowIndex from t;

--获取订单总数量 
set @totalCount = @@ROWCOUNT

--delete from @orderIds where num not between @rowFrom and @rowTo;
Insert into @orderIds
select * from  @orderIds1 where num between @rowFrom and @rowTo;

set @rowsCount = @@ROWCOUNT

set nocount on;

select @totalCount;

select *,(select top 1 RefundAmount from ymt_refundbill(nolock) where orderid=o.iorderid) as TotalSalesRefundAmount from Ymt_Orders(nolock) o join @orderIds t on o.iOrderId = t.id where @rowsCount > 0 order by t.num asc option(recompile)

--获取评价列表  
select * from Ymt_CreditDetail(nolock) where @rowsCount > 0 and stargetid in (select cast(id as varchar(36)) from @orderIds) 

--获取备注列表  
select iOrderId,sContent from Ymt_O_OrderNote(nolock) where @rowsCount > 0 and iuserid = @sellerId and iorderid in (select id from @orderIds)  

--获取订单金额详情列表
select * from Ymt_OrderState(nolock) where @rowsCount > 0 and iorderid in (select id from @orderIds)

--获取订单补款列表  
select * from Ymt_OrderPostPay(nolock) where @rowsCount > 0  and iorderid in (select id from @orderIds)

--获取订单商品详情列表
select
i.iOrderId,i.sOrderInfoId,i.fOriginalPrice,i.iPriceType,i.iAmount,i.iBondedArea,i.iCatalogStatus,i.iCatalogType,i.iProductSubCategoryId,i.iSailProtected,i.iType,i.sCatalogId,i.sDescription,i.sPictureUrl,i.sProductId,i.sPropertyInfo,i.sReferenceUrl,i.sSKU
,i.sTitle 
,e.sOrderInfoId as sOrderInfoExtId,e.bGiftAvail4Reward,e.iActivityId,e.iActivityTemplateId
from Ymt_OrderInfo i(nolock) 
left join Ymt_OrderInfoExt(nolock) e
on i.sOrderInfoId = e.sOrderInfoId
where @rowsCount > 0 and i.iOrderId in (select id from @orderIds)

--获取订单物流信息  
select iOrderId, iBillType, sSummary from Ymt_OrderSummary(nolock) where @rowsCount > 0 and iorderid in (select id from @orderIds)

--获取订单冻结信息  
select * from Ymt_Order_Frozen(nolock) where @rowsCount > 0 and iorderid in (select id from @orderIds)  

--获取订单账单信息
insert into @orderToBills select iOrderid, sBillId from Ymt_OrderToBill(nolock) where @rowsCount > 0 and iorderid in (select id from @orderIds) and iaction >= 0
select iOrderid, sBillId from @orderToBills where @rowsCount > 0;

--print 'ymt_bill'
--获取订单账单信息  
select * from Ymt_Bill(nolock) where @rowsCount > 0 and sbillid in (select sBillId from @orderToBills) and iaction >= 0

--print 'orderTradingId'
--订单有效的交易ID  
if @rowsCount > 0 begin
  insert into @orderTradingIds select iOrderId, iTradingId, dUpdateTime from Ymt_TradingItem(nolock) where iOrderId in (select id from @orderIds)
  update @orderTradingIds set virtualTime = '9999-1-1' where tradingId in (select iTradingId from Ymt_TradingInfo(nolock) where iTradingId in (select tradingId from @orderTradingIds) and iTradingStatus = 2)
  ;with t as(
    select ROW_NUMBER() over(partition by orderId order by virtualTime desc) as n, orderId, tradingId from @orderTradingIds
  ) 
  select orderId as iOrderId, tradingId as iTradingId from t where n = 1 order by orderId;
end else begin
  select top 0 0 as iOrderId, 0 as iTradingId;
end

select iOrderId,bIsNeedUploadIdCard,bHaveUploadedIdCard from ymt_orderext(nolock) where iorderid in (select id from @orderIds)

set nocount off;

--set statistics time off;set statistics io off;--set statistics profile off;

--print datediff(ms,@t1,getdate())

END;

