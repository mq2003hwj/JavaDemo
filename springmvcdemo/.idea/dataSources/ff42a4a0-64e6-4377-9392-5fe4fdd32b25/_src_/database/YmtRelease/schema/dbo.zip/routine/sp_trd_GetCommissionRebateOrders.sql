
-- =============================================            
-- Author:  fanwei        
-- CREATE date: 2016-7-14
-- Description: 获取带返佣订单信息       
-- =============================================
CREATE PROCEDURE sp_trd_GetCommissionRebateOrders
@count int,
@pageKey varchar(500),
@timefrom datetime,
@timeTo datetime
AS BEGIN

--------------process--------------

--set statistics time on;set statistics io on;
declare @orders table([index] int identity(1,1) primary key, [time] datetime, orderId int)

if @pageKey is null or len(@pageKey) < 1 begin

	insert into @orders([time],[orderId])
	select top (@count+1) SettlementTime,OrderId 
	from Ymt_SettlementInvoice with(nolock,index=IX_BusinessType_SettlementStatus_SettlementTime_OrderId)
	where BusinessType = 4 and SettlementStatus = 1
	and SettlementTime >= @timeFrom and SettlementTime < @timeTo
	order by SettlementTime asc, OrderId asc

end else begin
	declare @index int = charindex('|', @pageKey)
	declare @timeline datetime = cast(SUBSTRING(@pageKey,1,@index-1) as datetime)
	declare @orderId int = cast(SUBSTRING(@pageKey,@index+1,500) as int)

	insert into @orders([time],[orderId])
	select top (@count+1) SettlementTime,OrderId 
	from Ymt_SettlementInvoice with(nolock,index=IX_BusinessType_SettlementStatus_SettlementTime_OrderId)
	where BusinessType = 4 and SettlementStatus = 1
	and SettlementTime >= @timeline and SettlementTime < @timeTo
	and OrderId > @orderId
	order by SettlementTime asc, OrderId asc

end

declare @n int = @@ROWCOUNT;

if @n < 1 return;

if @n > @count begin
	delete @orders where [index]=(select max([index]) from @orders)
	select top 1 convert(varchar,[time],121)+'|'+cast(orderId as varchar) from @orders order by [index] desc
end else begin
	select '';
end

select 
 o.iOrderId as OrderId
,o.iUserId as BuyerId
,o.iBuyerId as SellerId
,o.fSellerCouponAmount as SellerCouponAmount
,isnull(o.dPostPaidTime,o.dPaidTime) as PaidTime
,isnull(s.fPaidAmountOfCash, 0) + isnull(s.fPostPaidAmountOfCash, 0) as TotalPaidCash
,f.OrderId as BuyerSellerFirstOrderId
,f.PaidTime as BuyerSellerFirstOrderPaidTime
,(select SettlementTime from Ymt_SettlementInvoice with(nolock,index=AK_SI_BusinessNo_BusinessType) where BusinessNo = cast(o.iOrderId as varchar(50)) and BusinessType = 4 and SettlementStatus = 1) as CommissionDeductedTime
from 
@orders o2 inner loop join 
Ymt_Orders o with(nolock,index=PK_Ymt_Orders)
on o.iOrderId = o2.orderId
left join Ymt_OrderState(nolock) s on o.iOrderId = s.iOrderId
outer apply (
	select top 1 iOrderId as OrderId, isnull(dPostPaidTime,dPaidTime) as PaidTime from Ymt_Orders with(nolock,index=IX_iBuyerId_iUserId_dPaidTime) 
	where iUserId = o.iUserId and iBuyerId = o.iBuyerId
	and dPaidTime is not null
	order by dPaidTime asc
) f
--where o.iOrderId in (select orderId from @orders)


--获取订单商品详情列表
select 
 i.iOrderId as OrderId
,i.sCatalogId as CatalogId
,i.sProductId as ProductId
,i.iAmount as ProductCount
,i.fOriginalPrice as ProductOriginalPrice
,i.iPriceType as PriceType
,i.iProductMainCategoryId as Category1
,i.iProductSubCategoryId as Category2
,i.iProductThirdCategoryId as Category3

,p.RefundBillNo as ProductRefundedBillNo
,p.RefundProductNum as ProductRefundedCount
,p.SalesRefundStatus as ProductRefundedStatus
,d.RealPayAmountPerProd as ProductPrice
,d.SingleCommissionRate as CommissionRate
,d.StrategyId as CommissionId
,d.CommissionAmount as CommissionAmount
,IIF(d2.Id is null, 0 , 1) as CommissionRefunded
,d2.CommissionAmount as CommissionRefundedAmount

from 
@orders o2 inner loop join 
Ymt_OrderInfo i with(nolock,ForceSeek)
on i.iOrderId = o2.orderId
left join Ymt_CommissionDetail d with(nolock)--扣佣
on i.sOrderInfoId = d.OrderInfoId and d.InvoiceType = 4
left join Ymt_CommissionDetail d2 with(nolock)--退佣
on i.sOrderInfoId = d.OrderInfoId and d2.InvoiceType = 5
outer apply(
	select top 1 a.RefundBillNo,a.RefundProductNum,b.SalesRefundStatus from Ymt_RefundProduct a with(nolock)
	join Ymt_RefundBill b with(nolock) on a.RefundBillNo = b.RefundBillNo
	where a.OrderInfoId = i.sOrderInfoId
	order by a.AddTime desc
) p
--where i.iOrderId in (select orderId from @orders)

--set statistics time off;set statistics io off;--set statistics profile off;

END;
