

-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-8-13
-- Description: 交易服务SP       
-- =============================================

CREATE PROCEDURE [dbo].[sp_trd_GetExportProductInfo]

@sellerId int,
@orderType int,
@timeType int,
@beginTime  datetime,
@endTime datetime,
@paidInFull bit,
@orderStatusXml xml,
@keyword varchar(200)

AS BEGIN

-------------variables-------------
declare @orderIds table(id int primary key clustered);
declare @orderStatus table(value int primary key);

declare @rowCount int = 0;

--------------process--------------
if @orderStatusXml is not null
begin
    insert into @orderStatus 
    select tbl.col.value('@s','int')
    from @orderStatusXml.nodes('/root/x') tbl(col)
end

--set statistics time on;set statistics io on;

set nocount off;

insert into @orderIds select distinct o.iOrderId
from ymt_orders(nolock) o 
join ymt_orderinfo(nolock) i on o.iorderid = i.iorderid
where iBuyerId = @sellerId
and (@timeType = 0
or @timeType = 1 and o.dAddTime between @beginTime and @endTime
or @timeType = 2 and o.dPaidTime between @beginTime and @endTime
or @timeType = 3 and o.dDispathTime between @beginTime and @endTime
or @timeType = 4 and o.dApplyPostPayTime between @beginTime and @endTime
)
and (@orderStatusXml is null
or (@paidInFull is not null and iTradingStatus = 17 and bPaidInFull = @paidInFull
	or iTradingStatus in (select value from @orderStatus)
	)
)
and (@orderType = 0
or @orderType = 1 and (o.bShangouOrder = 1 or i.sCatalogId is not null)
or @orderType = 2 and o.bShangouOrder = 0
or @orderType = 3 and (o.bShangouOrder = 1 or i.sCatalogId is null)
or @orderType = 4 and (o.bShangouOrder = 0 or i.sCatalogId is not null)
or @orderType = 5 and o.bShangouOrder = 1
or @orderType = 6 and i.sCatalogId is null
)
and (@keyword is null
or (o.iOrderId like @keyword or i.sSKU like @keyword or i.sTitle like @keyword)
)

set @rowCount = @@ROWCOUNT;

set nocount on;

select iOrderId,fFreight,fOrderPrice,iTradingStatus,bPaidInFull,dAddTime,dPaidTime,dApplyPostPayTime,sLeaveWord,sBuyerLoginId,sReceivePerson,sPhone,sTelephone,sAddress,sPostCode,bShangouOrder
from ymt_orders(nolock) where @rowCount > 0 and iOrderId in (select id from @orderIds)

select iOrderId,sTitle,iAmount,fOriginalPrice,sSKU,sPropertyInfo,case when sCatalogId is null then null else '1' end as [sCatalogId] 
from Ymt_OrderInfo(nolock)
where @rowCount > 0 and iOrderId in (select id from @orderIds)

select iOrderId,sContent from Ymt_O_OrderNote(nolock) where @rowCount > 0 and iuserid = @sellerId and iorderid in (select id from @orderids)  

select * from Ymt_OrderState(nolock) where @rowCount > 0 and iorderid in (select id from @orderids)

set nocount off;
--set statistics time off;set statistics io off;
--print datediff(ms,@t1,getdate())
END;

