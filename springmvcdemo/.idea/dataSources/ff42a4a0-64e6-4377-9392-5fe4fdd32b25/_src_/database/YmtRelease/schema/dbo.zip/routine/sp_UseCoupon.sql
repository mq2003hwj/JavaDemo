

-- =============================================            
-- Author:  gejianhua        
-- Create date: 2017-2-28
-- Description: 创建订单使用优惠券
-- =============================================     

CREATE PROC [dbo].[sp_UseCoupon]
	@CouponCode varchar(36),		--优惠券编号
	@UserId int,					--用户ID
	@CouponType int,				--废弃，现都是私有券
	@mainOrderId int = null			--主订单ID
AS

DECLARE @RetCode int = 0
declare @remainTimes int = 0
declare @batchId int

SELECT @batchId = iBatchId, @remainTimes = iCouponUsedCount FROM Ymt_CouponPrivateUserBound WITH(NOLOCK,index  = IX_Ymt_CouponPrivateUserBound_sCouponCode) 
WHERE sCouponCode=@CouponCode AND iUserId=@UserId

if(@batchId is null)
begin
	SET @RetCode = -102  --用户优惠券不存在
	GOTO exit_flag
end

if(@remainTimes <= 0)
begin
	SET @RetCode = -101  --使用次数超过上限
	GOTO exit_flag
end

UPDATE a SET iCouponUsedCount=iCouponUsedCount-1 from Ymt_CouponPrivateUserBound a with (index  = IX_Ymt_CouponPrivateUserBound_sCouponCode) 
WHERE sCouponCode=@CouponCode AND iUserId=@UserId and iCouponUsedCount > 0
		
if(@@ROWCOUNT = 0)
begin
	SET @RetCode = -101  --使用次数超过上限
	GOTO exit_flag
end

--如果是虚拟券则要更新其使用状态
if(exists(select null from Ymt_CouponVirtualRelation with(nolock) where CouponCode = @CouponCode))
begin
	update Ymt_CouponVirtualRelation set IsUsed = 1 where CouponCode = @CouponCode
end

--插入使用记录
if(@mainOrderId is not null)
begin
	insert into ymt_CouponTradeRecord(OrderId, UserId, CouponCode, BatchId, TradeType)values(@mainOrderId, @UserId, @CouponCode, @batchId, 1)
end
else
begin
	--更新批次剩余使用次数
	UPDATE Ymt_CouponSetting SET iMaxUseTime=iMaxUseTime-1 
			WHERE iCouponSettingId IN (SELECT iCouponSetting FROM Ymt_Coupon WITH(NOLOCK) WHERE sCouponCode=@CouponCode) 
end


exit_flag:
    SELECT  @RetCode AS RetCode




