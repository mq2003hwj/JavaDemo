

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetMessageList]
	@see int,
	@from int,
	@to int,
	@timeline datetime,
	@count int,
	@isnew int
AS
BEGIN
 
  if(@isnew = 0)
	BEGIN
		;WITH Cte1 AS (
			 SELECT TOP(@count) iMsgFromId AS MsgFromId ,iMsgToId AS MsgToId ,sMessage AS [Message]
				  ,sMessageId AS MessageId ,dPostTime AS PostTime
				  ,RSee ,SSee ,sMsgFrom AS MsgFrom ,sMsgTo AS MsgTo
				FROM Ymt_Message 
				WHERE iFromUserType<> 10 AND ((SSee = @see AND iMsgFromId = @from AND iMsgToId = @to)  ) AND dPostTime < @timeline
				ORDER BY  dPostTime DESC 
			)     
		,Cte2 AS (    
			  SELECT TOP(@count) iMsgFromId AS MsgFromId ,iMsgToId AS MsgToId ,sMessage AS [Message]
			  ,sMessageId AS MessageId  ,dPostTime AS PostTime
			  ,RSee  ,SSee ,sMsgFrom AS MsgFrom  ,sMsgTo AS MsgTo
			FROM Ymt_Message 
			WHERE iFromUserType<> 10 AND (  (RSee = @see AND iMsgFromId = @to AND iMsgToId = @from)) AND dPostTime < @timeline
			ORDER BY  dPostTime DESC 
		)
		,Cte3 AS (
			SELECT * FROM cte1
			UNION 
			SELECT * FROM cte2
			)
		,Cte4 as (
			SELECT *, ROW_NUMBER() OVER(ORDER BY PostTime DESC ) AS rn 
			FROM cte3
			)
		SELECT MsgFromId,MsgToId,[Message],MessageId,PostTime,RSee,SSee,MsgFrom,MsgTo
		FROM cte4
		WHERE rn <= @count 
		ORDER BY rn  
				  
		--SELECT MsgFromId,MsgToId,[Message],MessageId,PostTime,RSee,SSee,MsgFrom,MsgTo FROM(
		--  SELECT ROW_NUMBER() OVER(ORDER BY dPostTime) AS rn
		--  ,iMsgFromId AS MsgFromId
		--  ,iMsgToId AS MsgToId
		--  ,sMessage AS [Message]
		--  ,sMessageId AS MessageId
		--  ,dPostTime AS PostTime
		--  ,RSee
		--  ,SSee
		--  ,sMsgFrom AS MsgFrom
		--  ,sMsgTo AS MsgTo
		--FROM Ymt_Message(NOLOCK)
		--WHERE iFromUserType<> 10 AND ((SSee = @see AND iMsgFromId = @from AND iMsgToId = @to) OR (RSee = @see AND iMsgFromId = @to AND iMsgToId = @from)) AND dPostTime < @timeline) t
		--WHERE rn <= @count ORDER BY rn DESC

	end
	else
	begin
		;WITH Cte1 AS (
			 SELECT TOP(@count) iMsgFromId AS MsgFromId ,iMsgToId AS MsgToId ,sMessage AS [Message]
				  ,sMessageId AS MessageId ,dPostTime AS PostTime
				  ,RSee ,SSee ,sMsgFrom AS MsgFrom ,sMsgTo AS MsgTo
				FROM Ymt_Message 
				WHERE iFromUserType<> 10 AND ((SSee = @see AND iMsgFromId = @from AND iMsgToId = @to)  ) AND dPostTime > @timeline
				ORDER BY  dPostTime   
			)     
		,Cte2 AS (    
			  SELECT TOP(@count) iMsgFromId AS MsgFromId ,iMsgToId AS MsgToId ,sMessage AS [Message]
			  ,sMessageId AS MessageId  ,dPostTime AS PostTime
			  ,RSee  ,SSee ,sMsgFrom AS MsgFrom  ,sMsgTo AS MsgTo
			FROM Ymt_Message 
			WHERE iFromUserType<> 10 AND (  (RSee = @see AND iMsgFromId = @to AND iMsgToId = @from)) AND dPostTime > @timeline
			ORDER BY  dPostTime   
		)
		,Cte3 AS (
			SELECT * FROM cte1
			UNION 
			SELECT * FROM cte2
			)
		,Cte4 as (
			SELECT *, ROW_NUMBER() OVER(ORDER BY PostTime  ) AS rn 
			FROM cte3
			)
		SELECT MsgFromId,MsgToId,[Message],MessageId,PostTime,RSee,SSee,MsgFrom,MsgTo
		FROM cte4
		WHERE rn <= @count 
		ORDER BY rn 
		/*
	 	SELECT MsgFromId,MsgToId,[Message],MessageId,PostTime,RSee,SSee,MsgFrom,MsgTo FROM(
		  SELECT ROW_NUMBER() OVER(ORDER BY dPostTime) AS rn
		  ,iMsgFromId AS MsgFromId
		  ,iMsgToId AS MsgToId
		  ,sMessage AS [Message]
		  ,sMessageId AS MessageId
		  ,dPostTime AS PostTime
		  ,RSee
		  ,SSee
		  ,sMsgFrom AS MsgFrom
		  ,sMsgTo AS MsgTo
		FROM Ymt_Message(NOLOCK)
		WHERE iFromUserType<> 10 AND ((SSee = @see AND iMsgFromId = @from AND iMsgToId = @to) OR (RSee = @see AND iMsgFromId = @to AND iMsgToId = @from)) AND dPostTime > @timeline) t
		WHERE rn <= @count ORDER BY rn*/
	end

END

