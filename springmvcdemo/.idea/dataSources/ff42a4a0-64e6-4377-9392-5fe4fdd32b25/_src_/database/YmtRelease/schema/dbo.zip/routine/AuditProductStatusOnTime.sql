--胡果  2015-4-4停用
CREATE PROCEDURE [dbo].[AuditProductStatusOnTime]
AS
BEGIN
	
DECLARE @StartDate DATETIME = '2015-03-27 12:00:00'
DECLARE @AuditProduct TABLE
(
	productId VARCHAR(64)
)
INSERT INTO @AuditProduct
(
	productId
)
SELECT P.sProductId 
FROM Ymt_Products AS P 
INNER JOIN Ymt_ProductsInActivity AS A 
	ON P.sProductId = A.sProductId 
WHERE P.CheckStatus <> 2 
	AND A.dAddTime > @StartDate;


UPDATE P
SET CheckStatus = 2
FROM Ymt_Products AS P
INNER JOIN @AuditProduct AS A
	ON P.sProductId = A.productId;

END
