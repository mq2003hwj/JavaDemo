-- =============================================
-- Author:		jmtek
-- Create date: 2012-12-29
-- Last update: 2013-8-6
-- Modify log:	
--		2013-8-6: 优化查询，同时排除闪购的订单
-- Description:	根据指定的三级分类+品牌统计关联三级分类数据
-- =============================================
CREATE PROCEDURE [dbo].[spUpdateRecommendProductDimension]
	@CategoryId	INT,
	@BrandId	INT
AS
BEGIN
	Delete From Ymt_RecommendProductsDimension Where iThirdCategoryId = @CategoryId and iBrandId = @BrandId

	Insert Into Ymt_RecommendProductsDimension (iThirdCategoryId, iBrandId, iRelatedThirdCategoryId, iUserAmount, iOrderAmount)
	Select @CategoryId, @BrandId, iProductThirdCategoryId, count(distinct o.iUserid), count(distinct o.iorderid) From 
	ymt_orders o with(nolock) inner join ymt_orderinfo oi with(nolock) on o.iorderid = oi.iorderid
	inner join (
		select o.iuserid from 
		ymt_orders o with(nolock) inner join ymt_orderinfo oi with(nolock) on o.iorderid = oi.iorderid
		where o.daddtime > '2012-7-1' and o.itradingstatus not in (1, 12, 13, 18) and o.bShangouOrder <> 1 and
		oi.iProductThirdCategoryId = Case @CategoryId When 0 Then oi.iProductThirdCategoryId Else @CategoryId End and
		oi.iProductBrandId = Case @BrandId When 0 Then oi.iProductBrandId Else @BrandId End
		) t on t.iUserId = o.iUserId
	where o.daddtime > '2012-7-1' and o.itradingstatus not in (1, 12, 13, 18) and o.bShangouOrder <> 1 and o.fOrderPrice > 20 and iProductThirdCategoryId > 0 and
	iProductThirdCategoryId not in (select iCategoryId from Ymt_ProductCategory where sCategory like '%其他%' and iLevel = 3) and
	o.bShangouOrder <> 1
	group by iProductThirdCategoryId
	order by 2 desc, 3 desc	
END
