-- =============================================
-- Author:		adu	
-- Create date: 2013-12-20
-- Description:	获取活动下的产品的评论信息列表
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetProductCommentsByActivityId]
	@ActivityId int,
	@CommentNum int,
	@LastCommentId int
AS
BEGIN	
	SET NOCOUNT ON;
	--SET TRANSACTION ISOLATION LEVEL READ COMMITTED
DECLARE @SQL nvarchar(3250)

SET @SQL = N'SELECT c.iCommentId as CommentId,c.sProductId as ProductId,c.sUserName as UserName,c.iUserId as UserId,c.sUserLogo as UserLogo,c.sContent as Content,c.dAddTime as AddTime,
c.iToUserId as ToUserId,u.sLoginId as ToUserName 
from App_Comment c with(nolock)
inner join Ymt_Users u with(nolock) on c.iToUserId =u.iUserId
inner join Ymt_Products p with(nolock) on p.sProductId = c.sProductId
inner join Ymt_ProductsInActivity pa with(nolock) ON p.sProductId = pa.sProductId  
where pa.iActivityId= ' + CAST(@ActivityId AS VARCHAR(10)) + ' and c.iCommentId<' + CAST(@LastCommentId AS VARCHAR(10)) + ' and c.iAction>-1
 order by c.dAddTime desc'
 
EXEC (@SQL)   
END
