
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROC [spGeneratePostId]
	 
AS
BEGIN
	INSERT INTO Ymt_AutoPostIds DEFAULT VALUES
	
	IF @@ERROR > 0
		Return -1
		
	RETURN SCOPE_IDENTITY() + 200000000
END

