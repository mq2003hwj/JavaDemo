-- =============================================            
-- Author:  zhangzhiqiang Modifyer:cpx          
-- Create date: 2014-8-8  Modify date:2015-1-5   
-- Description: 获取卖家订单列表 Modify Reason:商家后台业务逻辑修改           
-- =============================================      
CREATE PROCEDURE [dbo].[SPGetSellerOrderList]    
 @SellerId INT,   
 @IsShangouOrder BIT,  --是否闪购订单  1-闪购  0-非闪购   
 @BeginTime DATETIME = NULL,  
 @EndTime DATETIME = NULL,  
 @OrderStatusList VARCHAR(100) = NULL,  
 @IsPaidInFull BIT = NULL,  
 @SearchKeyWord VARCHAR(200) = NULL,  
 @LogisticsTypeList VARCHAR(20) = NULL,  
 @OrderTypeList VARCHAR(20) = NULL, --订单类型 0-现货订单 1-扫货订单 2-下单器订单  
 @OrderDateType VARCHAR(20) = NULL, --订单查询日期类型 0-未知 1-下单时间 2-支付时间 3-发货时间 4-申请补款时间
 @PageStart INT,  
 @PageEnd INT,
 @OverTimeList VARCHAR(200) = NULL, --订单超时时间列表 例如：AccountPaid16*20,SellerAccept20*20 AccountPaid表示订单状态 
                                    --16表示即将超时的时间长度 *号后的20表示已超时的时间长度 如果没有*号，则16只表示已超时的时间长度
 @OrderCount INT OUTPUT  
AS    
BEGIN  
    SET NOCOUNT ON  
    SET LOCK_TIMEOUT 3000  
    DECLARE @SearchSql NVARCHAR(1000)  
   ,@NewOrderStatus VARCHAR(100)  
   ,@NewOrderType VARCHAR(100)
   ,@OrderAcceptOverTimeCol VARCHAR(50) = NULL --等待接单超时时间信息
   ,@OrderPostpayOverTimeCol VARCHAR(50) = NULL --等待发起补款超时时间信息
   ,@OrderDispatchOverTimeCol VARCHAR(50) = NULL --等待发货超时时间信息
   ,@OrderAcceptOverTimeSoon VARCHAR(50) = NULL --等待接单即将超时时间
   ,@OrderPostpayOverTimeSoon VARCHAR(50) = NULL --等待发起补款即将超时时间
   ,@OrderDispatchOverTimeSoon VARCHAR(50) = NULL --等待发货即将超时时间
   ,@OrderAcceptOverTime VARCHAR(50) = NULL --等待接单超时时间
   ,@OrderPostpayOverTime VARCHAR(50) = NULL --等待发起补款超时时间
   ,@OrderDispatchOverTime VARCHAR(50) = NULL --等待发货超时时间
   ,@OrderOverTimeCount INT = 0 --超时状态个数    
 CREATE TABLE #AllOrderList (iOrderId INT,RowNum INT)  
  
    SET @SearchSql = 'SELECT o.iOrderId,ROW_NUMBER() OVER('  
    IF @SearchKeyWord IS NULL OR @SearchKeyWord = ''  
    BEGIN  
  IF @OrderStatusList IS NOT NULL AND @OrderStatusList <> ''  
  BEGIN  
   SET @NewOrderStatus = ','+@OrderStatusList+','  
   IF CHARINDEX(',4,',@NewOrderStatus) > 0 OR CHARINDEX(',8,',@NewOrderStatus) > 0   -- 4--确认收货  8-退货完成（以退款给买家）  
   BEGIN  
    SET @SearchSql = @SearchSql + ' ORDER BY ISNULL(o.dConfirmedTime,o.dAddTime) DESC'  
   END  
   ELSE  
   BEGIN  
    IF CHARINDEX(',17,',@NewOrderStatus) > 0 AND @IsPaidInFull IS NOT NULL AND @IsPaidInFull = 1   -- 17--等待发货
    BEGIN  
     SET @SearchSql = @SearchSql + ' ORDER BY ISNULL(dPostPaidTime,o.dAcceptTime) DESC'  
    END  
    ELSE IF CHARINDEX(',17,',@NewOrderStatus) > 0 AND @IsPaidInFull IS NOT NULL AND @IsPaidInFull = 0   -- 17--等待发起补款  
    BEGIN  
     SET @SearchSql = @SearchSql + ' ORDER BY ISNULL(o.dAcceptTime,o.dAddTime) DESC'  
    END  
    ELSE  
    BEGIN  
     IF CHARINDEX(',3,',@NewOrderStatus) > 0   -- 3--已发货  
     BEGIN  
      SET @SearchSql = @SearchSql + ' ORDER BY ISNULL(o.dDispathTime,o.dAddTime) DESC'  
     END
	 ELSE IF CHARINDEX(',16,',@NewOrderStatus) > 0   -- 16--补款中
     BEGIN  
      SET @SearchSql = @SearchSql + ' ORDER BY ISNULL(o.dApplyPostPayTime,o.dAddTime) DESC'  
     END 
     ELSE IF CHARINDEX(',4,',@NewOrderStatus) > 0   -- 4--确认收货  
     BEGIN  
      SET @SearchSql = @SearchSql + ' ORDER BY ISNULL(o.dConfirmedTime,o.dAddTime) DESC'  
     END  
     ELSE IF CHARINDEX(',2,',@NewOrderStatus) > 0   -- 2--已付款  
     BEGIN  
      SET @SearchSql = @SearchSql + ' ORDER BY ISNULL(o.dPaidTime,o.dAddTime) DESC'  
     END  
     ELSE  
     BEGIN  
      SET @SearchSql = @SearchSql + ' ORDER BY o.dAddTime DESC'  
     END  
    END  
   END  
  END  
  ELSE  
  BEGIN  
   SET @SearchSql = @SearchSql + ' ORDER BY o.dAddTime DESC'  
  END  
    END  
    ELSE  
    BEGIN  
  SET @SearchSql = @SearchSql + ' ORDER BY o.dAddTime DESC'  
    END  
    IF(@OrderTypeList = '' OR @OrderTypeList is NULL) --这里只是临时性的过渡兼容性代码 后期要去除 cpx 2014年10月11日  
    BEGIN      
  SET @SearchSql = @SearchSql + ')AS RowNum FROM YMT_Orders o WITH(NOLOCK) WHERE o.bShangouOrder = @IsShangouOrder AND o.iBuyerId = @SellerId'  
    END  
    ELSE   
    BEGIN                
  SET @NewOrderType = ',' + @OrderTypeList + ','  
  SET @SearchSql = @SearchSql + ') AS RowNum FROM YMT_Orders o WITH(NOLOCK) WHERE o.iBuyerId = @SellerId'  
  IF(CHARINDEX(',0,',@NewOrderType) > 0 AND CHARINDEX(',1,',@NewOrderType) > 0  AND LEN(@OrderTypeList) > 2 AND LEN(@OrderTypeList) < 5) --如果同时包含现货与扫货订单并排除包含全部类型的情况  
  BEGIN  
   SET @SearchSql = @SearchSql + ' AND EXISTS(SELECT 1 FROM Ymt_OrderInfo oi WITH(NOLOCK) WHERE oi.iOrderId=o.iOrderId AND oi.sCatalogId is NOT NULL)'  
  END  
  IF(CHARINDEX(',0,',@NewOrderType) > 0 AND CHARINDEX(',2,',@NewOrderType) > 0  AND LEN(@OrderTypeList) > 2 AND LEN(@OrderTypeList) < 5) --如果同时包含现货与下单器订单并排除包含全部类型的情况  
  BEGIN  
   SET @SearchSql = @SearchSql + ' AND o.bShangouOrder = 0'  
  END  
  IF(CHARINDEX(',1,',@NewOrderType) > 0 AND CHARINDEX(',2,',@NewOrderType) > 0  AND LEN(@OrderTypeList) > 2 AND LEN(@OrderTypeList) < 5) --如果同时包含扫货与下单器订单并排除包含全部类型的情况  
  BEGIN  
   SET @SearchSql = @SearchSql + ' AND (o.bShangouOrder = 1 OR (o.bShangouOrder = 0 AND EXISTS(SELECT 1 FROM Ymt_OrderInfo oi WITH(NOLOCK) WHERE oi.iOrderId=o.iOrderId AND oi.sCatalogId is NULL)))'  
  END    
  IF(CHARINDEX(',0,',@NewOrderType) > 0 AND LEN(@NewOrderType) = 3) --如果包含现货订单并确保单个类型  
  BEGIN  
   SET @SearchSql = @SearchSql + ' AND o.bShangouOrder = 0  AND EXISTS(SELECT 1 FROM Ymt_OrderInfo oi WITH(NOLOCK) WHERE oi.iOrderId=o.iOrderId AND oi.sCatalogId is NOT NULL)'  
  END  
  IF(CHARINDEX(',1,',@NewOrderType) > 0  AND LEN(@NewOrderType) = 3) --如果包含扫货订单并确保单个类型  
  BEGIN  
   SET @SearchSql = @SearchSql + ' AND o.bShangouOrder = 1'  
  END   
  IF(CHARINDEX(',2,',@NewOrderType) > 0  AND LEN(@NewOrderType) = 3) --如果包含下单器订单并确保单个类型  
  BEGIN  
   SET @SearchSql = @SearchSql + ' AND o.bShangouOrder = 0 AND EXISTS(SELECT 1 FROM Ymt_OrderInfo oi WITH(NOLOCK) WHERE oi.iOrderId=o.iOrderId AND oi.sCatalogId is NULL)'  
  END  
    END  
      
    IF @BeginTime IS NOT NULL AND @EndTime IS NOT NULL  
    BEGIN  
  IF @OrderDateType IS NOT NULL AND @OrderDateType <> ''  
  BEGIN  
   IF CHARINDEX(@OrderDateType,'1') > 0 --下单时间  
   BEGIN  
    SET @SearchSql = @SearchSql + ' AND o.dAddTime BETWEEN @BeginTime AND @EndTime'  
   END  
   IF CHARINDEX(@OrderDateType,'2') > 0 --支付时间  
   BEGIN  
    SET @SearchSql = @SearchSql + ' AND o.dPaidTime BETWEEN @BeginTime AND @EndTime'  
   END  
   IF CHARINDEX(@OrderDateType,'3') > 0 --发货时间  
   BEGIN  
    SET @SearchSql = @SearchSql + ' AND o.dDispathTime BETWEEN @BeginTime AND @EndTime'  
   END  
   IF CHARINDEX(@OrderDateType,'4') > 0 --申请补款时间  
   BEGIN  
    SET @SearchSql = @SearchSql + ' AND o.dApplyPostPayTime BETWEEN @BeginTime AND @EndTime'  
   END  
  END  
  ELSE  
  BEGIN  
   SET @SearchSql = @SearchSql + ' AND o.dAddTime BETWEEN @BeginTime AND @EndTime'  
  END  
    END  
      
    IF @OrderStatusList IS NOT NULL AND @OrderStatusList <> ''  
    BEGIN  
  SET @SearchSql = @SearchSql + ' AND o.iTradingStatus IN ('+@OrderStatusList+')'  
    END  
      
    IF @IsPaidInFull IS NOT NULL  
    BEGIN  
  SET @SearchSql = @SearchSql + ' AND o.bPaidInFull = @IsPaidInFull'  
    END
	
	IF @OverTimeList IS NOT NULL AND LEN(@OverTimeList) > 0
	BEGIN
		SET @SearchSql = @SearchSql + ' AND ('
	    SELECT * INTO #TempOverTime FROM dbo.Split(@OverTimeList,',')
		SELECT @OrderOverTimeCount = COUNT(1) FROM #TempOverTime
		IF EXISTS(SELECT 1 FROM #TempOverTime WHERE COL LIKE 'AccountPaid%')--等待接单超时
		BEGIN
			SELECT @OrderAcceptOverTimeCol = COL FROM #TempOverTime WHERE COL LIKE 'AccountPaid%'			
		END
		IF EXISTS(SELECT 1 FROM #TempOverTime WHERE COL LIKE 'OrderPostPay%')--等待发起补款
		BEGIN
			SELECT @OrderPostpayOverTimeCol = COL FROM #TempOverTime WHERE COL LIKE 'OrderPostPay%'			
		END
		IF EXISTS(SELECT 1 FROM #TempOverTime WHERE COL LIKE 'SellerAccept%')--等待发货超时
		BEGIN
			SELECT @OrderDispatchOverTimeCol = COL FROM #TempOverTime WHERE COL LIKE 'SellerAccept%'			
		END
		IF @OrderOverTimeCount = 1 --单个订单状态超时情况
		BEGIN
			IF @OrderAcceptOverTimeCol IS NOT NULL
			BEGIN
				IF CHARINDEX('*',@OrderAcceptOverTimeCol) > 0 --即将超时的情况 必须排除掉已超时的情况
				BEGIN
					SET @OrderAcceptOverTimeSoon = SUBSTRING(@OrderAcceptOverTimeCol,LEN('AccountPaid') + 1,CHARINDEX('*',@OrderAcceptOverTimeCol) - LEN('AccountPaid') - 1)
					SET @OrderAcceptOverTime = SUBSTRING(@OrderAcceptOverTimeCol,CHARINDEX('*',@OrderAcceptOverTimeCol) + 1,LEN(@OrderAcceptOverTimeCol) - CHARINDEX('*',@OrderAcceptOverTimeCol))					
					SET @SearchSql = @SearchSql + ' (DATEDIFF(N,o.dPaidTime,GETDATE()) >= CAST(' + @OrderAcceptOverTimeSoon + ' AS INT) AND DATEDIFF(N,o.dPaidTime,GETDATE()) < CAST(' + @OrderAcceptOverTime + ' AS INT) AND o.iTradingStatus = 2 )'
				END
				ELSE
				BEGIN
					SET @OrderAcceptOverTime = SUBSTRING(@OrderAcceptOverTimeCol,LEN('AccountPaid') + 1,LEN(@OrderAcceptOverTimeCol))
					SET @SearchSql = @SearchSql + ' (DATEDIFF(N,o.dPaidTime,GETDATE()) >= CAST(' + @OrderAcceptOverTime + ' AS INT) AND o.iTradingStatus = 2)'
				END			
			END
			IF @OrderPostpayOverTimeCol IS NOT NULL
			BEGIN
				IF CHARINDEX('*',@OrderPostpayOverTimeCol) > 0 --即将超时的情况 必须排除掉已超时的情况
				BEGIN
					SET @OrderPostpayOverTimeSoon = SUBSTRING(@OrderPostpayOverTimeCol,LEN('OrderPostPay') + 1,CHARINDEX('*',@OrderPostpayOverTimeCol) - LEN('OrderPostPay') - 1)
					SET @OrderPostpayOverTime = SUBSTRING(@OrderPostpayOverTimeCol,CHARINDEX('*',@OrderPostpayOverTimeCol) + 1,LEN(@OrderPostpayOverTimeCol) - CHARINDEX('*',@OrderPostpayOverTimeCol))
					SET @SearchSql = @SearchSql + ' (DATEDIFF(N,o.dAcceptTime,GETDATE()) >= CAST(' + @OrderPostpayOverTimeSoon + ' AS INT) AND DATEDIFF(N,ISNULL(o.dAcceptTime,ISNULL(o.dPaidTime,o.dAddTime)),GETDATE()) < CAST(' + @OrderPostpayOverTime + ' AS INT) AND o.iTradingStatus = 17 AND o.bPaidInFull = 0)'
				END
				ELSE
				BEGIN
					SET @OrderPostpayOverTime = SUBSTRING(@OrderPostpayOverTimeCol,LEN('OrderPostPay') + 1,LEN(@OrderPostpayOverTimeCol))
					SET @SearchSql = @SearchSql + ' (DATEDIFF(N,o.dAcceptTime,GETDATE()) >= CAST(' + @OrderPostpayOverTime + ' AS INT) AND o.iTradingStatus = 17 AND o.bPaidInFull = 0)'
				END						
			END
			IF @OrderDispatchOverTimeCol IS NOT NULL
			BEGIN
				IF CHARINDEX('*',@OrderDispatchOverTimeCol) > 0 --即将超时的情况 必须排除掉已超时的情况
				BEGIN
					SET @OrderDispatchOverTimeSoon = SUBSTRING(@OrderDispatchOverTimeCol,LEN('SellerAccept') + 1,CHARINDEX('*',@OrderDispatchOverTimeCol) - LEN('SellerAccept') - 1)
					SET @OrderDispatchOverTime = SUBSTRING(@OrderDispatchOverTimeCol,CHARINDEX('*',@OrderDispatchOverTimeCol) + 1,LEN(@OrderDispatchOverTimeCol)  - CHARINDEX('*',@OrderDispatchOverTimeCol))
					SET @SearchSql = @SearchSql + ' (DATEDIFF(N,ISNULL(o.dPostPaidTime,o.dPaidTime),GETDATE()) >= CAST(' + @OrderDispatchOverTimeSoon + ' AS INT) AND DATEDIFF(N,ISNULL(o.dPostPaidTime,o.dPaidTime),GETDATE()) < CAST(' + @OrderDispatchOverTime + ' AS INT)  AND o.iTradingStatus = 17 AND o.bPaidInFull = 1)'
				END
				ELSE
				BEGIN
					SET @OrderDispatchOverTime = SUBSTRING(@OrderDispatchOverTimeCol,LEN('SellerAccept') + 1,LEN(@OrderDispatchOverTimeCol))
					SET @SearchSql = @SearchSql + ' (DATEDIFF(N,ISNULL(o.dPostPaidTime,o.dPaidTime),GETDATE()) >= CAST(' + @OrderDispatchOverTime + ' AS INT) AND o.iTradingStatus = 17 AND o.bPaidInFull = 1)'
				END			
			END
		END													
		SET @SearchSql = @SearchSql + ' )'
		
		DROP TABLE #TempOverTime		
	END  
      
    IF @SearchKeyWord IS NOT NULL AND @SearchKeyWord <> ''  
    BEGIN  
  SET @SearchSql = @SearchSql + ' AND (o.iOrderId LIKE ''%'+@SearchKeyWord+'%'' OR sBuyerLoginId LIKE ''%'+@SearchKeyWord+'%''   
   OR EXISTS(SELECT 1 FROM Ymt_OrderInfo oi WITH(NOLOCK) WHERE oi.iOrderId=o.iOrderId AND oi.sTitle LIKE ''%'+@SearchKeyWord+'%''))'  
    END  
      
    IF @LogisticsTypeList IS NOT NULL AND @LogisticsTypeList <> ''  
    BEGIN  
  SET @SearchSql = @SearchSql + ' AND EXISTS(SELECT 1 FROM Ymt_OrderInfo oi WITH(NOLOCK) WHERE oi.iOrderId=o.iOrderId AND oi.iCatalogStatus IN ('+@LogisticsTypeList+'))'  
    END  
    INSERT INTO #AllOrderList  EXEC sp_executesql @SearchSql,N'@SellerId INT,@IsShangouOrder Bit,@BeginTime DATETIME,@EndTime DATETIME,@SearchKeyWord VARCHAR(200),@IsPaidInFull BIT'   
  ,@SellerId,@IsShangouOrder,@BeginTime,@EndTime,@SearchKeyWord,@IsPaidInFull  

 --获取订单列表  
 SELECT * INTO #SellerOrderList FROM #AllOrderList WHERE RowNum BETWEEN @PageStart AND @PageEnd  
 SELECT * FROM Ymt_Orders WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #SellerOrderList)  
 --获取评价列表  
 SELECT * FROM Ymt_CreditDetail WITH(NOLOCK) WHERE sTargetId IN (SELECT CAST(iOrderId AS VARCHAR(36)) FROM #SellerOrderList)  
 --获取备注列表  
 SELECT * FROM Ymt_O_OrderNote WITH(NOLOCK) WHERE iUserId = @SellerId AND iOrderId IN (SELECT iOrderId FROM #SellerOrderList)  
 --获取订单金额详情列表  
 SELECT * FROM Ymt_OrderState WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #SellerOrderList)  
 --获取订单补款列表  
 SELECT * FROM Ymt_OrderPostPay WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #SellerOrderList)  
 --获取订单商品详情列表  
 SELECT * FROM Ymt_OrderInfo WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #SellerOrderList)  
 --获取订单物流信息  
 SELECT * FROM Ymt_OrderSummary WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #SellerOrderList)  
 --获取订单冻结信息  
 SELECT * FROM Ymt_Order_Frozen WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #SellerOrderList)  
 --获取订单账单信息  
 SELECT * FROM Ymt_OrderToBill WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #SellerOrderList)  
 --获取订单账单信息  
 SELECT * FROM Ymt_Bill WITH(NOLOCK) WHERE sBillId IN (SELECT sBillId FROM Ymt_OrderToBill WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #SellerOrderList))  
 --获取订单总数量  
 SELECT @OrderCount = COUNT(1) FROM #AllOrderList  
   
 DROP TABLE #SellerOrderList  
 DROP TABLE #AllOrderList
  
    SET NOCOUNT OFF  
END  