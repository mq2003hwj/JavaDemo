



-- =============================================
-- Author:		adu
-- Create date: 2014-11-24
-- Description:	在码头或是贝海数据找到该人的身份证信息则同步身份证是否有的状态
-- =============================================
CREATE PROCEDURE [dbo].[sp_SyncIdCardStateByName]
	 @UserId int,
	 @Name varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @iUserId	INT
	DECLARE @iOrderId	INT
	DECLARE @sName		NVARCHAR(50)
	DECLARE @sPhone		VARCHAR(100)

DECLARE order_cursor CURSOR FOR 
	--找出所有对身份证有要求的订单，目前目前护航直邮和保税商品为需要上传身份证
	SELECT distinct o.iUserId, o.iOrderId, sReceivePerson, sPhone
	from ymt_orders o with(nolock) 
	inner join Ymt_OrderExt oe on oe.iOrderId=o.iOrderId
	Left Join Ymt_OrderIdCard oi with(nolock) on o.iOrderId = oi.iOrderId
	where 
	o.iUserId=@UserId and o.sReceivePerson=@Name
	and oe.bIsNeedUploadIdCard=1  
	and IsNull(oi.bIdCardUploaded, 0) = 0 And o.dAddTime > '2014-7-1'
	Order By o.iOrderId Desc

OPEN order_cursor;

FETCH NEXT FROM order_cursor
INTO @iUserId,@iOrderId,@sName,@sPhone;

WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT @iOrderId;

	--如果码头找到该人的身份证信息则同步身份证是否有的状态
	IF EXISTS (SELECT 1 FROM Ymt_IdPic WHERE iUserId = @iUserId And sName = @sName) BEGIN
	    --如果存在订单身份证匹配的记录那么更新这个值，否则插入新的记录
		IF EXISTS (SELECT 1 FROM Ymt_OrderIdCard WHERE iUserId = @iUserId And iOrderId = @iOrderId) BEGIN
			update Ymt_OrderIdCard set bIdCardUploaded=1 where iUserId = @iUserId And iOrderId = @iOrderId
		END 
		ELSE
		BEGIN
			INSERT INTO Ymt_OrderIdCard
						SELECT @iOrderId, @iUserId, 1
		END
	END 
	----如果贝海找到该人的身份证信息则同步身份证是否有的状态
	ELSE IF EXISTS (SELECT 1 FROM XloboRelease.[dbo].IdentityCard A WITH(NOLOCK) JOIN XloboRelease.[dbo].IdMatchPhone B WITH(NOLOCK) ON A.Id = B.iIdentityCardId WHERE B.sPhone = @sPhone And A.sName = @sName) BEGIN
		--如果存在订单身份证匹配的记录那么更新这个值，否则插入新的记录
		IF EXISTS (SELECT 1 FROM Ymt_OrderIdCard WHERE iUserId = @iUserId And iOrderId = @iOrderId) BEGIN
			update Ymt_OrderIdCard set bIdCardUploaded=1 where iUserId = @iUserId And iOrderId = @iOrderId
		END 
		ELSE
		BEGIN
			INSERT INTO Ymt_OrderIdCard
						SELECT @iOrderId, @iUserId, 1
		END
	END 

    FETCH NEXT FROM order_cursor 
    INTO @iUserId,@iOrderId,@sName,@sPhone;
END
CLOSE order_cursor;
DEALLOCATE order_cursor;
END




