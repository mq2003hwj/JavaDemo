CREATE VIEW dbo.ViewSellerOrderInfo
AS
SELECT     dbo.Ymt_OrderInfo.sOrderInfoId, dbo.Ymt_OrderInfo.iOrderId, dbo.Ymt_OrderInfo.sCatalogId, dbo.Ymt_OrderInfo.iAmount, dbo.Ymt_OrderInfo.sPropertyInfo, 
                      dbo.Ymt_OrderInfo.fOriginalPrice, dbo.Ymt_OrderInfo.fDiscount, dbo.Ymt_OrderInfo.fTotalPrice, dbo.Ymt_Catalogs.iUserId, dbo.Ymt_Catalogs.sUser, 
                      dbo.Ymt_Catalogs.sProductName, dbo.Ymt_Catalogs.sPicUrl
FROM         dbo.Ymt_Catalogs INNER JOIN
                      dbo.Ymt_OrderInfo ON dbo.Ymt_Catalogs.sCatalogId = dbo.Ymt_OrderInfo.sCatalogId INNER JOIN
                      dbo.Ymt_Orders ON dbo.Ymt_OrderInfo.iOrderId = dbo.Ymt_Orders.iOrderId
