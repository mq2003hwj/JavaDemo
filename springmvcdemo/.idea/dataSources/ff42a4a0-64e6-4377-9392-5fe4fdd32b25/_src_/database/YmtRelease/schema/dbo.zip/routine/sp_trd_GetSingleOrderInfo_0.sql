-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-9-16
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetSingleOrderInfo_0]

@userId int,
@orderId int

AS

--------------process--------------
select * from [YmtRelease].[dbo].[Ymt_Orders](nolock) where iOrderId = @orderId and (iUserId = @userId or iBuyerId = @userId)

if(@@ROWCOUNT = 0)
return;

--print 'ymt_orderext';
select iOrderId,iOrderType,sOrderSource from [YmtRelease].[dbo].Ymt_OrderExt(nolock) where iOrderId = @orderId 

--print 'ymt_creditdetail'   
--获取评价列表  
select * from [YmtRelease].[dbo].Ymt_CreditDetail(nolock) where stargetid = cast(@orderId as varchar(36))  

--print 'ymt_o_ordernote'
--获取备注列表  
select iOrderId,sContent from [YmtRelease].[dbo].Ymt_O_OrderNote(nolock) where iuserid = @userId and iorderid = @orderId 

--print 'ymt_orderstate'
--获取订单金额详情列表  ymt_orderinfo
select * from [YmtRelease].[dbo].Ymt_OrderState(nolock) where iorderid = @orderId 

--print 'ymt_orderpostpay'
--获取订单补款列表  
select iOrderId,fAmount,fUseGiftAmount from [YmtRelease].[dbo].Ymt_OrderPostPay(nolock) where iorderid = @orderId 

--获取订单商品详情列表
--print 'ymt_orderinfo'
select
i.iOrderId,i.sOrderInfoId,i.fOriginalPrice,i.iAmount,i.iBondedArea,i.iCatalogStatus,i.iCatalogType,i.iProductSubCategoryId,i.iSailProtected,i.iType,i.sCatalogId,i.sDescription,i.sPictureUrl,i.sProductId,i.sPropertyInfo,i.sReferenceUrl,i.sSKU,i.sTitle,i.iPriceType,
e.sOrderInfoId as sOrderInfoExtId,e.bGiftAvail4Reward,e.iActivityId,e.iActivityTemplateId
from [YmtRelease].[dbo].Ymt_OrderInfo i(nolock) 
left join [YmtRelease].[dbo].Ymt_OrderInfoExt(nolock) e
on i.sOrderInfoId = e.sOrderInfoId
where i.iOrderId = @orderId 

--print 'ymt_ordersummary'
--获取订单物流信息  
select iOrderId, iBillType, sSummary from [YmtRelease].[dbo].Ymt_OrderSummary(nolock) where iorderid = @orderId 

--print 'ymt_order_frozen'
--获取订单冻结信息  
select * from [YmtRelease].[dbo].Ymt_Order_Frozen(nolock) where  iorderid = @orderId 

if(EXISTS(select top 1 item.iOrderId, item.iTradingId from Ymt_TradingItem(nolock) item join Ymt_TradingInfo(nolock) info on item.iTradingId = info.iTradingId where iorderid = @orderId and info.iTradingStatus = 2))
  begin
    select top 1 item.iOrderId, item.iTradingId
    from Ymt_TradingItem(nolock) item
    join Ymt_TradingInfo(nolock) info
    on   item.iTradingId = info.iTradingId   
    where  iorderid = @orderId 
    and    info.iTradingStatus = 2
  end
else
  begin
    select top 1 iOrderId, iTradingId
    from Ymt_TradingItem(nolock) 
    where  iorderid = @orderId 
    order by dUpdateTime desc
  end

declare @orderToBills table(iOrderId int not null, sBillId varchar(36) not null)

--print 'ymt_ordertobill'
--获取订单账单信息
insert into @orderToBills select iOrderid, sBillId from [YmtRelease].[dbo].Ymt_OrderToBill(nolock) where iorderid = @orderId  and iaction >= 0
select iOrderid, sBillId from @orderToBills 

--print 'ymt_bill'
--获取订单账单信息  
select * from [YmtRelease].[dbo].Ymt_Bill(nolock) where sbillid in (select sBillId from @orderToBills) and iaction >= 0