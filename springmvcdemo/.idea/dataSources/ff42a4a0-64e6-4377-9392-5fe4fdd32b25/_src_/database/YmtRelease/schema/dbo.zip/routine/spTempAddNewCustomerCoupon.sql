
CREATE PROCEDURE [dbo].[spTempAddNewCustomerCoupon]
	@sCode Varchar(20),
	@fBaseAmount decimal(18,2),
	@fAmount	decimal(18,2)
as
begin
	if not exists (Select 1 From Ymt_Coupon with(nolock) where sCouponCode = @sCode)
	begin
		declare @iScenarioid int
		declare @iSettingid int
		declare @iBatchId int

		-- user type = 1：新人优惠券
		insert into Ymt_CouponScenario (iUserType) values (1)

		set @iScenarioid = @@IDENTITY

		insert into Ymt_CouponSetting (iScenarioId, iCouponUseType, iMaxUseTime, iMaxUseTimePerUser, dValidStart, dValidEnd) values
		(@iScenarioid, 1, 1, 1, '2014-10-22 0:0:0', '2014-11-1 0:0:0')

		set @iSettingid = @@IDENTITY

		insert into Ymt_CouponBatch (sBatchCode, iCouponTotalNum, iCouponNumPerUser, iOperatorId, iCouponSettingId, dExpiredDate, iSendType, dAddTime, iUsage)
		Values
		(newid(), 1, 1, 1, @iSettingid, '2014-11-1', 1, getdate(), 1)
	
		set @iBatchId = @@IDENTITY

		insert into Ymt_CouponValue (fMinOrderValue, fCouponValue, iCouponSettingId) values
		(@fBaseAmount, @fAmount, @iSettingid)

		insert into Ymt_Coupon (sCouponId, sCouponCode, iCouponType, dValidStart, dValidEnd, iCouponSetting, iBatchId, iUsage) values
		(newid(), @sCode, 1, '2014-10-22 0:0:0', '2014-11-1 0:0:0', @iSettingid, @iBatchId, 1)
	end
	else
	begin
		print @sCode
	end
	--select top 5 * from Ymt_CouponScenario order by iCouponScenarioId desc
	--select top 5 * from Ymt_CouponSetting order by iCouponSettingId desc
	--select top 5 * from Ymt_CouponBatch order by iBatchId desc
end