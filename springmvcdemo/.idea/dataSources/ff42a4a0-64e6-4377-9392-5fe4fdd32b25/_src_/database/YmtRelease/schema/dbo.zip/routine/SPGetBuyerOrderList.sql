-- =============================================          
-- Author:  zhangzhiqiang          
-- Create date: 2014-8-13       
-- Description: 获取买家订单列表          
-- =============================================    
CREATE PROCEDURE [dbo].[spGetBuyerOrderList]
	@BuyerId INT, 
	@OrderStatusList VARCHAR(100) = NULL,
	@PageStart INT,
	@PageEnd INT,
	@AllOrderCount INT OUTPUT
AS  
BEGIN
    SET NOCOUNT ON
    SET LOCK_TIMEOUT 3000
    DECLARE @SearchSql NVARCHAR(1000)
			,@NewOrderStatus VARCHAR(100)
	
	CREATE TABLE #AllOrderList (iOrderId INT,RowNum INT)
	
	SET @SearchSql = 'SELECT iOrderId,ROW_NUMBER() OVER(ORDER BY dAddTime DESC) AS RowNum FROM YMT_Orders WITH(NOLOCK) WHERE iUserId = @BuyerId'
	IF @OrderStatusList IS NOT NULL AND @OrderStatusList <> ''
	BEGIN
		SET @SearchSql = @SearchSql + ' AND iTradingStatus IN ('+@OrderStatusList+')'
	END
	
	INSERT INTO #AllOrderList EXEC sp_executesql @SearchSql,N'@BuyerId INT' ,@BuyerId
	
	--获取订单列表
	SELECT iOrderId INTO #BuyerOrderList FROM #AllOrderList WHERE RowNum BETWEEN @PageStart AND @PageEnd
	
	SELECT * FROM Ymt_Orders WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #BuyerOrderList)
	
	--获取评价列表
	SELECT * FROM Ymt_CreditDetail WITH(NOLOCK) WHERE sTargetId IN (SELECT iOrderId FROM #BuyerOrderList)
	--获取备注列表
	SELECT * FROM Ymt_O_OrderNote WITH(NOLOCK) WHERE iUserId = @BuyerId AND iOrderId IN (SELECT iOrderId FROM #BuyerOrderList)
	--获取订单金额详情列表
	SELECT * FROM Ymt_OrderState WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #BuyerOrderList)
	--获取订单补款列表
	SELECT * FROM Ymt_OrderPostPay WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #BuyerOrderList)
	--获取订单商品详情列表
	SELECT * FROM Ymt_OrderInfo WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #BuyerOrderList)
	--获取订单物流信息
	SELECT * FROM Ymt_OrderSummary WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #BuyerOrderList)
	--获取订单冻结信息
	SELECT * FROM Ymt_Order_Frozen WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #BuyerOrderList)
	--获取订单账单信息
	SELECT * FROM Ymt_OrderToBill WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #BuyerOrderList)
	--获取订单账单信息
	SELECT * FROM Ymt_Bill WITH(NOLOCK) WHERE sBillId IN (SELECT sBillId FROM Ymt_OrderToBill WITH(NOLOCK) WHERE iOrderId IN (SELECT iOrderId FROM #BuyerOrderList))
	--获取订单总数量
	SELECT @AllOrderCount = COUNT(1) FROM #AllOrderList
	
	DROP TABLE #BuyerOrderList
	DROP TABLE #AllOrderList
    SET NOCOUNT OFF
END
