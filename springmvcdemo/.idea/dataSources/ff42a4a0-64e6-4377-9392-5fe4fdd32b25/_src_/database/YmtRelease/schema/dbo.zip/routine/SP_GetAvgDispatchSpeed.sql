CREATE proc [dbo].[SP_GetAvgDispatchSpeed](@beginTime datetime,@endTime datetime)
as
begin

	if OBJECT_ID(N'tempdb..#tempSellerInfo',N'U') is not null
	begin
	   print 'drop table #tempSellerInfo'
	   drop table #tempSellerInfo
	end

	--创建临时表,保存SellerInfo中间结果
	create table #tempSellerInfo
	(
	  iUserId int NOT NULL,
	  sGoodsAverageDispatchSpeed decimal NULL,
	  sShoppingAverageDispatchSpeed decimal NULL
	)

	--保存24小时内有订单的买家ID
	insert into #tempSellerInfo(iUserId,sGoodsAverageDispatchSpeed,sShoppingAverageDispatchSpeed) select distinct iBuyerId as iUserId,0 as sGoodsAverageDispatchSpeed,0 as sShoppingAverageDispatchSpeed from Ymt_Orders orders where orders.dDispathTime>= @beginTime and orders.dDispathTime<=@endTime 

	--更新对应sellerID的sGoodsAverageDispatchSpeed
	update #tempSellerInfo set [sGoodsAverageDispatchSpeed]= a.sGoodsAverageDispatchSpeed from #tempSellerInfo inner join
	(select Ymt_Orders.iBuyerId,round(avg(DateDiff(HOUR,Ymt_Orders.dAddTime,Ymt_Orders.dDispathTime)),2) as sGoodsAverageDispatchSpeed  
	from Ymt_Orders where Ymt_Orders.iBuyerId in (select [iUserId] from #tempSellerInfo) and Ymt_Orders.iTradingStatus=4 and Ymt_Orders.dDispathTime is not null and Exists
	(select 1 from Ymt_OrderInfo where Ymt_OrderInfo.iOrderId=Ymt_Orders.iOrderId and  Ymt_OrderInfo.sCatalogId is not null and Ymt_OrderInfo.sCatalogId!='' and Ymt_OrderInfo.iCatalogType !=1)
	group by Ymt_Orders.iBuyerId having count(1)>=5
	) as a on #tempSellerInfo.iUserId=a.iBuyerId  
	
	--更新对应sellerID的sShoppingAverageDispatchSpeed

	update #tempSellerInfo set [sGoodsAverageDispatchSpeed]= c.ShoppingAverageDispatchSpeed from #tempSellerInfo
	inner join
	(select iBuyerId,round(avg(DateDiff(HOUR,dAddTime,dDispathTime)),2) as ShoppingAverageDispatchSpeed from
	(select Ymt_Orders.* from Ymt_Orders
	where Ymt_Orders.iTradingStatus=4
	and Ymt_Orders.dDispathTime is not null
	and Exists(select 1 from Ymt_OrderInfo where Ymt_OrderInfo.iOrderId=Ymt_Orders.iOrderId and (Ymt_OrderInfo.sCatalogId is null or Ymt_OrderInfo.sCatalogId=''))
	union 
	select Ymt_Orders.* from Ymt_Orders inner join Ymt_OrderInfo on Ymt_Orders.iOrderId=Ymt_OrderInfo.iOrderId 
	where Ymt_Orders.iTradingStatus=4
	and Ymt_Orders.dDispathTime is not null
	and Exists(select 1 from Ymt_OrderInfo where Ymt_OrderInfo.iOrderId=Ymt_Orders.iOrderId and Ymt_Orders.dDispathTime is not null and Ymt_OrderInfo.iCatalogType =1)) as b 
	where b.iBuyerId in (select [iUserId] from #tempSellerInfo)
	group by b.iBuyerId having count(1)>=5) as c on #tempSellerInfo.iUserId=c.iBuyerId

	--显示所有
	select * from #tempSellerInfo

	drop table #tempSellerInfo
end