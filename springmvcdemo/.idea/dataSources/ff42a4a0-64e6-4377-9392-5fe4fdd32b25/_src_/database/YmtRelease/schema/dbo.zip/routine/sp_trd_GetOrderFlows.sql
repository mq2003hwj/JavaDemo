-- =============================================            
-- Author:  fanwei        
-- Create date: 2015-12-15
-- Description: 交易服务SP       
-- =============================================
CREATE PROCEDURE [dbo].[sp_trd_GetOrderFlows]
@orderId int
AS

declare @shangou bit
declare @status int
declare @refund int

select @shangou = bshangouorder, @status = iTradingStatus, @refund = iSalesRefundStatus from ymt_orders(nolock) where iorderid = @orderId


select @orderId as OrderId, @shangou as Shangou where @status is not null
if @status is null
	return;

declare @t table(
[Time] datetime
,Cash decimal(18,2),Gift decimal(18,2),FreeCard decimal(18,2)
,Coupon decimal(18,2)
,CouponChannel decimal(18,2),CouponCode varchar(50)
,Total decimal(18,2)
,OccurredPrice decimal(18,2)
,PriceChange decimal(18,2),Freight decimal(18,2)
,Evidence varchar(50),IsIncoming bit,Operation int)


if @shangou = 1 begin
	if @status in (2,3,4,16,17) begin
		insert into @t
		select top 1
		o.dPaidTime
		,s.fPaidAmountOfCash,fPaidAmountOfGift,fPaidAmountOfFreeCard
		,case when s.fPaidAmountOfCoupon > 0
		 then (
		    case o.iCouponChannel when 2 then -s.fPaidAmountOfCoupon else s.fPaidAmountOfCoupon end
		 )
		 else 0 end
		,o.iCouponChannel,o.sCouponCode
		,s.fPaidAmountOfCash+fPaidAmountOfGift+fPaidAmountOfFreeCard+(
			case when s.fPaidAmountOfCoupon > 0
			then (
				case o.iCouponChannel when 2 then 0 else s.fPaidAmountOfCoupon end
			)
			else 0 end
		)
		,o.fOrderPrice
		,0,o.fFreight
		,null,1,1
		from Ymt_OrderState(nolock) s join Ymt_Orders(nolock) o
		on s.iorderid = o.iorderid
		where s.iorderid = @orderId
	end
	
	if @status in (3,4,17) begin
		insert into @t
		select top 1
		o.dPostPaidTime
		,s.fPostPaidAmountOfCash,fPostPaidAmountOfGift,0
		,0,0,null
		,s.fPostPaidAmountOfCash+fPostPaidAmountOfGift
		,s.fPostPaidAmountOfCash+fPostPaidAmountOfGift
		,s.fPostPaidAmountOfCash+fPostPaidAmountOfGift-(o.fTotalPrice-o.fOrderPrice),0
		,null,1,2
		from Ymt_OrderState(nolock) s join Ymt_Orders(nolock) o
		on s.iorderid = o.iorderid
		where s.iorderid = @orderId and o.bPaidInFull = 1 and s.fPostPaidAmountOfCash > 0
	end
	
	if @refund = 10 begin
		insert into @t
		select top 1
		AddTime
		,-RefundedAmountOfCash,-RefundedAmountOfGift,0
		,0,0,null
		,-RefundAmount
		,-RefundAmount
		,0,0
		,RefundBillNo,0,3
		from Ymt_RefundBill(nolock)
		where orderid = @orderId and RefundStatus = 1
	end


end else begin

	if @status in (2,3,4,16,17) begin
		insert into @t
		select top 1
		o.dPaidTime
		,s.fPaidAmountOfCash,fPaidAmountOfGift,fPaidAmountOfFreeCard
		,case when s.fPaidAmountOfCoupon > 0
			then (
				case o.iCouponChannel when 2 then -s.fPaidAmountOfCoupon else s.fPaidAmountOfCoupon end
			)
		else 0 end,o.iCouponChannel,o.sCouponCode
		,s.fPaidAmountOfCash+fPaidAmountOfGift+fPaidAmountOfFreeCard+(
			case when s.fPaidAmountOfCoupon > 0
			then (
				case o.iCouponChannel when 2 then 0 else s.fPaidAmountOfCoupon end
			)
			else 0 end
		)
		,o.fOrderPrice
		,o.fOrderDiscount,o.fFreight
		,null,1,1
		from Ymt_OrderState(nolock) s join Ymt_Orders(nolock) o
		on s.iorderid = o.iorderid
		where s.iorderid = @orderId
	end
	
	if @refund = 10 begin
		insert into @t
		select top 1
		AddTime
		,-RefundedAmountOfCash,-RefundedAmountOfGift,0
		,0,0,null
		,-RefundAmount
		,-RefundAmount
		,0,0
		,RefundBillNo,0,3
		from Ymt_RefundBill(nolock)
		where orderid = @orderId and RefundStatus = 1
	end

end
select * from @t